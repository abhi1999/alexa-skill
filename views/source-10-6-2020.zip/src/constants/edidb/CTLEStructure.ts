import { ITLEStructure } from '../edidb'
export class CTLEStructure implements ITLEStructure {
    public CDID:string = '';
    public Position:number = 0;
    public DGID:string = '';
    public Direction:string = '';
    public STRID:number = 0;
    public constructor(init?:Partial<CTLEStructure>) { Object.assign(this, init); }
}
export const ITLEStructure_CDID_length = 5;
export const ITLEStructure_DGID_length = 5;
export const ITLEStructure_Direction_length = 1;

export const kTLEStructure_CDID="CDID";
export const kTLEStructure_Position="Position";
export const kTLEStructure_DGID="DGID";
export const kTLEStructure_Direction="Direction";
export const kTLEStructure_STRID="STRID";

/*
        'TLEStructure' : {
            'CDID' : 'CDID',
            'Position' : 'Position',
            'DGID' : 'DGID',
            'Direction' : 'Direction',
            'STRID' : 'STRID',        },
*/

export const Label_CDID = 'TLEStructure.CDID';
export const Label_Position = 'TLEStructure.Position';
export const Label_DGID = 'TLEStructure.DGID';
export const Label_Direction = 'TLEStructure.Direction';
export const Label_STRID = 'TLEStructure.STRID';
