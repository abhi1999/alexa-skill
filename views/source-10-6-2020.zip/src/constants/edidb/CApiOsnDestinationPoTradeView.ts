import { IApiOsnDestinationPoTradeView } from '../edidb'
export class CApiOsnDestinationPoTradeView implements IApiOsnDestinationPoTradeView {
    public ID:string = '';
    public Name:string = '';
    public Address1:string = '';
    public Address2:string = '';
    public City:string = '';
    public State:string = '';
    public Zip:string = '';
    public Country:string = '';
    public Source:string = '';
    public BEG_03:string = '';
    public constructor(init?:Partial<CApiOsnDestinationPoTradeView>) { Object.assign(this, init); }
}
export const IApiOsnDestinationPoTradeView_ID_length = 80;
export const IApiOsnDestinationPoTradeView_Name_length = 60;
export const IApiOsnDestinationPoTradeView_Address1_length = 60;
export const IApiOsnDestinationPoTradeView_Address2_length = 60;
export const IApiOsnDestinationPoTradeView_City_length = 35;
export const IApiOsnDestinationPoTradeView_State_length = 2;
export const IApiOsnDestinationPoTradeView_Zip_length = 15;
export const IApiOsnDestinationPoTradeView_Country_length = 30;
export const IApiOsnDestinationPoTradeView_Source_length = 18;
export const IApiOsnDestinationPoTradeView_BEG_03_length = 22;

export const kApiOsnDestinationPoTradeView_ID="ID";
export const kApiOsnDestinationPoTradeView_Name="Name";
export const kApiOsnDestinationPoTradeView_Address1="Address1";
export const kApiOsnDestinationPoTradeView_Address2="Address2";
export const kApiOsnDestinationPoTradeView_City="City";
export const kApiOsnDestinationPoTradeView_State="State";
export const kApiOsnDestinationPoTradeView_Zip="Zip";
export const kApiOsnDestinationPoTradeView_Country="Country";
export const kApiOsnDestinationPoTradeView_Source="Source";
export const kApiOsnDestinationPoTradeView_BEG_03="BEG_03";

/*
        'ApiOsnDestinationPoTradeView' : {
            'ID' : 'ID',
            'Name' : 'Name',
            'Address1' : 'Address1',
            'Address2' : 'Address2',
            'City' : 'City',
            'State' : 'State',
            'Zip' : 'Zip',
            'Country' : 'Country',
            'Source' : 'Source',
            'BEG_03' : 'BEG_03',        },
*/

export const Label_ID = 'ApiOsnDestinationPoTradeView.ID';
export const Label_Name = 'ApiOsnDestinationPoTradeView.Name';
export const Label_Address1 = 'ApiOsnDestinationPoTradeView.Address1';
export const Label_Address2 = 'ApiOsnDestinationPoTradeView.Address2';
export const Label_City = 'ApiOsnDestinationPoTradeView.City';
export const Label_State = 'ApiOsnDestinationPoTradeView.State';
export const Label_Zip = 'ApiOsnDestinationPoTradeView.Zip';
export const Label_Country = 'ApiOsnDestinationPoTradeView.Country';
export const Label_Source = 'ApiOsnDestinationPoTradeView.Source';
export const Label_BEG_03 = 'ApiOsnDestinationPoTradeView.BEG_03';
