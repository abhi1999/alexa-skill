import { IC303v810hBaseView } from '../edidb'
export class CC303v810hBaseView implements IC303v810hBaseView {
    public ORD_ID:number = 0;
    public TP_PartID:string = '';
    public TP_Name:string = '';
    public BIG_02:string = '';
    public BIG_04:string = '';
    public Exp_Flag:string = '';
    public status:string = '';
    public ImportDate:Date;
    public ExportDate:Date;
    public GCN:number = 0;
    public TCN:number = 0;
    public AckDesc:string = '';
    public Acct_CusNo:string = '';
    public constructor(init?:Partial<CC303v810hBaseView>) { Object.assign(this, init); }
}
export const IC303v810hBaseView_TP_PartID_length = 30;
export const IC303v810hBaseView_TP_Name_length = 30;
export const IC303v810hBaseView_BIG_02_length = 22;
export const IC303v810hBaseView_BIG_04_length = 22;
export const IC303v810hBaseView_Exp_Flag_length = 1;
export const IC303v810hBaseView_status_length = 500;
export const IC303v810hBaseView_AckDesc_length = 10;
export const IC303v810hBaseView_Acct_CusNo_length = 50;

export const kC303v810hBaseView_ORD_ID="ORD_ID";
export const kC303v810hBaseView_TP_PartID="TP_PartID";
export const kC303v810hBaseView_TP_Name="TP_Name";
export const kC303v810hBaseView_BIG_02="BIG_02";
export const kC303v810hBaseView_BIG_04="BIG_04";
export const kC303v810hBaseView_Exp_Flag="Exp_Flag";
export const kC303v810hBaseView_status="status";
export const kC303v810hBaseView_ImportDate="ImportDate";
export const kC303v810hBaseView_ExportDate="ExportDate";
export const kC303v810hBaseView_GCN="GCN";
export const kC303v810hBaseView_TCN="TCN";
export const kC303v810hBaseView_AckDesc="AckDesc";
export const kC303v810hBaseView_Acct_CusNo="Acct_CusNo";

/*
        'C303v810hBaseView' : {
            'ORD_ID' : 'ORD_ID',
            'TP_PartID' : 'TP_PartID',
            'TP_Name' : 'TP_Name',
            'BIG_02' : 'BIG_02',
            'BIG_04' : 'BIG_04',
            'Exp_Flag' : 'Exp_Flag',
            'status' : 'status',
            'ImportDate' : 'ImportDate',
            'ExportDate' : 'ExportDate',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'AckDesc' : 'AckDesc',
            'Acct_CusNo' : 'Acct_CusNo',        },
*/

export const Label_ORD_ID = 'C303v810hBaseView.ORD_ID';
export const Label_TP_PartID = 'C303v810hBaseView.TP_PartID';
export const Label_TP_Name = 'C303v810hBaseView.TP_Name';
export const Label_BIG_02 = 'C303v810hBaseView.BIG_02';
export const Label_BIG_04 = 'C303v810hBaseView.BIG_04';
export const Label_Exp_Flag = 'C303v810hBaseView.Exp_Flag';
export const Label_status = 'C303v810hBaseView.status';
export const Label_ImportDate = 'C303v810hBaseView.ImportDate';
export const Label_ExportDate = 'C303v810hBaseView.ExportDate';
export const Label_GCN = 'C303v810hBaseView.GCN';
export const Label_TCN = 'C303v810hBaseView.TCN';
export const Label_AckDesc = 'C303v810hBaseView.AckDesc';
export const Label_Acct_CusNo = 'C303v810hBaseView.Acct_CusNo';
