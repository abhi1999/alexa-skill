import { IDelimiter } from '../edidb'
export class CDelimiter implements IDelimiter {
    public DLID:string = '';
    public TP_PartID:string = '';
    public DGID:string = '';
    public TransID:string = '';
    public ElemSep:number = 0;
    public SubElemSep:number = 0;
    public SegTerm:number = 0;
    public RepSep:number = 0;
    public constructor(init?:Partial<CDelimiter>) { Object.assign(this, init); }
}
export const IDelimiter_TP_PartID_length = 30;
export const IDelimiter_DGID_length = 5;
export const IDelimiter_TransID_length = 50;

export const kDelimiter_DLID="DLID";
export const kDelimiter_TP_PartID="TP_PartID";
export const kDelimiter_DGID="DGID";
export const kDelimiter_TransID="TransID";
export const kDelimiter_ElemSep="ElemSep";
export const kDelimiter_SubElemSep="SubElemSep";
export const kDelimiter_SegTerm="SegTerm";
export const kDelimiter_RepSep="RepSep";

/*
        'Delimiter' : {
            'DLID' : 'DLID',
            'TP_PartID' : 'TP_PartID',
            'DGID' : 'DGID',
            'TransID' : 'TransID',
            'ElemSep' : 'ElemSep',
            'SubElemSep' : 'SubElemSep',
            'SegTerm' : 'SegTerm',
            'RepSep' : 'RepSep',        },
*/

export const Label_DLID = 'Delimiter.DLID';
export const Label_TP_PartID = 'Delimiter.TP_PartID';
export const Label_DGID = 'Delimiter.DGID';
export const Label_TransID = 'Delimiter.TransID';
export const Label_ElemSep = 'Delimiter.ElemSep';
export const Label_SubElemSep = 'Delimiter.SubElemSep';
export const Label_SegTerm = 'Delimiter.SegTerm';
export const Label_RepSep = 'Delimiter.RepSep';
