import { IInboundALL } from '../edidb'
export class CInboundALL implements IInboundALL {
    public TP_PartID:string = '';
    public Cust_PO:string = '';
    public ReleaseNo:string = '';
    public PO_Date:string = '';
    public CTT_01:string = '';
    public Exp_Flag:string = '';
    public PO_ID:number = 0;
    public Cust_Ship_To:string = '';
    public PO1_LineNo:string = '';
    public Item_Qual:string = '';
    public Item_No:string = '';
    public Item_Qty:string = '';
    public Item_Price:string = '';
    public Item_UM:string = '';
    public SAC_Flag:boolean;
    public ID:number = 0;
    public vp_LineNo:string = '';
    public docline:number = 0;
    public etline_no:number = 0;
    public sch_ship_date:string = '';
    public Out850PID:string = '';
    public constructor(init?:Partial<CInboundALL>) { Object.assign(this, init); }
}
export const IInboundALL_TP_PartID_length = 30;
export const IInboundALL_Cust_PO_length = 22;
export const IInboundALL_ReleaseNo_length = 30;
export const IInboundALL_PO_Date_length = 8;
export const IInboundALL_CTT_01_length = 7;
export const IInboundALL_Exp_Flag_length = 1;
export const IInboundALL_Cust_Ship_To_length = 80;
export const IInboundALL_PO1_LineNo_length = 20;
export const IInboundALL_Item_Qual_length = 3;
export const IInboundALL_Item_No_length = 500;
export const IInboundALL_Item_Qty_length = 16;
export const IInboundALL_Item_Price_length = 17;
export const IInboundALL_Item_UM_length = 10;
export const IInboundALL_vp_LineNo_length = 11;
export const IInboundALL_sch_ship_date_length = 8;

export const kInboundALL_TP_PartID="TP_PartID";
export const kInboundALL_Cust_PO="Cust_PO";
export const kInboundALL_ReleaseNo="ReleaseNo";
export const kInboundALL_PO_Date="PO_Date";
export const kInboundALL_CTT_01="CTT_01";
export const kInboundALL_Exp_Flag="Exp_Flag";
export const kInboundALL_PO_ID="PO_ID";
export const kInboundALL_Cust_Ship_To="Cust_Ship_To";
export const kInboundALL_PO1_LineNo="PO1_LineNo";
export const kInboundALL_Item_Qual="Item_Qual";
export const kInboundALL_Item_No="Item_No";
export const kInboundALL_Item_Qty="Item_Qty";
export const kInboundALL_Item_Price="Item_Price";
export const kInboundALL_Item_UM="Item_UM";
export const kInboundALL_SAC_Flag="SAC_Flag";
export const kInboundALL_ID="ID";
export const kInboundALL_vp_LineNo="vp_LineNo";
export const kInboundALL_docline="docline";
export const kInboundALL_etline_no="etline_no";
export const kInboundALL_sch_ship_date="sch_ship_date";
export const kInboundALL_Out850PID="Out850PID";

/*
        'InboundALL' : {
            'TP_PartID' : 'TP_PartID',
            'Cust_PO' : 'Cust_PO',
            'ReleaseNo' : 'ReleaseNo',
            'PO_Date' : 'PO_Date',
            'CTT_01' : 'CTT_01',
            'Exp_Flag' : 'Exp_Flag',
            'PO_ID' : 'PO_ID',
            'Cust_Ship_To' : 'Cust_Ship_To',
            'PO1_LineNo' : 'PO1_LineNo',
            'Item_Qual' : 'Item_Qual',
            'Item_No' : 'Item_No',
            'Item_Qty' : 'Item_Qty',
            'Item_Price' : 'Item_Price',
            'Item_UM' : 'Item_UM',
            'SAC_Flag' : 'SAC_Flag',
            'ID' : 'ID',
            'vp_LineNo' : 'vp_LineNo',
            'docline' : 'docline',
            'etline_no' : 'etline_no',
            'sch_ship_date' : 'sch_ship_date',
            'Out850PID' : 'Out850PID',
        },
*/

export const Label_TP_PartID = 'InboundALL.TP_PartID';
export const Label_Cust_PO = 'InboundALL.Cust_PO';
export const Label_ReleaseNo = 'InboundALL.ReleaseNo';
export const Label_PO_Date = 'InboundALL.PO_Date';
export const Label_CTT_01 = 'InboundALL.CTT_01';
export const Label_Exp_Flag = 'InboundALL.Exp_Flag';
export const Label_PO_ID = 'InboundALL.PO_ID';
export const Label_Cust_Ship_To = 'InboundALL.Cust_Ship_To';
export const Label_PO1_LineNo = 'InboundALL.PO1_LineNo';
export const Label_Item_Qual = 'InboundALL.Item_Qual';
export const Label_Item_No = 'InboundALL.Item_No';
export const Label_Item_Qty = 'InboundALL.Item_Qty';
export const Label_Item_Price = 'InboundALL.Item_Price';
export const Label_Item_UM = 'InboundALL.Item_UM';
export const Label_SAC_Flag = 'InboundALL.SAC_Flag';
export const Label_ID = 'InboundALL.ID';
export const Label_vp_LineNo = 'InboundALL.vp_LineNo';
export const Label_docline = 'InboundALL.docline';
export const Label_etline_no = 'InboundALL.etline_no';
export const Label_sch_ship_date = 'InboundALL.sch_ship_date';
export const Label_Out850PID = 'InboundALL.Out850PID';
