import { IFa } from '../edidb'
export class CFa implements IFa {
    public FA_ID:number = 0;
    public Direction:string = '';
    public ISA01:string = '';
    public ISA02:string = '';
    public ISA03:string = '';
    public ISA04:string = '';
    public ISA05:string = '';
    public ISA06:string = '';
    public ISA07:string = '';
    public ISA08:string = '';
    public ISA09:string = '';
    public ISA10:string = '';
    public ISA11:string = '';
    public ISA12:string = '';
    public ISA13:string = '';
    public ISA14:string = '';
    public ISA15:string = '';
    public ISA16:string = '';
    public GS01:string = '';
    public GS02:string = '';
    public GS03:string = '';
    public GS04:string = '';
    public GS05:string = '';
    public GS06:string = '';
    public GS07:string = '';
    public GS08:string = '';
    public ST01:string = '';
    public ST02:string = '';
    public AK101:string = '';
    public AK102:string = '';
    public AK901:string = '';
    public AK902:string = '';
    public AK903:string = '';
    public AK904:string = '';
    public SE01:string = '';
    public SE02:string = '';
    public GE01:string = '';
    public GE02:string = '';
    public IEA01:string = '';
    public IEA02:string = '';
    public Exp_Flag:string = '';
    public constructor(init?:Partial<CFa>) { Object.assign(this, init); }
}
export const IFa_Direction_length = 1;
export const IFa_ISA01_length = 2;
export const IFa_ISA02_length = 10;
export const IFa_ISA03_length = 2;
export const IFa_ISA04_length = 10;
export const IFa_ISA05_length = 2;
export const IFa_ISA06_length = 15;
export const IFa_ISA07_length = 2;
export const IFa_ISA08_length = 15;
export const IFa_ISA09_length = 8;
export const IFa_ISA10_length = 8;
export const IFa_ISA11_length = 1;
export const IFa_ISA12_length = 5;
export const IFa_ISA13_length = 9;
export const IFa_ISA14_length = 1;
export const IFa_ISA15_length = 1;
export const IFa_ISA16_length = 1;
export const IFa_GS01_length = 2;
export const IFa_GS02_length = 15;
export const IFa_GS03_length = 15;
export const IFa_GS04_length = 8;
export const IFa_GS05_length = 8;
export const IFa_GS06_length = 9;
export const IFa_GS07_length = 2;
export const IFa_GS08_length = 12;
export const IFa_ST01_length = 3;
export const IFa_ST02_length = 9;
export const IFa_AK101_length = 2;
export const IFa_AK102_length = 9;
export const IFa_AK901_length = 1;
export const IFa_AK902_length = 6;
export const IFa_AK903_length = 6;
export const IFa_AK904_length = 6;
export const IFa_SE01_length = 10;
export const IFa_SE02_length = 9;
export const IFa_GE01_length = 6;
export const IFa_GE02_length = 9;
export const IFa_IEA01_length = 5;
export const IFa_IEA02_length = 9;
export const IFa_Exp_Flag_length = 1;

export const kFa_FA_ID="FA_ID";
export const kFa_Direction="Direction";
export const kFa_ISA01="ISA01";
export const kFa_ISA02="ISA02";
export const kFa_ISA03="ISA03";
export const kFa_ISA04="ISA04";
export const kFa_ISA05="ISA05";
export const kFa_ISA06="ISA06";
export const kFa_ISA07="ISA07";
export const kFa_ISA08="ISA08";
export const kFa_ISA09="ISA09";
export const kFa_ISA10="ISA10";
export const kFa_ISA11="ISA11";
export const kFa_ISA12="ISA12";
export const kFa_ISA13="ISA13";
export const kFa_ISA14="ISA14";
export const kFa_ISA15="ISA15";
export const kFa_ISA16="ISA16";
export const kFa_GS01="GS01";
export const kFa_GS02="GS02";
export const kFa_GS03="GS03";
export const kFa_GS04="GS04";
export const kFa_GS05="GS05";
export const kFa_GS06="GS06";
export const kFa_GS07="GS07";
export const kFa_GS08="GS08";
export const kFa_ST01="ST01";
export const kFa_ST02="ST02";
export const kFa_AK101="AK101";
export const kFa_AK102="AK102";
export const kFa_AK901="AK901";
export const kFa_AK902="AK902";
export const kFa_AK903="AK903";
export const kFa_AK904="AK904";
export const kFa_SE01="SE01";
export const kFa_SE02="SE02";
export const kFa_GE01="GE01";
export const kFa_GE02="GE02";
export const kFa_IEA01="IEA01";
export const kFa_IEA02="IEA02";
export const kFa_Exp_Flag="Exp_Flag";

/*
        'Fa' : {
            'FA_ID' : 'FA_ID',
            'Direction' : 'Direction',
            'ISA01' : 'ISA01',
            'ISA02' : 'ISA02',
            'ISA03' : 'ISA03',
            'ISA04' : 'ISA04',
            'ISA05' : 'ISA05',
            'ISA06' : 'ISA06',
            'ISA07' : 'ISA07',
            'ISA08' : 'ISA08',
            'ISA09' : 'ISA09',
            'ISA10' : 'ISA10',
            'ISA11' : 'ISA11',
            'ISA12' : 'ISA12',
            'ISA13' : 'ISA13',
            'ISA14' : 'ISA14',
            'ISA15' : 'ISA15',
            'ISA16' : 'ISA16',
            'GS01' : 'GS01',
            'GS02' : 'GS02',
            'GS03' : 'GS03',
            'GS04' : 'GS04',
            'GS05' : 'GS05',
            'GS06' : 'GS06',
            'GS07' : 'GS07',
            'GS08' : 'GS08',
            'ST01' : 'ST01',
            'ST02' : 'ST02',
            'AK101' : 'AK101',
            'AK102' : 'AK102',
            'AK901' : 'AK901',
            'AK902' : 'AK902',
            'AK903' : 'AK903',
            'AK904' : 'AK904',
            'SE01' : 'SE01',
            'SE02' : 'SE02',
            'GE01' : 'GE01',
            'GE02' : 'GE02',
            'IEA01' : 'IEA01',
            'IEA02' : 'IEA02',
            'Exp_Flag' : 'Exp_Flag',        },
*/

export const Label_FA_ID = 'Fa.FA_ID';
export const Label_Direction = 'Fa.Direction';
export const Label_ISA01 = 'Fa.ISA01';
export const Label_ISA02 = 'Fa.ISA02';
export const Label_ISA03 = 'Fa.ISA03';
export const Label_ISA04 = 'Fa.ISA04';
export const Label_ISA05 = 'Fa.ISA05';
export const Label_ISA06 = 'Fa.ISA06';
export const Label_ISA07 = 'Fa.ISA07';
export const Label_ISA08 = 'Fa.ISA08';
export const Label_ISA09 = 'Fa.ISA09';
export const Label_ISA10 = 'Fa.ISA10';
export const Label_ISA11 = 'Fa.ISA11';
export const Label_ISA12 = 'Fa.ISA12';
export const Label_ISA13 = 'Fa.ISA13';
export const Label_ISA14 = 'Fa.ISA14';
export const Label_ISA15 = 'Fa.ISA15';
export const Label_ISA16 = 'Fa.ISA16';
export const Label_GS01 = 'Fa.GS01';
export const Label_GS02 = 'Fa.GS02';
export const Label_GS03 = 'Fa.GS03';
export const Label_GS04 = 'Fa.GS04';
export const Label_GS05 = 'Fa.GS05';
export const Label_GS06 = 'Fa.GS06';
export const Label_GS07 = 'Fa.GS07';
export const Label_GS08 = 'Fa.GS08';
export const Label_ST01 = 'Fa.ST01';
export const Label_ST02 = 'Fa.ST02';
export const Label_AK101 = 'Fa.AK101';
export const Label_AK102 = 'Fa.AK102';
export const Label_AK901 = 'Fa.AK901';
export const Label_AK902 = 'Fa.AK902';
export const Label_AK903 = 'Fa.AK903';
export const Label_AK904 = 'Fa.AK904';
export const Label_SE01 = 'Fa.SE01';
export const Label_SE02 = 'Fa.SE02';
export const Label_GE01 = 'Fa.GE01';
export const Label_GE02 = 'Fa.GE02';
export const Label_IEA01 = 'Fa.IEA01';
export const Label_IEA02 = 'Fa.IEA02';
export const Label_Exp_Flag = 'Fa.Exp_Flag';
