import { IApiC303v850hBaseView } from '../edidb'
export class CApiC303v850hBaseView implements IApiC303v850hBaseView {
    public rownum:number = 0;
    public PO_ID:number = 0;
    public TP_PartID:string = '';
    public TP_Name:string = '';
    public BEG_03:string = '';
    public BEG_04:string = '';
    public BEG_05:string = '';
    public ImportDate:Date;
    public ExportDate:Date;
    public Exp_Flag:string = '';
    public Status:string = '';
    public Misc_ID:number = 0;
    public HoldID:number = 0;
    public Notes:string = '';
    public ErrorID:string = '';
    public TLE:number = 0;
    public VPIDFA:number = 0;
    public constructor(init?:Partial<CApiC303v850hBaseView>) { Object.assign(this, init); }
}
export const IApiC303v850hBaseView_TP_PartID_length = 30;
export const IApiC303v850hBaseView_TP_Name_length = 30;
export const IApiC303v850hBaseView_BEG_03_length = 22;
export const IApiC303v850hBaseView_BEG_04_length = 30;
export const IApiC303v850hBaseView_BEG_05_length = 8;
export const IApiC303v850hBaseView_Exp_Flag_length = 1;
export const IApiC303v850hBaseView_Status_length = 500;
export const IApiC303v850hBaseView_Notes_length = 60;
export const IApiC303v850hBaseView_ErrorID_length = 50;

export const kApiC303v850hBaseView_rownum="rownum";
export const kApiC303v850hBaseView_PO_ID="PO_ID";
export const kApiC303v850hBaseView_TP_PartID="TP_PartID";
export const kApiC303v850hBaseView_TP_Name="TP_Name";
export const kApiC303v850hBaseView_BEG_03="BEG_03";
export const kApiC303v850hBaseView_BEG_04="BEG_04";
export const kApiC303v850hBaseView_BEG_05="BEG_05";
export const kApiC303v850hBaseView_ImportDate="ImportDate";
export const kApiC303v850hBaseView_ExportDate="ExportDate";
export const kApiC303v850hBaseView_Exp_Flag="Exp_Flag";
export const kApiC303v850hBaseView_Status="Status";
export const kApiC303v850hBaseView_Misc_ID="Misc_ID";
export const kApiC303v850hBaseView_HoldID="HoldID";
export const kApiC303v850hBaseView_Notes="Notes";
export const kApiC303v850hBaseView_ErrorID="ErrorID";
export const kApiC303v850hBaseView_TLE="TLE";
export const kApiC303v850hBaseView_VPIDFA="VPIDFA";

/*
        'ApiC303v850hBaseView' : {
            'rownum' : 'rownum',
            'PO_ID' : 'PO_ID',
            'TP_PartID' : 'TP_PartID',
            'TP_Name' : 'TP_Name',
            'BEG_03' : 'BEG_03',
            'BEG_04' : 'BEG_04',
            'BEG_05' : 'BEG_05',
            'ImportDate' : 'ImportDate',
            'ExportDate' : 'ExportDate',
            'Exp_Flag' : 'Exp_Flag',
            'Status' : 'Status',
            'Misc_ID' : 'Misc_ID',
            'HoldID' : 'HoldID',
            'Notes' : 'Notes',
            'ErrorID' : 'ErrorID',
            'TLE' : 'TLE',
            'VPIDFA' : 'VPIDFA',        },
*/

export const Label_rownum = 'ApiC303v850hBaseView.rownum';
export const Label_PO_ID = 'ApiC303v850hBaseView.PO_ID';
export const Label_TP_PartID = 'ApiC303v850hBaseView.TP_PartID';
export const Label_TP_Name = 'ApiC303v850hBaseView.TP_Name';
export const Label_BEG_03 = 'ApiC303v850hBaseView.BEG_03';
export const Label_BEG_04 = 'ApiC303v850hBaseView.BEG_04';
export const Label_BEG_05 = 'ApiC303v850hBaseView.BEG_05';
export const Label_ImportDate = 'ApiC303v850hBaseView.ImportDate';
export const Label_ExportDate = 'ApiC303v850hBaseView.ExportDate';
export const Label_Exp_Flag = 'ApiC303v850hBaseView.Exp_Flag';
export const Label_Status = 'ApiC303v850hBaseView.Status';
export const Label_Misc_ID = 'ApiC303v850hBaseView.Misc_ID';
export const Label_HoldID = 'ApiC303v850hBaseView.HoldID';
export const Label_Notes = 'ApiC303v850hBaseView.Notes';
export const Label_ErrorID = 'ApiC303v850hBaseView.ErrorID';
export const Label_TLE = 'ApiC303v850hBaseView.TLE';
export const Label_VPIDFA = 'ApiC303v850hBaseView.VPIDFA';
