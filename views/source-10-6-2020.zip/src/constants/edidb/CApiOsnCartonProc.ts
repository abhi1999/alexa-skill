import { IApiOsnCartonProc } from '../edidb'
export class CApiOsnCartonProc implements IApiOsnCartonProc {
    public Asn_ID:number = 0;
    public Box_ID:number = 0;
    public Pack_Level:number = 0;
    public TrackingNo:string = '';
    public SSCC:string = '';
    public PKG_ID:string = '';
    public Pack_Wt:string = '';
    public constructor(init?:Partial<CApiOsnCartonProc>) { Object.assign(this, init); }
}
export const IApiOsnCartonProc_TrackingNo_length = 50;
export const IApiOsnCartonProc_SSCC_length = 30;
export const IApiOsnCartonProc_PKG_ID_length = 10;
export const IApiOsnCartonProc_Pack_Wt_length = 100;

export const kApiOsnCartonProc_Asn_ID="Asn_ID";
export const kApiOsnCartonProc_Box_ID="Box_ID";
export const kApiOsnCartonProc_Pack_Level="Pack_Level";
export const kApiOsnCartonProc_TrackingNo="TrackingNo";
export const kApiOsnCartonProc_SSCC="SSCC";
export const kApiOsnCartonProc_PKG_ID="PKG_ID";
export const kApiOsnCartonProc_Pack_Wt="Pack_Wt";

/*
        'ApiOsnCartonProc' : {
            'Asn_ID' : 'Asn_ID',
            'Box_ID' : 'Box_ID',
            'Pack_Level' : 'Pack_Level',
            'TrackingNo' : 'TrackingNo',
            'SSCC' : 'SSCC',
            'PKG_ID' : 'PKG_ID',
            'Pack_Wt' : 'Pack_Wt',        },
*/

export const Label_Asn_ID = 'ApiOsnCartonProc.Asn_ID';
export const Label_Box_ID = 'ApiOsnCartonProc.Box_ID';
export const Label_Pack_Level = 'ApiOsnCartonProc.Pack_Level';
export const Label_TrackingNo = 'ApiOsnCartonProc.TrackingNo';
export const Label_SSCC = 'ApiOsnCartonProc.SSCC';
export const Label_PKG_ID = 'ApiOsnCartonProc.PKG_ID';
export const Label_Pack_Wt = 'ApiOsnCartonProc.Pack_Wt';
