import { IShipTo } from '../edidb'
export class CShipTo implements IShipTo {
    public TP_PartID:string = '';
    public ShipTo_ID:string = '';
    public ShipTo_Xref:string = '';
    public ShipTo_Name:string = '';
    public ShipTo_Address:string = '';
    public ShipTo_Address2:string = '';
    public ShipTo_City:string = '';
    public ShipTo_State:string = '';
    public ShipTo_Zip:string = '';
    public ShipTo_Country:string = '';
    public ShipTo_CustID:string = '';
    public ShipTo_DC:string = '';
    public ShipTo_ShipDateQual:string = '';
    public ShipTo_StoreName:string = '';
    public ShipTo_Carrier:string = '';
    public User1:string = '';
    public User2:string = '';
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public ShipTo_rfid:boolean;
    public ShipTo_GroupID:string = '';
    public TransitDays:number = 0;
    public FrozenDays:number = 0;
    public ShipDlvPattern:string = '';
    public Loc_Override:string = '';
    public constructor(init?:Partial<CShipTo>) { Object.assign(this, init); }
}
export const IShipTo_TP_PartID_length = 30;
export const IShipTo_ShipTo_ID_length = 80;
export const IShipTo_ShipTo_Xref_length = 30;
export const IShipTo_ShipTo_Name_length = 80;
export const IShipTo_ShipTo_Address_length = 80;
export const IShipTo_ShipTo_Address2_length = 80;
export const IShipTo_ShipTo_City_length = 40;
export const IShipTo_ShipTo_State_length = 20;
export const IShipTo_ShipTo_Zip_length = 15;
export const IShipTo_ShipTo_Country_length = 30;
export const IShipTo_ShipTo_CustID_length = 30;
export const IShipTo_ShipTo_DC_length = 30;
export const IShipTo_ShipTo_ShipDateQual_length = 3;
export const IShipTo_ShipTo_StoreName_length = 50;
export const IShipTo_ShipTo_Carrier_length = 30;
export const IShipTo_User1_length = 50;
export const IShipTo_User2_length = 50;
export const IShipTo_User3_length = 50;
export const IShipTo_User4_length = 50;
export const IShipTo_User5_length = 50;
export const IShipTo_ShipTo_GroupID_length = 30;
export const IShipTo_ShipDlvPattern_length = 20;
export const IShipTo_Loc_Override_length = 20;

export const kShipTo_TP_PartID="TP_PartID";
export const kShipTo_ShipTo_ID="ShipTo_ID";
export const kShipTo_ShipTo_Xref="ShipTo_Xref";
export const kShipTo_ShipTo_Name="ShipTo_Name";
export const kShipTo_ShipTo_Address="ShipTo_Address";
export const kShipTo_ShipTo_Address2="ShipTo_Address2";
export const kShipTo_ShipTo_City="ShipTo_City";
export const kShipTo_ShipTo_State="ShipTo_State";
export const kShipTo_ShipTo_Zip="ShipTo_Zip";
export const kShipTo_ShipTo_Country="ShipTo_Country";
export const kShipTo_ShipTo_CustID="ShipTo_CustID";
export const kShipTo_ShipTo_DC="ShipTo_DC";
export const kShipTo_ShipTo_ShipDateQual="ShipTo_ShipDateQual";
export const kShipTo_ShipTo_StoreName="ShipTo_StoreName";
export const kShipTo_ShipTo_Carrier="ShipTo_Carrier";
export const kShipTo_User1="User1";
export const kShipTo_User2="User2";
export const kShipTo_User3="User3";
export const kShipTo_User4="User4";
export const kShipTo_User5="User5";
export const kShipTo_ShipTo_rfid="ShipTo_rfid";
export const kShipTo_ShipTo_GroupID="ShipTo_GroupID";
export const kShipTo_TransitDays="TransitDays";
export const kShipTo_FrozenDays="FrozenDays";
export const kShipTo_ShipDlvPattern="ShipDlvPattern";
export const kShipTo_Loc_Override="Loc_Override";

/*
        'ShipTo' : {
            'TP_PartID' : 'TP_PartID',
            'ShipTo_ID' : 'ShipTo_ID',
            'ShipTo_Xref' : 'ShipTo_Xref',
            'ShipTo_Name' : 'ShipTo_Name',
            'ShipTo_Address' : 'ShipTo_Address',
            'ShipTo_Address2' : 'ShipTo_Address2',
            'ShipTo_City' : 'ShipTo_City',
            'ShipTo_State' : 'ShipTo_State',
            'ShipTo_Zip' : 'ShipTo_Zip',
            'ShipTo_Country' : 'ShipTo_Country',
            'ShipTo_CustID' : 'ShipTo_CustID',
            'ShipTo_DC' : 'ShipTo_DC',
            'ShipTo_ShipDateQual' : 'ShipTo_ShipDateQual',
            'ShipTo_StoreName' : 'ShipTo_StoreName',
            'ShipTo_Carrier' : 'ShipTo_Carrier',
            'User1' : 'User1',
            'User2' : 'User2',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'ShipTo_rfid' : 'ShipTo_rfid',
            'ShipTo_GroupID' : 'ShipTo_GroupID',
            'TransitDays' : 'TransitDays',
            'FrozenDays' : 'FrozenDays',
            'ShipDlvPattern' : 'ShipDlvPattern',
            'Loc_Override' : 'Loc_Override',        },
*/

export const Label_TP_PartID = 'ShipTo.TP_PartID';
export const Label_ShipTo_ID = 'ShipTo.ShipTo_ID';
export const Label_ShipTo_Xref = 'ShipTo.ShipTo_Xref';
export const Label_ShipTo_Name = 'ShipTo.ShipTo_Name';
export const Label_ShipTo_Address = 'ShipTo.ShipTo_Address';
export const Label_ShipTo_Address2 = 'ShipTo.ShipTo_Address2';
export const Label_ShipTo_City = 'ShipTo.ShipTo_City';
export const Label_ShipTo_State = 'ShipTo.ShipTo_State';
export const Label_ShipTo_Zip = 'ShipTo.ShipTo_Zip';
export const Label_ShipTo_Country = 'ShipTo.ShipTo_Country';
export const Label_ShipTo_CustID = 'ShipTo.ShipTo_CustID';
export const Label_ShipTo_DC = 'ShipTo.ShipTo_DC';
export const Label_ShipTo_ShipDateQual = 'ShipTo.ShipTo_ShipDateQual';
export const Label_ShipTo_StoreName = 'ShipTo.ShipTo_StoreName';
export const Label_ShipTo_Carrier = 'ShipTo.ShipTo_Carrier';
export const Label_User1 = 'ShipTo.User1';
export const Label_User2 = 'ShipTo.User2';
export const Label_User3 = 'ShipTo.User3';
export const Label_User4 = 'ShipTo.User4';
export const Label_User5 = 'ShipTo.User5';
export const Label_ShipTo_rfid = 'ShipTo.ShipTo_rfid';
export const Label_ShipTo_GroupID = 'ShipTo.ShipTo_GroupID';
export const Label_TransitDays = 'ShipTo.TransitDays';
export const Label_FrozenDays = 'ShipTo.FrozenDays';
export const Label_ShipDlvPattern = 'ShipTo.ShipDlvPattern';
export const Label_Loc_Override = 'ShipTo.Loc_Override';
