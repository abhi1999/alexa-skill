import { IApiShipDetail5 } from '../edidb'
export class CApiShipDetail5 implements IApiShipDetail5 {
    public ID:string = '';
    public Name:string = '';
    public Address1:string = '';
    public Address2:string = '';
    public City:string = '';
    public State:string = '';
    public Zip:string = '';
    public Country:string = '';
    public Source:string = '';
    public constructor(init?:Partial<CApiShipDetail5>) { Object.assign(this, init); }
}
export const IApiShipDetail5_ID_length = 80;
export const IApiShipDetail5_Name_length = 60;
export const IApiShipDetail5_Address1_length = 60;
export const IApiShipDetail5_Address2_length = 60;
export const IApiShipDetail5_City_length = 35;
export const IApiShipDetail5_State_length = 2;
export const IApiShipDetail5_Zip_length = 15;
export const IApiShipDetail5_Country_length = 30;
export const IApiShipDetail5_Source_length = 15;

export const kApiShipDetail5_ID="ID";
export const kApiShipDetail5_Name="Name";
export const kApiShipDetail5_Address1="Address1";
export const kApiShipDetail5_Address2="Address2";
export const kApiShipDetail5_City="City";
export const kApiShipDetail5_State="State";
export const kApiShipDetail5_Zip="Zip";
export const kApiShipDetail5_Country="Country";
export const kApiShipDetail5_Source="Source";

/*
        'ApiShipDetail5' : {
            'ID' : 'ID',
            'Name' : 'Name',
            'Address1' : 'Address1',
            'Address2' : 'Address2',
            'City' : 'City',
            'State' : 'State',
            'Zip' : 'Zip',
            'Country' : 'Country',
            'Source' : 'Source',        },
*/

export const Label_ID = 'ApiShipDetail5.ID';
export const Label_Name = 'ApiShipDetail5.Name';
export const Label_Address1 = 'ApiShipDetail5.Address1';
export const Label_Address2 = 'ApiShipDetail5.Address2';
export const Label_City = 'ApiShipDetail5.City';
export const Label_State = 'ApiShipDetail5.State';
export const Label_Zip = 'ApiShipDetail5.Zip';
export const Label_Country = 'ApiShipDetail5.Country';
export const Label_Source = 'ApiShipDetail5.Source';
