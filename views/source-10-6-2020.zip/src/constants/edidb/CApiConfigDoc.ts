import { IApiConfigDoc } from '../edidb'
export class CApiConfigDoc implements IApiConfigDoc {
    public VPID:number = 0;
    public DGID:string = '';
    public TP_PartID:string = '';
    public TP_Name:string = '';
    public Doc_Group:string = '';
    public XMLRef:string = '';
    public statuscode:string = '';
    public CreatedDate:Date;
    public XMLID:string = '';
    public GCN:string = '';
    public TCN:string = '';
    public Misc_ID:number = 0;
    public constructor(init?:Partial<CApiConfigDoc>) { Object.assign(this, init); }
}
export const IApiConfigDoc_DGID_length = 5;
export const IApiConfigDoc_TP_PartID_length = 30;
export const IApiConfigDoc_TP_Name_length = 30;
export const IApiConfigDoc_Doc_Group_length = 50;
export const IApiConfigDoc_XMLRef_length = 1000;
export const IApiConfigDoc_statuscode_length = 1;
export const IApiConfigDoc_GCN_length = 50;
export const IApiConfigDoc_TCN_length = 50;

export const kApiConfigDoc_VPID="VPID";
export const kApiConfigDoc_DGID="DGID";
export const kApiConfigDoc_TP_PartID="TP_PartID";
export const kApiConfigDoc_TP_Name="TP_Name";
export const kApiConfigDoc_Doc_Group="Doc_Group";
export const kApiConfigDoc_XMLRef="XMLRef";
export const kApiConfigDoc_statuscode="statuscode";
export const kApiConfigDoc_CreatedDate="CreatedDate";
export const kApiConfigDoc_XMLID="XMLID";
export const kApiConfigDoc_GCN="GCN";
export const kApiConfigDoc_TCN="TCN";
export const kApiConfigDoc_Misc_ID="Misc_ID";

/*
        'ApiConfigDoc' : {
            'VPID' : 'VPID',
            'DGID' : 'DGID',
            'TP_PartID' : 'TP_PartID',
            'TP_Name' : 'TP_Name',
            'Doc_Group' : 'Doc_Group',
            'XMLRef' : 'XMLRef',
            'statuscode' : 'statuscode',
            'CreatedDate' : 'CreatedDate',
            'XMLID' : 'XMLID',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'Misc_ID' : 'Misc_ID',        },
*/

export const Label_VPID = 'ApiConfigDoc.VPID';
export const Label_DGID = 'ApiConfigDoc.DGID';
export const Label_TP_PartID = 'ApiConfigDoc.TP_PartID';
export const Label_TP_Name = 'ApiConfigDoc.TP_Name';
export const Label_Doc_Group = 'ApiConfigDoc.Doc_Group';
export const Label_XMLRef = 'ApiConfigDoc.XMLRef';
export const Label_statuscode = 'ApiConfigDoc.statuscode';
export const Label_CreatedDate = 'ApiConfigDoc.CreatedDate';
export const Label_XMLID = 'ApiConfigDoc.XMLID';
export const Label_GCN = 'ApiConfigDoc.GCN';
export const Label_TCN = 'ApiConfigDoc.TCN';
export const Label_Misc_ID = 'ApiConfigDoc.Misc_ID';
