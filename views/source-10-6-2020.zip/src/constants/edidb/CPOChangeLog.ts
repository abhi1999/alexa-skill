import { IPOChangeLog } from '../edidb'
export class CPOChangeLog implements IPOChangeLog {
    public PO_ID:number = 0;
    public PO1_LineNo:string = '';
    public ShipTo_ID:string = '';
    public PID:string = '';
    public LogDate:Date;
    public DataArea:string = '';
    public DataAction:string = '';
    public DataValue:string = '';
    public POCID:string = '';
    public constructor(init?:Partial<CPOChangeLog>) { Object.assign(this, init); }
}
export const IPOChangeLog_PO1_LineNo_length = 11;
export const IPOChangeLog_ShipTo_ID_length = 80;
export const IPOChangeLog_DataArea_length = 10;
export const IPOChangeLog_DataAction_length = 80;
export const IPOChangeLog_DataValue_length = 80;

export const kPOChangeLog_PO_ID="PO_ID";
export const kPOChangeLog_PO1_LineNo="PO1_LineNo";
export const kPOChangeLog_ShipTo_ID="ShipTo_ID";
export const kPOChangeLog_PID="PID";
export const kPOChangeLog_LogDate="LogDate";
export const kPOChangeLog_DataArea="DataArea";
export const kPOChangeLog_DataAction="DataAction";
export const kPOChangeLog_DataValue="DataValue";
export const kPOChangeLog_POCID="POCID";

/*
        'POChangeLog' : {
            'PO_ID' : 'PO_ID',
            'PO1_LineNo' : 'PO1_LineNo',
            'ShipTo_ID' : 'ShipTo_ID',
            'PID' : 'PID',
            'LogDate' : 'LogDate',
            'DataArea' : 'DataArea',
            'DataAction' : 'DataAction',
            'DataValue' : 'DataValue',
            'POCID' : 'POCID',        },
*/

export const Label_PO_ID = 'POChangeLog.PO_ID';
export const Label_PO1_LineNo = 'POChangeLog.PO1_LineNo';
export const Label_ShipTo_ID = 'POChangeLog.ShipTo_ID';
export const Label_PID = 'POChangeLog.PID';
export const Label_LogDate = 'POChangeLog.LogDate';
export const Label_DataArea = 'POChangeLog.DataArea';
export const Label_DataAction = 'POChangeLog.DataAction';
export const Label_DataValue = 'POChangeLog.DataValue';
export const Label_POCID = 'POChangeLog.POCID';
