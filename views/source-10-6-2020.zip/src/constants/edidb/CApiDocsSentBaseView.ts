import { IApiDocsSentBaseView } from '../edidb'
export class CApiDocsSentBaseView implements IApiDocsSentBaseView {
    public Sent_ID:number = 0;
    public TP_PartID:string = '';
    public DocType:string = '';
    public DocRef:string = '';
    public DateSent:Date;
    public DocStatus:string = '';
    public ICN:string = '';
    public GCN:string = '';
    public ErrorID:number = 0;
    public TP_Name:string = '';
    public TCN:string = '';
    public constructor(init?:Partial<CApiDocsSentBaseView>) { Object.assign(this, init); }
}
export const IApiDocsSentBaseView_TP_PartID_length = 30;
export const IApiDocsSentBaseView_DocType_length = 10;
export const IApiDocsSentBaseView_DocRef_length = 50;
export const IApiDocsSentBaseView_DocStatus_length = 1;
export const IApiDocsSentBaseView_ICN_length = 20;
export const IApiDocsSentBaseView_GCN_length = 20;
export const IApiDocsSentBaseView_TP_Name_length = 30;
export const IApiDocsSentBaseView_TCN_length = 20;

export const kApiDocsSentBaseView_Sent_ID="Sent_ID";
export const kApiDocsSentBaseView_TP_PartID="TP_PartID";
export const kApiDocsSentBaseView_DocType="DocType";
export const kApiDocsSentBaseView_DocRef="DocRef";
export const kApiDocsSentBaseView_DateSent="DateSent";
export const kApiDocsSentBaseView_DocStatus="DocStatus";
export const kApiDocsSentBaseView_ICN="ICN";
export const kApiDocsSentBaseView_GCN="GCN";
export const kApiDocsSentBaseView_ErrorID="ErrorID";
export const kApiDocsSentBaseView_TP_Name="TP_Name";
export const kApiDocsSentBaseView_TCN="TCN";

/*
        'ApiDocsSentBaseView' : {
            'Sent_ID' : 'Sent_ID',
            'TP_PartID' : 'TP_PartID',
            'DocType' : 'DocType',
            'DocRef' : 'DocRef',
            'DateSent' : 'DateSent',
            'DocStatus' : 'DocStatus',
            'ICN' : 'ICN',
            'GCN' : 'GCN',
            'ErrorID' : 'ErrorID',
            'TP_Name' : 'TP_Name',
            'TCN' : 'TCN',        },
*/

export const Label_Sent_ID = 'ApiDocsSentBaseView.Sent_ID';
export const Label_TP_PartID = 'ApiDocsSentBaseView.TP_PartID';
export const Label_DocType = 'ApiDocsSentBaseView.DocType';
export const Label_DocRef = 'ApiDocsSentBaseView.DocRef';
export const Label_DateSent = 'ApiDocsSentBaseView.DateSent';
export const Label_DocStatus = 'ApiDocsSentBaseView.DocStatus';
export const Label_ICN = 'ApiDocsSentBaseView.ICN';
export const Label_GCN = 'ApiDocsSentBaseView.GCN';
export const Label_ErrorID = 'ApiDocsSentBaseView.ErrorID';
export const Label_TP_Name = 'ApiDocsSentBaseView.TP_Name';
export const Label_TCN = 'ApiDocsSentBaseView.TCN';
