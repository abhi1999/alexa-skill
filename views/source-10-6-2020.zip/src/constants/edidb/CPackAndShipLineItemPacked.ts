import { IPackAndShipLineItemPacked  } from '../edidb'

export class CPackAndShipLineItemPacked implements IPackAndShipLineItemPacked {
  
    // KB: NOTE: This Id is not in the table, but I added for a unique key, which is set in the reducer
    public Id: string = "";
    
    public Order_No: number = 0;
    public Line_No: number = 0;
    public Pack_ID: number = 0;
    public Pack_Level: string = '';    
    public PackQty: number = 0;
    public Pack_Wt: number = 0;
    public Item_No: string = '';

    public Box_ID: number = 0;
    public PKG_ID: string = '';
    public Item_Desc: string = '';
    public QtyPacked: number = 0;
    public Quantity: number = 0;

    public constructor(init?:Partial<CPackAndShipLineItemPacked>) { Object.assign(this, init); }
}

export const IPackAndShip_Order_No_length = 30;
export const IPackAndShip_Line_No_length = 30;
export const IPackAndShip_Item_No_length = 30;
export const IPackAndShip_Pack_Qty = 30;
export const IPackAndShip_Pack_Id = 30;
export const IPackAndShip_Package_No = 30;
export const IPackAndShip_Pack_Level = 30;

export const IPackAndShip_ML_Pkg_Id = 30;
export const IPackAndShip_ML_Box_Id = 30;
export const IPackAndShip_ML_Pack_Id = 30;
export const IPackAndShip_ML_Pack_Qty = 30;
export const IPackAndShip_ML_Item_No = 30;
export const IPackAndShip_ML_Item_Desc = 100;

export const kPackAndShip_Order_No = 'Order_No';
export const kPackAndShip_Line_No = 'Line_No';
export const kPackAndShip_Item_No = 'Int_Item_No';
export const kPackAndShip_Pack_Qty = 'PackQty';
export const kPackAndShip_Pack_Id = 'Pack_ID';
export const kPackAndShip_Package_No = 'Box_ID';
export const kPackAndShip_Pack_Level = 'Pack_Level';

export const kPackAndShip_ML_Pkg_Id = 'PKG_ID';
export const kPackAndShip_ML_Box_Id = 'Box_ID';
export const kPackAndShip_ML_Pack_Id = 'Pack_ID';
export const kPackAndShip_ML_Pack_Qty = 'PackQty';
export const kPackAndShip_ML_Item_No = 'Int_Item_No';
export const kPackAndShip_ML_Item_Desc = 'Item_Desc';

export const Label_Order_No = 'PackAndShip.Order_No';
export const Label_Line_No = 'PackAndShip.Line_No';
export const Label_Item = 'PackAndShip.Item';
export const Label_Pack_Qty = 'PackAndShip.Pack_Qty';
export const Label_Pack_Id = 'PackAndShip.Pack_Id';
export const Label_Package_No = 'PackAndShip.Package_No';
export const Label_Pack_Level = 'PackAndShip.Pack_Level';

export const Label_ML_Pkg_Id = 'PackAndShip.ML_Pkg_Id';
export const Label_ML_Box_Id = 'PackAndShip.ML_Box_Id';
export const Label_ML_Pack_Id = 'PackAndShip.ML_Pack_Id';
export const Label_ML_Pack_Id_Level1 = 'PackAndShip.ML_Pack_Id_Level1';
export const Label_ML_Pack_Id_Level2 = 'PackAndShip.ML_Pack_Id_Level2';
export const Label_ML_Pack_Qty = 'PackAndShip.ML_Pack_Qty';
export const Label_ML_Item_No = 'PackAndShip.ML_Item_No';
export const Label_ML_Item_Desc = 'PackAndShip.ML_Item_Desc';