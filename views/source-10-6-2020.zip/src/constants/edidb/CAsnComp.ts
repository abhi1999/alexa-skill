import { IAsnComp } from '../edidb'
export class CAsnComp implements IAsnComp {
    public CntrID:number = 0;
    public Asn_ID:number = 0;
    public Ship_Weight:number = 0;
    public Ship_Date:string = '';
    public Ship_Via_ID:string = '';
    public Asn_Complete:string = '';
    public Exp_Flag:string = '';
    public Order_No:number = 0;
    public Cust_Dept:string = '';
    public Order_Wt:number = 0;
    public Pack_ID:number = 0;
    public PackQty:number = 0;
    public Pack_Wt:number = 0;
    public Box_ID:number = 0;
    public Line_No:number = 0;
    public Int_Item_No:string = '';
    public Stat_Flag:string = '';
    public TP_ID:string = '';
    public ShipTo_Xref:string = '';
    public Order_Date:string = '';
    public Cust_PO:string = '';
    public Ship_To_ID:string = '';
    public Ship_To_Name:string = '';
    public Ship_To_Address1:string = '';
    public Ship_To_Address2:string = '';
    public Ship_To_City:string = '';
    public Ship_To_St:string = '';
    public Ship_To_Zip:string = '';
    public Quantity:number = 0;
    public QtyPacked:number = 0;
    public Price:number = 0;
    public Del_Date:string = '';
    public UnitofMeas:string = '';
    public ShipToPeps:boolean;
    public Bol_No:string = '';
    public Pro_No:string = '';
    public User1:string = '';
    public User2:string = '';
    public Trailer:string = '';
    public Collect:boolean;
    public constructor(init?:Partial<CAsnComp>) { Object.assign(this, init); }
}
export const IAsnComp_Ship_Date_length = 8;
export const IAsnComp_Ship_Via_ID_length = 30;
export const IAsnComp_Asn_Complete_length = 1;
export const IAsnComp_Exp_Flag_length = 1;
export const IAsnComp_Cust_Dept_length = 30;
export const IAsnComp_Int_Item_No_length = 30;
export const IAsnComp_Stat_Flag_length = 1;
export const IAsnComp_TP_ID_length = 30;
export const IAsnComp_ShipTo_Xref_length = 30;
export const IAsnComp_Order_Date_length = 8;
export const IAsnComp_Cust_PO_length = 30;
export const IAsnComp_Ship_To_ID_length = 40;
export const IAsnComp_Ship_To_Name_length = 50;
export const IAsnComp_Ship_To_Address1_length = 50;
export const IAsnComp_Ship_To_Address2_length = 50;
export const IAsnComp_Ship_To_City_length = 50;
export const IAsnComp_Ship_To_St_length = 50;
export const IAsnComp_Ship_To_Zip_length = 20;
export const IAsnComp_Del_Date_length = 8;
export const IAsnComp_UnitofMeas_length = 10;
export const IAsnComp_Bol_No_length = 30;
export const IAsnComp_Pro_No_length = 30;
export const IAsnComp_User1_length = 50;
export const IAsnComp_User2_length = 50;
export const IAsnComp_Trailer_length = 50;

export const kAsnComp_CntrID="CntrID";
export const kAsnComp_Asn_ID="Asn_ID";
export const kAsnComp_Ship_Weight="Ship_Weight";
export const kAsnComp_Ship_Date="Ship_Date";
export const kAsnComp_Ship_Via_ID="Ship_Via_ID";
export const kAsnComp_Asn_Complete="Asn_Complete";
export const kAsnComp_Exp_Flag="Exp_Flag";
export const kAsnComp_Order_No="Order_No";
export const kAsnComp_Cust_Dept="Cust_Dept";
export const kAsnComp_Order_Wt="Order_Wt";
export const kAsnComp_Pack_ID="Pack_ID";
export const kAsnComp_PackQty="PackQty";
export const kAsnComp_Pack_Wt="Pack_Wt";
export const kAsnComp_Box_ID="Box_ID";
export const kAsnComp_Line_No="Line_No";
export const kAsnComp_Int_Item_No="Int_Item_No";
export const kAsnComp_Stat_Flag="Stat_Flag";
export const kAsnComp_TP_ID="TP_ID";
export const kAsnComp_ShipTo_Xref="ShipTo_Xref";
export const kAsnComp_Order_Date="Order_Date";
export const kAsnComp_Cust_PO="Cust_PO";
export const kAsnComp_Ship_To_ID="Ship_To_ID";
export const kAsnComp_Ship_To_Name="Ship_To_Name";
export const kAsnComp_Ship_To_Address1="Ship_To_Address1";
export const kAsnComp_Ship_To_Address2="Ship_To_Address2";
export const kAsnComp_Ship_To_City="Ship_To_City";
export const kAsnComp_Ship_To_St="Ship_To_St";
export const kAsnComp_Ship_To_Zip="Ship_To_Zip";
export const kAsnComp_Quantity="Quantity";
export const kAsnComp_QtyPacked="QtyPacked";
export const kAsnComp_Price="Price";
export const kAsnComp_Del_Date="Del_Date";
export const kAsnComp_UnitofMeas="UnitofMeas";
export const kAsnComp_ShipToPeps="ShipToPeps";
export const kAsnComp_Bol_No="Bol_No";
export const kAsnComp_Pro_No="Pro_No";
export const kAsnComp_User1="User1";
export const kAsnComp_User2="User2";
export const kAsnComp_Trailer="Trailer";
export const kAsnComp_Collect="Collect";

/*
        'AsnComp' : {
            'CntrID' : 'CntrID',
            'Asn_ID' : 'Asn_ID',
            'Ship_Weight' : 'Ship_Weight',
            'Ship_Date' : 'Ship_Date',
            'Ship_Via_ID' : 'Ship_Via_ID',
            'Asn_Complete' : 'Asn_Complete',
            'Exp_Flag' : 'Exp_Flag',
            'Order_No' : 'Order_No',
            'Cust_Dept' : 'Cust_Dept',
            'Order_Wt' : 'Order_Wt',
            'Pack_ID' : 'Pack_ID',
            'PackQty' : 'PackQty',
            'Pack_Wt' : 'Pack_Wt',
            'Box_ID' : 'Box_ID',
            'Line_No' : 'Line_No',
            'Int_Item_No' : 'Int_Item_No',
            'Stat_Flag' : 'Stat_Flag',
            'TP_ID' : 'TP_ID',
            'ShipTo_Xref' : 'ShipTo_Xref',
            'Order_Date' : 'Order_Date',
            'Cust_PO' : 'Cust_PO',
            'Ship_To_ID' : 'Ship_To_ID',
            'Ship_To_Name' : 'Ship_To_Name',
            'Ship_To_Address1' : 'Ship_To_Address1',
            'Ship_To_Address2' : 'Ship_To_Address2',
            'Ship_To_City' : 'Ship_To_City',
            'Ship_To_St' : 'Ship_To_St',
            'Ship_To_Zip' : 'Ship_To_Zip',
            'Quantity' : 'Quantity',
            'QtyPacked' : 'QtyPacked',
            'Price' : 'Price',
            'Del_Date' : 'Del_Date',
            'UnitofMeas' : 'UnitofMeas',
            'ShipToPeps' : 'ShipToPeps',
            'Bol_No' : 'Bol_No',
            'Pro_No' : 'Pro_No',
            'User1' : 'User1',
            'User2' : 'User2',
            'Trailer' : 'Trailer',
            'Collect' : 'Collect',        },
*/

export const Label_CntrID = 'AsnComp.CntrID';
export const Label_Asn_ID = 'AsnComp.Asn_ID';
export const Label_Ship_Weight = 'AsnComp.Ship_Weight';
export const Label_Ship_Date = 'AsnComp.Ship_Date';
export const Label_Ship_Via_ID = 'AsnComp.Ship_Via_ID';
export const Label_Asn_Complete = 'AsnComp.Asn_Complete';
export const Label_Exp_Flag = 'AsnComp.Exp_Flag';
export const Label_Order_No = 'AsnComp.Order_No';
export const Label_Cust_Dept = 'AsnComp.Cust_Dept';
export const Label_Order_Wt = 'AsnComp.Order_Wt';
export const Label_Pack_ID = 'AsnComp.Pack_ID';
export const Label_PackQty = 'AsnComp.PackQty';
export const Label_Pack_Wt = 'AsnComp.Pack_Wt';
export const Label_Box_ID = 'AsnComp.Box_ID';
export const Label_Line_No = 'AsnComp.Line_No';
export const Label_Int_Item_No = 'AsnComp.Int_Item_No';
export const Label_Stat_Flag = 'AsnComp.Stat_Flag';
export const Label_TP_ID = 'AsnComp.TP_ID';
export const Label_ShipTo_Xref = 'AsnComp.ShipTo_Xref';
export const Label_Order_Date = 'AsnComp.Order_Date';
export const Label_Cust_PO = 'AsnComp.Cust_PO';
export const Label_Ship_To_ID = 'AsnComp.Ship_To_ID';
export const Label_Ship_To_Name = 'AsnComp.Ship_To_Name';
export const Label_Ship_To_Address1 = 'AsnComp.Ship_To_Address1';
export const Label_Ship_To_Address2 = 'AsnComp.Ship_To_Address2';
export const Label_Ship_To_City = 'AsnComp.Ship_To_City';
export const Label_Ship_To_St = 'AsnComp.Ship_To_St';
export const Label_Ship_To_Zip = 'AsnComp.Ship_To_Zip';
export const Label_Quantity = 'AsnComp.Quantity';
export const Label_QtyPacked = 'AsnComp.QtyPacked';
export const Label_Price = 'AsnComp.Price';
export const Label_Del_Date = 'AsnComp.Del_Date';
export const Label_UnitofMeas = 'AsnComp.UnitofMeas';
export const Label_ShipToPeps = 'AsnComp.ShipToPeps';
export const Label_Bol_No = 'AsnComp.Bol_No';
export const Label_Pro_No = 'AsnComp.Pro_No';
export const Label_User1 = 'AsnComp.User1';
export const Label_User2 = 'AsnComp.User2';
export const Label_Trailer = 'AsnComp.Trailer';
export const Label_Collect = 'AsnComp.Collect';
