import { IAPIsacXRef } from '../edidb'
export class CAPIsacXRef implements IAPIsacXRef {
    public TP_Name:string = '';
    public SAC_Qual:string = '';
    public Int_Item_No:string = '';
    public TP_PartID:string = '';
    public constructor(init?:Partial<CAPIsacXRef>) { Object.assign(this, init); }
}
export const IAPIsacXRef_TP_Name_length = 30;
export const IAPIsacXRef_SAC_Qual_length = 4;
export const IAPIsacXRef_Int_Item_No_length = 500;
export const IAPIsacXRef_TP_PartID_length = 30;

export const kAPIsacXRef_TP_Name="TP_Name";
export const kAPIsacXRef_SAC_Qual="SAC_Qual";
export const kAPIsacXRef_Int_Item_No="Int_Item_No";
export const kAPIsacXRef_TP_PartID="TP_PartID";

/*
        'APIsacXRef' : {
            'TP_Name' : 'TP_Name',
            'SAC_Qual' : 'SAC_Qual',
            'Int_Item_No' : 'Int_Item_No',
            'TP_PartID' : 'TP_PartID',        },
*/

export const Label_TP_Name = 'APIsacXRef.TP_Name';
export const Label_SAC_Qual = 'APIsacXRef.SAC_Qual';
export const Label_Int_Item_No = 'APIsacXRef.Int_Item_No';
export const Label_TP_PartID = 'APIsacXRef.TP_PartID';
