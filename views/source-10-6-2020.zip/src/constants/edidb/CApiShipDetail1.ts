import { IApiShipDetail1 } from '../edidb'
export class CApiShipDetail1 implements IApiShipDetail1 {
    public Asn_ID:number = 0;
    public Bol_No:string = '';
    public Pro_No:string = '';
    public ShipToPeps:boolean;
    public Ship_Weight:number = 0;
    public Ship_Date:string = '';
    public Del_Date:string = '';
    public Ship_Via_ID:string = '';
    public Asn_Complete:string = '';
    public Exp_Flag:string = '';
    public TP_PartID:string = '';
    public User1:string = '';
    public User2:string = '';
    public Trailer:string = '';
    public Collect:boolean;
    public AckID:string = '';
    public GCN:number = 0;
    public TCN:number = 0;
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public SealNo:string = '';
    public ExportDate:Date;
    public CreatedDate:Date;
    public PackImport:string = '';
    public VPIDFA:number = 0;
    public TP_Name:string = '';
    public Ship_Via_Name:string = '';
    public Ship_Date_Full:Date;
    public Del_Date_Full:Date;
    public Exp:string = '';
    public AckDesc:string = '';
    public PackImportDesc:string = '';
    public constructor(init?:Partial<CApiShipDetail1>) { Object.assign(this, init); }
}
export const IApiShipDetail1_Bol_No_length = 30;
export const IApiShipDetail1_Pro_No_length = 30;
export const IApiShipDetail1_Ship_Date_length = 8;
export const IApiShipDetail1_Del_Date_length = 8;
export const IApiShipDetail1_Ship_Via_ID_length = 30;
export const IApiShipDetail1_Asn_Complete_length = 1;
export const IApiShipDetail1_Exp_Flag_length = 1;
export const IApiShipDetail1_TP_PartID_length = 30;
export const IApiShipDetail1_User1_length = 50;
export const IApiShipDetail1_User2_length = 50;
export const IApiShipDetail1_Trailer_length = 50;
export const IApiShipDetail1_AckID_length = 1;
export const IApiShipDetail1_User3_length = 50;
export const IApiShipDetail1_User4_length = 50;
export const IApiShipDetail1_User5_length = 50;
export const IApiShipDetail1_SealNo_length = 200;
export const IApiShipDetail1_PackImport_length = 1;
export const IApiShipDetail1_TP_Name_length = 30;
export const IApiShipDetail1_Ship_Via_Name_length = 30;
export const IApiShipDetail1_Exp_length = 500;
export const IApiShipDetail1_AckDesc_length = 10;
export const IApiShipDetail1_PackImportDesc_length = 500;

export const kApiShipDetail1_Asn_ID="Asn_ID";
export const kApiShipDetail1_Bol_No="Bol_No";
export const kApiShipDetail1_Pro_No="Pro_No";
export const kApiShipDetail1_ShipToPeps="ShipToPeps";
export const kApiShipDetail1_Ship_Weight="Ship_Weight";
export const kApiShipDetail1_Ship_Date="Ship_Date";
export const kApiShipDetail1_Del_Date="Del_Date";
export const kApiShipDetail1_Ship_Via_ID="Ship_Via_ID";
export const kApiShipDetail1_Asn_Complete="Asn_Complete";
export const kApiShipDetail1_Exp_Flag="Exp_Flag";
export const kApiShipDetail1_TP_PartID="TP_PartID";
export const kApiShipDetail1_User1="User1";
export const kApiShipDetail1_User2="User2";
export const kApiShipDetail1_Trailer="Trailer";
export const kApiShipDetail1_Collect="Collect";
export const kApiShipDetail1_AckID="AckID";
export const kApiShipDetail1_GCN="GCN";
export const kApiShipDetail1_TCN="TCN";
export const kApiShipDetail1_User3="User3";
export const kApiShipDetail1_User4="User4";
export const kApiShipDetail1_User5="User5";
export const kApiShipDetail1_SealNo="SealNo";
export const kApiShipDetail1_ExportDate="ExportDate";
export const kApiShipDetail1_CreatedDate="CreatedDate";
export const kApiShipDetail1_PackImport="PackImport";
export const kApiShipDetail1_VPIDFA="VPIDFA";
export const kApiShipDetail1_TP_Name="TP_Name";
export const kApiShipDetail1_Ship_Via_Name="Ship_Via_Name";
export const kApiShipDetail1_Ship_Date_Full="Ship_Date_Full";
export const kApiShipDetail1_Del_Date_Full="Del_Date_Full";
export const kApiShipDetail1_Exp="Exp";
export const kApiShipDetail1_AckDesc="AckDesc";
export const kApiShipDetail1_PackImportDesc="PackImportDesc";

/*
        'ApiShipDetail1' : {
            'Asn_ID' : 'Asn_ID',
            'Bol_No' : 'Bol_No',
            'Pro_No' : 'Pro_No',
            'ShipToPeps' : 'ShipToPeps',
            'Ship_Weight' : 'Ship_Weight',
            'Ship_Date' : 'Ship_Date',
            'Del_Date' : 'Del_Date',
            'Ship_Via_ID' : 'Ship_Via_ID',
            'Asn_Complete' : 'Asn_Complete',
            'Exp_Flag' : 'Exp_Flag',
            'TP_PartID' : 'TP_PartID',
            'User1' : 'User1',
            'User2' : 'User2',
            'Trailer' : 'Trailer',
            'Collect' : 'Collect',
            'AckID' : 'AckID',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'SealNo' : 'SealNo',
            'ExportDate' : 'ExportDate',
            'CreatedDate' : 'CreatedDate',
            'PackImport' : 'PackImport',
            'VPIDFA' : 'VPIDFA',
            'TP_Name' : 'TP_Name',
            'Ship_Via_Name' : 'Ship_Via_Name',
            'Ship_Date_Full' : 'Ship_Date_Full',
            'Del_Date_Full' : 'Del_Date_Full',
            'Exp' : 'Exp',
            'AckDesc' : 'AckDesc',
            'PackImportDesc' : 'PackImportDesc',        },
*/

export const Label_Asn_ID = 'ApiShipDetail1.Asn_ID';
export const Label_Bol_No = 'ApiShipDetail1.Bol_No';
export const Label_Pro_No = 'ApiShipDetail1.Pro_No';
export const Label_ShipToPeps = 'ApiShipDetail1.ShipToPeps';
export const Label_Ship_Weight = 'ApiShipDetail1.Ship_Weight';
export const Label_Ship_Date = 'ApiShipDetail1.Ship_Date';
export const Label_Del_Date = 'ApiShipDetail1.Del_Date';
export const Label_Ship_Via_ID = 'ApiShipDetail1.Ship_Via_ID';
export const Label_Asn_Complete = 'ApiShipDetail1.Asn_Complete';
export const Label_Exp_Flag = 'ApiShipDetail1.Exp_Flag';
export const Label_TP_PartID = 'ApiShipDetail1.TP_PartID';
export const Label_User1 = 'ApiShipDetail1.User1';
export const Label_User2 = 'ApiShipDetail1.User2';
export const Label_Trailer = 'ApiShipDetail1.Trailer';
export const Label_Collect = 'ApiShipDetail1.Collect';
export const Label_AckID = 'ApiShipDetail1.AckID';
export const Label_GCN = 'ApiShipDetail1.GCN';
export const Label_TCN = 'ApiShipDetail1.TCN';
export const Label_User3 = 'ApiShipDetail1.User3';
export const Label_User4 = 'ApiShipDetail1.User4';
export const Label_User5 = 'ApiShipDetail1.User5';
export const Label_SealNo = 'ApiShipDetail1.SealNo';
export const Label_ExportDate = 'ApiShipDetail1.ExportDate';
export const Label_CreatedDate = 'ApiShipDetail1.CreatedDate';
export const Label_PackImport = 'ApiShipDetail1.PackImport';
export const Label_VPIDFA = 'ApiShipDetail1.VPIDFA';
export const Label_TP_Name = 'ApiShipDetail1.TP_Name';
export const Label_Ship_Via_Name = 'ApiShipDetail1.Ship_Via_Name';
export const Label_Ship_Date_Full = 'ApiShipDetail1.Ship_Date_Full';
export const Label_Del_Date_Full = 'ApiShipDetail1.Del_Date_Full';
export const Label_Exp = 'ApiShipDetail1.Exp';
export const Label_AckDesc = 'ApiShipDetail1.AckDesc';
export const Label_PackImportDesc = 'ApiShipDetail1.PackImportDesc';
