import { IApiFABaseView } from '../edidb'
export class CApiFABaseView implements IApiFABaseView {
    public FA_ID:number = 0;
    public TP_Name:string = '';
    public ISA08:string = '';
    public ISA09:string = '';
    public ISA13:string = '';
    public Direction:string = '';
    public AK101:string = '';
    public AK102:string = '';
    public Exp_Flag:string = '';
    public status:string = '';
    public constructor(init?:Partial<CApiFABaseView>) { Object.assign(this, init); }
}
export const IApiFABaseView_TP_Name_length = 30;
export const IApiFABaseView_ISA08_length = 15;
export const IApiFABaseView_ISA09_length = 8;
export const IApiFABaseView_ISA13_length = 9;
export const IApiFABaseView_Direction_length = 1;
export const IApiFABaseView_AK101_length = 2;
export const IApiFABaseView_AK102_length = 9;
export const IApiFABaseView_Exp_Flag_length = 1;
export const IApiFABaseView_status_length = 500;

export const kApiFABaseView_FA_ID="FA_ID";
export const kApiFABaseView_TP_Name="TP_Name";
export const kApiFABaseView_ISA08="ISA08";
export const kApiFABaseView_ISA09="ISA09";
export const kApiFABaseView_ISA13="ISA13";
export const kApiFABaseView_Direction="Direction";
export const kApiFABaseView_AK101="AK101";
export const kApiFABaseView_AK102="AK102";
export const kApiFABaseView_Exp_Flag="Exp_Flag";
export const kApiFABaseView_status="status";

/*
        'ApiFABaseView' : {
            'FA_ID' : 'FA_ID',
            'TP_Name' : 'TP_Name',
            'ISA08' : 'ISA08',
            'ISA09' : 'ISA09',
            'ISA13' : 'ISA13',
            'Direction' : 'Direction',
            'AK101' : 'AK101',
            'AK102' : 'AK102',
            'Exp_Flag' : 'Exp_Flag',
            'status' : 'status',        },
*/

export const Label_FA_ID = 'ApiFABaseView.FA_ID';
export const Label_TP_Name = 'ApiFABaseView.TP_Name';
export const Label_ISA08 = 'ApiFABaseView.ISA08';
export const Label_ISA09 = 'ApiFABaseView.ISA09';
export const Label_ISA13 = 'ApiFABaseView.ISA13';
export const Label_Direction = 'ApiFABaseView.Direction';
export const Label_AK101 = 'ApiFABaseView.AK101';
export const Label_AK102 = 'ApiFABaseView.AK102';
export const Label_Exp_Flag = 'ApiFABaseView.Exp_Flag';
export const Label_status = 'ApiFABaseView.status';
