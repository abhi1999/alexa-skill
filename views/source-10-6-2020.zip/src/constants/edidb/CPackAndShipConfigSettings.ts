import { IPackAndShipConfigSettings  } from '../edidb'

export class CPackAndShipConfigSettings implements IPackAndShipConfigSettings {
  
    public AllowOverPacking: boolean = false;
    public AllowUnderPacking: boolean = false;
    public DefaultHidePackedChecked: boolean = false;
    public DefaultSortByItemChecked: boolean = false;

    public constructor(init?:Partial<CPackAndShipConfigSettings>) { Object.assign(this, init); }
}

// export const IPackAndShip_Order_No_length = 30;
// export const IPackAndShip_Acct_Order_No_length = 30;
// export const IPackAndShip_Level_0_Package_Type_length = 50;
// export const IPackAndShip_Order_Weight_length = 30;
// export const IPackAndShip_Pack_Level_0_Count_length = 30;
// export const IPackAndShip_Pack_Level_1_Count_length = 30;
// export const IPackAndShip_Pack_Level_2_Count_length = 30;

// export const kPackAndShip_Order_No = 'Order_No';
// export const kPackAndShip_Acct_Order_No = 'Acct_Order_No';
// export const kPackAndShip_Level_0_Package_Type = 'Level_0_Package_Type';
// export const kPackAndShip_Order_Weight = 'Order_Weight';
// export const kPackAndShip_Pack_Level_0_Count = 'Pack_Level_0_Count';
// export const kPackAndShip_Pack_Level_1_Count = 'Pack_Level_1_Count';
// export const kPackAndShip_Pack_Level_2_Count = 'Pack_Level_2_Count';

// export const Label_Order_No = 'PackAndShip.Order_No';
// export const Label_Acct_Order_No = 'PackAndShip.ERP_Order_No';
// export const Label_Level_0_Package_Type = 'PackAndShip.Level_0_Package_Type';
// export const Label_Order_Weight = 'PackAndShip.Order_Weight';
// export const Label_Pack_Level_0_Count = 'PackAndShip.Pack_Level_0_Count';
// export const Label_Pack_Level_1_Count = 'PackAndShip.Pack_Level_1_Count';
// export const Label_Pack_Level_2_Count = 'PackAndShip.Pack_Level_2_Count';
