import { IProcess } from '../edidb'
export class CProcess implements IProcess {
    public procid:string = '';
    public procname:string = '';
    public constructor(init?:Partial<CProcess>) { Object.assign(this, init); }
}
export const IProcess_procid_length = 20;
export const IProcess_procname_length = 50;

export const kProcess_procid="procid";
export const kProcess_procname="procname";

/*
        'Process' : {
            'procid' : 'procid',
            'procname' : 'procname',        },
*/

export const Label_procid = 'Process.procid';
export const Label_procname = 'Process.procname';
