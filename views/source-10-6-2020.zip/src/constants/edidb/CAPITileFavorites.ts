import { IAPITileFavorites } from '../edidb'
export class CAPITileFavorites implements IAPITileFavorites {
    public quantity:number = 0;
    public Caption:string = '';
    public GroupTile:string = '';
    public GroupName:string = '';
    public ControlID:number = 0;
    public ControlName:string = '';
    public MethodCall:string = '';
    public ImageFile:string = '';
    public func_code:string = '';
    public MethodParams:string = '';
    public Type:string = '';
    public BeginGroup:boolean;
    public GroupColor:string = '';
    public FavGroupID:number = 0;
    public FavID:number = 0;
    public FavGroupOrder:number = 0;
    public FavOrder:number = 0;
    public ControlEnabled:boolean;
    public ControlVisible:boolean;
    public OrigCaption:string = '';
    public IsFavorite:number = 0;
    public constructor(init?:Partial<CAPITileFavorites>) { Object.assign(this, init); }
}
export const IAPITileFavorites_Caption_length = 100;
export const IAPITileFavorites_GroupTile_length = 9;
export const IAPITileFavorites_GroupName_length = 50;
export const IAPITileFavorites_ControlName_length = 200;
export const IAPITileFavorites_MethodCall_length = 500;
export const IAPITileFavorites_ImageFile_length = 500;
export const IAPITileFavorites_func_code_length = 3;
export const IAPITileFavorites_MethodParams_length = 1000;
export const IAPITileFavorites_Type_length = 50;
export const IAPITileFavorites_GroupColor_length = 50;
export const IAPITileFavorites_OrigCaption_length = 404;

export const kAPITileFavorites_quantity="quantity";
export const kAPITileFavorites_Caption="Caption";
export const kAPITileFavorites_GroupTile="GroupTile";
export const kAPITileFavorites_GroupName="GroupName";
export const kAPITileFavorites_ControlID="ControlID";
export const kAPITileFavorites_ControlName="ControlName";
export const kAPITileFavorites_MethodCall="MethodCall";
export const kAPITileFavorites_ImageFile="ImageFile";
export const kAPITileFavorites_func_code="func_code";
export const kAPITileFavorites_MethodParams="MethodParams";
export const kAPITileFavorites_Type="Type";
export const kAPITileFavorites_BeginGroup="BeginGroup";
export const kAPITileFavorites_GroupColor="GroupColor";
export const kAPITileFavorites_FavGroupID="FavGroupID";
export const kAPITileFavorites_FavID="FavID";
export const kAPITileFavorites_FavGroupOrder="FavGroupOrder";
export const kAPITileFavorites_FavOrder="FavOrder";
export const kAPITileFavorites_ControlEnabled="ControlEnabled";
export const kAPITileFavorites_ControlVisible="ControlVisible";
export const kAPITileFavorites_OrigCaption="OrigCaption";
export const kAPITileFavorites_IsFavorite="IsFavorite";

/*
        'APITileFavorites' : {
            'quantity' : 'quantity',
            'Caption' : 'Caption',
            'GroupTile' : 'GroupTile',
            'GroupName' : 'GroupName',
            'ControlID' : 'ControlID',
            'ControlName' : 'ControlName',
            'MethodCall' : 'MethodCall',
            'ImageFile' : 'ImageFile',
            'func_code' : 'func_code',
            'MethodParams' : 'MethodParams',
            'Type' : 'Type',
            'BeginGroup' : 'BeginGroup',
            'GroupColor' : 'GroupColor',
            'FavGroupID' : 'FavGroupID',
            'FavID' : 'FavID',
            'FavGroupOrder' : 'FavGroupOrder',
            'FavOrder' : 'FavOrder',
            'ControlEnabled' : 'ControlEnabled',
            'ControlVisible' : 'ControlVisible',
            'OrigCaption' : 'OrigCaption',
            'IsFavorite' : 'IsFavorite',        },
*/

export const Label_quantity = 'APITileFavorites.quantity';
export const Label_Caption = 'APITileFavorites.Caption';
export const Label_GroupTile = 'APITileFavorites.GroupTile';
export const Label_GroupName = 'APITileFavorites.GroupName';
export const Label_ControlID = 'APITileFavorites.ControlID';
export const Label_ControlName = 'APITileFavorites.ControlName';
export const Label_MethodCall = 'APITileFavorites.MethodCall';
export const Label_ImageFile = 'APITileFavorites.ImageFile';
export const Label_func_code = 'APITileFavorites.func_code';
export const Label_MethodParams = 'APITileFavorites.MethodParams';
export const Label_Type = 'APITileFavorites.Type';
export const Label_BeginGroup = 'APITileFavorites.BeginGroup';
export const Label_GroupColor = 'APITileFavorites.GroupColor';
export const Label_FavGroupID = 'APITileFavorites.FavGroupID';
export const Label_FavID = 'APITileFavorites.FavID';
export const Label_FavGroupOrder = 'APITileFavorites.FavGroupOrder';
export const Label_FavOrder = 'APITileFavorites.FavOrder';
export const Label_ControlEnabled = 'APITileFavorites.ControlEnabled';
export const Label_ControlVisible = 'APITileFavorites.ControlVisible';
export const Label_OrigCaption = 'APITileFavorites.OrigCaption';
export const Label_IsFavorite = 'APITileFavorites.IsFavorite';
