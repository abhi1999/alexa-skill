import { IAuditDetailXmlDoc } from '../edidb'
export class CAuditDetailXmlDoc implements IAuditDetailXmlDoc {
  
  public AuditDetailXmlDocID: number = 0;
  public AuditDetailID: number = 0;
  public OldValueName:string = '';
  public NewValueName:string = '';
  public OldValue:string = '';
  public NewValue: string = '';
  public DetailDescription: string = '';
  
  public constructor(init?:Partial<CAuditDetailXmlDoc>) { Object.assign(this, init); }
}

export const IAuditDetailXmlDoc_AuditDetailID_length = 30;
export const IAuditDetailXmlDoc_AuditID_length = 30;
export const IAuditDetailXmlDoc_OldValueName_length = 50;
export const IAuditDetailXmlDoc_NewValueName_length = 50;
export const IAuditDetailXmlDoc_OldValue_length = 50;
export const IAuditDetailXmlDoc_NewValue_length = 50;
export const IAuditDetailXmlDoc_DetailDescription_length = 50;

export const kAuditDetailXmlDoc_AuditDetailID = 'AuditDetailID';
export const kAuditDetailXmlDoc_AuditID = 'AuditID';
export const kAuditDetailXmlDoc_OldValueName = 'OldValueName';
export const kAuditDetailXmlDoc_NewValueName = 'NewValueName';
export const kAuditDetailXmlDoc_OldValue = 'OldValue';
export const kAuditDetailXmlDoc_NewValue = 'NewValue';
export const kAuditDetailXmlDoc_DetailDescription = 'DetailDescription';

export const Label_AuditDetailXmlDocID = 'AuditViewer.AuditDetailXmlDocID';
export const Label_AuditDetailID = 'AuditViewer.AuditDetailID';
export const Label_OldValueName = 'AuditViewer.OldValueName';
export const Label_NewValueName = 'AuditViewer.NewValueName';
export const Label_OldValue = 'AuditViewer.OldValue';
export const Label_NewValue = 'AuditViewer.NewValue';
export const Label_DetailDescription = 'AuditViewer.DetailDescription';

