import { IApiTradeOrderLin } from '../edidb'
export class CApiTradeOrderLin implements IApiTradeOrderLin {
    public Order_No:number = 0;
    public Line_No:number = 0;
    public TP_ID:string = '';
    public Order_Date:Date;
    public Int_Item_No:string = '';
    public Quantity:number = 0;
    public QtyRecvd:number = 0;
    public POPrice:number = 0;
    public DateLastRecvd:Date;
    public QtyInv:number = 0;
    public DateLastInv:Date;
    public Stat_Flag:string = '';
    public Inv_Stat_Flag:string = '';
    public Loc_ID:string = '';
    public TP_Name:string = '';
    public constructor(init?:Partial<CApiTradeOrderLin>) { Object.assign(this, init); }
}
export const IApiTradeOrderLin_TP_ID_length = 30;
export const IApiTradeOrderLin_Int_Item_No_length = 500;
export const IApiTradeOrderLin_Stat_Flag_length = 1;
export const IApiTradeOrderLin_Inv_Stat_Flag_length = 1;
export const IApiTradeOrderLin_Loc_ID_length = 10;
export const IApiTradeOrderLin_TP_Name_length = 30;

export const kApiTradeOrderLin_Order_No="Order_No";
export const kApiTradeOrderLin_Line_No="Line_No";
export const kApiTradeOrderLin_TP_ID="TP_ID";
export const kApiTradeOrderLin_Order_Date="Order_Date";
export const kApiTradeOrderLin_Int_Item_No="Int_Item_No";
export const kApiTradeOrderLin_Quantity="Quantity";
export const kApiTradeOrderLin_QtyRecvd="QtyRecvd";
export const kApiTradeOrderLin_POPrice="POPrice";
export const kApiTradeOrderLin_DateLastRecvd="DateLastRecvd";
export const kApiTradeOrderLin_QtyInv="QtyInv";
export const kApiTradeOrderLin_DateLastInv="DateLastInv";
export const kApiTradeOrderLin_Stat_Flag="Stat_Flag";
export const kApiTradeOrderLin_Inv_Stat_Flag="Inv_Stat_Flag";
export const kApiTradeOrderLin_Loc_ID="Loc_ID";
export const kApiTradeOrderLin_TP_Name="TP_Name";

/*
        'ApiTradeOrderLin' : {
            'Order_No' : 'Order_No',
            'Line_No' : 'Line_No',
            'TP_ID' : 'TP_ID',
            'Order_Date' : 'Order_Date',
            'Int_Item_No' : 'Int_Item_No',
            'Quantity' : 'Quantity',
            'QtyRecvd' : 'QtyRecvd',
            'POPrice' : 'POPrice',
            'DateLastRecvd' : 'DateLastRecvd',
            'QtyInv' : 'QtyInv',
            'DateLastInv' : 'DateLastInv',
            'Stat_Flag' : 'Stat_Flag',
            'Inv_Stat_Flag' : 'Inv_Stat_Flag',
            'Loc_ID' : 'Loc_ID',
            'TP_Name' : 'TP_Name',        },
*/

export const Label_Order_No = 'ApiTradeOrderLin.Order_No';
export const Label_Line_No = 'ApiTradeOrderLin.Line_No';
export const Label_TP_ID = 'ApiTradeOrderLin.TP_ID';
export const Label_Order_Date = 'ApiTradeOrderLin.Order_Date';
export const Label_Int_Item_No = 'ApiTradeOrderLin.Int_Item_No';
export const Label_Quantity = 'ApiTradeOrderLin.Quantity';
export const Label_QtyRecvd = 'ApiTradeOrderLin.QtyRecvd';
export const Label_POPrice = 'ApiTradeOrderLin.POPrice';
export const Label_DateLastRecvd = 'ApiTradeOrderLin.DateLastRecvd';
export const Label_QtyInv = 'ApiTradeOrderLin.QtyInv';
export const Label_DateLastInv = 'ApiTradeOrderLin.DateLastInv';
export const Label_Stat_Flag = 'ApiTradeOrderLin.Stat_Flag';
export const Label_Inv_Stat_Flag = 'ApiTradeOrderLin.Inv_Stat_Flag';
export const Label_Loc_ID = 'ApiTradeOrderLin.Loc_ID';
export const Label_TP_Name = 'ApiTradeOrderLin.TP_Name';
