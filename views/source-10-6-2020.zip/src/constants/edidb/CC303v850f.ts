import { IC303v850f } from '../edidb'
export class CC303v850f implements IC303v850f {
    public PO_ID:number = 0;
    public PO1_LineNo:string = '';
    public SAC_Ind:string = '';
    public SAC_Code:string = '';
    public Agency_Qual:string = '';
    public Agency_SAC_Code:string = '';
    public Amt:number = 0;
    public SAC_Pct_Qual:string = '';
    public Pct:number = 0;
    public Rate:number = 0;
    public Uom:string = '';
    public Qty_1:number = 0;
    public Qty_2:number = 0;
    public SAC_Handling_Meth:string = '';
    public Ref_ID:string = '';
    public Opt_No:string = '';
    public Desc:string = '';
    public Qty_Used:number = 0;
    public URECID:string = '';
    public constructor(init?:Partial<CC303v850f>) { Object.assign(this, init); }
}
export const IC303v850f_PO1_LineNo_length = 11;
export const IC303v850f_SAC_Ind_length = 1;
export const IC303v850f_SAC_Code_length = 4;
export const IC303v850f_Agency_Qual_length = 2;
export const IC303v850f_Agency_SAC_Code_length = 16;
export const IC303v850f_SAC_Pct_Qual_length = 1;
export const IC303v850f_Uom_length = 2;
export const IC303v850f_SAC_Handling_Meth_length = 2;
export const IC303v850f_Ref_ID_length = 50;
export const IC303v850f_Opt_No_length = 20;
export const IC303v850f_Desc_length = 80;

export const kC303v850f_PO_ID="PO_ID";
export const kC303v850f_PO1_LineNo="PO1_LineNo";
export const kC303v850f_SAC_Ind="SAC_Ind";
export const kC303v850f_SAC_Code="SAC_Code";
export const kC303v850f_Agency_Qual="Agency_Qual";
export const kC303v850f_Agency_SAC_Code="Agency_SAC_Code";
export const kC303v850f_Amt="Amt";
export const kC303v850f_SAC_Pct_Qual="SAC_Pct_Qual";
export const kC303v850f_Pct="Pct";
export const kC303v850f_Rate="Rate";
export const kC303v850f_Uom="Uom";
export const kC303v850f_Qty_1="Qty_1";
export const kC303v850f_Qty_2="Qty_2";
export const kC303v850f_SAC_Handling_Meth="SAC_Handling_Meth";
export const kC303v850f_Ref_ID="Ref_ID";
export const kC303v850f_Opt_No="Opt_No";
export const kC303v850f_Desc="Desc";
export const kC303v850f_Qty_Used="Qty_Used";
export const kC303v850f_URECID="URECID";

/*
        'C303v850f' : {
            'PO_ID' : 'PO_ID',
            'PO1_LineNo' : 'PO1_LineNo',
            'SAC_Ind' : 'SAC_Ind',
            'SAC_Code' : 'SAC_Code',
            'Agency_Qual' : 'Agency_Qual',
            'Agency_SAC_Code' : 'Agency_SAC_Code',
            'Amt' : 'Amt',
            'SAC_Pct_Qual' : 'SAC_Pct_Qual',
            'Pct' : 'Pct',
            'Rate' : 'Rate',
            'Uom' : 'Uom',
            'Qty_1' : 'Qty_1',
            'Qty_2' : 'Qty_2',
            'SAC_Handling_Meth' : 'SAC_Handling_Meth',
            'Ref_ID' : 'Ref_ID',
            'Opt_No' : 'Opt_No',
            'Desc' : 'Desc',
            'Qty_Used' : 'Qty_Used',
            'URECID' : 'URECID',        },
*/

export const Label_PO_ID = 'C303v850f.PO_ID';
export const Label_PO1_LineNo = 'C303v850f.PO1_LineNo';
export const Label_SAC_Ind = 'C303v850f.SAC_Ind';
export const Label_SAC_Code = 'C303v850f.SAC_Code';
export const Label_Agency_Qual = 'C303v850f.Agency_Qual';
export const Label_Agency_SAC_Code = 'C303v850f.Agency_SAC_Code';
export const Label_Amt = 'C303v850f.Amt';
export const Label_SAC_Pct_Qual = 'C303v850f.SAC_Pct_Qual';
export const Label_Pct = 'C303v850f.Pct';
export const Label_Rate = 'C303v850f.Rate';
export const Label_Uom = 'C303v850f.Uom';
export const Label_Qty_1 = 'C303v850f.Qty_1';
export const Label_Qty_2 = 'C303v850f.Qty_2';
export const Label_SAC_Handling_Meth = 'C303v850f.SAC_Handling_Meth';
export const Label_Ref_ID = 'C303v850f.Ref_ID';
export const Label_Opt_No = 'C303v850f.Opt_No';
export const Label_Desc = 'C303v850f.Desc';
export const Label_Qty_Used = 'C303v850f.Qty_Used';
export const Label_URECID = 'C303v850f.URECID';
