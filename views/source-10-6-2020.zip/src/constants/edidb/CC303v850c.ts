import { IC303v850c } from '../edidb'
export class CC303v850c implements IC303v850c {
    public PO_ID:number = 0;
    public PO1_LineNo:string = '';
    public Seq_No:number = 0;
    public Msg:string = '';
    public constructor(init?:Partial<CC303v850c>) { Object.assign(this, init); }
}
export const IC303v850c_PO1_LineNo_length = 11;
export const IC303v850c_Msg_length = 80;

export const kC303v850c_PO_ID="PO_ID";
export const kC303v850c_PO1_LineNo="PO1_LineNo";
export const kC303v850c_Seq_No="Seq_No";
export const kC303v850c_Msg="Msg";

/*
        'C303v850c' : {
            'PO_ID' : 'PO_ID',
            'PO1_LineNo' : 'PO1_LineNo',
            'Seq_No' : 'Seq_No',
            'Msg' : 'Msg',        },
*/

export const Label_PO_ID = 'C303v850c.PO_ID';
export const Label_PO1_LineNo = 'C303v850c.PO1_LineNo';
export const Label_Seq_No = 'C303v850c.Seq_No';
export const Label_Msg = 'C303v850c.Msg';
