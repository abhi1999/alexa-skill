import { IProdSeqItm } from '../edidb'
export class CProdSeqItm implements IProdSeqItm {
    public PSIID:string = '';
    public PSHID:string = '';
    public VPID:number = 0;
    public processtype:string = '';
    public processdate:Date;
    public itmdocline:number = 0;
    public fcdocline:number = 0;
    public fcqual:string = '';
    public fctqual:string = '';
    public fcqty:number = 0;
    public fcdate1:string = '';
    public fcdate2:string = '';
    public fcdtqual:string = '';
    public fcdtid:string = '';
    public itemuom:string = '';
    public importdate:Date;
    public status:string = '';
    public price:number = 0;
    public custitemno:string = '';
    public po:string = '';
    public poline:string = '';
    public shipto:string = '';
    public shipfrom:string = '';
    public supplier:string = '';
    public psdoctype:string = '';
    public tp_partid:string = '';
    public tp_id:string = '';
    public releaseno:string = '';
    public dlvdate:string = '';
    public shipdate:string = '';
    public dock:string = '';
    public linefeed:string = '';
    public vin:string = '';
    public jobseqno:string = '';
    public jobno:string = '';
    public laborgrp:string = '';
    public commodity:string = '';
    public linesetno:string = '';
    public storageid:string = '';
    public assembly:string = '';
    public engchg:string = '';
    public chassissn:string = '';
    public color:string = '';
    public position:string = '';
    public ctlno:string = '';
    public producttype:string = '';
    public kanban:string = '';
    public custorderno:string = '';
    public proddesc:string = '';
    public pscreatedate:string = '';
    public GSSenderID:string = '';
    public constructor(init?:Partial<CProdSeqItm>) { Object.assign(this, init); }
}
export const IProdSeqItm_processtype_length = 2;
export const IProdSeqItm_fcqual_length = 1;
export const IProdSeqItm_fctqual_length = 1;
export const IProdSeqItm_fcdate1_length = 8;
export const IProdSeqItm_fcdate2_length = 8;
export const IProdSeqItm_fcdtqual_length = 3;
export const IProdSeqItm_fcdtid_length = 8;
export const IProdSeqItm_itemuom_length = 10;
export const IProdSeqItm_status_length = 1;
export const IProdSeqItm_custitemno_length = 30;
export const IProdSeqItm_po_length = 30;
export const IProdSeqItm_poline_length = 10;
export const IProdSeqItm_shipto_length = 30;
export const IProdSeqItm_shipfrom_length = 30;
export const IProdSeqItm_supplier_length = 30;
export const IProdSeqItm_psdoctype_length = 2;
export const IProdSeqItm_tp_partid_length = 30;
export const IProdSeqItm_tp_id_length = 15;
export const IProdSeqItm_releaseno_length = 30;
export const IProdSeqItm_dlvdate_length = 8;
export const IProdSeqItm_shipdate_length = 8;
export const IProdSeqItm_dock_length = 30;
export const IProdSeqItm_linefeed_length = 30;
export const IProdSeqItm_vin_length = 30;
export const IProdSeqItm_jobseqno_length = 30;
export const IProdSeqItm_jobno_length = 30;
export const IProdSeqItm_laborgrp_length = 30;
export const IProdSeqItm_commodity_length = 30;
export const IProdSeqItm_linesetno_length = 30;
export const IProdSeqItm_storageid_length = 30;
export const IProdSeqItm_assembly_length = 30;
export const IProdSeqItm_engchg_length = 30;
export const IProdSeqItm_chassissn_length = 30;
export const IProdSeqItm_color_length = 30;
export const IProdSeqItm_position_length = 30;
export const IProdSeqItm_ctlno_length = 30;
export const IProdSeqItm_producttype_length = 30;
export const IProdSeqItm_kanban_length = 30;
export const IProdSeqItm_custorderno_length = 50;
export const IProdSeqItm_proddesc_length = 50;
export const IProdSeqItm_pscreatedate_length = 30;
export const IProdSeqItm_GSSenderID_length = 50;

export const kProdSeqItm_PSIID="PSIID";
export const kProdSeqItm_PSHID="PSHID";
export const kProdSeqItm_VPID="VPID";
export const kProdSeqItm_processtype="processtype";
export const kProdSeqItm_processdate="processdate";
export const kProdSeqItm_itmdocline="itmdocline";
export const kProdSeqItm_fcdocline="fcdocline";
export const kProdSeqItm_fcqual="fcqual";
export const kProdSeqItm_fctqual="fctqual";
export const kProdSeqItm_fcqty="fcqty";
export const kProdSeqItm_fcdate1="fcdate1";
export const kProdSeqItm_fcdate2="fcdate2";
export const kProdSeqItm_fcdtqual="fcdtqual";
export const kProdSeqItm_fcdtid="fcdtid";
export const kProdSeqItm_itemuom="itemuom";
export const kProdSeqItm_importdate="importdate";
export const kProdSeqItm_status="status";
export const kProdSeqItm_price="price";
export const kProdSeqItm_custitemno="custitemno";
export const kProdSeqItm_po="po";
export const kProdSeqItm_poline="poline";
export const kProdSeqItm_shipto="shipto";
export const kProdSeqItm_shipfrom="shipfrom";
export const kProdSeqItm_supplier="supplier";
export const kProdSeqItm_psdoctype="psdoctype";
export const kProdSeqItm_tp_partid="tp_partid";
export const kProdSeqItm_tp_id="tp_id";
export const kProdSeqItm_releaseno="releaseno";
export const kProdSeqItm_dlvdate="dlvdate";
export const kProdSeqItm_shipdate="shipdate";
export const kProdSeqItm_dock="dock";
export const kProdSeqItm_linefeed="linefeed";
export const kProdSeqItm_vin="vin";
export const kProdSeqItm_jobseqno="jobseqno";
export const kProdSeqItm_jobno="jobno";
export const kProdSeqItm_laborgrp="laborgrp";
export const kProdSeqItm_commodity="commodity";
export const kProdSeqItm_linesetno="linesetno";
export const kProdSeqItm_storageid="storageid";
export const kProdSeqItm_assembly="assembly";
export const kProdSeqItm_engchg="engchg";
export const kProdSeqItm_chassissn="chassissn";
export const kProdSeqItm_color="color";
export const kProdSeqItm_position="position";
export const kProdSeqItm_ctlno="ctlno";
export const kProdSeqItm_producttype="producttype";
export const kProdSeqItm_kanban="kanban";
export const kProdSeqItm_custorderno="custorderno";
export const kProdSeqItm_proddesc="proddesc";
export const kProdSeqItm_pscreatedate="pscreatedate";
export const kProdSeqItm_GSSenderID="GSSenderID";

/*
        'ProdSeqItm' : {
            'PSIID' : 'PSIID',
            'PSHID' : 'PSHID',
            'VPID' : 'VPID',
            'processtype' : 'processtype',
            'processdate' : 'processdate',
            'itmdocline' : 'itmdocline',
            'fcdocline' : 'fcdocline',
            'fcqual' : 'fcqual',
            'fctqual' : 'fctqual',
            'fcqty' : 'fcqty',
            'fcdate1' : 'fcdate1',
            'fcdate2' : 'fcdate2',
            'fcdtqual' : 'fcdtqual',
            'fcdtid' : 'fcdtid',
            'itemuom' : 'itemuom',
            'importdate' : 'importdate',
            'status' : 'status',
            'price' : 'price',
            'custitemno' : 'custitemno',
            'po' : 'po',
            'poline' : 'poline',
            'shipto' : 'shipto',
            'shipfrom' : 'shipfrom',
            'supplier' : 'supplier',
            'psdoctype' : 'psdoctype',
            'tp_partid' : 'tp_partid',
            'tp_id' : 'tp_id',
            'releaseno' : 'releaseno',
            'dlvdate' : 'dlvdate',
            'shipdate' : 'shipdate',
            'dock' : 'dock',
            'linefeed' : 'linefeed',
            'vin' : 'vin',
            'jobseqno' : 'jobseqno',
            'jobno' : 'jobno',
            'laborgrp' : 'laborgrp',
            'commodity' : 'commodity',
            'linesetno' : 'linesetno',
            'storageid' : 'storageid',
            'assembly' : 'assembly',
            'engchg' : 'engchg',
            'chassissn' : 'chassissn',
            'color' : 'color',
            'position' : 'position',
            'ctlno' : 'ctlno',
            'producttype' : 'producttype',
            'kanban' : 'kanban',
            'custorderno' : 'custorderno',
            'proddesc' : 'proddesc',
            'pscreatedate' : 'pscreatedate',
            'GSSenderID' : 'GSSenderID',        },
*/

export const Label_PSIID = 'ProdSeqItm.PSIID';
export const Label_PSHID = 'ProdSeqItm.PSHID';
export const Label_VPID = 'ProdSeqItm.VPID';
export const Label_processtype = 'ProdSeqItm.processtype';
export const Label_processdate = 'ProdSeqItm.processdate';
export const Label_itmdocline = 'ProdSeqItm.itmdocline';
export const Label_fcdocline = 'ProdSeqItm.fcdocline';
export const Label_fcqual = 'ProdSeqItm.fcqual';
export const Label_fctqual = 'ProdSeqItm.fctqual';
export const Label_fcqty = 'ProdSeqItm.fcqty';
export const Label_fcdate1 = 'ProdSeqItm.fcdate1';
export const Label_fcdate2 = 'ProdSeqItm.fcdate2';
export const Label_fcdtqual = 'ProdSeqItm.fcdtqual';
export const Label_fcdtid = 'ProdSeqItm.fcdtid';
export const Label_itemuom = 'ProdSeqItm.itemuom';
export const Label_importdate = 'ProdSeqItm.importdate';
export const Label_status = 'ProdSeqItm.status';
export const Label_price = 'ProdSeqItm.price';
export const Label_custitemno = 'ProdSeqItm.custitemno';
export const Label_po = 'ProdSeqItm.po';
export const Label_poline = 'ProdSeqItm.poline';
export const Label_shipto = 'ProdSeqItm.shipto';
export const Label_shipfrom = 'ProdSeqItm.shipfrom';
export const Label_supplier = 'ProdSeqItm.supplier';
export const Label_psdoctype = 'ProdSeqItm.psdoctype';
export const Label_tp_partid = 'ProdSeqItm.tp_partid';
export const Label_tp_id = 'ProdSeqItm.tp_id';
export const Label_releaseno = 'ProdSeqItm.releaseno';
export const Label_dlvdate = 'ProdSeqItm.dlvdate';
export const Label_shipdate = 'ProdSeqItm.shipdate';
export const Label_dock = 'ProdSeqItm.dock';
export const Label_linefeed = 'ProdSeqItm.linefeed';
export const Label_vin = 'ProdSeqItm.vin';
export const Label_jobseqno = 'ProdSeqItm.jobseqno';
export const Label_jobno = 'ProdSeqItm.jobno';
export const Label_laborgrp = 'ProdSeqItm.laborgrp';
export const Label_commodity = 'ProdSeqItm.commodity';
export const Label_linesetno = 'ProdSeqItm.linesetno';
export const Label_storageid = 'ProdSeqItm.storageid';
export const Label_assembly = 'ProdSeqItm.assembly';
export const Label_engchg = 'ProdSeqItm.engchg';
export const Label_chassissn = 'ProdSeqItm.chassissn';
export const Label_color = 'ProdSeqItm.color';
export const Label_position = 'ProdSeqItm.position';
export const Label_ctlno = 'ProdSeqItm.ctlno';
export const Label_producttype = 'ProdSeqItm.producttype';
export const Label_kanban = 'ProdSeqItm.kanban';
export const Label_custorderno = 'ProdSeqItm.custorderno';
export const Label_proddesc = 'ProdSeqItm.proddesc';
export const Label_pscreatedate = 'ProdSeqItm.pscreatedate';
export const Label_GSSenderID = 'ProdSeqItm.GSSenderID';
