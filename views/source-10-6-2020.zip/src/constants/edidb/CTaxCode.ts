import { ITaxCode } from '../edidb'
export class CTaxCode implements ITaxCode {
    public Tax_Xref:string = '';
    public TP_PartID:string = '';
    public EDI_TaxQual:string = '';
    public EDI_TaxCode:string = '';
    public EDI_TaxDesc:string = '';
    public constructor(init?:Partial<CTaxCode>) { Object.assign(this, init); }
}
export const ITaxCode_Tax_Xref_length = 10;
export const ITaxCode_TP_PartID_length = 30;
export const ITaxCode_EDI_TaxQual_length = 10;
export const ITaxCode_EDI_TaxCode_length = 10;
export const ITaxCode_EDI_TaxDesc_length = 30;

export const kTaxCode_Tax_Xref="Tax_Xref";
export const kTaxCode_TP_PartID="TP_PartID";
export const kTaxCode_EDI_TaxQual="EDI_TaxQual";
export const kTaxCode_EDI_TaxCode="EDI_TaxCode";
export const kTaxCode_EDI_TaxDesc="EDI_TaxDesc";

/*
        'TaxCode' : {
            'Tax_Xref' : 'Tax_Xref',
            'TP_PartID' : 'TP_PartID',
            'EDI_TaxQual' : 'EDI_TaxQual',
            'EDI_TaxCode' : 'EDI_TaxCode',
            'EDI_TaxDesc' : 'EDI_TaxDesc',        },
*/

export const Label_Tax_Xref = 'TaxCode.Tax_Xref';
export const Label_TP_PartID = 'TaxCode.TP_PartID';
export const Label_EDI_TaxQual = 'TaxCode.EDI_TaxQual';
export const Label_EDI_TaxCode = 'TaxCode.EDI_TaxCode';
export const Label_EDI_TaxDesc = 'TaxCode.EDI_TaxDesc';
