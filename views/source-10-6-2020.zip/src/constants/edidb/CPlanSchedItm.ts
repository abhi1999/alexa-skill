import { IPlanSchedItm } from '../edidb'
export class CPlanSchedItm implements IPlanSchedItm {
    public PSIID:string = '';
    public PSHID:string = '';
    public VPID:number = 0;
    public processtype:string = '';
    public processdate:Date;
    public itmdocline:number = 0;
    public fcdocline:number = 0;
    public fcqual:string = '';
    public fctqual:string = '';
    public fcqty:number = 0;
    public fcdate1:string = '';
    public fcdate2:string = '';
    public fcdtqual:string = '';
    public fcdtid:string = '';
    public itemuom:string = '';
    public importdate:Date;
    public status:string = '';
    public price:number = 0;
    public shpqtyqual:string = '';
    public shpqty:number = 0;
    public shpdtqual:string = '';
    public shpdate1:string = '';
    public shpdate2:string = '';
    public engchangelevel:string = '';
    public constructor(init?:Partial<CPlanSchedItm>) { Object.assign(this, init); }
}
export const IPlanSchedItm_processtype_length = 2;
export const IPlanSchedItm_fcqual_length = 2;
export const IPlanSchedItm_fctqual_length = 1;
export const IPlanSchedItm_fcdate1_length = 8;
export const IPlanSchedItm_fcdate2_length = 8;
export const IPlanSchedItm_fcdtqual_length = 3;
export const IPlanSchedItm_fcdtid_length = 8;
export const IPlanSchedItm_itemuom_length = 10;
export const IPlanSchedItm_status_length = 1;
export const IPlanSchedItm_shpqtyqual_length = 2;
export const IPlanSchedItm_shpdtqual_length = 3;
export const IPlanSchedItm_shpdate1_length = 8;
export const IPlanSchedItm_shpdate2_length = 8;
export const IPlanSchedItm_engchangelevel_length = 80;

export const kPlanSchedItm_PSIID="PSIID";
export const kPlanSchedItm_PSHID="PSHID";
export const kPlanSchedItm_VPID="VPID";
export const kPlanSchedItm_processtype="processtype";
export const kPlanSchedItm_processdate="processdate";
export const kPlanSchedItm_itmdocline="itmdocline";
export const kPlanSchedItm_fcdocline="fcdocline";
export const kPlanSchedItm_fcqual="fcqual";
export const kPlanSchedItm_fctqual="fctqual";
export const kPlanSchedItm_fcqty="fcqty";
export const kPlanSchedItm_fcdate1="fcdate1";
export const kPlanSchedItm_fcdate2="fcdate2";
export const kPlanSchedItm_fcdtqual="fcdtqual";
export const kPlanSchedItm_fcdtid="fcdtid";
export const kPlanSchedItm_itemuom="itemuom";
export const kPlanSchedItm_importdate="importdate";
export const kPlanSchedItm_status="status";
export const kPlanSchedItm_price="price";
export const kPlanSchedItm_shpqtyqual="shpqtyqual";
export const kPlanSchedItm_shpqty="shpqty";
export const kPlanSchedItm_shpdtqual="shpdtqual";
export const kPlanSchedItm_shpdate1="shpdate1";
export const kPlanSchedItm_shpdate2="shpdate2";
export const kPlanSchedItm_engchangelevel="engchangelevel";

/*
        'PlanSchedItm' : {
            'PSIID' : 'PSIID',
            'PSHID' : 'PSHID',
            'VPID' : 'VPID',
            'processtype' : 'processtype',
            'processdate' : 'processdate',
            'itmdocline' : 'itmdocline',
            'fcdocline' : 'fcdocline',
            'fcqual' : 'fcqual',
            'fctqual' : 'fctqual',
            'fcqty' : 'fcqty',
            'fcdate1' : 'fcdate1',
            'fcdate2' : 'fcdate2',
            'fcdtqual' : 'fcdtqual',
            'fcdtid' : 'fcdtid',
            'itemuom' : 'itemuom',
            'importdate' : 'importdate',
            'status' : 'status',
            'price' : 'price',
            'shpqtyqual' : 'shpqtyqual',
            'shpqty' : 'shpqty',
            'shpdtqual' : 'shpdtqual',
            'shpdate1' : 'shpdate1',
            'shpdate2' : 'shpdate2',
            'engchangelevel' : 'engchangelevel',        },
*/

export const Label_PSIID = 'PlanSchedItm.PSIID';
export const Label_PSHID = 'PlanSchedItm.PSHID';
export const Label_VPID = 'PlanSchedItm.VPID';
export const Label_processtype = 'PlanSchedItm.processtype';
export const Label_processdate = 'PlanSchedItm.processdate';
export const Label_itmdocline = 'PlanSchedItm.itmdocline';
export const Label_fcdocline = 'PlanSchedItm.fcdocline';
export const Label_fcqual = 'PlanSchedItm.fcqual';
export const Label_fctqual = 'PlanSchedItm.fctqual';
export const Label_fcqty = 'PlanSchedItm.fcqty';
export const Label_fcdate1 = 'PlanSchedItm.fcdate1';
export const Label_fcdate2 = 'PlanSchedItm.fcdate2';
export const Label_fcdtqual = 'PlanSchedItm.fcdtqual';
export const Label_fcdtid = 'PlanSchedItm.fcdtid';
export const Label_itemuom = 'PlanSchedItm.itemuom';
export const Label_importdate = 'PlanSchedItm.importdate';
export const Label_status = 'PlanSchedItm.status';
export const Label_price = 'PlanSchedItm.price';
export const Label_shpqtyqual = 'PlanSchedItm.shpqtyqual';
export const Label_shpqty = 'PlanSchedItm.shpqty';
export const Label_shpdtqual = 'PlanSchedItm.shpdtqual';
export const Label_shpdate1 = 'PlanSchedItm.shpdate1';
export const Label_shpdate2 = 'PlanSchedItm.shpdate2';
export const Label_engchangelevel = 'PlanSchedItm.engchangelevel';
