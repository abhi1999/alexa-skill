import { IItem } from '../edidb'
export class CItem implements IItem {
    public Int_Item_No:string = '';
    public Item_Desc:string = '';
    public UPC:string = '';
    public Def_Pack_Qty:number = 0;
    public Item_Wt:number = 0;
    public Item_Um:string = '';
    public Item_UOM:string = '';
    public EDI_UOM:string = '';
    public RetailPrice:number = 0;
    public SellingPrice:number = 0;
    public SAC_Flag:boolean;
    public SAC_Qual:string = '';
    public Cube_Length:number = 0;
    public Cube_Width:number = 0;
    public Cube_Height:number = 0;
    public Cube_Qty:number = 0;
    public Cube_UOM:string = '';
    public User1:string = '';
    public User2:string = '';
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public Item_rfid:boolean;
    public locid:string = '';
    public PackingClass:string = '';
    public Item_Alt_No:string = '';
    public Item_Config:string = '';
    public Item_Size:string = '';
    public Item_Color:string = '';
    public Frt_Code:string = '';
    public GTIN:string = '';
    public EAN:string = '';
    public constructor(init?:Partial<CItem>) { Object.assign(this, init); }
}
export const IItem_Int_Item_No_length = 500;
export const IItem_Item_Desc_length = 80;
export const IItem_UPC_length = 20;
export const IItem_Item_Um_length = 3;
export const IItem_Item_UOM_length = 10;
export const IItem_EDI_UOM_length = 3;
export const IItem_SAC_Qual_length = 4;
export const IItem_Cube_UOM_length = 2;
export const IItem_User1_length = 50;
export const IItem_User2_length = 50;
export const IItem_User3_length = 50;
export const IItem_User4_length = 50;
export const IItem_User5_length = 50;
export const IItem_locid_length = 20;
export const IItem_PackingClass_length = 30;
export const IItem_Item_Alt_No_length = 30;
export const IItem_Item_Config_length = 30;
export const IItem_Item_Size_length = 30;
export const IItem_Item_Color_length = 30;
export const IItem_Frt_Code_length = 50;
export const IItem_GTIN_length = 20;
export const IItem_EAN_length = 20;

export const kItem_Int_Item_No="Int_Item_No";
export const kItem_Item_Desc="Item_Desc";
export const kItem_UPC="UPC";
export const kItem_Def_Pack_Qty="Def_Pack_Qty";
export const kItem_Item_Wt="Item_Wt";
export const kItem_Item_Um="Item_Um";
export const kItem_Item_UOM="Item_UOM";
export const kItem_EDI_UOM="EDI_UOM";
export const kItem_RetailPrice="RetailPrice";
export const kItem_SellingPrice="SellingPrice";
export const kItem_SAC_Flag="SAC_Flag";
export const kItem_SAC_Qual="SAC_Qual";
export const kItem_Cube_Length="Cube_Length";
export const kItem_Cube_Width="Cube_Width";
export const kItem_Cube_Height="Cube_Height";
export const kItem_Cube_Qty="Cube_Qty";
export const kItem_Cube_UOM="Cube_UOM";
export const kItem_User1="User1";
export const kItem_User2="User2";
export const kItem_User3="User3";
export const kItem_User4="User4";
export const kItem_User5="User5";
export const kItem_Item_rfid="Item_rfid";
export const kItem_locid="locid";
export const kItem_PackingClass="PackingClass";
export const kItem_Item_Alt_No="Item_Alt_No";
export const kItem_Item_Config="Item_Config";
export const kItem_Item_Size="Item_Size";
export const kItem_Item_Color="Item_Color";
export const kItem_Frt_Code="Frt_Code";
export const kItem_GTIN="GTIN";
export const kItem_EAN="EAN";

/*
        'Item' : {
            'Int_Item_No' : 'Int_Item_No',
            'Item_Desc' : 'Item_Desc',
            'UPC' : 'UPC',
            'Def_Pack_Qty' : 'Def_Pack_Qty',
            'Item_Wt' : 'Item_Wt',
            'Item_Um' : 'Item_Um',
            'Item_UOM' : 'Item_UOM',
            'EDI_UOM' : 'EDI_UOM',
            'RetailPrice' : 'RetailPrice',
            'SellingPrice' : 'SellingPrice',
            'SAC_Flag' : 'SAC_Flag',
            'SAC_Qual' : 'SAC_Qual',
            'Cube_Length' : 'Cube_Length',
            'Cube_Width' : 'Cube_Width',
            'Cube_Height' : 'Cube_Height',
            'Cube_Qty' : 'Cube_Qty',
            'Cube_UOM' : 'Cube_UOM',
            'User1' : 'User1',
            'User2' : 'User2',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'Item_rfid' : 'Item_rfid',
            'locid' : 'locid',
            'PackingClass' : 'PackingClass',
            'Item_Alt_No' : 'Item_Alt_No',
            'Item_Config' : 'Item_Config',
            'Item_Size' : 'Item_Size',
            'Item_Color' : 'Item_Color',
            'Frt_Code' : 'Frt_Code',
            'GTIN' : 'GTIN',
            'EAN' : 'EAN',
        },
*/

export const Label_Int_Item_No = 'Item.Int_Item_No';
export const Label_Item_Desc = 'Item.Item_Desc';
export const Label_UPC = 'Item.UPC';
export const Label_Def_Pack_Qty = 'Item.Def_Pack_Qty';
export const Label_Item_Wt = 'Item.Item_Wt';
export const Label_Item_Um = 'Item.Item_Um';
export const Label_Item_UOM = 'Item.Item_UOM';
export const Label_EDI_UOM = 'Item.EDI_UOM';
export const Label_RetailPrice = 'Item.RetailPrice';
export const Label_SellingPrice = 'Item.SellingPrice';
export const Label_SAC_Flag = 'Item.SAC_Flag';
export const Label_SAC_Qual = 'Item.SAC_Qual';
export const Label_Cube_Length = 'Item.Cube_Length';
export const Label_Cube_Width = 'Item.Cube_Width';
export const Label_Cube_Height = 'Item.Cube_Height';
export const Label_Cube_Qty = 'Item.Cube_Qty';
export const Label_Cube_UOM = 'Item.Cube_UOM';
export const Label_User1 = 'Item.User1';
export const Label_User2 = 'Item.User2';
export const Label_User3 = 'Item.User3';
export const Label_User4 = 'Item.User4';
export const Label_User5 = 'Item.User5';
export const Label_Item_rfid = 'Item.Item_rfid';
export const Label_locid = 'Item.locid';
export const Label_PackingClass = 'Item.PackingClass';
export const Label_Item_Alt_No = 'Item.Item_Alt_No';
export const Label_Item_Config = 'Item.Item_Config';
export const Label_Item_Size = 'Item.Item_Size';
export const Label_Item_Color = 'Item.Item_Color';
export const Label_Frt_Code = 'Item.Frt_Code';
export const Label_GTIN = 'Item.GTIN';
export const Label_EAN = 'Item.EAN';

export const kItem_Int_Item_No_Type="string";
export const kItem_Item_Desc_Type ="string";
export const kItem_UPC_Type ="string";
export const kItem_Def_Pack_Qty_Type ="number";
