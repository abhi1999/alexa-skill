import { IPlanSchedAdd } from '../edidb'
export class CPlanSchedAdd implements IPlanSchedAdd {
    public PSAID:string = '';
    public PSGID:string = '';
    public locname:string = '';
    public locadd1:string = '';
    public locadd2:string = '';
    public locadd3:string = '';
    public loccity:string = '';
    public locstate:string = '';
    public loczip:string = '';
    public loccountry:string = '';
    public constructor(init?:Partial<CPlanSchedAdd>) { Object.assign(this, init); }
}
export const IPlanSchedAdd_locname_length = 80;
export const IPlanSchedAdd_locadd1_length = 80;
export const IPlanSchedAdd_locadd2_length = 80;
export const IPlanSchedAdd_locadd3_length = 80;
export const IPlanSchedAdd_loccity_length = 50;
export const IPlanSchedAdd_locstate_length = 30;
export const IPlanSchedAdd_loczip_length = 15;
export const IPlanSchedAdd_loccountry_length = 30;

export const kPlanSchedAdd_PSAID="PSAID";
export const kPlanSchedAdd_PSGID="PSGID";
export const kPlanSchedAdd_locname="locname";
export const kPlanSchedAdd_locadd1="locadd1";
export const kPlanSchedAdd_locadd2="locadd2";
export const kPlanSchedAdd_locadd3="locadd3";
export const kPlanSchedAdd_loccity="loccity";
export const kPlanSchedAdd_locstate="locstate";
export const kPlanSchedAdd_loczip="loczip";
export const kPlanSchedAdd_loccountry="loccountry";

/*
        'PlanSchedAdd' : {
            'PSAID' : 'PSAID',
            'PSGID' : 'PSGID',
            'locname' : 'locname',
            'locadd1' : 'locadd1',
            'locadd2' : 'locadd2',
            'locadd3' : 'locadd3',
            'loccity' : 'loccity',
            'locstate' : 'locstate',
            'loczip' : 'loczip',
            'loccountry' : 'loccountry',        },
*/

export const Label_PSAID = 'PlanSchedAdd.PSAID';
export const Label_PSGID = 'PlanSchedAdd.PSGID';
export const Label_locname = 'PlanSchedAdd.locname';
export const Label_locadd1 = 'PlanSchedAdd.locadd1';
export const Label_locadd2 = 'PlanSchedAdd.locadd2';
export const Label_locadd3 = 'PlanSchedAdd.locadd3';
export const Label_loccity = 'PlanSchedAdd.loccity';
export const Label_locstate = 'PlanSchedAdd.locstate';
export const Label_loczip = 'PlanSchedAdd.loczip';
export const Label_loccountry = 'PlanSchedAdd.loccountry';
