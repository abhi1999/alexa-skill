import { ILastNums } from '../edidb'
export class CLastNums implements ILastNums {
    public All_Keys:number = 0;
    public Last_850:number = 0;
    public Last_810:number = 0;
    public Last_856:number = 0;
    public Last_UCC:number = 0;
    public Last_FA:number = 0;
    public Last_PC:number = 0;
    public Last_BOL:number = 0;
    public Last_RRC:number = 0;
    public Last_RRC_Ctrl_No:number = 0;
    public Last_Order_No:number = 0;
    public constructor(init?:Partial<CLastNums>) { Object.assign(this, init); }
}
export const kLastNums_All_Keys="All_Keys";
export const kLastNums_Last_850="Last_850";
export const kLastNums_Last_810="Last_810";
export const kLastNums_Last_856="Last_856";
export const kLastNums_Last_UCC="Last_UCC";
export const kLastNums_Last_FA="Last_FA";
export const kLastNums_Last_PC="Last_PC";
export const kLastNums_Last_BOL="Last_BOL";
export const kLastNums_Last_RRC="Last_RRC";
export const kLastNums_Last_RRC_Ctrl_No="Last_RRC_Ctrl_No";
export const kLastNums_Last_Order_No="Last_Order_No";

/*
        'LastNums' : {
            'All_Keys' : 'All_Keys',
            'Last_850' : 'Last_850',
            'Last_810' : 'Last_810',
            'Last_856' : 'Last_856',
            'Last_UCC' : 'Last_UCC',
            'Last_FA' : 'Last_FA',
            'Last_PC' : 'Last_PC',
            'Last_BOL' : 'Last_BOL',
            'Last_RRC' : 'Last_RRC',
            'Last_RRC_Ctrl_No' : 'Last_RRC_Ctrl_No',
            'Last_Order_No' : 'Last_Order_No',
        },
*/

export const Label_All_Keys = 'LastNums.All_Keys';
export const Label_Last_850 = 'LastNums.Last_850';
export const Label_Last_810 = 'LastNums.Last_810';
export const Label_Last_856 = 'LastNums.Last_856';
export const Label_Last_UCC = 'LastNums.Last_UCC';
export const Label_Last_FA = 'LastNums.Last_FA';
export const Label_Last_PC = 'LastNums.Last_PC';
export const Label_Last_BOL = 'LastNums.Last_BOL';
export const Label_Last_RRC = 'LastNums.Last_RRC';
export const Label_Last_RRC_Ctrl_No = 'LastNums.Last_RRC_Ctrl_No';
export const Label_Last_Order_No = 'LastNums.Last_Order_No';
