import { IApiOsnShipReportViews } from '../EdiDb';

export class CApiOsnShipReportViews implements IApiOsnShipReportViews {
    public Order : 0;
    public PO : '';
    public Pack_ID : 0;
    public Box : 0;
    public Tracking_Number : '';
    public Item : '';
    public Quantity : 0;
    public UOM : '';
    public Asn_ID : 0;
  public constructor(init?:Partial<CApiOsnShipReportViews>) { Object.assign(this, init); }
};


/*
        'ApiOsnShipReportViews' : {
            'Order' : 'Order',
            'PO' : 'PO',
            'Pack_ID' : 'Pack_ID',
            'Box' : 'Box',
            'Tracking_Number' : 'Tracking_Number',
            'Item' : 'Item',
            'Quantity' : 'Quantity',
            'UOM' : 'UOM',
            'Asn_ID' : 'Asn_ID',
        },
*/

export const KApiOsnShipReportViews_Order = 'Order';
export const KApiOsnShipReportViews_PO = 'PO';
export const KApiOsnShipReportViews_Pack_ID = 'Pack_ID';
export const KApiOsnShipReportViews_Box = 'Box';
export const KApiOsnShipReportViews_Tracking_Number = 'Tracking_Number';
export const KApiOsnShipReportViews_Item = 'Item';
export const KApiOsnShipReportViews_Quantity = 'Quantity';
export const KApiOsnShipReportViews_UOM = 'UOM';
export const KApiOsnShipReportViews_Asn_ID = 'Asn_ID';

export const Label_Order = 'ApiOsnShipReportViews.Order';
export const Label_PO = 'ApiOsnShipReportViews.PO';
export const Label_Pack_ID = 'ApiOsnShipReportViews.Pack_ID';
export const Label_Box = 'ApiOsnShipReportViews.Box';
export const Label_Tracking_Number = 'ApiOsnShipReportViews.Tracking_Number';
export const Label_Item = 'ApiOsnShipReportViews.Item';
export const Label_Quantity = 'ApiOsnShipReportViews.Quantity';
export const Label_UOM = 'ApiOsnShipReportViews.UOM';
export const Label_Asn_ID = 'ApiOsnShipReportViews.Asn_ID';