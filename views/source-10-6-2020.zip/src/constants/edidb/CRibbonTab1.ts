import { IRibbonTab1 } from '../edidb'
export class CRibbonTab1 implements IRibbonTab1 {
    public TabID:number = 0;
    public FormName:string = '';
    public Caption:string = '';
    public TabOrder:number = 0;
    public Visible:boolean;
    public Enabled:boolean;
    public KeyboardTip:string = '';
    public FriendlyName:string = '';
    public UserEnabled:boolean;
    public UserVisible:boolean;
    public constructor(init?:Partial<CRibbonTab1>) { Object.assign(this, init); }
}
export const IRibbonTab1_FormName_length = 200;
export const IRibbonTab1_Caption_length = 200;
export const IRibbonTab1_KeyboardTip_length = 500;
export const IRibbonTab1_FriendlyName_length = 200;

export const kRibbonTab1_TabID="TabID";
export const kRibbonTab1_FormName="FormName";
export const kRibbonTab1_Caption="Caption";
export const kRibbonTab1_TabOrder="TabOrder";
export const kRibbonTab1_Visible="Visible";
export const kRibbonTab1_Enabled="Enabled";
export const kRibbonTab1_KeyboardTip="KeyboardTip";
export const kRibbonTab1_FriendlyName="FriendlyName";
export const kRibbonTab1_UserEnabled="UserEnabled";
export const kRibbonTab1_UserVisible="UserVisible";

/*
        'RibbonTab1' : {
            'TabID' : 'TabID',
            'FormName' : 'FormName',
            'Caption' : 'Caption',
            'TabOrder' : 'TabOrder',
            'Visible' : 'Visible',
            'Enabled' : 'Enabled',
            'KeyboardTip' : 'KeyboardTip',
            'FriendlyName' : 'FriendlyName',
            'UserEnabled' : 'UserEnabled',
            'UserVisible' : 'UserVisible',        },
*/

export const Label_TabID = 'RibbonTab1.TabID';
export const Label_FormName = 'RibbonTab1.FormName';
export const Label_Caption = 'RibbonTab1.Caption';
export const Label_TabOrder = 'RibbonTab1.TabOrder';
export const Label_Visible = 'RibbonTab1.Visible';
export const Label_Enabled = 'RibbonTab1.Enabled';
export const Label_KeyboardTip = 'RibbonTab1.KeyboardTip';
export const Label_FriendlyName = 'RibbonTab1.FriendlyName';
export const Label_UserEnabled = 'RibbonTab1.UserEnabled';
export const Label_UserVisible = 'RibbonTab1.UserVisible';
