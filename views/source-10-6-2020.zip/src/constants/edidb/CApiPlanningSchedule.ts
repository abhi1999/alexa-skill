import { IApiPlanningSchedule } from '../edidb'
export class CApiPlanningSchedule implements IApiPlanningSchedule {
    public PSIID:string = '';
    public VPID:number = 0;
    public tp_name:string = '';
    public TP_ID:string='';
    public processtype:string = '';
    public importdate:Date;
    public processdate:Date;
    public tp_partid:string = '';
    public fcqual:string = '';
    public itemid:string = '';
    public fcqty:number = 0;
    public fcdate1:Date;
    public fcdtqual:string = '';
    public shpqty:number = 0;
    public shpdtqual:string = '';
    public shpdate1:Date;
    public shpdate2:Date;
    public purchaseorder:string = '';
    public releaseno:string = '';
    public engchangelevel:string = '';
    public tp_stqual:string = '';
    public shiptoid:string = '';
    public status:string = '';
    public psdoctype:string = '';
    public constructor(init?:Partial<CApiPlanningSchedule>) { Object.assign(this, init); }
}
export const IApiPlanningSchedule_tp_name_length = 30;
export const IApiPlanningSchedule_processtype_length = 2;
export const IApiPlanningSchedule_tp_partid_length = 30;
export const IApiPlanningSchedule_fcqual_length = 2;
export const IApiPlanningSchedule_itemid_length = 80;
export const IApiPlanningSchedule_fcdtqual_length = 3;
export const IApiPlanningSchedule_shpdtqual_length = 3;
export const IApiPlanningSchedule_purchaseorder_length = 30;
export const IApiPlanningSchedule_releaseno_length = 30;
export const IApiPlanningSchedule_engchangelevel_length = 80;
export const IApiPlanningSchedule_tp_stqual_length = 3;
export const IApiPlanningSchedule_shiptoid_length = 80;
export const IApiPlanningSchedule_status_length = 1;
export const IApiPlanningSchedule_psdoctype_length = 2;

export const kApiPlanningSchedule_PSIID="PSIID";
export const kApiPlanningSchedule_VPID="VPID";
export const kApiPlanningSchedule_tp_name="tp_name";
export const kApiPlanningSchedule_processtype="processtype";
export const kApiPlanningSchedule_importdate="importdate";
export const kApiPlanningSchedule_processdate="processdate";
export const kApiPlanningSchedule_tp_partid="tp_partid";
export const kApiPlanningSchedule_fcqual="fcqual";
export const kApiPlanningSchedule_itemid="itemid";
export const kApiPlanningSchedule_fcqty="fcqty";
export const kApiPlanningSchedule_fcdate1="fcdate1";
export const kApiPlanningSchedule_fcdtqual="fcdtqual";
export const kApiPlanningSchedule_shpqty="shpqty";
export const kApiPlanningSchedule_shpdtqual="shpdtqual";
export const kApiPlanningSchedule_shpdate1="shpdate1";
export const kApiPlanningSchedule_shpdate2="shpdate2";
export const kApiPlanningSchedule_purchaseorder="purchaseorder";
export const kApiPlanningSchedule_releaseno="releaseno";
export const kApiPlanningSchedule_engchangelevel="engchangelevel";
export const kApiPlanningSchedule_tp_stqual="tp_stqual";
export const kApiPlanningSchedule_shiptoid="shiptoid";
export const kApiPlanningSchedule_status="status";
export const kApiPlanningSchedule_psdoctype="psdoctype";
export const kApiPlanningSchedule_tp_id="TP_ID";

/*
        'ApiPlanningSchedule' : {
            'PSIID' : 'PSIID',
            'VPID' : 'VPID',
            'tp_name' : 'tp_name',
            'processtype' : 'processtype',
            'importdate' : 'importdate',
            'processdate' : 'processdate',
            'tp_partid' : 'tp_partid',
            'fcqual' : 'fcqual',
            'itemid' : 'itemid',
            'fcqty' : 'fcqty',
            'fcdate1' : 'fcdate1',
            'fcdtqual' : 'fcdtqual',
            'shpqty' : 'shpqty',
            'shpdtqual' : 'shpdtqual',
            'shpdate1' : 'shpdate1',
            'shpdate2' : 'shpdate2',
            'purchaseorder' : 'purchaseorder',
            'releaseno' : 'releaseno',
            'engchangelevel' : 'engchangelevel',
            'tp_stqual' : 'tp_stqual',
            'shiptoid' : 'shiptoid',
            'status' : 'status',
            'psdoctype' : 'psdoctype',
        },
*/

export const Label_PSIID = 'ApiPlanningSchedule.PSIID';
export const Label_VPID = 'ApiPlanningSchedule.VPID';
export const Label_tp_name = 'ApiPlanningSchedule.tp_name';
export const Label_tp_id = 'ApiPlanningSchedule.TP_ID';
export const Label_processtype = 'ApiPlanningSchedule.processtype';
export const Label_importdate = 'ApiPlanningSchedule.importdate';
export const Label_processdate = 'ApiPlanningSchedule.processdate';
export const Label_tp_partid = 'ApiPlanningSchedule.tp_partid';
export const Label_fcqual = 'ApiPlanningSchedule.fcqual';
export const Label_itemid = 'ApiPlanningSchedule.itemid';
export const Label_fcqty = 'ApiPlanningSchedule.fcqty';
export const Label_fcdate1 = 'ApiPlanningSchedule.fcdate1';
export const Label_fcdtqual = 'ApiPlanningSchedule.fcdtqual';
export const Label_shpqty = 'ApiPlanningSchedule.shpqty';
export const Label_shpdtqual = 'ApiPlanningSchedule.shpdtqual';
export const Label_shpdate1 = 'ApiPlanningSchedule.shpdate1';
export const Label_shpdate2 = 'ApiPlanningSchedule.shpdate2';
export const Label_purchaseorder = 'ApiPlanningSchedule.purchaseorder';
export const Label_releaseno = 'ApiPlanningSchedule.releaseno';
export const Label_engchangelevel = 'ApiPlanningSchedule.engchangelevel';
export const Label_tp_stqual = 'ApiPlanningSchedule.tp_stqual';
export const Label_shiptoid = 'ApiPlanningSchedule.shiptoid';
export const Label_status = 'ApiPlanningSchedule.status';
export const Label_psdoctype = 'ApiPlanningSchedule.psdoctype';
