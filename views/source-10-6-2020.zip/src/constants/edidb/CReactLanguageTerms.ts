import { IReactLanguageTerms } from '../edidb'
export class CReactLanguageTerms implements IReactLanguageTerms {
    public TermID:string = '';
    public LanguageCode:string = '';
    public Caption:string = '';
    public Custom:string = '';
    public constructor(init?:Partial<CReactLanguageTerms>) { Object.assign(this, init); }
}
export const IReactLanguageTerms_ReactLanguageCode_length = 10;
export const IReactLanguageTerms_Caption_length = 2000;
export const IReactLanguageTerms_Custom_length = 2000;

export const kReactLanguageTerms_TermID="TermID";
export const kReactLanguageTerms_ReactLanguageCode="ReactLanguageCode";
export const kReactLanguageTerms_Caption="Caption";
export const kReactLanguageTerms_Custom="Custom";
/*
        'ReactLanguageTerms' : {
            'TermID' : 'TermID',
            'LanguageCode' : 'LanguageCode',
            'Caption' : 'Caption',
            'Custom' : 'Custom',
        },
*/

export const Label_TermID = 'ReactLanguageTerms.TermID';
export const Label_LanguageCode = 'ReactLanguageTerms.LanguageCode';
export const Label_Caption = 'ReactLanguageTerms.Caption';
export const Label_Custom = 'ReactLanguageTerms.Custom';
