import { IApiShipViaCustViews } from '../EdiDb';

export class CApiShipViaCustViews implements IApiShipViaCustViews {
    public Ship_Via_ID : '';
    public TP_PartID : '';
    public Cust_Ship_Via_ID : '';
    public User1 : '';
    public User2 : '';
    public User3 : '';
    public User4 : '';
    public User5 : '';
    public TP_Name : '';

  public constructor(init?:Partial<CApiShipViaCustViews>) { Object.assign(this, init); }
};

export const KApiShipViaCustViews_Ship_Via_ID = 'Ship_Via_ID';
export const KApiShipViaCustViews_TP_PartID = 'TP_PartID';
export const KApiShipViaCustViews_Cust_Ship_Via_ID = 'Cust_Ship_Via_ID';
export const KApiShipViaCustViews_User1 = 'User1';
export const KApiShipViaCustViews_User2 = 'User2';
export const KApiShipViaCustViews_User3 = 'User3';
export const KApiShipViaCustViews_User4 = 'User4';
export const KApiShipViaCustViews_User5 = 'User5';
export const KApiShipViaCustViews_TP_Name = 'TP_Name';

export const IApiShipViaCustViews_Ship_Via_ID_length = 30;
export const IApiShipViaCustViews_TP_PartID_length = 30;
export const IApiShipViaCustViews_Cust_Ship_Via_ID_length = 50;
export const IApiShipViaCustViews_User1_length = 50;
export const IApiShipViaCustViews_User2_length = 50;
export const IApiShipViaCustViews_User3_length = 50;
export const IApiShipViaCustViews_User4_length = 50;
export const IApiShipViaCustViews_User5_length = 50;
export const IApiShipViaCustViews_TP_Name_length = 50;

export const Label_Ship_Via_ID = 'ApiShipViaCustViews.Ship_Via_ID';
export const Label_TP_PartID = 'ApiShipViaCustViews.TP_PartID';
export const Label_Cust_Ship_Via_ID = 'ApiShipViaCustViews.Cust_Ship_Via_ID';
export const Label_User1 = 'ApiShipViaCustViews.User1';
export const Label_User2 = 'ApiShipViaCustViews.User2';
export const Label_User3 = 'ApiShipViaCustViews.User3';
export const Label_User4 = 'ApiShipViaCustViews.User4';
export const Label_User5 = 'ApiShipViaCustViews.User5';
export const Label_TP_Name = 'ApiShipViaCustViews.TP_Name';