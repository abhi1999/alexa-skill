import { IApiXmlDocView } from '../edidb';

export class CApiXMLDocView implements IApiXmlDocView {
  public CreatedDate: undefined;
  public TP_PartID: '';
  public TP_Name: '';
  public TP_ID: '';
  public DGID: '';
  public Doc_Desc: '';
  public Config: false;
  public URECID: '';
  public Exp_Flag: '';
  public ExportDate: undefined;
  public XMLID: '';
  public Misc_ID: 0;
  public XMLRef: '';
  public GCN: '';
  public TCN: '';
  public Direction: '';
  public VPID: 0;
  public AckID: '';
  public ErrorID: '';
  public VPIDFA: 0;
  public TLE: 0;
  public NoteText: '';
  public TLEJump: '';
  public CDID: '';
  public Resolved: false;
  public FAResolved: false;
  public HoldID: 0;

  public constructor(init?: Partial<CApiXMLDocView>) { Object.assign(this, init); }
};


/*
        'ApiXMLDocView' : {
            'CreatedDate' : 'CreatedDate',
            'TP_PartID' : 'TP_PartID',
            'TP_PartID' : 'TP_Name',
            'DGID' : 'DGID',
            'Doc_Desc' : 'Doc Group',
            'Config' : 'Config',
            'URECID' : 'URECID',
            'Exp_Flag' : 'Exp_Flag',
            'ExportDate' : 'ExportDate',
            'XMLID' : 'XMLID',
            'Misc_ID' : 'Misc_ID',
            'XMLRef' : 'XMLRef',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'Direction' : 'Direction',
            'VPID' : 'VPID',
            'AckID' : 'AckID',
            'ErrorID' : 'ErrorID',
            'VPIDFA' : 'VPIDFA',
            'TLE' : 'TLE',
            'NoteText' : 'NoteText',
            'TLEJump' : 'TLEJump',
        },
*/

export const KApiXMLDocViews_CreatedDate = 'CreatedDate';
export const KApiXMLDocViews_TP_PartID = 'TP_PartID';
export const KApiXMLDocViews_TP_Name = 'TP_Name';
export const KApiXMLDocViews_TP_ID = 'TP_ID';
export const KApiXMLDocViews_DGID = 'DGID';
export const KApiXMLDocViews_Doc_Desc = 'Doc_Desc';
export const KApiXMLDocViews_Config = 'Config';
export const KApiXMLDocViews_URECID = 'URECID';
export const KApiXMLDocViews_Exp_Flag = 'Exp_Flag';
export const KApiXMLDocViews_ExportDate = 'ExportDate';
export const KApiXMLDocViews_XMLID = 'XMLID';
export const KApiXMLDocViews_Misc_ID = 'Misc_ID';
export const KApiXMLDocViews_XMLRef = 'XMLRef';
export const KApiXMLDocViews_GCN = 'GCN';
export const KApiXMLDocViews_TCN = 'TCN';
export const KApiXMLDocViews_Direction = 'Direction';
export const KApiXMLDocViews_VPID = 'VPID';
export const KApiXMLDocViews_AckID = 'AckID';
export const KApiXMLDocViews_ErrorID = 'ErrorID';
export const KApiXMLDocViews_VPIDFA = 'VPIDFA';
export const KApiXMLDocViews_TLE = 'TLE';
export const KApiXMLDocViews_NoteText = 'NoteText';
export const KApiXMLDocViews_TLEJump = 'TLEJump';
export const KApiXMLDocViews_Resolved = 'Resolved';
export const KApiXMLDocViews_FAResolved = 'FAResolved';

export const Label_CreatedDate = 'ApiXMLDocView.CreatedDate';
export const Label_TP_PartID = 'ApiXMLDocView.TP_PartID';
export const Label_TP_Name = 'ApiXMLDocView.TP_Name';
export const Label_TP_ID = 'ApiXMLDocView.TP_ID';
export const Label_DGID = 'ApiXMLDocView.DGID';
export const Label_Doc_Desc = 'ApiXMLDocView.Doc_Desc';
export const Label_Config = 'ApiXMLDocView.Config';
export const Label_URECID = 'ApiXMLDocView.URECID';
export const Label_Exp_Flag = 'ApiXMLDocView.Exp_Flag';
export const Label_ExportDate = 'ApiXMLDocView.ExportDate';
export const Label_XMLID = 'ApiXMLDocView.XMLID';
export const Label_Misc_ID = 'ApiXMLDocView.Misc_ID';
export const Label_XMLRef = 'ApiXMLDocView.XMLRef';
export const Label_GCN = 'ApiXMLDocView.GCN';
export const Label_TCN = 'ApiXMLDocView.TCN';
export const Label_Direction = 'ApiXMLDocView.Direction';
export const Label_VPID = 'ApiXMLDocView.VPID';
export const Label_AckID = 'ApiXMLDocView.AckID';
export const Label_ErrorID = 'ApiXMLDocView.ErrorID';
export const Label_VPIDFA = 'ApiXMLDocView.VPIDFA';
export const Label_TLE = 'ApiXMLDocView.TLE';
export const Label_NoteText = 'ApiXMLDocView.NoteText';
export const Label_TLEJump = 'ApiXMLDocView.TLEJump';
export const Label_Resolved = 'ApiXMLDocView.Resolved';
export const Label_FAResolved = 'ApiXMLDocView.FAResolved';
export const Label_ErrorToolTip = 'ApiXMLDocView.Error_Tooltip';