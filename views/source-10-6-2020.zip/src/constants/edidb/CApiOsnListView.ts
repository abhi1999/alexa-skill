import { IApiOsnListView } from '../edidb';

export class CApiOsnListView implements IApiOsnListView {
    public Asn_ID : 0;
    public TP_Name : '';
    public TP_PartID : '';
    public Bol_No : '';
    public Asn_Complete : '';
    public Exp_Flag : '';
    public GCN : '';
    public TCN : '';
    public AckDesc : '';
    public HoldID : 0;
    public NoteText : '';
    public ErrorID : '';
    public Ship_Date : undefined;
    public TLE : 0;
    public VPIDFA : 0;
    public ExportDate : undefined;
    public CreatedDate : undefined;
    public FAResolved : false

  public constructor(init?:Partial<CApiOsnListView>) { Object.assign(this, init); }
};


export const KApiOsnListView_Asn_ID = 'Asn_ID';
export const KApiOsnListView_TP_Name = 'TP_Name';
export const KApiOsnListView_TP_PartID = 'TP_PartID';
export const KApiOsnListView_Bol_No = 'Bol_No';
export const KApiOsnListView_Asn_Complete = 'Asn_Complete';
export const KApiOsnListView_Exp_Flag = 'Exp_Flag';
export const KApiOsnListView_GCN = 'GCN';
export const KApiOsnListView_TCN = 'TCN';
export const KApiOsnListView_AckDesc = 'AckDesc';
export const KApiOsnListView_HoldID = 'HoldID';
export const KApiOsnListView_NoteText = 'NoteText';
export const KApiOsnListView_ErrorID = 'ErrorID';
export const KApiOsnListView_Ship_Date = 'Ship_Date';
export const KApiOsnListView_TLE = 'TLE';
export const KApiOsnListView_VPIDFA = 'VPIDFA';
export const KApiOsnListView_ExportDate = 'ExportDate';
export const KApiOsnListView_CreatedDate = 'CreatedDate';
export const KApiOsnListView_FAResolved = 'FAResolved';

export const Label_Asn_ID = 'ApiOsnListView.Asn_ID';
export const Label_TP_Name = 'ApiOsnListView.TP_Name';
export const Label_Bol_No = 'ApiOsnListView.Bol_No';
export const Label_Asn_Complete = 'ApiOsnListView.Asn_Complete';
export const Label_Exp_Flag = 'ApiOsnListView.Exp_Flag';
export const Label_GCN = 'ApiOsnListView.GCN';
export const Label_TCN = 'ApiOsnListView.TCN';
export const Label_AckDesc = 'ApiOsnListView.AckDesc';
export const Label_HoldID = 'ApiOsnListView.HoldID';
export const Label_NoteText = 'ApiOsnListView.NoteText';
export const Label_ErrorID = 'ApiOsnListView.ErrorID';
export const Label_Ship_Date = 'ApiOsnListView.Ship_Date';
export const Label_TLE = 'ApiOsnListView.TLE';
export const Label_VPIDFA = 'ApiOsnListView.VPIDFA';
export const Label_ExportDate = 'ApiOsnListView.ExportDate';
export const Label_CreatedDate = 'ApiOsnListView.CreatedDate';
export const Label_FAResolved = 'ApiOsnListView.FAResolved';

/*
        'OsnListView' : {
            'Asn_ID' : 'Shipment',
            'TP_Name' : 'Trading Partner',
            'Bol_No' : 'BOL Number',
            'Asn_Complete' : 'Complete',
            'Exp_Flag' : 'Exported',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'AckDesc' : 'Ack',
            'HoldID' : 'HoldID',
            'NoteText' : 'User Note',
            'ErrorID' : 'Error',
            'Ship_Date' : 'Ship Date',
            'TLE' : 'TLE',
            'VPIDFA' : 'VPIDFA',
            'ExportDate' : 'ExportDate'
        },
*/