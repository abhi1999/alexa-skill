import { IEDIRptFilterASN } from '../edidb'
export class CEDIRptFilterASN implements IEDIRptFilterASN {
    public VPID:number = 0;
    public Misc_ID:number = 0;
    public DGID:string = '';
    public TP_PartID:string = '';
    public TP_Name:string = '';
    public DocType:string = '';
    public DateRecv:Date;
    public DocRef:string = '';
    public PO_NO:string = '';
    public EmailTo:string = '';
    public ReportName:string = '';
    public constructor(init?:Partial<CEDIRptFilterASN>) { Object.assign(this, init); }
}
export const IEDIRptFilterASN_DGID_length = 5;
export const IEDIRptFilterASN_TP_PartID_length = 30;
export const IEDIRptFilterASN_TP_Name_length = 30;
export const IEDIRptFilterASN_DocType_length = 10;
export const IEDIRptFilterASN_DocRef_length = 50;
export const IEDIRptFilterASN_PO_NO_length = 4000;
export const IEDIRptFilterASN_EmailTo_length = 4000;
export const IEDIRptFilterASN_ReportName_length = 18;

export const kEDIRptFilterASN_VPID="VPID";
export const kEDIRptFilterASN_Misc_ID="Misc_ID";
export const kEDIRptFilterASN_DGID="DGID";
export const kEDIRptFilterASN_TP_PartID="TP_PartID";
export const kEDIRptFilterASN_TP_Name="TP_Name";
export const kEDIRptFilterASN_DocType="DocType";
export const kEDIRptFilterASN_DateRecv="DateRecv";
export const kEDIRptFilterASN_DocRef="DocRef";
export const kEDIRptFilterASN_PO_NO="PO_NO";
export const kEDIRptFilterASN_EmailTo="EmailTo";
export const kEDIRptFilterASN_ReportName="ReportName";

/*
        'EDIRptFilterASN' : {
            'VPID' : 'VPID',
            'Misc_ID' : 'Misc_ID',
            'DGID' : 'DGID',
            'TP_PartID' : 'TP_PartID',
            'TP_Name' : 'TP_Name',
            'DocType' : 'DocType',
            'DateRecv' : 'DateRecv',
            'DocRef' : 'DocRef',
            'PO_NO' : 'PO_NO',
            'EmailTo' : 'EmailTo',
            'ReportName' : 'ReportName',        },
*/

export const Label_VPID = 'EDIRptFilterASN.VPID';
export const Label_Misc_ID = 'EDIRptFilterASN.Misc_ID';
export const Label_DGID = 'EDIRptFilterASN.DGID';
export const Label_TP_PartID = 'EDIRptFilterASN.TP_PartID';
export const Label_TP_Name = 'EDIRptFilterASN.TP_Name';
export const Label_DocType = 'EDIRptFilterASN.DocType';
export const Label_DateRecv = 'EDIRptFilterASN.DateRecv';
export const Label_DocRef = 'EDIRptFilterASN.DocRef';
export const Label_PO_NO = 'EDIRptFilterASN.PO_NO';
export const Label_EmailTo = 'EDIRptFilterASN.EmailTo';
export const Label_ReportName = 'EDIRptFilterASN.ReportName';
