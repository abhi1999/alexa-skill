import { IItemCustSAC } from '../edidb'
export class CItemCustSAC implements IItemCustSAC {
    public TP_PartID:string = '';
    public Int_Item_No:string = '';
    public SAC_Qual:string = '';
    public constructor(init?:Partial<CItemCustSAC>) { Object.assign(this, init); }
}
export const IItemCustSAC_TP_PartID_length = 30;
export const IItemCustSAC_Int_Item_No_length = 500;
export const IItemCustSAC_SAC_Qual_length = 4;

export const kItemCustSAC_TP_PartID="TP_PartID";
export const kItemCustSAC_Int_Item_No="Int_Item_No";
export const kItemCustSAC_SAC_Qual="SAC_Qual";

/*
        'ItemCustSAC' : {
            'TP_PartID' : 'TP_PartID',
            'Int_Item_No' : 'Int_Item_No',
            'SAC_Qual' : 'SAC_Qual',        },
*/

export const Label_TP_PartID = 'ItemCustSAC.TP_PartID';
export const Label_Int_Item_No = 'ItemCustSAC.Int_Item_No';
export const Label_SAC_Qual = 'ItemCustSAC.SAC_Qual';
