import { IApiTaxCodeView } from '../edidb'
export class CApiTaxCodeView implements IApiTaxCodeView {
    public Tax_Xref:string = '';
    public EDI_TaxQual:string = '';
    public EDI_TaxCode:string = '';
    public EDI_TaxDesc:string = '';
    public TP_PartID:string = '';
    public TP_Name:string = '';
    public constructor(init?:Partial<CApiTaxCodeView>) { Object.assign(this, init); }
}
export const IApiTaxCodeView_Tax_Xref_length = 10;
export const IApiTaxCodeView_EDI_TaxQual_length = 10;
export const IApiTaxCodeView_EDI_TaxCode_length = 10;
export const IApiTaxCodeView_EDI_TaxDesc_length = 30;
export const IApiTaxCodeView_TP_PartID_length = 30;
export const IApiTaxCodeView_TP_Name_length = 30;

export const kApiTaxCodeView_Tax_Xref="Tax_Xref";
export const kApiTaxCodeView_EDI_TaxQual="EDI_TaxQual";
export const kApiTaxCodeView_EDI_TaxCode="EDI_TaxCode";
export const kApiTaxCodeView_EDI_TaxDesc="EDI_TaxDesc";
export const kApiTaxCodeView_TP_PartID="TP_PartID";
export const kApiTaxCodeView_TP_Name="TP_Name";

/*
        'ApiTaxCodeView' : {
            'Tax_Xref' : 'Tax_Xref',
            'EDI_TaxQual' : 'EDI_TaxQual',
            'EDI_TaxCode' : 'EDI_TaxCode',
            'EDI_TaxDesc' : 'EDI_TaxDesc',
            'TP_PartID' : 'TP_PartID',
            'TP_Name' : 'TP_Name',        },
*/

export const Label_Tax_Xref = 'ApiTaxCodeView.Tax_Xref';
export const Label_EDI_TaxQual = 'ApiTaxCodeView.EDI_TaxQual';
export const Label_EDI_TaxCode = 'ApiTaxCodeView.EDI_TaxCode';
export const Label_EDI_TaxDesc = 'ApiTaxCodeView.EDI_TaxDesc';
export const Label_TP_PartID = 'ApiTaxCodeView.TP_PartID';
export const Label_TP_Name = 'ApiTaxCodeView.TP_Name';
