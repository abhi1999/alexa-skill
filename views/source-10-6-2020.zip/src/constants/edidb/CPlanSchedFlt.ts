import { IPlanSchedFlt } from '../edidb'
export class CPlanSchedFlt implements IPlanSchedFlt {
    public PSFID:string = '';
    public PSIID:string = '';
    public dtstamp:Date;
    public userid:string = '';
    public machineid:string = '';
    public PID:string = '';
    public constructor(init?:Partial<CPlanSchedFlt>) { Object.assign(this, init); }
}
export const IPlanSchedFlt_userid_length = 50;
export const IPlanSchedFlt_machineid_length = 50;

export const kPlanSchedFlt_PSFID="PSFID";
export const kPlanSchedFlt_PSIID="PSIID";
export const kPlanSchedFlt_dtstamp="dtstamp";
export const kPlanSchedFlt_userid="userid";
export const kPlanSchedFlt_machineid="machineid";
export const kPlanSchedFlt_PID="PID";

/*
        'PlanSchedFlt' : {
            'PSFID' : 'PSFID',
            'PSIID' : 'PSIID',
            'dtstamp' : 'dtstamp',
            'userid' : 'userid',
            'machineid' : 'machineid',
            'PID' : 'PID',        },
*/

export const Label_PSFID = 'PlanSchedFlt.PSFID';
export const Label_PSIID = 'PlanSchedFlt.PSIID';
export const Label_dtstamp = 'PlanSchedFlt.dtstamp';
export const Label_userid = 'PlanSchedFlt.userid';
export const Label_machineid = 'PlanSchedFlt.machineid';
export const Label_PID = 'PlanSchedFlt.PID';
