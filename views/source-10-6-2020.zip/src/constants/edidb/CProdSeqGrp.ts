import { IProdSeqGrp } from '../edidb'
export class CProdSeqGrp implements IProdSeqGrp {
    public PSGID:string = '';
    public PSIID:string = '';
    public PSHID:string = '';
    public psglevel:number = 0;
    public psgtype:string = '';
    public psgdocline:number = 0;
    public pardocline:number = 0;
    public psgqual:string = '';
    public psgtext:string = '';
    public constructor(init?:Partial<CProdSeqGrp>) { Object.assign(this, init); }
}
export const IProdSeqGrp_psgtype_length = 1;
export const IProdSeqGrp_psgqual_length = 10;
export const IProdSeqGrp_psgtext_length = 80;

export const kProdSeqGrp_PSGID="PSGID";
export const kProdSeqGrp_PSIID="PSIID";
export const kProdSeqGrp_PSHID="PSHID";
export const kProdSeqGrp_psglevel="psglevel";
export const kProdSeqGrp_psgtype="psgtype";
export const kProdSeqGrp_psgdocline="psgdocline";
export const kProdSeqGrp_pardocline="pardocline";
export const kProdSeqGrp_psgqual="psgqual";
export const kProdSeqGrp_psgtext="psgtext";

/*
        'ProdSeqGrp' : {
            'PSGID' : 'PSGID',
            'PSIID' : 'PSIID',
            'PSHID' : 'PSHID',
            'psglevel' : 'psglevel',
            'psgtype' : 'psgtype',
            'psgdocline' : 'psgdocline',
            'pardocline' : 'pardocline',
            'psgqual' : 'psgqual',
            'psgtext' : 'psgtext',        },
*/

export const Label_PSGID = 'ProdSeqGrp.PSGID';
export const Label_PSIID = 'ProdSeqGrp.PSIID';
export const Label_PSHID = 'ProdSeqGrp.PSHID';
export const Label_psglevel = 'ProdSeqGrp.psglevel';
export const Label_psgtype = 'ProdSeqGrp.psgtype';
export const Label_psgdocline = 'ProdSeqGrp.psgdocline';
export const Label_pardocline = 'ProdSeqGrp.pardocline';
export const Label_psgqual = 'ProdSeqGrp.psgqual';
export const Label_psgtext = 'ProdSeqGrp.psgtext';
