import { IMap } from '../edidb'
export class CMap implements IMap {
    public eMap:string = '';
    public eSeq:number = 0;
    public eName:string = '';
    public eDate:Date;
    public eDesc:string = '';
    public eDocument:string = '';
    public eDocID:string = '';
    public eSegment:string = '';
    public eHL:string = '';
    public eArg1:string = '';
    public eArg2:string = '';
    public eArg3:string = '';
    public eArg4:string = '';
    public eArg5:string = '';
    public eElement1:string = '';
    public eElement2:string = '';
    public eElement3:string = '';
    public eElement4:string = '';
    public eElement5:string = '';
    public eElement6:string = '';
    public eElement7:string = '';
    public eElement8:string = '';
    public eElement9:string = '';
    public eElement10:string = '';
    public eElement11:string = '';
    public eElement12:string = '';
    public eElement13:string = '';
    public eElement14:string = '';
    public eElement15:string = '';
    public constructor(init?:Partial<CMap>) { Object.assign(this, init); }
}
export const IMap_eMap_length = 30;
export const IMap_eName_length = 50;
export const IMap_eDesc_length = 50;
export const IMap_eDocument_length = 3;
export const IMap_eDocID_length = 3;
export const IMap_eSegment_length = 4;
export const IMap_eHL_length = 1;
export const IMap_eArg1_length = 30;
export const IMap_eArg2_length = 30;
export const IMap_eArg3_length = 30;
export const IMap_eArg4_length = 30;
export const IMap_eArg5_length = 30;
export const IMap_eElement1_length = 30;
export const IMap_eElement2_length = 30;
export const IMap_eElement3_length = 30;
export const IMap_eElement4_length = 30;
export const IMap_eElement5_length = 30;
export const IMap_eElement6_length = 30;
export const IMap_eElement7_length = 30;
export const IMap_eElement8_length = 30;
export const IMap_eElement9_length = 30;
export const IMap_eElement10_length = 30;
export const IMap_eElement11_length = 30;
export const IMap_eElement12_length = 30;
export const IMap_eElement13_length = 30;
export const IMap_eElement14_length = 30;
export const IMap_eElement15_length = 30;

export const kMap_eMap="eMap";
export const kMap_eSeq="eSeq";
export const kMap_eName="eName";
export const kMap_eDate="eDate";
export const kMap_eDesc="eDesc";
export const kMap_eDocument="eDocument";
export const kMap_eDocID="eDocID";
export const kMap_eSegment="eSegment";
export const kMap_eHL="eHL";
export const kMap_eArg1="eArg1";
export const kMap_eArg2="eArg2";
export const kMap_eArg3="eArg3";
export const kMap_eArg4="eArg4";
export const kMap_eArg5="eArg5";
export const kMap_eElement1="eElement1";
export const kMap_eElement2="eElement2";
export const kMap_eElement3="eElement3";
export const kMap_eElement4="eElement4";
export const kMap_eElement5="eElement5";
export const kMap_eElement6="eElement6";
export const kMap_eElement7="eElement7";
export const kMap_eElement8="eElement8";
export const kMap_eElement9="eElement9";
export const kMap_eElement10="eElement10";
export const kMap_eElement11="eElement11";
export const kMap_eElement12="eElement12";
export const kMap_eElement13="eElement13";
export const kMap_eElement14="eElement14";
export const kMap_eElement15="eElement15";

/*
        'Map' : {
            'eMap' : 'eMap',
            'eSeq' : 'eSeq',
            'eName' : 'eName',
            'eDate' : 'eDate',
            'eDesc' : 'eDesc',
            'eDocument' : 'eDocument',
            'eDocID' : 'eDocID',
            'eSegment' : 'eSegment',
            'eHL' : 'eHL',
            'eArg1' : 'eArg1',
            'eArg2' : 'eArg2',
            'eArg3' : 'eArg3',
            'eArg4' : 'eArg4',
            'eArg5' : 'eArg5',
            'eElement1' : 'eElement1',
            'eElement2' : 'eElement2',
            'eElement3' : 'eElement3',
            'eElement4' : 'eElement4',
            'eElement5' : 'eElement5',
            'eElement6' : 'eElement6',
            'eElement7' : 'eElement7',
            'eElement8' : 'eElement8',
            'eElement9' : 'eElement9',
            'eElement10' : 'eElement10',
            'eElement11' : 'eElement11',
            'eElement12' : 'eElement12',
            'eElement13' : 'eElement13',
            'eElement14' : 'eElement14',
            'eElement15' : 'eElement15',        },
*/

export const Label_eMap = 'Map.eMap';
export const Label_eSeq = 'Map.eSeq';
export const Label_eName = 'Map.eName';
export const Label_eDate = 'Map.eDate';
export const Label_eDesc = 'Map.eDesc';
export const Label_eDocument = 'Map.eDocument';
export const Label_eDocID = 'Map.eDocID';
export const Label_eSegment = 'Map.eSegment';
export const Label_eHL = 'Map.eHL';
export const Label_eArg1 = 'Map.eArg1';
export const Label_eArg2 = 'Map.eArg2';
export const Label_eArg3 = 'Map.eArg3';
export const Label_eArg4 = 'Map.eArg4';
export const Label_eArg5 = 'Map.eArg5';
export const Label_eElement1 = 'Map.eElement1';
export const Label_eElement2 = 'Map.eElement2';
export const Label_eElement3 = 'Map.eElement3';
export const Label_eElement4 = 'Map.eElement4';
export const Label_eElement5 = 'Map.eElement5';
export const Label_eElement6 = 'Map.eElement6';
export const Label_eElement7 = 'Map.eElement7';
export const Label_eElement8 = 'Map.eElement8';
export const Label_eElement9 = 'Map.eElement9';
export const Label_eElement10 = 'Map.eElement10';
export const Label_eElement11 = 'Map.eElement11';
export const Label_eElement12 = 'Map.eElement12';
export const Label_eElement13 = 'Map.eElement13';
export const Label_eElement14 = 'Map.eElement14';
export const Label_eElement15 = 'Map.eElement15';
