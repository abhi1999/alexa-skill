import { IApiDocLoadConfig } from '../edidb'
export class CApiDocLoadConfig implements IApiDocLoadConfig {
    public DLID:string = '';
    public DGID:string = '';
    public DocType:string = '';
    public TP_PartID:string = '';
    public Doc_Group:string = '';
    public Doc_Name:string = '';
    public TP_Name:string = '';
    public ProcessFlag:number = 0;
    public constructor(init?:Partial<CApiDocLoadConfig>) { Object.assign(this, init); }
}
export const IApiDocLoadConfig_DGID_length = 5;
export const IApiDocLoadConfig_DocType_length = 10;
export const IApiDocLoadConfig_TP_PartID_length = 30;
export const IApiDocLoadConfig_Doc_Group_length = 50;
export const IApiDocLoadConfig_Doc_Name_length = 10;
export const IApiDocLoadConfig_TP_Name_length = 30;

export const kApiDocLoadConfig_DLID="DLID";
export const kApiDocLoadConfig_DGID="DGID";
export const kApiDocLoadConfig_DocType="DocType";
export const kApiDocLoadConfig_TP_PartID="TP_PartID";
export const kApiDocLoadConfig_Doc_Group="Doc_Group";
export const kApiDocLoadConfig_Doc_Name="Doc_Name";
export const kApiDocLoadConfig_TP_Name="TP_Name";
export const kApiDocLoadConfig_ProcessFlag="ProcessFlag";

/*
        'ApiDocLoadConfig' : {
            'DLID' : 'DLID',
            'DGID' : 'DGID',
            'DocType' : 'DocType',
            'TP_PartID' : 'TP_PartID',
            'Doc_Group' : 'Doc_Group',
            'Doc_Name' : 'Doc_Name',
            'TP_Name' : 'TP_Name',
            'ProcessFlag' : 'ProcessFlag',        },
*/

export const Label_DLID = 'ApiDocLoadConfig.DLID';
export const Label_DGID = 'ApiDocLoadConfig.DGID';
export const Label_DocType = 'ApiDocLoadConfig.DocType';
export const Label_TP_PartID = 'ApiDocLoadConfig.TP_PartID';
export const Label_Doc_Group = 'ApiDocLoadConfig.Doc_Group';
export const Label_Doc_Name = 'ApiDocLoadConfig.Doc_Name';
export const Label_TP_Name = 'ApiDocLoadConfig.TP_Name';
export const Label_ProcessFlag = 'ApiDocLoadConfig.ProcessFlag';
