import { IPartnerDocGroup } from '../edidb'
import uuid from 'uuid-v4';

export class CPartnerDocGroup implements IPartnerDocGroup {
    public Id: string = uuid();
    public Doc_Group:string = '';
    public TP_PartID:string = '';
    public DGID:string = '';
    public PartnerQual:string = '';
    public PartnerID:string = '';
    public TP_Name:string = '';
    public GroupID:string = '';
    public Van_ID:string = '';
    public TestProdInd:string = '';
    public CipherKey:string = '';
    public constructor(init?:Partial<CPartnerDocGroup>) { Object.assign(this, init); }
}
export const IPartnerDocGroup_Doc_Group_length = 50;
export const IPartnerDocGroup_TP_PartID_length = 30;
export const IPartnerDocGroup_DGID_length = 5;
export const IPartnerDocGroup_PartnerQual_length = 2;
export const IPartnerDocGroup_PartnerID_length = 30;
export const IPartnerDocGroup_TP_Name_length = 30;
export const IPartnerDocGroup_GroupID_length = 30;
export const IPartnerDocGroup_Van_ID_length = 10;
export const IPartnerDocGroup_TestProdInd_length = 1;
export const IPartnerDocGroup_CipherKey_length = 80;

export const kPartnerDocGroup_Doc_Group="Doc_Group";
export const kPartnerDocGroup_TP_PartID="TP_PartID";
export const kPartnerDocGroup_DGID="DGID";
export const kPartnerDocGroup_PartnerQual="PartnerQual";
export const kPartnerDocGroup_PartnerID="PartnerID";
export const kPartnerDocGroup_TP_Name="TP_Name";
export const kPartnerDocGroup_GroupID="GroupID";
export const kPartnerDocGroup_Van_ID="Van_ID";
export const kPartnerDocGroup_TestProdInd="TestProdInd";
export const kPartnerDocGroup_CipherKey="CipherKey";

/*
        'PartnerDocGroup' : {
            'Doc_Group' : 'Doc_Group',
            'TP_PartID' : 'TP_PartID',
            'DGID' : 'DGID',
            'PartnerQual' : 'PartnerQual',
            'PartnerID' : 'PartnerID',
            'TP_Name' : 'TP_Name',
            'GroupID' : 'GroupID',
            'Van_ID' : 'Van_ID',
            'TestProdInd' : 'TestProdInd',
            'CipherKey' : 'CipherKey',        },
*/

export const Label_Doc_Group = 'PartnerDocGroup.Doc_Group';
export const Label_TP_PartID = 'PartnerDocGroup.TP_PartID';
export const Label_DGID = 'PartnerDocGroup.DGID';
export const Label_PartnerQual = 'PartnerDocGroup.PartnerQual';
export const Label_PartnerID = 'PartnerDocGroup.PartnerID';
export const Label_TP_Name = 'PartnerDocGroup.TP_Name';
export const Label_GroupID = 'PartnerDocGroup.GroupID';
export const Label_Van_ID = 'PartnerDocGroup.Van_ID';
export const Label_TestProdInd = 'PartnerDocGroup.TestProdInd';
export const Label_CipherKey = 'PartnerDocGroup.CipherKey';
