import { ITempDocsToHold } from '../edidb'
export class CTempDocsToHold implements ITempDocsToHold {
    public machinename:string = '';
    public username:string = '';
    public LogDate:Date;
    public VPID:number = 0;
    public TransID:string = '';
    public DGID:string = '';
    public constructor(init?:Partial<CTempDocsToHold>) { Object.assign(this, init); }
}
export const kTempDocsToHold_machinename="machinename";
export const kTempDocsToHold_username="username";
export const kTempDocsToHold_LogDate="LogDate";
export const kTempDocsToHold_VPID="VPID";
export const kTempDocsToHold_TransID="TransID";
export const kTempDocsToHold_DGID="DGID";

/*
        'TempDocsToHold' : {
            'machinename' : 'machinename',
            'username' : 'username',
            'LogDate' : 'LogDate',
            'VPID' : 'VPID',
            'TransID' : 'TransID',
            'DGID' : 'DGID',        },
*/

export const Label_machinename = 'TempDocsToHold.machinename';
export const Label_username = 'TempDocsToHold.username';
export const Label_LogDate = 'TempDocsToHold.LogDate';
export const Label_VPID = 'TempDocsToHold.VPID';
export const Label_TransID = 'TempDocsToHold.TransID';
export const Label_DGID = 'TempDocsToHold.DGID';
