import { IRibbonShortcutUser } from '../edidb'
export class CRibbonShortcutUser implements IRibbonShortcutUser {
    public ID:number = 0;
    public TabID:number = 0;
    public managedID:number = 0;
    public UserEnabled:boolean;
    public UserVisible:boolean;
    public constructor(init?:Partial<CRibbonShortcutUser>) { Object.assign(this, init); }
}
export const kRibbonShortcutUser_ID="ID";
export const kRibbonShortcutUser_TabID="TabID";
export const kRibbonShortcutUser_managedID="managedID";
export const kRibbonShortcutUser_UserEnabled="UserEnabled";
export const kRibbonShortcutUser_UserVisible="UserVisible";

/*
        'RibbonShortcutUser' : {
            'ID' : 'ID',
            'TabID' : 'TabID',
            'managedID' : 'managedID',
            'UserEnabled' : 'UserEnabled',
            'UserVisible' : 'UserVisible',        },
*/

export const Label_ID = 'RibbonShortcutUser.ID';
export const Label_TabID = 'RibbonShortcutUser.TabID';
export const Label_managedID = 'RibbonShortcutUser.managedID';
export const Label_UserEnabled = 'RibbonShortcutUser.UserEnabled';
export const Label_UserVisible = 'RibbonShortcutUser.UserVisible';
