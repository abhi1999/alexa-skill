import { IEDIInventoryFeed } from '../edidb'
export class CEDIInventoryFeed implements IEDIInventoryFeed {
    public recid:string = '';
    public inventoryinqdate:string = '';
    public cusno:string = '';
    public transpurposecode:string = '';
    public shipfrid:string = '';
    public shipfrname:string = '';
    public shipfradd1:string = '';
    public shipfradd2:string = '';
    public shipfrcity:string = '';
    public shipfrstate:string = '';
    public shipfrzip:string = '';
    public shipfrcountry:string = '';
    public shipfrcontact:string = '';
    public shipfrphone:string = '';
    public shipfrfax:string = '';
    public shipfremail:string = '';
    public shipfruser1:string = '';
    public shipfruser2:string = '';
    public shipfruser3:string = '';
    public shipfruser4:string = '';
    public shipfruser5:string = '';
    public itemid:string = '';
    public itemactivitycode:string = '';
    public itemdesc:string = '';
    public itemdesc2:string = '';
    public price:number = 0;
    public qtyavailable:number = 0;
    public qtyonorder:number = 0;
    public qtyonorderavaildate:string = '';
    public uom:string = '';
    public engchangelevel:string = '';
    public itmuser1:string = '';
    public itmuser2:string = '';
    public itmuser3:string = '';
    public itmuser4:string = '';
    public itmuser5:string = '';
    public invenuser1:string = '';
    public invenuser2:string = '';
    public invenuser3:string = '';
    public invenuser4:string = '';
    public invenuser5:string = '';
    public EDILastQuantity:number = 0;
    public EDILastDateSent:Date;
    public EDILastGrouping:boolean;
    public ShowInImport:boolean;
    public constructor(init?:Partial<CEDIInventoryFeed>) { Object.assign(this, init); }
}
export const IEDIInventoryFeed_recid_length = 30;
export const IEDIInventoryFeed_inventoryinqdate_length = 30;
export const IEDIInventoryFeed_cusno_length = 15;
export const IEDIInventoryFeed_transpurposecode_length = 10;
export const IEDIInventoryFeed_shipfrid_length = 20;
export const IEDIInventoryFeed_shipfrname_length = 30;
export const IEDIInventoryFeed_shipfradd1_length = 100;
export const IEDIInventoryFeed_shipfradd2_length = 100;
export const IEDIInventoryFeed_shipfrcity_length = 60;
export const IEDIInventoryFeed_shipfrstate_length = 20;
export const IEDIInventoryFeed_shipfrzip_length = 10;
export const IEDIInventoryFeed_shipfrcountry_length = 30;
export const IEDIInventoryFeed_shipfrcontact_length = 60;
export const IEDIInventoryFeed_shipfrphone_length = 20;
export const IEDIInventoryFeed_shipfrfax_length = 20;
export const IEDIInventoryFeed_shipfremail_length = 50;
export const IEDIInventoryFeed_shipfruser1_length = 200;
export const IEDIInventoryFeed_shipfruser2_length = 200;
export const IEDIInventoryFeed_shipfruser3_length = 200;
export const IEDIInventoryFeed_shipfruser4_length = 200;
export const IEDIInventoryFeed_shipfruser5_length = 200;
export const IEDIInventoryFeed_itemid_length = 200;
export const IEDIInventoryFeed_itemactivitycode_length = 10;
export const IEDIInventoryFeed_itemdesc_length = 100;
export const IEDIInventoryFeed_itemdesc2_length = 100;
export const IEDIInventoryFeed_qtyonorderavaildate_length = 8;
export const IEDIInventoryFeed_uom_length = 4;
export const IEDIInventoryFeed_engchangelevel_length = 40;
export const IEDIInventoryFeed_itmuser1_length = 200;
export const IEDIInventoryFeed_itmuser2_length = 200;
export const IEDIInventoryFeed_itmuser3_length = 200;
export const IEDIInventoryFeed_itmuser4_length = 200;
export const IEDIInventoryFeed_itmuser5_length = 200;
export const IEDIInventoryFeed_invenuser1_length = 200;
export const IEDIInventoryFeed_invenuser2_length = 200;
export const IEDIInventoryFeed_invenuser3_length = 200;
export const IEDIInventoryFeed_invenuser4_length = 200;
export const IEDIInventoryFeed_invenuser5_length = 200;

export const kEDIInventoryFeed_recid="recid";
export const kEDIInventoryFeed_inventoryinqdate="inventoryinqdate";
export const kEDIInventoryFeed_cusno="cusno";
export const kEDIInventoryFeed_transpurposecode="transpurposecode";
export const kEDIInventoryFeed_shipfrid="shipfrid";
export const kEDIInventoryFeed_shipfrname="shipfrname";
export const kEDIInventoryFeed_shipfradd1="shipfradd1";
export const kEDIInventoryFeed_shipfradd2="shipfradd2";
export const kEDIInventoryFeed_shipfrcity="shipfrcity";
export const kEDIInventoryFeed_shipfrstate="shipfrstate";
export const kEDIInventoryFeed_shipfrzip="shipfrzip";
export const kEDIInventoryFeed_shipfrcountry="shipfrcountry";
export const kEDIInventoryFeed_shipfrcontact="shipfrcontact";
export const kEDIInventoryFeed_shipfrphone="shipfrphone";
export const kEDIInventoryFeed_shipfrfax="shipfrfax";
export const kEDIInventoryFeed_shipfremail="shipfremail";
export const kEDIInventoryFeed_shipfruser1="shipfruser1";
export const kEDIInventoryFeed_shipfruser2="shipfruser2";
export const kEDIInventoryFeed_shipfruser3="shipfruser3";
export const kEDIInventoryFeed_shipfruser4="shipfruser4";
export const kEDIInventoryFeed_shipfruser5="shipfruser5";
export const kEDIInventoryFeed_itemid="itemid";
export const kEDIInventoryFeed_itemactivitycode="itemactivitycode";
export const kEDIInventoryFeed_itemdesc="itemdesc";
export const kEDIInventoryFeed_itemdesc2="itemdesc2";
export const kEDIInventoryFeed_price="price";
export const kEDIInventoryFeed_qtyavailable="qtyavailable";
export const kEDIInventoryFeed_qtyonorder="qtyonorder";
export const kEDIInventoryFeed_qtyonorderavaildate="qtyonorderavaildate";
export const kEDIInventoryFeed_uom="uom";
export const kEDIInventoryFeed_engchangelevel="engchangelevel";
export const kEDIInventoryFeed_itmuser1="itmuser1";
export const kEDIInventoryFeed_itmuser2="itmuser2";
export const kEDIInventoryFeed_itmuser3="itmuser3";
export const kEDIInventoryFeed_itmuser4="itmuser4";
export const kEDIInventoryFeed_itmuser5="itmuser5";
export const kEDIInventoryFeed_invenuser1="invenuser1";
export const kEDIInventoryFeed_invenuser2="invenuser2";
export const kEDIInventoryFeed_invenuser3="invenuser3";
export const kEDIInventoryFeed_invenuser4="invenuser4";
export const kEDIInventoryFeed_invenuser5="invenuser5";
export const kEDIInventoryFeed_EDILastQuantity="EDILastQuantity";
export const kEDIInventoryFeed_EDILastDateSent="EDILastDateSent";
export const kEDIInventoryFeed_EDILastGrouping="EDILastGrouping";
export const kEDIInventoryFeed_ShowInImport="ShowInImport";

/*
        'EDIInventoryFeed' : {
            'recid' : 'recid',
            'inventoryinqdate' : 'inventoryinqdate',
            'cusno' : 'cusno',
            'transpurposecode' : 'transpurposecode',
            'shipfrid' : 'shipfrid',
            'shipfrname' : 'shipfrname',
            'shipfradd1' : 'shipfradd1',
            'shipfradd2' : 'shipfradd2',
            'shipfrcity' : 'shipfrcity',
            'shipfrstate' : 'shipfrstate',
            'shipfrzip' : 'shipfrzip',
            'shipfrcountry' : 'shipfrcountry',
            'shipfrcontact' : 'shipfrcontact',
            'shipfrphone' : 'shipfrphone',
            'shipfrfax' : 'shipfrfax',
            'shipfremail' : 'shipfremail',
            'shipfruser1' : 'shipfruser1',
            'shipfruser2' : 'shipfruser2',
            'shipfruser3' : 'shipfruser3',
            'shipfruser4' : 'shipfruser4',
            'shipfruser5' : 'shipfruser5',
            'itemid' : 'itemid',
            'itemactivitycode' : 'itemactivitycode',
            'itemdesc' : 'itemdesc',
            'itemdesc2' : 'itemdesc2',
            'price' : 'price',
            'qtyavailable' : 'qtyavailable',
            'qtyonorder' : 'qtyonorder',
            'qtyonorderavaildate' : 'qtyonorderavaildate',
            'uom' : 'uom',
            'engchangelevel' : 'engchangelevel',
            'itmuser1' : 'itmuser1',
            'itmuser2' : 'itmuser2',
            'itmuser3' : 'itmuser3',
            'itmuser4' : 'itmuser4',
            'itmuser5' : 'itmuser5',
            'invenuser1' : 'invenuser1',
            'invenuser2' : 'invenuser2',
            'invenuser3' : 'invenuser3',
            'invenuser4' : 'invenuser4',
            'invenuser5' : 'invenuser5',
            'EDILastQuantity' : 'EDILastQuantity',
            'EDILastDateSent' : 'EDILastDateSent',
            'EDILastGrouping' : 'EDILastGrouping',
            'ShowInImport' : 'ShowInImport',        },
*/

export const Label_recid = 'EDIInventoryFeed.recid';
export const Label_inventoryinqdate = 'EDIInventoryFeed.inventoryinqdate';
export const Label_cusno = 'EDIInventoryFeed.cusno';
export const Label_transpurposecode = 'EDIInventoryFeed.transpurposecode';
export const Label_shipfrid = 'EDIInventoryFeed.shipfrid';
export const Label_shipfrname = 'EDIInventoryFeed.shipfrname';
export const Label_shipfradd1 = 'EDIInventoryFeed.shipfradd1';
export const Label_shipfradd2 = 'EDIInventoryFeed.shipfradd2';
export const Label_shipfrcity = 'EDIInventoryFeed.shipfrcity';
export const Label_shipfrstate = 'EDIInventoryFeed.shipfrstate';
export const Label_shipfrzip = 'EDIInventoryFeed.shipfrzip';
export const Label_shipfrcountry = 'EDIInventoryFeed.shipfrcountry';
export const Label_shipfrcontact = 'EDIInventoryFeed.shipfrcontact';
export const Label_shipfrphone = 'EDIInventoryFeed.shipfrphone';
export const Label_shipfrfax = 'EDIInventoryFeed.shipfrfax';
export const Label_shipfremail = 'EDIInventoryFeed.shipfremail';
export const Label_shipfruser1 = 'EDIInventoryFeed.shipfruser1';
export const Label_shipfruser2 = 'EDIInventoryFeed.shipfruser2';
export const Label_shipfruser3 = 'EDIInventoryFeed.shipfruser3';
export const Label_shipfruser4 = 'EDIInventoryFeed.shipfruser4';
export const Label_shipfruser5 = 'EDIInventoryFeed.shipfruser5';
export const Label_itemid = 'EDIInventoryFeed.itemid';
export const Label_itemactivitycode = 'EDIInventoryFeed.itemactivitycode';
export const Label_itemdesc = 'EDIInventoryFeed.itemdesc';
export const Label_itemdesc2 = 'EDIInventoryFeed.itemdesc2';
export const Label_price = 'EDIInventoryFeed.price';
export const Label_qtyavailable = 'EDIInventoryFeed.qtyavailable';
export const Label_qtyonorder = 'EDIInventoryFeed.qtyonorder';
export const Label_qtyonorderavaildate = 'EDIInventoryFeed.qtyonorderavaildate';
export const Label_uom = 'EDIInventoryFeed.uom';
export const Label_engchangelevel = 'EDIInventoryFeed.engchangelevel';
export const Label_itmuser1 = 'EDIInventoryFeed.itmuser1';
export const Label_itmuser2 = 'EDIInventoryFeed.itmuser2';
export const Label_itmuser3 = 'EDIInventoryFeed.itmuser3';
export const Label_itmuser4 = 'EDIInventoryFeed.itmuser4';
export const Label_itmuser5 = 'EDIInventoryFeed.itmuser5';
export const Label_invenuser1 = 'EDIInventoryFeed.invenuser1';
export const Label_invenuser2 = 'EDIInventoryFeed.invenuser2';
export const Label_invenuser3 = 'EDIInventoryFeed.invenuser3';
export const Label_invenuser4 = 'EDIInventoryFeed.invenuser4';
export const Label_invenuser5 = 'EDIInventoryFeed.invenuser5';
export const Label_EDILastQuantity = 'EDIInventoryFeed.EDILastQuantity';
export const Label_EDILastDateSent = 'EDIInventoryFeed.EDILastDateSent';
export const Label_EDILastGrouping = 'EDIInventoryFeed.EDILastGrouping';
export const Label_ShowInImport = 'EDIInventoryFeed.ShowInImport';
