import { IGetTransObjectsWithCacheResult } from '../edidb'
export class CGetTransObjectsWithCacheResult implements IGetTransObjectsWithCacheResult {
    public DGID:string = '';
    public TransID:string = '';
    public TP_PartID:string = '';
    public TDocName:string = '';
    public FilenameLayout:string = '';
    public PackageSeparately:boolean;
    public UseControlNums:boolean;
    public TransIDImportDate:Date;
    public TransIDObj_Date:Date;
    public TDocNameImportDate:Date;
    public TDocNameObj_Date:Date;
    public constructor(init?:Partial<CGetTransObjectsWithCacheResult>) { Object.assign(this, init); }
}
export const kGetTransObjectsWithCacheResult_DGID="DGID";
export const kGetTransObjectsWithCacheResult_TransID="TransID";
export const kGetTransObjectsWithCacheResult_TP_PartID="TP_PartID";
export const kGetTransObjectsWithCacheResult_TDocName="TDocName";
export const kGetTransObjectsWithCacheResult_FilenameLayout="FilenameLayout";
export const kGetTransObjectsWithCacheResult_PackageSeparately="PackageSeparately";
export const kGetTransObjectsWithCacheResult_UseControlNums="UseControlNums";
export const kGetTransObjectsWithCacheResult_TransIDImportDate="TransIDImportDate";
export const kGetTransObjectsWithCacheResult_TransIDObj_Date="TransIDObj_Date";
export const kGetTransObjectsWithCacheResult_TDocNameImportDate="TDocNameImportDate";
export const kGetTransObjectsWithCacheResult_TDocNameObj_Date="TDocNameObj_Date";

/*
        'GetTransObjectsWithCacheResult' : {
            'DGID' : 'DGID',
            'TransID' : 'TransID',
            'TP_PartID' : 'TP_PartID',
            'TDocName' : 'TDocName',
            'FilenameLayout' : 'FilenameLayout',
            'PackageSeparately' : 'PackageSeparately',
            'UseControlNums' : 'UseControlNums',
            'TransIDImportDate' : 'TransIDImportDate',
            'TransIDObj_Date' : 'TransIDObj_Date',
            'TDocNameImportDate' : 'TDocNameImportDate',
            'TDocNameObj_Date' : 'TDocNameObj_Date',        },
*/

export const Label_DGID = 'GetTransObjectsWithCacheResult.DGID';
export const Label_TransID = 'GetTransObjectsWithCacheResult.TransID';
export const Label_TP_PartID = 'GetTransObjectsWithCacheResult.TP_PartID';
export const Label_TDocName = 'GetTransObjectsWithCacheResult.TDocName';
export const Label_FilenameLayout = 'GetTransObjectsWithCacheResult.FilenameLayout';
export const Label_PackageSeparately = 'GetTransObjectsWithCacheResult.PackageSeparately';
export const Label_UseControlNums = 'GetTransObjectsWithCacheResult.UseControlNums';
export const Label_TransIDImportDate = 'GetTransObjectsWithCacheResult.TransIDImportDate';
export const Label_TransIDObj_Date = 'GetTransObjectsWithCacheResult.TransIDObj_Date';
export const Label_TDocNameImportDate = 'GetTransObjectsWithCacheResult.TDocNameImportDate';
export const Label_TDocNameObj_Date = 'GetTransObjectsWithCacheResult.TDocNameObj_Date';
