import { IApiRouteInstruction } from '../edidb'
export class CApiRouteInstruction implements IApiRouteInstruction {
    public Id:string = '';
    public RI_ID:number = 0;
    public Seq_No:number = 0;
    public Ref_ID:string = '';
    public FullRRC_Ctrl_No:string = '';
    public Cust_PO:string = '';
    public PU_Appt:string = '';
    public PU_Date:Date;
    public SCAC:string = '';
    public Resp_RRC:string = '';
    public Trans_Lvl_Req:string = '';
    public Multi_Stop:string = '';
    public Stop_Seq:string = '';
    public ShipTo_ID:string = '';
    public Order_No:string = '';
    public TP_Name:string = '';
    public constructor(init?:Partial<CApiRouteInstruction>) { Object.assign(this, init); }
}
export const IApiRouteInstruction_Ref_ID_length = 50;
export const IApiRouteInstruction_FullRRC_Ctrl_No_length = 50;
export const IApiRouteInstruction_Cust_PO_length = 30;
export const IApiRouteInstruction_PU_Appt_length = 50;
export const IApiRouteInstruction_SCAC_length = 4;
export const IApiRouteInstruction_Resp_RRC_length = 2;
export const IApiRouteInstruction_Trans_Lvl_Req_length = 80;
export const IApiRouteInstruction_Multi_Stop_length = 1;
export const IApiRouteInstruction_Stop_Seq_length = 3;
export const IApiRouteInstruction_ShipTo_ID_length = 30;
export const IApiRouteInstruction_Order_No_length = 10;
export const IApiRouteInstruction_TP_Name_length = 30;

export const kApiRouteInstruction_RI_ID="RI_ID";
export const kApiRouteInstruction_Seq_No="Seq_No";
export const kApiRouteInstruction_Ref_ID="Ref_ID";
export const kApiRouteInstruction_FullRRC_Ctrl_No="FullRRC_Ctrl_No";
export const kApiRouteInstruction_Cust_PO="Cust_PO";
export const kApiRouteInstruction_PU_Appt="PU_Appt";
export const kApiRouteInstruction_PU_Date="PU_Date";
export const kApiRouteInstruction_SCAC="SCAC";
export const kApiRouteInstruction_Resp_RRC="Resp_RRC";
export const kApiRouteInstruction_Trans_Lvl_Req="Trans_Lvl_Req";
export const kApiRouteInstruction_Multi_Stop="Multi_Stop";
export const kApiRouteInstruction_Stop_Seq="Stop_Seq";
export const kApiRouteInstruction_ShipTo_ID="ShipTo_ID";
export const kApiRouteInstruction_Order_No="Order_No";
export const kApiRouteInstruction_TP_Name="TP_Name";

/*
        'RouteInstr' : {
            'RI_ID' : 'RI_ID',
            'Seq_No' : 'Seq_No',
            'Ref_ID' : 'Ref_ID',
            'FullRRC_Ctrl_No' : 'FullRRC_Ctrl_No',
            'Cust_PO' : 'Cust_PO',
            'PU_Appt' : 'PU_Appt',
            'PU_Date' : 'PU_Date',
            'SCAC' : 'SCAC',
            'Resp_RRC' : 'Resp_RRC',
            'Trans_Lvl_Req' : 'Trans_Lvl_Req',
            'Multi_Stop' : 'Multi_Stop',
            'Stop_Seq' : 'Stop_Seq',
            'ShipTo_ID' : 'ShipTo_ID',
            'Asn_ID' : 'Asn_ID',
            'Misc_ID' : 'Misc_ID',
        },
*/

export const Label_RI_ID = 'ApiRouteInstruction.RI_ID';
export const Label_Seq_No = 'ApiRouteInstruction.Seq_No';
export const Label_Ref_ID = 'ApiRouteInstruction.Ref_ID';
export const Label_FullRRC_Ctrl_No = 'ApiRouteInstruction.FullRRC_Ctrl_No';
export const Label_Cust_PO = 'ApiRouteInstruction.Cust_PO';
export const Label_PU_Appt = 'ApiRouteInstruction.PU_Appt';
export const Label_PU_Date = 'ApiRouteInstruction.PU_Date';
export const Label_SCAC = 'ApiRouteInstruction.SCAC';
export const Label_Resp_RRC = 'ApiRouteInstruction.Resp_RRC';
export const Label_Trans_Lvl_Req = 'ApiRouteInstruction.Trans_Lvl_Req';
export const Label_Multi_Stop = 'ApiRouteInstruction.Multi_Stop';
export const Label_Stop_Seq = 'ApiRouteInstruction.Stop_Seq';
export const Label_ShipTo_ID = 'ApiRouteInstruction.ShipTo_ID';
export const Label_Order_No = 'ApiRouteInstruction.Order_No';
export const Label_TP_Name = 'ApiRouteInstruction.TP_Name';
