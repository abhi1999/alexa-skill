import { IApiAsnBaseView } from '../edidb'
export class CApiAsnBaseView implements IApiAsnBaseView {
    public Asn_ID:number = 0;
    public Bol_No:string = '';
    public Pro_No:string = '';
    public ShipToPeps:boolean;
    public Ship_Weight:number = 0;
    public Ship_Date:string = '';
    public Del_Date:string = '';
    public Ship_Via_ID:string = '';
    public Asn_Complete:string = '';
    public Exp_Flag:string = '';
    public TP_PartID:string = '';
    public User1:string = '';
    public User2:string = '';
    public Trailer:string = '';
    public Collect:boolean;
    public AckID:string = '';
    public GCN:number = 0;
    public TCN:number = 0;
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public SealNo:string = '';
    public ExportDate:Date;
    public CreatedDate:Date;
    public PackImport:string = '';
    public VPIDFA:number = 0;
    public TP_Name:string = '';
    public NoteText:string = '';
    public constructor(init?:Partial<CApiAsnBaseView>) { Object.assign(this, init); }
}
export const IApiAsnBaseView_Bol_No_length = 30;
export const IApiAsnBaseView_Pro_No_length = 30;
export const IApiAsnBaseView_Ship_Date_length = 8;
export const IApiAsnBaseView_Del_Date_length = 8;
export const IApiAsnBaseView_Ship_Via_ID_length = 30;
export const IApiAsnBaseView_Asn_Complete_length = 1;
export const IApiAsnBaseView_Exp_Flag_length = 1;
export const IApiAsnBaseView_TP_PartID_length = 30;
export const IApiAsnBaseView_User1_length = 50;
export const IApiAsnBaseView_User2_length = 50;
export const IApiAsnBaseView_Trailer_length = 50;
export const IApiAsnBaseView_AckID_length = 1;
export const IApiAsnBaseView_User3_length = 50;
export const IApiAsnBaseView_User4_length = 50;
export const IApiAsnBaseView_User5_length = 50;
export const IApiAsnBaseView_SealNo_length = 200;
export const IApiAsnBaseView_PackImport_length = 1;
export const IApiAsnBaseView_TP_Name_length = 30;
export const IApiAsnBaseView_NoteText_length = 2000;

export const kApiAsnBaseView_Asn_ID="Asn_ID";
export const kApiAsnBaseView_Bol_No="Bol_No";
export const kApiAsnBaseView_Pro_No="Pro_No";
export const kApiAsnBaseView_ShipToPeps="ShipToPeps";
export const kApiAsnBaseView_Ship_Weight="Ship_Weight";
export const kApiAsnBaseView_Ship_Date="Ship_Date";
export const kApiAsnBaseView_Del_Date="Del_Date";
export const kApiAsnBaseView_Ship_Via_ID="Ship_Via_ID";
export const kApiAsnBaseView_Asn_Complete="Asn_Complete";
export const kApiAsnBaseView_Exp_Flag="Exp_Flag";
export const kApiAsnBaseView_TP_PartID="TP_PartID";
export const kApiAsnBaseView_User1="User1";
export const kApiAsnBaseView_User2="User2";
export const kApiAsnBaseView_Trailer="Trailer";
export const kApiAsnBaseView_Collect="Collect";
export const kApiAsnBaseView_AckID="AckID";
export const kApiAsnBaseView_GCN="GCN";
export const kApiAsnBaseView_TCN="TCN";
export const kApiAsnBaseView_User3="User3";
export const kApiAsnBaseView_User4="User4";
export const kApiAsnBaseView_User5="User5";
export const kApiAsnBaseView_SealNo="SealNo";
export const kApiAsnBaseView_ExportDate="ExportDate";
export const kApiAsnBaseView_CreatedDate="CreatedDate";
export const kApiAsnBaseView_PackImport="PackImport";
export const kApiAsnBaseView_VPIDFA="VPIDFA";
export const kApiAsnBaseView_TP_Name="TP_Name";
export const kApiAsnBaseView_NoteText="NoteText";

/*
        'ApiAsnBaseView' : {
            'Asn_ID' : 'Asn_ID',
            'Bol_No' : 'Bol_No',
            'Pro_No' : 'Pro_No',
            'ShipToPeps' : 'ShipToPeps',
            'Ship_Weight' : 'Ship_Weight',
            'Ship_Date' : 'Ship_Date',
            'Del_Date' : 'Del_Date',
            'Ship_Via_ID' : 'Ship_Via_ID',
            'Asn_Complete' : 'Asn_Complete',
            'Exp_Flag' : 'Exp_Flag',
            'TP_PartID' : 'TP_PartID',
            'User1' : 'User1',
            'User2' : 'User2',
            'Trailer' : 'Trailer',
            'Collect' : 'Collect',
            'AckID' : 'AckID',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'SealNo' : 'SealNo',
            'ExportDate' : 'ExportDate',
            'CreatedDate' : 'CreatedDate',
            'PackImport' : 'PackImport',
            'VPIDFA' : 'VPIDFA',
            'TP_Name' : 'TP_Name',
            'NoteText' : 'NoteText',        },
*/

export const Label_Asn_ID = 'ApiAsnBaseView.Asn_ID';
export const Label_Bol_No = 'ApiAsnBaseView.Bol_No';
export const Label_Pro_No = 'ApiAsnBaseView.Pro_No';
export const Label_ShipToPeps = 'ApiAsnBaseView.ShipToPeps';
export const Label_Ship_Weight = 'ApiAsnBaseView.Ship_Weight';
export const Label_Ship_Date = 'ApiAsnBaseView.Ship_Date';
export const Label_Del_Date = 'ApiAsnBaseView.Del_Date';
export const Label_Ship_Via_ID = 'ApiAsnBaseView.Ship_Via_ID';
export const Label_Asn_Complete = 'ApiAsnBaseView.Asn_Complete';
export const Label_Exp_Flag = 'ApiAsnBaseView.Exp_Flag';
export const Label_TP_PartID = 'ApiAsnBaseView.TP_PartID';
export const Label_User1 = 'ApiAsnBaseView.User1';
export const Label_User2 = 'ApiAsnBaseView.User2';
export const Label_Trailer = 'ApiAsnBaseView.Trailer';
export const Label_Collect = 'ApiAsnBaseView.Collect';
export const Label_AckID = 'ApiAsnBaseView.AckID';
export const Label_GCN = 'ApiAsnBaseView.GCN';
export const Label_TCN = 'ApiAsnBaseView.TCN';
export const Label_User3 = 'ApiAsnBaseView.User3';
export const Label_User4 = 'ApiAsnBaseView.User4';
export const Label_User5 = 'ApiAsnBaseView.User5';
export const Label_SealNo = 'ApiAsnBaseView.SealNo';
export const Label_ExportDate = 'ApiAsnBaseView.ExportDate';
export const Label_CreatedDate = 'ApiAsnBaseView.CreatedDate';
export const Label_PackImport = 'ApiAsnBaseView.PackImport';
export const Label_VPIDFA = 'ApiAsnBaseView.VPIDFA';
export const Label_TP_Name = 'ApiAsnBaseView.TP_Name';
export const Label_NoteText = 'ApiAsnBaseView.NoteText';
