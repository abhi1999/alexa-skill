import { IC303v850h } from '../edidb'
export class CC303v850h implements IC303v850h {
    public PO_ID:number = 0;
    public TP_PartID:string = '';
    public BEG_01:string = '';
    public BEG_02:string = '';
    public BEG_03:string = '';
    public BEG_04:string = '';
    public BEG_05:string = '';
    public BEG_06:string = '';
    public CTT_01:string = '';
    public Exp_Flag:string = '';
    public Int_OrdID:number = 0;
    public SDQ_Flag:string = '';
    public CUR_02:string = '';
    public ImportDate:Date;
    public ExportDate:Date;
    public Misc_ID:number = 0;
    public URECID:string = '';
    public UDID:string = '';
    public Revision:number = 0;
    public Cust_Ship_Via_ID:string = '';
    public Cust_Terms_ID:string = '';
    public FrtPayMeth:string = '';
    public VPIDFA:number = 0;
    public constructor(init?:Partial<CC303v850h>) { Object.assign(this, init); }
}
export const IC303v850h_TP_PartID_length = 30;
export const IC303v850h_BEG_01_length = 2;
export const IC303v850h_BEG_02_length = 3;
export const IC303v850h_BEG_03_length = 22;
export const IC303v850h_BEG_04_length = 30;
export const IC303v850h_BEG_05_length = 8;
export const IC303v850h_BEG_06_length = 30;
export const IC303v850h_CTT_01_length = 7;
export const IC303v850h_Exp_Flag_length = 1;
export const IC303v850h_SDQ_Flag_length = 1;
export const IC303v850h_CUR_02_length = 3;
export const IC303v850h_Cust_Ship_Via_ID_length = 50;
export const IC303v850h_Cust_Terms_ID_length = 50;
export const IC303v850h_FrtPayMeth_length = 3;

export const kC303v850h_PO_ID="PO_ID";
export const kC303v850h_TP_PartID="TP_PartID";
export const kC303v850h_BEG_01="BEG_01";
export const kC303v850h_BEG_02="BEG_02";
export const kC303v850h_BEG_03="BEG_03";
export const kC303v850h_BEG_04="BEG_04";
export const kC303v850h_BEG_05="BEG_05";
export const kC303v850h_BEG_06="BEG_06";
export const kC303v850h_CTT_01="CTT_01";
export const kC303v850h_Exp_Flag="Exp_Flag";
export const kC303v850h_Int_OrdID="Int_OrdID";
export const kC303v850h_SDQ_Flag="SDQ_Flag";
export const kC303v850h_CUR_02="CUR_02";
export const kC303v850h_ImportDate="ImportDate";
export const kC303v850h_ExportDate="ExportDate";
export const kC303v850h_Misc_ID="Misc_ID";
export const kC303v850h_URECID="URECID";
export const kC303v850h_UDID="UDID";
export const kC303v850h_Revision="Revision";
export const kC303v850h_Cust_Ship_Via_ID="Cust_Ship_Via_ID";
export const kC303v850h_Cust_Terms_ID="Cust_Terms_ID";
export const kC303v850h_FrtPayMeth="FrtPayMeth";
export const kC303v850h_VPIDFA="VPIDFA";

/*
        'C303v850h' : {
            'PO_ID' : 'PO_ID',
            'TP_PartID' : 'TP_PartID',
            'BEG_01' : 'BEG_01',
            'BEG_02' : 'BEG_02',
            'BEG_03' : 'BEG_03',
            'BEG_04' : 'BEG_04',
            'BEG_05' : 'BEG_05',
            'BEG_06' : 'BEG_06',
            'CTT_01' : 'CTT_01',
            'Exp_Flag' : 'Exp_Flag',
            'Int_OrdID' : 'Int_OrdID',
            'SDQ_Flag' : 'SDQ_Flag',
            'CUR_02' : 'CUR_02',
            'ImportDate' : 'ImportDate',
            'ExportDate' : 'ExportDate',
            'Misc_ID' : 'Misc_ID',
            'URECID' : 'URECID',
            'UDID' : 'UDID',
            'Revision' : 'Revision',
            'Cust_Ship_Via_ID' : 'Cust_Ship_Via_ID',
            'Cust_Terms_ID' : 'Cust_Terms_ID',
            'FrtPayMeth' : 'FrtPayMeth',
            'VPIDFA' : 'VPIDFA',        },
*/

export const Label_PO_ID = 'C303v850h.PO_ID';
export const Label_TP_PartID = 'C303v850h.TP_PartID';
export const Label_BEG_01 = 'C303v850h.BEG_01';
export const Label_BEG_02 = 'C303v850h.BEG_02';
export const Label_BEG_03 = 'C303v850h.BEG_03';
export const Label_BEG_04 = 'C303v850h.BEG_04';
export const Label_BEG_05 = 'C303v850h.BEG_05';
export const Label_BEG_06 = 'C303v850h.BEG_06';
export const Label_CTT_01 = 'C303v850h.CTT_01';
export const Label_Exp_Flag = 'C303v850h.Exp_Flag';
export const Label_Int_OrdID = 'C303v850h.Int_OrdID';
export const Label_SDQ_Flag = 'C303v850h.SDQ_Flag';
export const Label_CUR_02 = 'C303v850h.CUR_02';
export const Label_ImportDate = 'C303v850h.ImportDate';
export const Label_ExportDate = 'C303v850h.ExportDate';
export const Label_Misc_ID = 'C303v850h.Misc_ID';
export const Label_URECID = 'C303v850h.URECID';
export const Label_UDID = 'C303v850h.UDID';
export const Label_Revision = 'C303v850h.Revision';
export const Label_Cust_Ship_Via_ID = 'C303v850h.Cust_Ship_Via_ID';
export const Label_Cust_Terms_ID = 'C303v850h.Cust_Terms_ID';
export const Label_FrtPayMeth = 'C303v850h.FrtPayMeth';
export const Label_VPIDFA = 'C303v850h.VPIDFA';
