import { IApiGetProductActivitySummary } from '../edidb'
export class CApiGetProductActivitySummary implements IApiGetProductActivitySummary {
    public Year:number = 0;
    public Name:string = '';
    public Total:number = 0;
    public constructor(init?:Partial<CApiGetProductActivitySummary>) { Object.assign(this, init); }
}
export const IApiGetProductActivitySummary_Name_length = 30;

export const kApiGetProductActivitySummary_Year="Year";
export const kApiGetProductActivitySummary_Name="Name";
export const kApiGetProductActivitySummary_Total="Total";

/*
        'ApiGetProductActivitySummary' : {
            'Year' : 'Year',
            'Name' : 'Name',
            'Total' : 'Total',        },
*/

export const Label_Year = 'ApiGetProductActivitySummary.Year';
export const Label_Name = 'ApiGetProductActivitySummary.Name';
export const Label_Total = 'ApiGetProductActivitySummary.Total';
