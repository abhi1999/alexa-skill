import { IPackAndShipSelectOrder } from '../edidb'
export class CPackAndShipSelectOrder implements IPackAndShipSelectOrder {
  
  public Order_No: number = 0;
  public Acct_Order_No: string = "";
  public TP_ID: string = "";
  public TP_Name: string = "";  
  public ShipTo_Xref: string = "";  
  public Order_Date: string = "";  
  public Ship_Date: string= "";  
  public Cust_PO: string = "";  
  public Exp_Flag: string = "";  
  public Stat_Flag: string = "";  
  public Ship_To_Name: string = "";  
  public Loc_ID: string = "";  
  public ShipTo_ID: string = ""; 
  public ShipTo_DC: string = ""; 
  public ASN_ID: string = "";
  public status: string = "";

  public constructor(init?:Partial<CPackAndShipSelectOrder>) { Object.assign(this, init); }
}

export const IPackAndShipSelectOrder_Order_No_length = 30;
export const IPackAndShipSelectOrder_Acct_Order_No_length = 30;
export const IPackAndShipSelectOrder_TP_ID_length = 30;
export const IPackAndShipSelectOrder_TP_Name_length = 30;
export const IPackAndShipSelectOrder_ShipTo_Xref_length = 30;
export const IPackAndShipSelectOrder_Order_Date_length = 30;
export const IPackAndShipSelectOrder_Ship_Date_length = 8;
export const IPackAndShipSelectOrder_Cust_PO_length = 50;
export const IPackAndShipSelectOrder_Exp_Flag_length = 5;
export const IPackAndShipSelectOrder_Stat_Flag_length = 5;
export const IPackAndShipSelectOrder_Ship_To_Name = 30;
export const IPackAndShipSelectOrder_Loc_ID_length = 5;
export const IPackAndShipSelectOrder_ShipTo_ID_length = 5;
export const IPackAndShipSelectOrder_ShipTo_DC_length = 5;
export const IPackAndShipSelectOrder_ASN_ID_length = 5;
export const IPackAndShipSelectOrder_status_length = 5;

export const kPackAndShipSelectOrder_Order_No = 'Order_No';
export const kPackAndShipSelectOrder_Acct_Order_No = 'Acct_Order_No';
export const kPackAndShipSelectOrder_TP_ID = 'TP_ID';
export const kPackAndShipSelectOrder_TP_Name = 'TP_Name';
export const kPackAndShipSelectOrder_ShipTo_Xref = 'ShipTo_Xref';
export const kPackAndShipSelectOrder_Order_Date = 'Order_Date';
export const kPackAndShipSelectOrder_Ship_Date = 'Ship_Date';
export const kPackAndShipSelectOrder_Cust_PO = 'Cust_PO';
export const kPackAndShipSelectOrder_Exp_Flag = 'Exp_Flag';
export const kPackAndShipSelectOrder_Stat_Flag = 'Stat_Flag';
export const kPackAndShipSelectOrder_Ship_To_Name = 'Ship_To_Name';
export const kPackAndShipSelectOrder_Loc_ID = 'Loc_ID';
export const kPackAndShipSelectOrder_ShipTo_ID = 'ShipTo_ID';
export const kPackAndShipSelectOrder_ShipTo_DC = 'ShipTo_DC';
export const kPackAndShipSelectOrder_ASN_ID = 'ASN_ID';
export const kPackAndShipSelectOrder_status = 'status';

export const Label_Order_No = 'PackAndShip.Order_No';
export const Label_Acct_Order_No = 'PackAndShip.Acct_Order_No';
export const Label_TP_ID = 'PackAndShip.TP_ID';
export const Label_TP_Name = 'PackAndShip.TP_Name';
export const Label_ShipTo_Xref = 'PackAndShip.ShipTo_Xref';
export const Label_Order_Date = 'PackAndShip.Order_Date';
export const Label_Ship_Date = 'PackAndShip.Ship_Date';
export const Label_Cust_PO = 'PackAndShip.Cust_PO';
export const Label_Exp_Flag = 'PackAndShip.Exp_Flag';
export const Label_Stat_Flag = 'PackAndShip.Stat_Flag';
export const Label_Ship_To_Name = 'PackAndShip.Ship_To_Name';
export const Label_Loc_ID = 'PackAndShip.Loc_ID';
export const Label_ShipTo_ID = 'PackAndShip.ShipTo_ID';
export const Label_ShipTo_DC = 'PackAndShip.ShipTo_DC';
export const Label_ASN_ID = 'PackAndShip.ASN_ID';
export const Label_status = 'PackAndShip.status';

