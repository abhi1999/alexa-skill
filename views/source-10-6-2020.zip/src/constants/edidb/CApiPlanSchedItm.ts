import { IApiPlanSchedItm } from '../edidb'
export class CApiPlanSchedItm implements IApiPlanSchedItm {
    public PSIID:string = '';
    public PSHID:string = '';
    public VPID:number = 0;
    public processtype:string = '';
    public processdate:Date;
    public itmdocline:number = 0;
    public fcdocline:number = 0;
    public fcqual:string = '';
    public fctqual:string = '';
    public fcqty:number = 0;
    public fcdate1:string = '';
    public fcdate2:string = '';
    public fcdtqual:string = '';
    public fcdtid:string = '';
    public itemuom:string = '';
    public importdate:Date;
    public status:string = '';
    public price:number = 0;
    public shpqtyqual:string = '';
    public shpqty:number = 0;
    public shpdtqual:string = '';
    public shpdate1:string = '';
    public shpdate2:string = '';
    public engchangelevel:string = '';
    public Expr1:string = '';
    public tp_partid:string = '';
    public psdoctype:string = '';
    public tspurposecode:string = '';
    public pstypequal:string = '';
    public psqtyqual:string = '';
    public pstypecode:string = '';
    public purchaseorder:string = '';
    public releaseno:string = '';
    public contractno:string = '';
    public hrznstartdate:string = '';
    public hrznenddate:string = '';
    public pscreatedate:string = '';
    public psupddate:string = '';
    public hdrdocline:number = 0;
    public XMLID:string = '';
    public CreatedDate:Date;
    public Expr2:string = '';
    public DGID:string = '';
    public Config:boolean;
    public URECID:string = '';
    public Exp_Flag:string = '';
    public ExportDate:Date;
    public XMLText:string = '';
    public Expr3:string = '';
    public Misc_ID:number = 0;
    public XMLRef:string = '';
    public GCN:string = '';
    public TCN:string = '';
    public Direction:string = '';
    public Expr4:number = 0;
    public AckID:string = '';
    public VPIDFA:number = 0;
    public constructor(init?:Partial<CApiPlanSchedItm>) { Object.assign(this, init); }
}
export const IApiPlanSchedItm_processtype_length = 2;
export const IApiPlanSchedItm_fcqual_length = 2;
export const IApiPlanSchedItm_fctqual_length = 1;
export const IApiPlanSchedItm_fcdate1_length = 8;
export const IApiPlanSchedItm_fcdate2_length = 8;
export const IApiPlanSchedItm_fcdtqual_length = 3;
export const IApiPlanSchedItm_fcdtid_length = 8;
export const IApiPlanSchedItm_itemuom_length = 10;
export const IApiPlanSchedItm_status_length = 1;
export const IApiPlanSchedItm_shpqtyqual_length = 2;
export const IApiPlanSchedItm_shpdtqual_length = 3;
export const IApiPlanSchedItm_shpdate1_length = 8;
export const IApiPlanSchedItm_shpdate2_length = 8;
export const IApiPlanSchedItm_engchangelevel_length = 80;
export const IApiPlanSchedItm_tp_partid_length = 30;
export const IApiPlanSchedItm_psdoctype_length = 2;
export const IApiPlanSchedItm_tspurposecode_length = 2;
export const IApiPlanSchedItm_pstypequal_length = 2;
export const IApiPlanSchedItm_psqtyqual_length = 1;
export const IApiPlanSchedItm_pstypecode_length = 2;
export const IApiPlanSchedItm_purchaseorder_length = 30;
export const IApiPlanSchedItm_releaseno_length = 30;
export const IApiPlanSchedItm_contractno_length = 30;
export const IApiPlanSchedItm_hrznstartdate_length = 8;
export const IApiPlanSchedItm_hrznenddate_length = 8;
export const IApiPlanSchedItm_pscreatedate_length = 8;
export const IApiPlanSchedItm_psupddate_length = 8;
export const IApiPlanSchedItm_Expr2_length = 30;
export const IApiPlanSchedItm_DGID_length = 5;
export const IApiPlanSchedItm_Exp_Flag_length = 1;
export const IApiPlanSchedItm_XMLText_length = 1073741823;
export const IApiPlanSchedItm_XMLRef_length = 1000;
export const IApiPlanSchedItm_GCN_length = 50;
export const IApiPlanSchedItm_TCN_length = 50;
export const IApiPlanSchedItm_Direction_length = 1;
export const IApiPlanSchedItm_AckID_length = 10;

export const kApiPlanSchedItm_PSIID="PSIID";
export const kApiPlanSchedItm_PSHID="PSHID";
export const kApiPlanSchedItm_VPID="VPID";
export const kApiPlanSchedItm_processtype="processtype";
export const kApiPlanSchedItm_processdate="processdate";
export const kApiPlanSchedItm_itmdocline="itmdocline";
export const kApiPlanSchedItm_fcdocline="fcdocline";
export const kApiPlanSchedItm_fcqual="fcqual";
export const kApiPlanSchedItm_fctqual="fctqual";
export const kApiPlanSchedItm_fcqty="fcqty";
export const kApiPlanSchedItm_fcdate1="fcdate1";
export const kApiPlanSchedItm_fcdate2="fcdate2";
export const kApiPlanSchedItm_fcdtqual="fcdtqual";
export const kApiPlanSchedItm_fcdtid="fcdtid";
export const kApiPlanSchedItm_itemuom="itemuom";
export const kApiPlanSchedItm_importdate="importdate";
export const kApiPlanSchedItm_status="status";
export const kApiPlanSchedItm_price="price";
export const kApiPlanSchedItm_shpqtyqual="shpqtyqual";
export const kApiPlanSchedItm_shpqty="shpqty";
export const kApiPlanSchedItm_shpdtqual="shpdtqual";
export const kApiPlanSchedItm_shpdate1="shpdate1";
export const kApiPlanSchedItm_shpdate2="shpdate2";
export const kApiPlanSchedItm_engchangelevel="engchangelevel";
export const kApiPlanSchedItm_Expr1="Expr1";
export const kApiPlanSchedItm_tp_partid="tp_partid";
export const kApiPlanSchedItm_psdoctype="psdoctype";
export const kApiPlanSchedItm_tspurposecode="tspurposecode";
export const kApiPlanSchedItm_pstypequal="pstypequal";
export const kApiPlanSchedItm_psqtyqual="psqtyqual";
export const kApiPlanSchedItm_pstypecode="pstypecode";
export const kApiPlanSchedItm_purchaseorder="purchaseorder";
export const kApiPlanSchedItm_releaseno="releaseno";
export const kApiPlanSchedItm_contractno="contractno";
export const kApiPlanSchedItm_hrznstartdate="hrznstartdate";
export const kApiPlanSchedItm_hrznenddate="hrznenddate";
export const kApiPlanSchedItm_pscreatedate="pscreatedate";
export const kApiPlanSchedItm_psupddate="psupddate";
export const kApiPlanSchedItm_hdrdocline="hdrdocline";
export const kApiPlanSchedItm_XMLID="XMLID";
export const kApiPlanSchedItm_CreatedDate="CreatedDate";
export const kApiPlanSchedItm_Expr2="Expr2";
export const kApiPlanSchedItm_DGID="DGID";
export const kApiPlanSchedItm_Config="Config";
export const kApiPlanSchedItm_URECID="URECID";
export const kApiPlanSchedItm_Exp_Flag="Exp_Flag";
export const kApiPlanSchedItm_ExportDate="ExportDate";
export const kApiPlanSchedItm_XMLText="XMLText";
export const kApiPlanSchedItm_Expr3="Expr3";
export const kApiPlanSchedItm_Misc_ID="Misc_ID";
export const kApiPlanSchedItm_XMLRef="XMLRef";
export const kApiPlanSchedItm_GCN="GCN";
export const kApiPlanSchedItm_TCN="TCN";
export const kApiPlanSchedItm_Direction="Direction";
export const kApiPlanSchedItm_Expr4="Expr4";
export const kApiPlanSchedItm_AckID="AckID";
export const kApiPlanSchedItm_VPIDFA="VPIDFA";

/*
        'ApiPlanSchedItm' : {
            'PSIID' : 'PSIID',
            'PSHID' : 'PSHID',
            'VPID' : 'VPID',
            'processtype' : 'processtype',
            'processdate' : 'processdate',
            'itmdocline' : 'itmdocline',
            'fcdocline' : 'fcdocline',
            'fcqual' : 'fcqual',
            'fctqual' : 'fctqual',
            'fcqty' : 'fcqty',
            'fcdate1' : 'fcdate1',
            'fcdate2' : 'fcdate2',
            'fcdtqual' : 'fcdtqual',
            'fcdtid' : 'fcdtid',
            'itemuom' : 'itemuom',
            'importdate' : 'importdate',
            'status' : 'status',
            'price' : 'price',
            'shpqtyqual' : 'shpqtyqual',
            'shpqty' : 'shpqty',
            'shpdtqual' : 'shpdtqual',
            'shpdate1' : 'shpdate1',
            'shpdate2' : 'shpdate2',
            'engchangelevel' : 'engchangelevel',
            'Expr1' : 'Expr1',
            'tp_partid' : 'tp_partid',
            'psdoctype' : 'psdoctype',
            'tspurposecode' : 'tspurposecode',
            'pstypequal' : 'pstypequal',
            'psqtyqual' : 'psqtyqual',
            'pstypecode' : 'pstypecode',
            'purchaseorder' : 'purchaseorder',
            'releaseno' : 'releaseno',
            'contractno' : 'contractno',
            'hrznstartdate' : 'hrznstartdate',
            'hrznenddate' : 'hrznenddate',
            'pscreatedate' : 'pscreatedate',
            'psupddate' : 'psupddate',
            'hdrdocline' : 'hdrdocline',
            'XMLID' : 'XMLID',
            'CreatedDate' : 'CreatedDate',
            'Expr2' : 'Expr2',
            'DGID' : 'DGID',
            'Config' : 'Config',
            'URECID' : 'URECID',
            'Exp_Flag' : 'Exp_Flag',
            'ExportDate' : 'ExportDate',
            'XMLText' : 'XMLText',
            'Expr3' : 'Expr3',
            'Misc_ID' : 'Misc_ID',
            'XMLRef' : 'XMLRef',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'Direction' : 'Direction',
            'Expr4' : 'Expr4',
            'AckID' : 'AckID',
            'VPIDFA' : 'VPIDFA',        },
*/

export const Label_PSIID = 'ApiPlanSchedItm.PSIID';
export const Label_PSHID = 'ApiPlanSchedItm.PSHID';
export const Label_VPID = 'ApiPlanSchedItm.VPID';
export const Label_processtype = 'ApiPlanSchedItm.processtype';
export const Label_processdate = 'ApiPlanSchedItm.processdate';
export const Label_itmdocline = 'ApiPlanSchedItm.itmdocline';
export const Label_fcdocline = 'ApiPlanSchedItm.fcdocline';
export const Label_fcqual = 'ApiPlanSchedItm.fcqual';
export const Label_fctqual = 'ApiPlanSchedItm.fctqual';
export const Label_fcqty = 'ApiPlanSchedItm.fcqty';
export const Label_fcdate1 = 'ApiPlanSchedItm.fcdate1';
export const Label_fcdate2 = 'ApiPlanSchedItm.fcdate2';
export const Label_fcdtqual = 'ApiPlanSchedItm.fcdtqual';
export const Label_fcdtid = 'ApiPlanSchedItm.fcdtid';
export const Label_itemuom = 'ApiPlanSchedItm.itemuom';
export const Label_importdate = 'ApiPlanSchedItm.importdate';
export const Label_status = 'ApiPlanSchedItm.status';
export const Label_price = 'ApiPlanSchedItm.price';
export const Label_shpqtyqual = 'ApiPlanSchedItm.shpqtyqual';
export const Label_shpqty = 'ApiPlanSchedItm.shpqty';
export const Label_shpdtqual = 'ApiPlanSchedItm.shpdtqual';
export const Label_shpdate1 = 'ApiPlanSchedItm.shpdate1';
export const Label_shpdate2 = 'ApiPlanSchedItm.shpdate2';
export const Label_engchangelevel = 'ApiPlanSchedItm.engchangelevel';
export const Label_Expr1 = 'ApiPlanSchedItm.Expr1';
export const Label_tp_partid = 'ApiPlanSchedItm.tp_partid';
export const Label_psdoctype = 'ApiPlanSchedItm.psdoctype';
export const Label_tspurposecode = 'ApiPlanSchedItm.tspurposecode';
export const Label_pstypequal = 'ApiPlanSchedItm.pstypequal';
export const Label_psqtyqual = 'ApiPlanSchedItm.psqtyqual';
export const Label_pstypecode = 'ApiPlanSchedItm.pstypecode';
export const Label_purchaseorder = 'ApiPlanSchedItm.purchaseorder';
export const Label_releaseno = 'ApiPlanSchedItm.releaseno';
export const Label_contractno = 'ApiPlanSchedItm.contractno';
export const Label_hrznstartdate = 'ApiPlanSchedItm.hrznstartdate';
export const Label_hrznenddate = 'ApiPlanSchedItm.hrznenddate';
export const Label_pscreatedate = 'ApiPlanSchedItm.pscreatedate';
export const Label_psupddate = 'ApiPlanSchedItm.psupddate';
export const Label_hdrdocline = 'ApiPlanSchedItm.hdrdocline';
export const Label_XMLID = 'ApiPlanSchedItm.XMLID';
export const Label_CreatedDate = 'ApiPlanSchedItm.CreatedDate';
export const Label_Expr2 = 'ApiPlanSchedItm.Expr2';
export const Label_DGID = 'ApiPlanSchedItm.DGID';
export const Label_Config = 'ApiPlanSchedItm.Config';
export const Label_URECID = 'ApiPlanSchedItm.URECID';
export const Label_Exp_Flag = 'ApiPlanSchedItm.Exp_Flag';
export const Label_ExportDate = 'ApiPlanSchedItm.ExportDate';
export const Label_XMLText = 'ApiPlanSchedItm.XMLText';
export const Label_Expr3 = 'ApiPlanSchedItm.Expr3';
export const Label_Misc_ID = 'ApiPlanSchedItm.Misc_ID';
export const Label_XMLRef = 'ApiPlanSchedItm.XMLRef';
export const Label_GCN = 'ApiPlanSchedItm.GCN';
export const Label_TCN = 'ApiPlanSchedItm.TCN';
export const Label_Direction = 'ApiPlanSchedItm.Direction';
export const Label_Expr4 = 'ApiPlanSchedItm.Expr4';
export const Label_AckID = 'ApiPlanSchedItm.AckID';
export const Label_VPIDFA = 'ApiPlanSchedItm.VPIDFA';
