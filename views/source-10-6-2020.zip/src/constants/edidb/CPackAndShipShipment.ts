import {
  IPackAndShipShipmentOrderReadySummary,
  IPackAndShipShipmentOrderReadyDetail,
  IPackAndShipShipmentOrderInShipmentSummary,
  IPackAndShipShipmentOrderInShipmentDetail
} from '../edidb'

export class CPackAndShipShipmentOrderReadySummary  implements IPackAndShipShipmentOrderReadySummary {
  
  // Manually added GUID key
  public Id: string;

  public Order_No: number = 0;
  public Acct_Order_No: string = "";
  public TP_ID: string = "";
  public TP_Name: string = "";  
  public Cust_PO: string = ""; 
  public ShipTo_ID: string = "";  
  public ShipTo_DC: string = ""; 
  public PackQty: number = 0;  
  public Pack_Wt: number = 0;
  public Stat_Flag: string = "";
  public Exp_Flag: string = "";
  public TP_PartID: string = "";

  public constructor(init?: Partial<CPackAndShipShipmentOrderReadySummary>) { Object.assign(this, init); }
}

export class CPackAndShipShipmentOrderReadyDetail  implements IPackAndShipShipmentOrderReadyDetail {
  
  // Manually added GUID key
  public Id: string;

  public Order_No: number = 0;
  public Acct_Order_No: string = "";
  public Asn_ID: number = 0;
  public TP_Name: string = "";  
  public Box_ID: string = ""; 
  public Pack_Level: number = 0;
  public Pack_Wt: number = 0;
  public Cust_PO: string = "";
  public Exp_Flag: string = "";
  public Stat_Flag: string = "";
  public PackQty: number = 0;  
  public ShipTo_ID: string = "";  
  public ShipTo_DC: string = ""; 
  public TP_ID: string = "";

  public constructor(init?: Partial<CPackAndShipShipmentOrderReadySummary>) { Object.assign(this, init); }
}

export class CPackAndShipShipmentOrderInShipmentSummary  implements IPackAndShipShipmentOrderInShipmentSummary {
  
  // Manually added GUID key
  public Id: string;

  public Order_No: number = 0;
  public Acct_Order_No: string = "";
  public TP_ID: string = "";
  public TP_Name: string = "";  
  public Asn_ID: number = 0;
  public Cust_PO: string = ""; 
  public ShipTo_ID: string = "";  
  public ShipTo_DC: string = ""; 
  public PackQty: number = 0;  
  public Pack_Wt: number = 0;

  public constructor(init?: Partial<CPackAndShipShipmentOrderInShipmentSummary>) { Object.assign(this, init); }
}

export class CPackAndShipShipmentOrderInShipmentDetail  implements IPackAndShipShipmentOrderInShipmentDetail {
  
  // Manually added GUID key
  public Id: string;

  public Order_No: number = 0;
  public Acct_Order_No: string = "";
  public Asn_ID: number = 0;
  public TP_Name: string = "";  
  public Box_ID: string = ""; 
  public Pack_Level: number = 0;
  public Pack_Wt: number = 0;
  public Cust_PO: string = "";
  public Exp_Flag: string = "";
  public Stat_Flag: string = "";
  public PackQty: number = 0;  
  public ShipTo_ID: string = "";  
  public ShipTo_DC: string = ""; 

  public constructor(init?: Partial<CPackAndShipShipmentOrderInShipmentSummary>) { Object.assign(this, init); }
}

export const IPackAndShipShipment_Order_No_length = 30;
export const IPackAndShipShipment_Acct_Order_No_length = 30;
export const IPackAndShipShipment_TP_ID_length = 30;
export const IPackAndShipShipment_TP_Name_length = 30;
export const IPackAndShipShipment_Cust_PO_length = 30;
export const IPackAndShipShipment_Ship_To_ID_length = 30;
export const IPackAndShipShipment_Ship_To_DC_length = 30;
export const IPackAndShipShipment_PackQty_length = 30;
export const IPackAndShipShipment_Pack_Wt_length = 30;
export const IPackAndShipShipment_Box_ID_length = 30;
export const IPackAndShipShipment_Pack_Level_length = 30;
// export const IPackAndShipShipment_Asn_ID_length = 30;

export const kPackAndShipShipment_Order_No = 'Order_No';
export const kPackAndShipShipment_Acct_Order_No = 'Acct_Order_No';
export const kPackAndShipShipment_TP_ID = 'TP_ID';
export const kPackAndShipShipment_TP_Name = 'TP_Name';
export const kPackAndShipShipment_Cust_PO = 'Cust_PO';
export const kPackAndShipShipment_Ship_To_ID = 'ShipTo_ID';
export const kPackAndShipShipment_Ship_To_DC = 'ShipTo_DC';
export const kPackAndShipShipment_PackQty = 'PackQty';
export const kPackAndShipShipment_Pack_Wt = 'Pack_Wt';
export const kPackAndShipShipment_Box_ID = 'Box_ID';
export const kPackAndShipShipment_Pack_Level = 'Pack_Level';
// export const kPackAndShipShipment_Asn_ID = 'Asn_ID';

export const Label_Order_No = 'PackAndShip.Order_No';
export const Label_Acct_Order_No = 'PackAndShip.ERP_Order_No';
export const Label_TP_ID = 'PackAndShip.TP_ID';
export const Label_TP_Name = 'PackAndShip.TP_Name';
export const Label_Cust_PO = 'PackAndShip.Cust_PO';
export const Label_Ship_To_ID = 'PackAndShip.PS_ShipTo_ID';
export const Label_Ship_To_DC = 'PackAndShip.PS_ShipTo_DC';
export const Label_PackQty = 'PackAndShip.PackQty';
export const Label_Pack_Wt = 'PackAndShip.Pack_Wt';
export const Label_Box_ID = 'PackAndShip.Package_No';
export const Label_Pack_Level = 'PackAndShip.Pack_Level';
// export const Label_Asn_ID = 'PackAndShip.Asn_ID';

