import { IApiTradeOrderDetails } from '../edidb'
export class CApiTradeOrderDetails implements IApiTradeOrderDetails {
    public Order_No:number = 0;
    public Acct_Order_No:string = '';
    public TP_ID:string = '';
    public TP_Name:string = '';
    public ShipTo_Xref:string = '';
    public Order_Date:string = '';
    public Ship_Date:Date;
    public Cust_PO:string = '';
    public Exp_Flag:string = '';
    public Stat_Flag:string = '';
    public Ship_To_Name:string = '';
    public Loc_ID:string = '';
    public ShipTo_ID:string = '';
    public ShipTo_DC:string = '';
    public ASN_ID:number = 0;
    public status:string = '';
    public constructor(init?:Partial<CApiTradeOrderDetails>) { Object.assign(this, init); }
}
export const kApiTradeOrderDetails_Order_No="Order_No";
export const kApiTradeOrderDetails_Acct_Order_No="Acct_Order_No";
export const kApiTradeOrderDetails_TP_ID="TP_ID";
export const kApiTradeOrderDetails_TP_Name="TP_Name";
export const kApiTradeOrderDetails_ShipTo_Xref="ShipTo_Xref";
export const kApiTradeOrderDetails_Order_Date="Order_Date";
export const kApiTradeOrderDetails_Ship_Date="Ship_Date";
export const kApiTradeOrderDetails_Cust_PO="Cust_PO";
export const kApiTradeOrderDetails_Exp_Flag="Exp_Flag";
export const kApiTradeOrderDetails_Stat_Flag="Stat_Flag";
export const kApiTradeOrderDetails_Ship_To_Name="Ship_To_Name";
export const kApiTradeOrderDetails_Loc_ID="Loc_ID";
export const kApiTradeOrderDetails_ShipTo_ID="ShipTo_ID";
export const kApiTradeOrderDetails_ShipTo_DC="ShipTo_DC";
export const kApiTradeOrderDetails_ASN_ID="ASN_ID";
export const kApiTradeOrderDetails_status="status";

/*
        'ApiTradeOrderDetails' : {
            'Order_No' : 'Order_No',
            'Acct_Order_No' : 'Acct_Order_No',
            'TP_ID' : 'TP_ID',
            'TP_Name' : 'TP_Name',
            'ShipTo_Xref' : 'ShipTo_Xref',
            'Order_Date' : 'Order_Date',
            'Ship_Date' : 'Ship_Date',
            'Cust_PO' : 'Cust_PO',
            'Exp_Flag' : 'Exp_Flag',
            'Stat_Flag' : 'Stat_Flag',
            'Ship_To_Name' : 'Ship_To_Name',
            'Loc_ID' : 'Loc_ID',
            'ShipTo_ID' : 'ShipTo_ID',
            'ShipTo_DC' : 'ShipTo_DC',
            'ASN_ID' : 'ASN_ID',
            'status' : 'status',        },
*/

export const Label_Order_No = 'ApiTradeOrderDetails.Order_No';
export const Label_Acct_Order_No = 'ApiTradeOrderDetails.Acct_Order_No';
export const Label_TP_ID = 'ApiTradeOrderDetails.TP_ID';
export const Label_TP_Name = 'ApiTradeOrderDetails.TP_Name';
export const Label_ShipTo_Xref = 'ApiTradeOrderDetails.ShipTo_Xref';
export const Label_Order_Date = 'ApiTradeOrderDetails.Order_Date';
export const Label_Ship_Date = 'ApiTradeOrderDetails.Ship_Date';
export const Label_Cust_PO = 'ApiTradeOrderDetails.Cust_PO';
export const Label_Exp_Flag = 'ApiTradeOrderDetails.Exp_Flag';
export const Label_Stat_Flag = 'ApiTradeOrderDetails.Stat_Flag';
export const Label_Ship_To_Name = 'ApiTradeOrderDetails.Ship_To_Name';
export const Label_Loc_ID = 'ApiTradeOrderDetails.Loc_ID';
export const Label_ShipTo_ID = 'ApiTradeOrderDetails.ShipTo_ID';
export const Label_ShipTo_DC = 'ApiTradeOrderDetails.ShipTo_DC';
export const Label_ASN_ID = 'ApiTradeOrderDetails.ASN_ID';
export const Label_status = 'ApiTradeOrderDetails.status';
