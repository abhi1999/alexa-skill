import { IEDIOutboundInvoice } from '../edidb'
export class CEDIOutboundInvoice implements IEDIOutboundInvoice {
    public TP_PartID:string = '';
    public VPID:number = 0;
    public DGID:string = '';
    public XMLRef:string = '';
    public ExportDate:Date;
    public CreatedDate:Date;
    public Exp_Flag:string = '';
    public AckID:string = '';
    public XMLText:string = '';
    public XMLId:string = '';
    public invoiceno:string = '';
    public invoicedate:string = '';
    public cusno:string = '';
    public purchaseorderno:string = '';
    public orderno:string = '';
    public lineno:string = '';
    public itemid:string = '';
    public itemdesc:string = '';
    public itemdesc2:string = '';
    public cusitemid:string = '';
    public price:number = 0;
    public extendedprice:number = 0;
    public uom:string = '';
    public qtyord:number = 0;
    public qtytoship:number = 0;
    public requestdate:string = '';
    public promisedate:string = '';
    public constructor(init?:Partial<CEDIOutboundInvoice>) { Object.assign(this, init); }
}
export const IEDIOutboundInvoice_TP_PartID_length = 30;
export const IEDIOutboundInvoice_DGID_length = 5;
export const IEDIOutboundInvoice_XMLRef_length = 1000;
export const IEDIOutboundInvoice_Exp_Flag_length = 1;
export const IEDIOutboundInvoice_AckID_length = 10;
export const IEDIOutboundInvoice_invoiceno_length = 50;
export const IEDIOutboundInvoice_invoicedate_length = 20;
export const IEDIOutboundInvoice_cusno_length = 80;
export const IEDIOutboundInvoice_purchaseorderno_length = 200;
export const IEDIOutboundInvoice_orderno_length = 50;
export const IEDIOutboundInvoice_lineno_length = 20;
export const IEDIOutboundInvoice_itemid_length = 200;
export const IEDIOutboundInvoice_itemdesc_length = 500;
export const IEDIOutboundInvoice_itemdesc2_length = 500;
export const IEDIOutboundInvoice_cusitemid_length = 200;
export const IEDIOutboundInvoice_uom_length = 20;
export const IEDIOutboundInvoice_requestdate_length = 20;
export const IEDIOutboundInvoice_promisedate_length = 20;

export const kEDIOutboundInvoice_TP_PartID="TP_PartID";
export const kEDIOutboundInvoice_VPID="VPID";
export const kEDIOutboundInvoice_DGID="DGID";
export const kEDIOutboundInvoice_XMLRef="XMLRef";
export const kEDIOutboundInvoice_ExportDate="ExportDate";
export const kEDIOutboundInvoice_CreatedDate="CreatedDate";
export const kEDIOutboundInvoice_Exp_Flag="Exp_Flag";
export const kEDIOutboundInvoice_AckID="AckID";
export const kEDIOutboundInvoice_XMLText="XMLText";
export const kEDIOutboundInvoice_XMLId="XMLId";
export const kEDIOutboundInvoice_invoiceno="invoiceno";
export const kEDIOutboundInvoice_invoicedate="invoicedate";
export const kEDIOutboundInvoice_cusno="cusno";
export const kEDIOutboundInvoice_purchaseorderno="purchaseorderno";
export const kEDIOutboundInvoice_orderno="orderno";
export const kEDIOutboundInvoice_lineno="lineno";
export const kEDIOutboundInvoice_itemid="itemid";
export const kEDIOutboundInvoice_itemdesc="itemdesc";
export const kEDIOutboundInvoice_itemdesc2="itemdesc2";
export const kEDIOutboundInvoice_cusitemid="cusitemid";
export const kEDIOutboundInvoice_price="price";
export const kEDIOutboundInvoice_extendedprice="extendedprice";
export const kEDIOutboundInvoice_uom="uom";
export const kEDIOutboundInvoice_qtyord="qtyord";
export const kEDIOutboundInvoice_qtytoship="qtytoship";
export const kEDIOutboundInvoice_requestdate="requestdate";
export const kEDIOutboundInvoice_promisedate="promisedate";

/*
        'EDIOutboundInvoice' : {
            'TP_PartID' : 'TP_PartID',
            'VPID' : 'VPID',
            'DGID' : 'DGID',
            'XMLRef' : 'XMLRef',
            'ExportDate' : 'ExportDate',
            'CreatedDate' : 'CreatedDate',
            'Exp_Flag' : 'Exp_Flag',
            'AckID' : 'AckID',
            'XMLText' : 'XMLText',
            'XMLId' : 'XMLId',
            'invoiceno' : 'invoiceno',
            'invoicedate' : 'invoicedate',
            'cusno' : 'cusno',
            'purchaseorderno' : 'purchaseorderno',
            'orderno' : 'orderno',
            'lineno' : 'lineno',
            'itemid' : 'itemid',
            'itemdesc' : 'itemdesc',
            'itemdesc2' : 'itemdesc2',
            'cusitemid' : 'cusitemid',
            'price' : 'price',
            'extendedprice' : 'extendedprice',
            'uom' : 'uom',
            'qtyord' : 'qtyord',
            'qtytoship' : 'qtytoship',
            'requestdate' : 'requestdate',
            'promisedate' : 'promisedate',        },
*/

export const Label_TP_PartID = 'EDIOutboundInvoice.TP_PartID';
export const Label_VPID = 'EDIOutboundInvoice.VPID';
export const Label_DGID = 'EDIOutboundInvoice.DGID';
export const Label_XMLRef = 'EDIOutboundInvoice.XMLRef';
export const Label_ExportDate = 'EDIOutboundInvoice.ExportDate';
export const Label_CreatedDate = 'EDIOutboundInvoice.CreatedDate';
export const Label_Exp_Flag = 'EDIOutboundInvoice.Exp_Flag';
export const Label_AckID = 'EDIOutboundInvoice.AckID';
export const Label_XMLText = 'EDIOutboundInvoice.XMLText';
export const Label_XMLId = 'EDIOutboundInvoice.XMLId';
export const Label_invoiceno = 'EDIOutboundInvoice.invoiceno';
export const Label_invoicedate = 'EDIOutboundInvoice.invoicedate';
export const Label_cusno = 'EDIOutboundInvoice.cusno';
export const Label_purchaseorderno = 'EDIOutboundInvoice.purchaseorderno';
export const Label_orderno = 'EDIOutboundInvoice.orderno';
export const Label_lineno = 'EDIOutboundInvoice.lineno';
export const Label_itemid = 'EDIOutboundInvoice.itemid';
export const Label_itemdesc = 'EDIOutboundInvoice.itemdesc';
export const Label_itemdesc2 = 'EDIOutboundInvoice.itemdesc2';
export const Label_cusitemid = 'EDIOutboundInvoice.cusitemid';
export const Label_price = 'EDIOutboundInvoice.price';
export const Label_extendedprice = 'EDIOutboundInvoice.extendedprice';
export const Label_uom = 'EDIOutboundInvoice.uom';
export const Label_qtyord = 'EDIOutboundInvoice.qtyord';
export const Label_qtytoship = 'EDIOutboundInvoice.qtytoship';
export const Label_requestdate = 'EDIOutboundInvoice.requestdate';
export const Label_promisedate = 'EDIOutboundInvoice.promisedate';
