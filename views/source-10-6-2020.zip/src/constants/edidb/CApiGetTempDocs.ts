import { IApiGetTempDocs } from '../edidb'
export class CApiGetTempDocs implements IApiGetTempDocs {
    public PSIID:string = '';
    public VPID:number = 0;
    public tp_name:string = '';
    public processtype:string = '';
    public importdate:Date;
    public processdate:Date;
    public tp_partid:string = '';
    public fcqual:string = '';
    public fcqty:number = 0;
    public fcdate1:Date;
    public fcdtqual:string = '';
    public itemid:string = '';
    public engchangelevel:string = '';
    public purchaseorder:string = '';
    public poline:string = '';
    public releaseno:string = '';
    public tp_stqual:string = '';
    public vin:string = '';
    public jobseqno:string = '';
    public storageid:string = '';
    public assembly:string = '';
    public HoldID:number = 0;
    public shiptoid:string = '';
    public status:string = '';
    public constructor(init?:Partial<CApiGetTempDocs>) { Object.assign(this, init); }
}
export const IApiGetTempDocs_tp_name_length = 30;
export const IApiGetTempDocs_processtype_length = 2;
export const IApiGetTempDocs_tp_partid_length = 30;
export const IApiGetTempDocs_fcqual_length = 1;
export const IApiGetTempDocs_fcdtqual_length = 3;
export const IApiGetTempDocs_itemid_length = 30;
export const IApiGetTempDocs_engchangelevel_length = 30;
export const IApiGetTempDocs_purchaseorder_length = 30;
export const IApiGetTempDocs_poline_length = 10;
export const IApiGetTempDocs_releaseno_length = 30;
export const IApiGetTempDocs_tp_stqual_length = 3;
export const IApiGetTempDocs_vin_length = 30;
export const IApiGetTempDocs_jobseqno_length = 30;
export const IApiGetTempDocs_storageid_length = 30;
export const IApiGetTempDocs_assembly_length = 30;
export const IApiGetTempDocs_shiptoid_length = 30;
export const IApiGetTempDocs_status_length = 1;

export const kApiGetTempDocs_PSIID="PSIID";
export const kApiGetTempDocs_VPID="VPID";
export const kApiGetTempDocs_tp_name="tp_name";
export const kApiGetTempDocs_processtype="processtype";
export const kApiGetTempDocs_importdate="importdate";
export const kApiGetTempDocs_processdate="processdate";
export const kApiGetTempDocs_tp_partid="tp_partid";
export const kApiGetTempDocs_fcqual="fcqual";
export const kApiGetTempDocs_fcqty="fcqty";
export const kApiGetTempDocs_fcdate1="fcdate1";
export const kApiGetTempDocs_fcdtqual="fcdtqual";
export const kApiGetTempDocs_itemid="itemid";
export const kApiGetTempDocs_engchangelevel="engchangelevel";
export const kApiGetTempDocs_purchaseorder="purchaseorder";
export const kApiGetTempDocs_poline="poline";
export const kApiGetTempDocs_releaseno="releaseno";
export const kApiGetTempDocs_tp_stqual="tp_stqual";
export const kApiGetTempDocs_vin="vin";
export const kApiGetTempDocs_jobseqno="jobseqno";
export const kApiGetTempDocs_storageid="storageid";
export const kApiGetTempDocs_assembly="assembly";
export const kApiGetTempDocs_HoldID="HoldID";
export const kApiGetTempDocs_shiptoid="shiptoid";
export const kApiGetTempDocs_status="status";

/*
        'ApiGetTempDocs' : {
            'PSIID' : 'PSIID',
            'VPID' : 'VPID',
            'tp_name' : 'tp_name',
            'processtype' : 'processtype',
            'importdate' : 'importdate',
            'processdate' : 'processdate',
            'tp_partid' : 'tp_partid',
            'fcqual' : 'fcqual',
            'fcqty' : 'fcqty',
            'fcdate1' : 'fcdate1',
            'fcdtqual' : 'fcdtqual',
            'itemid' : 'itemid',
            'engchangelevel' : 'engchangelevel',
            'purchaseorder' : 'purchaseorder',
            'poline' : 'poline',
            'releaseno' : 'releaseno',
            'tp_stqual' : 'tp_stqual',
            'vin' : 'vin',
            'jobseqno' : 'jobseqno',
            'storageid' : 'storageid',
            'assembly' : 'assembly',
            'HoldID' : 'HoldID',
            'shiptoid' : 'shiptoid',
            'status' : 'status',        },
*/

export const Label_PSIID = 'ApiGetTempDocs.PSIID';
export const Label_VPID = 'ApiGetTempDocs.VPID';
export const Label_tp_name = 'ApiGetTempDocs.tp_name';
export const Label_processtype = 'ApiGetTempDocs.processtype';
export const Label_importdate = 'ApiGetTempDocs.importdate';
export const Label_processdate = 'ApiGetTempDocs.processdate';
export const Label_tp_partid = 'ApiGetTempDocs.tp_partid';
export const Label_fcqual = 'ApiGetTempDocs.fcqual';
export const Label_fcqty = 'ApiGetTempDocs.fcqty';
export const Label_fcdate1 = 'ApiGetTempDocs.fcdate1';
export const Label_fcdtqual = 'ApiGetTempDocs.fcdtqual';
export const Label_itemid = 'ApiGetTempDocs.itemid';
export const Label_engchangelevel = 'ApiGetTempDocs.engchangelevel';
export const Label_purchaseorder = 'ApiGetTempDocs.purchaseorder';
export const Label_poline = 'ApiGetTempDocs.poline';
export const Label_releaseno = 'ApiGetTempDocs.releaseno';
export const Label_tp_stqual = 'ApiGetTempDocs.tp_stqual';
export const Label_vin = 'ApiGetTempDocs.vin';
export const Label_jobseqno = 'ApiGetTempDocs.jobseqno';
export const Label_storageid = 'ApiGetTempDocs.storageid';
export const Label_assembly = 'ApiGetTempDocs.assembly';
export const Label_HoldID = 'ApiGetTempDocs.HoldID';
export const Label_shiptoid = 'ApiGetTempDocs.shiptoid';
export const Label_status = 'ApiGetTempDocs.status';
