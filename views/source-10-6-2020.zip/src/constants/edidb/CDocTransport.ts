import { IDocTransport } from '../edidb'
export class CDocTransport implements IDocTransport {
    public TransDate:Date;
    public TP_PartID:string = '';
    public SendQual:string = '';
    public SendID:string = '';
    public SendGroupID:string = '';
    public RecvQual:string = '';
    public RecvID:string = '';
    public RecvGroupID:string = '';
    public DocID:string = '';
    public DGID:string = '';
    public TransID:string = '';
    public PkgFile:string = '';
    public SegCount:number = 0;
    public DataKey:string = '';
    public VanExt:string = '';
    public Machinename:string = '';
    public Username:string = '';
    public Status:string = '';
    public DocData:number[];
    public PID:string = '';
    public DTID:string = '';
    public Xml_Flag:boolean;
    public constructor(init?:Partial<CDocTransport>) { Object.assign(this, init); }
}
export const IDocTransport_TP_PartID_length = 30;
export const IDocTransport_SendQual_length = 2;
export const IDocTransport_SendID_length = 30;
export const IDocTransport_SendGroupID_length = 30;
export const IDocTransport_RecvQual_length = 2;
export const IDocTransport_RecvID_length = 30;
export const IDocTransport_RecvGroupID_length = 30;
export const IDocTransport_DocID_length = 50;
export const IDocTransport_DGID_length = 5;
export const IDocTransport_TransID_length = 50;
export const IDocTransport_PkgFile_length = 50;
export const IDocTransport_DataKey_length = 128;
export const IDocTransport_VanExt_length = 3;
export const IDocTransport_Machinename_length = 80;
export const IDocTransport_Username_length = 80;
export const IDocTransport_Status_length = 1;

export const kDocTransport_TransDate="TransDate";
export const kDocTransport_TP_PartID="TP_PartID";
export const kDocTransport_SendQual="SendQual";
export const kDocTransport_SendID="SendID";
export const kDocTransport_SendGroupID="SendGroupID";
export const kDocTransport_RecvQual="RecvQual";
export const kDocTransport_RecvID="RecvID";
export const kDocTransport_RecvGroupID="RecvGroupID";
export const kDocTransport_DocID="DocID";
export const kDocTransport_DGID="DGID";
export const kDocTransport_TransID="TransID";
export const kDocTransport_PkgFile="PkgFile";
export const kDocTransport_SegCount="SegCount";
export const kDocTransport_DataKey="DataKey";
export const kDocTransport_VanExt="VanExt";
export const kDocTransport_Machinename="Machinename";
export const kDocTransport_Username="Username";
export const kDocTransport_Status="Status";
export const kDocTransport_DocData="DocData";
export const kDocTransport_PID="PID";
export const kDocTransport_DTID="DTID";
export const kDocTransport_Xml_Flag="Xml_Flag";

/*
        'DocTransport' : {
            'TransDate' : 'TransDate',
            'TP_PartID' : 'TP_PartID',
            'SendQual' : 'SendQual',
            'SendID' : 'SendID',
            'SendGroupID' : 'SendGroupID',
            'RecvQual' : 'RecvQual',
            'RecvID' : 'RecvID',
            'RecvGroupID' : 'RecvGroupID',
            'DocID' : 'DocID',
            'DGID' : 'DGID',
            'TransID' : 'TransID',
            'PkgFile' : 'PkgFile',
            'SegCount' : 'SegCount',
            'DataKey' : 'DataKey',
            'VanExt' : 'VanExt',
            'Machinename' : 'Machinename',
            'Username' : 'Username',
            'Status' : 'Status',
            'DocData' : 'DocData',
            'PID' : 'PID',
            'DTID' : 'DTID',
            'Xml_Flag' : 'Xml_Flag',        },
*/

export const Label_TransDate = 'DocTransport.TransDate';
export const Label_TP_PartID = 'DocTransport.TP_PartID';
export const Label_SendQual = 'DocTransport.SendQual';
export const Label_SendID = 'DocTransport.SendID';
export const Label_SendGroupID = 'DocTransport.SendGroupID';
export const Label_RecvQual = 'DocTransport.RecvQual';
export const Label_RecvID = 'DocTransport.RecvID';
export const Label_RecvGroupID = 'DocTransport.RecvGroupID';
export const Label_DocID = 'DocTransport.DocID';
export const Label_DGID = 'DocTransport.DGID';
export const Label_TransID = 'DocTransport.TransID';
export const Label_PkgFile = 'DocTransport.PkgFile';
export const Label_SegCount = 'DocTransport.SegCount';
export const Label_DataKey = 'DocTransport.DataKey';
export const Label_VanExt = 'DocTransport.VanExt';
export const Label_Machinename = 'DocTransport.Machinename';
export const Label_Username = 'DocTransport.Username';
export const Label_Status = 'DocTransport.Status';
export const Label_DocData = 'DocTransport.DocData';
export const Label_PID = 'DocTransport.PID';
export const Label_DTID = 'DocTransport.DTID';
export const Label_Xml_Flag = 'DocTransport.Xml_Flag';
