import { IOrderP } from '../edidb'
export class COrderP implements IOrderP {
    public Order_No:number = 0;
    public Line_No:number = 0;
    public Pack_ID:number = 0;
    public Pack_Level:number = 0;
    public PackQty:number = 0;
    public Asn_ID:number = 0;
    public Box_ID:number = 0;
    public Pack_Wt:number = 0;
    public Mixed:string = '';
    public TrackingNo:string = '';
    public SSCC:string = '';
    public PKG_ID:string = '';
    public RFID:string = '';
    public constructor(init?:Partial<COrderP>) { Object.assign(this, init); }
}
export const IOrderP_Mixed_length = 1;
export const IOrderP_TrackingNo_length = 50;
export const IOrderP_SSCC_length = 30;
export const IOrderP_PKG_ID_length = 10;
export const IOrderP_RFID_length = 50;

export const kOrderP_Order_No="Order_No";
export const kOrderP_Line_No="Line_No";
export const kOrderP_Pack_ID="Pack_ID";
export const kOrderP_Pack_Level="Pack_Level";
export const kOrderP_PackQty="PackQty";
export const kOrderP_Asn_ID="Asn_ID";
export const kOrderP_Box_ID="Box_ID";
export const kOrderP_Pack_Wt="Pack_Wt";
export const kOrderP_Mixed="Mixed";
export const kOrderP_TrackingNo="TrackingNo";
export const kOrderP_SSCC="SSCC";
export const kOrderP_PKG_ID="PKG_ID";
export const kOrderP_RFID="RFID";

/*
        'OrderP' : {
            'Order_No' : 'Order_No',
            'Line_No' : 'Line_No',
            'Pack_ID' : 'Pack_ID',
            'Pack_Level' : 'Pack_Level',
            'PackQty' : 'PackQty',
            'Asn_ID' : 'Asn_ID',
            'Box_ID' : 'Box_ID',
            'Pack_Wt' : 'Pack_Wt',
            'Mixed' : 'Mixed',
            'TrackingNo' : 'TrackingNo',
            'SSCC' : 'SSCC',
            'PKG_ID' : 'PKG_ID',
            'RFID' : 'RFID',        },
*/

export const Label_Order_No = 'OrderP.Order_No';
export const Label_Line_No = 'OrderP.Line_No';
export const Label_Pack_ID = 'OrderP.Pack_ID';
export const Label_Pack_Level = 'OrderP.Pack_Level';
export const Label_PackQty = 'OrderP.PackQty';
export const Label_Asn_ID = 'OrderP.Asn_ID';
export const Label_Box_ID = 'OrderP.Box_ID';
export const Label_Pack_Wt = 'OrderP.Pack_Wt';
export const Label_Mixed = 'OrderP.Mixed';
export const Label_TrackingNo = 'OrderP.TrackingNo';
export const Label_SSCC = 'OrderP.SSCC';
export const Label_PKG_ID = 'OrderP.PKG_ID';
export const Label_RFID = 'OrderP.RFID';
