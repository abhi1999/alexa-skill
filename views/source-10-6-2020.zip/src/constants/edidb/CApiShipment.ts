import { IApiShipment } from '../edidb'
export class CApiShipment implements IApiShipment {
    public Asn_ID:number = 0;
    public TP_PartID:string = '';
    public TP_Name:string = '';
    public TP_ID:string = '';
    public Bol_No:string = '';
    public Asn_Complete:string = '';
    public Exp_Flag:string = '';
    public GCN:string = '';
    public TCN:string = '';
    public AckDesc:string = '';
    public HoldID:number = 0;
    public NoteText:string = '';
    public ErrorID:number = 0;
    public Ship_Date:string = '';
    public TLE:number = 0;
    public Pro_No:string = '';
    public Ship_Via_Name:string = '';
    public VPIDFA:number = 0;
    public constructor(init?:Partial<CApiShipment>) { Object.assign(this, init); }
}
export const IApiShipment_TP_PartID_length = 30;
export const IApiShipment_TP_Name_length = 30;
export const IApiShipment_TP_ID_length = 100;
export const IApiShipment_Bol_No_length = 30;
export const IApiShipment_Asn_Complete_length = 1;
export const IApiShipment_Exp_Flag_length = 1;
export const IApiShipment_GCN_length = 20;
export const IApiShipment_TCN_length = 20;
export const IApiShipment_AckDesc_length = 10;
export const IApiShipment_NoteText_length = 2000;
export const IApiShipment_Ship_Date_length = 8;
export const IApiShipment_Pro_No_length = 30;
export const IApiShipment_Ship_Via_Name_length = 30;

export const kApiShipment_Asn_ID="Asn_ID";
export const kApiShipment_TP_PartID="TP_PartID";
export const kApiShipment_TP_Name="TP_Name";
export const kApiShipment_TP_ID="TP_ID";
export const kApiShipment_Bol_No="Bol_No";
export const kApiShipment_Asn_Complete="Asn_Complete";
export const kApiShipment_Exp_Flag="Exp_Flag";
export const kApiShipment_GCN="GCN";
export const kApiShipment_TCN="TCN";
export const kApiShipment_AckDesc="AckDesc";
export const kApiShipment_HoldID="HoldID";
export const kApiShipment_NoteText="NoteText";
export const kApiShipment_ErrorID="ErrorID";
export const kApiShipment_Ship_Date="Ship_Date";
export const kApiShipment_TLE="TLE";
export const kApiShipment_Pro_No="Pro_No";
export const kApiShipment_Ship_Via_Name="Ship_Via_Name";
export const kApiShipment_VPIDFA="VPIDFA";

/*
        'ApiShipment' : {
            'Asn_ID' : 'Asn_ID',
            'TP_PartID' : 'TP_PartID',
            'TP_Name' : 'TP_Name',
            'TP_ID' : 'TP_ID',
            'Bol_No' : 'Bol_No',
            'Asn_Complete' : 'Asn_Complete',
            'Exp_Flag' : 'Exp_Flag',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'AckDesc' : 'AckDesc',
            'HoldID' : 'HoldID',
            'NoteText' : 'NoteText',
            'ErrorID' : 'ErrorID',
            'Ship_Date' : 'Ship_Date',
            'TLE' : 'TLE',
            'Pro_No' : 'Pro_No',
            'Ship_Via_Name' : 'Ship_Via_Name',
            'VPIDFA' : 'VPIDFA',        },
*/

export const Label_Asn_ID = 'ApiShipment.Asn_ID';
export const Label_TP_PartID = 'ApiShipment.TP_PartID';
export const Label_TP_Name = 'ApiShipment.TP_Name';
export const Label_TP_ID = 'ApiShipment.TP_ID';
export const Label_Bol_No = 'ApiShipment.Bol_No';
export const Label_Asn_Complete = 'ApiShipment.Asn_Complete';
export const Label_Exp_Flag = 'ApiShipment.Exp_Flag';
export const Label_GCN = 'ApiShipment.GCN';
export const Label_TCN = 'ApiShipment.TCN';
export const Label_AckDesc = 'ApiShipment.AckDesc';
export const Label_HoldID = 'ApiShipment.HoldID';
export const Label_NoteText = 'ApiShipment.NoteText';
export const Label_ErrorID = 'ApiShipment.ErrorID';
export const Label_Ship_Date = 'ApiShipment.Ship_Date';
export const Label_TLE = 'ApiShipment.TLE';
export const Label_Pro_No = 'ApiShipment.Pro_No';
export const Label_Ship_Via_Name = 'ApiShipment.Ship_Via_Name';
export const Label_VPIDFA = 'ApiShipment.VPIDFA';
