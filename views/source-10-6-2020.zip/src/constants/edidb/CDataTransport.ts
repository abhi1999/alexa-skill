import { IDataTransport } from '../edidb'
export class CDataTransport implements IDataTransport {
    public TransID:string = '';
    public TP_PartID:string = '';
    public DTMethod:number = 0;
    public DTIn:string = '';
    public DTOut:string = '';
    public DTServer:string = '';
    public DTDomain:string = '';
    public DTUser:string = '';
    public DTPass:string = '';
    public DTCID:string = '';
    public DTWeb_ERP_Flag:boolean;
    public constructor(init?:Partial<CDataTransport>) { Object.assign(this, init); }
}
export const IDataTransport_TransID_length = 50;
export const IDataTransport_TP_PartID_length = 30;
export const IDataTransport_DTIn_length = 256;
export const IDataTransport_DTOut_length = 256;
export const IDataTransport_DTServer_length = 256;
export const IDataTransport_DTDomain_length = 80;
export const IDataTransport_DTUser_length = 80;
export const IDataTransport_DTPass_length = 80;

export const kDataTransport_TransID="TransID";
export const kDataTransport_TP_PartID="TP_PartID";
export const kDataTransport_DTMethod="DTMethod";
export const kDataTransport_DTIn="DTIn";
export const kDataTransport_DTOut="DTOut";
export const kDataTransport_DTServer="DTServer";
export const kDataTransport_DTDomain="DTDomain";
export const kDataTransport_DTUser="DTUser";
export const kDataTransport_DTPass="DTPass";
export const kDataTransport_DTCID="DTCID";
export const kDataTransport_DTWeb_ERP_Flag="DTWeb_ERP_Flag";

/*
        'DataTransport' : {
            'TransID' : 'TransID',
            'TP_PartID' : 'TP_PartID',
            'DTMethod' : 'DTMethod',
            'DTIn' : 'DTIn',
            'DTOut' : 'DTOut',
            'DTServer' : 'DTServer',
            'DTDomain' : 'DTDomain',
            'DTUser' : 'DTUser',
            'DTPass' : 'DTPass',
            'DTCID' : 'DTCID',
            'DTWeb_ERP_Flag' : 'DTWeb_ERP_Flag',        },
*/

export const Label_TransID = 'DataTransport.TransID';
export const Label_TP_PartID = 'DataTransport.TP_PartID';
export const Label_DTMethod = 'DataTransport.DTMethod';
export const Label_DTIn = 'DataTransport.DTIn';
export const Label_DTOut = 'DataTransport.DTOut';
export const Label_DTServer = 'DataTransport.DTServer';
export const Label_DTDomain = 'DataTransport.DTDomain';
export const Label_DTUser = 'DataTransport.DTUser';
export const Label_DTPass = 'DataTransport.DTPass';
export const Label_DTCID = 'DataTransport.DTCID';
export const Label_DTWeb_ERP_Flag = 'DataTransport.DTWeb_ERP_Flag';
