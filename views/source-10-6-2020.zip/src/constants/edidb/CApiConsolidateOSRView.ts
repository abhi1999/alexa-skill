import { IApiConsolidateOSRView } from '../edidb'
export class CApiConsolidateOSRView implements IApiConsolidateOSRView {
    public TP_PartID:string = '';
    public XMLRef:string = '';
    public constructor(init?:Partial<CApiConsolidateOSRView>) { Object.assign(this, init); }
}
export const IApiConsolidateOSRView_TP_PartID_length = 30;
export const IApiConsolidateOSRView_XMLRef_length = 1000;

export const kApiConsolidateOSRView_TP_PartID="TP_PartID";
export const kApiConsolidateOSRView_XMLRef="XMLRef";

/*
        'ApiConsolidateOSRView' : {
            'TP_PartID' : 'TP_PartID',
            'XMLRef' : 'XMLRef',        },
*/

export const Label_TP_PartID = 'ApiConsolidateOSRView.TP_PartID';
export const Label_XMLRef = 'ApiConsolidateOSRView.XMLRef';
