import { IApiPurchaseOrderDetail } from '../edidb'
export class CApiPurchaseOrderDetail implements IApiPurchaseOrderDetail {
    public PO_ID:number = 0;
    public TP_PartID:string = '';
    public BEG_01:string = '';
    public BEG_02:string = '';
    public BEG_03:string = '';
    public BEG_04:string = '';
    public BEG_05:string = '';
    public BEG_06:string = '';
    public CTT_01:string = '';
    public Exp_Flag:string = '';
    public Int_OrdID:number = 0;
    public SDQ_Flag:string = '';
    public CUR_02:string = '';
    public ImportDate:Date;
    public ExportDate:Date;
    public Misc_ID:number = 0;
    public URECID:string = '';
    public UDID:string = '';
    public Revision:number = 0;
    public Cust_Ship_Via_ID:string = '';
    public Cust_Terms_ID:string = '';
    public FrtPayMeth:string = '';
    public VPIDFA:number = 0;
    public TP_Name:string = '';
    public NoteText:string = '';
    public constructor(init?:Partial<CApiPurchaseOrderDetail>) { Object.assign(this, init); }
}
export const IApiPurchaseOrderDetail_TP_PartID_length = 30;
export const IApiPurchaseOrderDetail_BEG_01_length = 2;
export const IApiPurchaseOrderDetail_BEG_02_length = 3;
export const IApiPurchaseOrderDetail_BEG_03_length = 22;
export const IApiPurchaseOrderDetail_BEG_04_length = 30;
export const IApiPurchaseOrderDetail_BEG_05_length = 8;
export const IApiPurchaseOrderDetail_BEG_06_length = 30;
export const IApiPurchaseOrderDetail_CTT_01_length = 7;
export const IApiPurchaseOrderDetail_Exp_Flag_length = 1;
export const IApiPurchaseOrderDetail_SDQ_Flag_length = 1;
export const IApiPurchaseOrderDetail_CUR_02_length = 3;
export const IApiPurchaseOrderDetail_Cust_Ship_Via_ID_length = 50;
export const IApiPurchaseOrderDetail_Cust_Terms_ID_length = 50;
export const IApiPurchaseOrderDetail_FrtPayMeth_length = 3;
export const IApiPurchaseOrderDetail_TP_Name_length = 30;
export const IApiPurchaseOrderDetail_NoteText_length = 2000;

export const kApiPurchaseOrderDetail_PO_ID="PO_ID";
export const kApiPurchaseOrderDetail_TP_PartID="TP_PartID";
export const kApiPurchaseOrderDetail_BEG_01="BEG_01";
export const kApiPurchaseOrderDetail_BEG_02="BEG_02";
export const kApiPurchaseOrderDetail_BEG_03="BEG_03";
export const kApiPurchaseOrderDetail_BEG_04="BEG_04";
export const kApiPurchaseOrderDetail_BEG_05="BEG_05";
export const kApiPurchaseOrderDetail_BEG_06="BEG_06";
export const kApiPurchaseOrderDetail_CTT_01="CTT_01";
export const kApiPurchaseOrderDetail_Exp_Flag="Exp_Flag";
export const kApiPurchaseOrderDetail_Int_OrdID="Int_OrdID";
export const kApiPurchaseOrderDetail_SDQ_Flag="SDQ_Flag";
export const kApiPurchaseOrderDetail_CUR_02="CUR_02";
export const kApiPurchaseOrderDetail_ImportDate="ImportDate";
export const kApiPurchaseOrderDetail_ExportDate="ExportDate";
export const kApiPurchaseOrderDetail_Misc_ID="Misc_ID";
export const kApiPurchaseOrderDetail_URECID="URECID";
export const kApiPurchaseOrderDetail_UDID="UDID";
export const kApiPurchaseOrderDetail_Revision="Revision";
export const kApiPurchaseOrderDetail_Cust_Ship_Via_ID="Cust_Ship_Via_ID";
export const kApiPurchaseOrderDetail_Cust_Terms_ID="Cust_Terms_ID";
export const kApiPurchaseOrderDetail_FrtPayMeth="FrtPayMeth";
export const kApiPurchaseOrderDetail_VPIDFA="VPIDFA";
export const kApiPurchaseOrderDetail_TP_Name="TP_Name";
export const kApiPurchaseOrderDetail_NoteText="NoteText";

/*
        'ApiPurchaseOrderDetail' : {
            'PO_ID' : 'PO_ID',
            'TP_PartID' : 'TP_PartID',
            'BEG_01' : 'BEG_01',
            'BEG_02' : 'BEG_02',
            'BEG_03' : 'BEG_03',
            'BEG_04' : 'BEG_04',
            'BEG_05' : 'BEG_05',
            'BEG_06' : 'BEG_06',
            'CTT_01' : 'CTT_01',
            'Exp_Flag' : 'Exp_Flag',
            'Int_OrdID' : 'Int_OrdID',
            'SDQ_Flag' : 'SDQ_Flag',
            'CUR_02' : 'CUR_02',
            'ImportDate' : 'ImportDate',
            'ExportDate' : 'ExportDate',
            'Misc_ID' : 'Misc_ID',
            'URECID' : 'URECID',
            'UDID' : 'UDID',
            'Revision' : 'Revision',
            'Cust_Ship_Via_ID' : 'Cust_Ship_Via_ID',
            'Cust_Terms_ID' : 'Cust_Terms_ID',
            'FrtPayMeth' : 'FrtPayMeth',
            'VPIDFA' : 'VPIDFA',
            'TP_Name' : 'TP_Name',
            'NoteText' : 'NoteText',        },
*/

export const Label_PO_ID = 'ApiPurchaseOrderDetail.PO_ID';
export const Label_TP_PartID = 'ApiPurchaseOrderDetail.TP_PartID';
export const Label_BEG_01 = 'ApiPurchaseOrderDetail.BEG_01';
export const Label_BEG_02 = 'ApiPurchaseOrderDetail.BEG_02';
export const Label_BEG_03 = 'ApiPurchaseOrderDetail.BEG_03';
export const Label_BEG_04 = 'ApiPurchaseOrderDetail.BEG_04';
export const Label_BEG_05 = 'ApiPurchaseOrderDetail.BEG_05';
export const Label_BEG_06 = 'ApiPurchaseOrderDetail.BEG_06';
export const Label_CTT_01 = 'ApiPurchaseOrderDetail.CTT_01';
export const Label_Exp_Flag = 'ApiPurchaseOrderDetail.Exp_Flag';
export const Label_Int_OrdID = 'ApiPurchaseOrderDetail.Int_OrdID';
export const Label_SDQ_Flag = 'ApiPurchaseOrderDetail.SDQ_Flag';
export const Label_CUR_02 = 'ApiPurchaseOrderDetail.CUR_02';
export const Label_ImportDate = 'ApiPurchaseOrderDetail.ImportDate';
export const Label_ExportDate = 'ApiPurchaseOrderDetail.ExportDate';
export const Label_Misc_ID = 'ApiPurchaseOrderDetail.Misc_ID';
export const Label_URECID = 'ApiPurchaseOrderDetail.URECID';
export const Label_UDID = 'ApiPurchaseOrderDetail.UDID';
export const Label_Revision = 'ApiPurchaseOrderDetail.Revision';
export const Label_Cust_Ship_Via_ID = 'ApiPurchaseOrderDetail.Cust_Ship_Via_ID';
export const Label_Cust_Terms_ID = 'ApiPurchaseOrderDetail.Cust_Terms_ID';
export const Label_FrtPayMeth = 'ApiPurchaseOrderDetail.FrtPayMeth';
export const Label_VPIDFA = 'ApiPurchaseOrderDetail.VPIDFA';
export const Label_TP_Name = 'ApiPurchaseOrderDetail.TP_Name';
export const Label_NoteText = 'ApiPurchaseOrderDetail.NoteText';
