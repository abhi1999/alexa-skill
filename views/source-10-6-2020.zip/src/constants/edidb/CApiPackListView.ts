import { IApiPackListView } from '../edidb'
export class CApiPackListView implements IApiPackListView {
    public Order_No:number = 0;
    public Acct_Order_No:string = '';
    public TP_ID:string = '';
    public TP_Name:string = '';
    public ShipTo_Xref:string = '';
    public Order_Date:string = '';
    public Ship_Date:Date;
    public Cust_PO:string = '';
    public Exp_Flag:string = '';
    public Stat_Flag:string = '';
    public Ship_To_Name:string = '';
    public Loc_ID:string = '';
    public ShipTo_ID:string = '';
    public ShipTo_DC:string = '';
    public ASN_ID:number = 0;
    public status:string = '';
    public constructor(init?:Partial<CApiPackListView>) { Object.assign(this, init); }
}
export const IApiPackListView_Acct_Order_No_length = 30;
export const IApiPackListView_TP_ID_length = 30;
export const IApiPackListView_TP_Name_length = 30;
export const IApiPackListView_ShipTo_Xref_length = 30;
export const IApiPackListView_Order_Date_length = 8;
export const IApiPackListView_Cust_PO_length = 30;
export const IApiPackListView_Exp_Flag_length = 1;
export const IApiPackListView_Stat_Flag_length = 1;
export const IApiPackListView_Ship_To_Name_length = 50;
export const IApiPackListView_Loc_ID_length = 20;
export const IApiPackListView_ShipTo_ID_length = 80;
export const IApiPackListView_ShipTo_DC_length = 30;
export const IApiPackListView_status_length = 500;

export const kApiPackListView_Order_No="Order_No";
export const kApiPackListView_Acct_Order_No="Acct_Order_No";
export const kApiPackListView_TP_ID="TP_ID";
export const kApiPackListView_TP_Name="TP_Name";
export const kApiPackListView_ShipTo_Xref="ShipTo_Xref";
export const kApiPackListView_Order_Date="Order_Date";
export const kApiPackListView_Ship_Date="Ship_Date";
export const kApiPackListView_Cust_PO="Cust_PO";
export const kApiPackListView_Exp_Flag="Exp_Flag";
export const kApiPackListView_Stat_Flag="Stat_Flag";
export const kApiPackListView_Ship_To_Name="Ship_To_Name";
export const kApiPackListView_Loc_ID="Loc_ID";
export const kApiPackListView_ShipTo_ID="ShipTo_ID";
export const kApiPackListView_ShipTo_DC="ShipTo_DC";
export const kApiPackListView_ASN_ID="ASN_ID";
export const kApiPackListView_status="status";

/*
        'ApiPackListView' : {
            'Order_No' : 'Order_No',
            'Acct_Order_No' : 'Acct_Order_No',
            'TP_ID' : 'TP_ID',
            'TP_Name' : 'TP_Name',
            'ShipTo_Xref' : 'ShipTo_Xref',
            'Order_Date' : 'Order_Date',
            'Ship_Date' : 'Ship_Date',
            'Cust_PO' : 'Cust_PO',
            'Exp_Flag' : 'Exp_Flag',
            'Stat_Flag' : 'Stat_Flag',
            'Ship_To_Name' : 'Ship_To_Name',
            'Loc_ID' : 'Loc_ID',
            'ShipTo_ID' : 'ShipTo_ID',
            'ShipTo_DC' : 'ShipTo_DC',
            'ASN_ID' : 'ASN_ID',
            'status' : 'status',        },
*/

export const Label_Order_No = 'ApiPackListView.Order_No';
export const Label_Acct_Order_No = 'ApiPackListView.Acct_Order_No';
export const Label_TP_ID = 'ApiPackListView.TP_ID';
export const Label_TP_Name = 'ApiPackListView.TP_Name';
export const Label_ShipTo_Xref = 'ApiPackListView.ShipTo_Xref';
export const Label_Order_Date = 'ApiPackListView.Order_Date';
export const Label_Ship_Date = 'ApiPackListView.Ship_Date';
export const Label_Cust_PO = 'ApiPackListView.Cust_PO';
export const Label_Exp_Flag = 'ApiPackListView.Exp_Flag';
export const Label_Stat_Flag = 'ApiPackListView.Stat_Flag';
export const Label_Ship_To_Name = 'ApiPackListView.Ship_To_Name';
export const Label_Loc_ID = 'ApiPackListView.Loc_ID';
export const Label_ShipTo_ID = 'ApiPackListView.ShipTo_ID';
export const Label_ShipTo_DC = 'ApiPackListView.ShipTo_DC';
export const Label_ASN_ID = 'ApiPackListView.ASN_ID';
export const Label_status = 'ApiPackListView.status';
