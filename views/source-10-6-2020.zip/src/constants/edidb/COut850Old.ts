import { IOut850Old } from '../edidb'
export class COut850Old implements IOut850Old {
    public ID:number = 0;
    public TP_ID:string = '';
    public PO_NO:string = '';
    public PO_Date:string = '';
    public PO_ID:string = '';
    public ShipTo_Xref:string = '';
    public ShipToContact:string = '';
    public ShipToName:string = '';
    public ShipToName2:string = '';
    public ShipToAddress:string = '';
    public ShipToAddress2:string = '';
    public ShipToCity:string = '';
    public ShipToState:string = '';
    public ShipToZip:string = '';
    public Cust_Dept_Code:string = '';
    public Ship_Date:string = '';
    public Cancel_Date:string = '';
    public Int_Item_No:string = '';
    public Item_Qty:string = '';
    public Item_UM:string = '';
    public Item_Price:string = '';
    public PostStatus:string = '';
    public ShipMethod:string = '';
    public ShipToCountry:string = '';
    public PO1_LineNo:string = '';
    public vp_LineNo:string = '';
    public docline:number = 0;
    public etline_no:number = 0;
    public ShipTo_DC_Xref:string = '';
    public constructor(init?:Partial<COut850Old>) { Object.assign(this, init); }
}
export const IOut850Old_TP_ID_length = 30;
export const IOut850Old_PO_NO_length = 22;
export const IOut850Old_PO_Date_length = 8;
export const IOut850Old_PO_ID_length = 10;
export const IOut850Old_ShipTo_Xref_length = 30;
export const IOut850Old_ShipToContact_length = 50;
export const IOut850Old_ShipToName_length = 80;
export const IOut850Old_ShipToName2_length = 80;
export const IOut850Old_ShipToAddress_length = 80;
export const IOut850Old_ShipToAddress2_length = 80;
export const IOut850Old_ShipToCity_length = 40;
export const IOut850Old_ShipToState_length = 20;
export const IOut850Old_ShipToZip_length = 15;
export const IOut850Old_Cust_Dept_Code_length = 30;
export const IOut850Old_Ship_Date_length = 8;
export const IOut850Old_Cancel_Date_length = 8;
export const IOut850Old_Int_Item_No_length = 30;
export const IOut850Old_Item_Qty_length = 16;
export const IOut850Old_Item_UM_length = 10;
export const IOut850Old_Item_Price_length = 16;
export const IOut850Old_PostStatus_length = 1;
export const IOut850Old_ShipMethod_length = 2;
export const IOut850Old_ShipToCountry_length = 30;
export const IOut850Old_PO1_LineNo_length = 20;
export const IOut850Old_vp_LineNo_length = 11;
export const IOut850Old_ShipTo_DC_Xref_length = 30;

export const kOut850Old_ID="ID";
export const kOut850Old_TP_ID="TP_ID";
export const kOut850Old_PO_NO="PO_NO";
export const kOut850Old_PO_Date="PO_Date";
export const kOut850Old_PO_ID="PO_ID";
export const kOut850Old_ShipTo_Xref="ShipTo_Xref";
export const kOut850Old_ShipToContact="ShipToContact";
export const kOut850Old_ShipToName="ShipToName";
export const kOut850Old_ShipToName2="ShipToName2";
export const kOut850Old_ShipToAddress="ShipToAddress";
export const kOut850Old_ShipToAddress2="ShipToAddress2";
export const kOut850Old_ShipToCity="ShipToCity";
export const kOut850Old_ShipToState="ShipToState";
export const kOut850Old_ShipToZip="ShipToZip";
export const kOut850Old_Cust_Dept_Code="Cust_Dept_Code";
export const kOut850Old_Ship_Date="Ship_Date";
export const kOut850Old_Cancel_Date="Cancel_Date";
export const kOut850Old_Int_Item_No="Int_Item_No";
export const kOut850Old_Item_Qty="Item_Qty";
export const kOut850Old_Item_UM="Item_UM";
export const kOut850Old_Item_Price="Item_Price";
export const kOut850Old_PostStatus="PostStatus";
export const kOut850Old_ShipMethod="ShipMethod";
export const kOut850Old_ShipToCountry="ShipToCountry";
export const kOut850Old_PO1_LineNo="PO1_LineNo";
export const kOut850Old_vp_LineNo="vp_LineNo";
export const kOut850Old_docline="docline";
export const kOut850Old_etline_no="etline_no";
export const kOut850Old_ShipTo_DC_Xref="ShipTo_DC_Xref";

/*
        'Out850Old' : {
            'ID' : 'ID',
            'TP_ID' : 'TP_ID',
            'PO_NO' : 'PO_NO',
            'PO_Date' : 'PO_Date',
            'PO_ID' : 'PO_ID',
            'ShipTo_Xref' : 'ShipTo_Xref',
            'ShipToContact' : 'ShipToContact',
            'ShipToName' : 'ShipToName',
            'ShipToName2' : 'ShipToName2',
            'ShipToAddress' : 'ShipToAddress',
            'ShipToAddress2' : 'ShipToAddress2',
            'ShipToCity' : 'ShipToCity',
            'ShipToState' : 'ShipToState',
            'ShipToZip' : 'ShipToZip',
            'Cust_Dept_Code' : 'Cust_Dept_Code',
            'Ship_Date' : 'Ship_Date',
            'Cancel_Date' : 'Cancel_Date',
            'Int_Item_No' : 'Int_Item_No',
            'Item_Qty' : 'Item_Qty',
            'Item_UM' : 'Item_UM',
            'Item_Price' : 'Item_Price',
            'PostStatus' : 'PostStatus',
            'ShipMethod' : 'ShipMethod',
            'ShipToCountry' : 'ShipToCountry',
            'PO1_LineNo' : 'PO1_LineNo',
            'vp_LineNo' : 'vp_LineNo',
            'docline' : 'docline',
            'etline_no' : 'etline_no',
            'ShipTo_DC_Xref' : 'ShipTo_DC_Xref',        },
*/

export const Label_ID = 'Out850Old.ID';
export const Label_TP_ID = 'Out850Old.TP_ID';
export const Label_PO_NO = 'Out850Old.PO_NO';
export const Label_PO_Date = 'Out850Old.PO_Date';
export const Label_PO_ID = 'Out850Old.PO_ID';
export const Label_ShipTo_Xref = 'Out850Old.ShipTo_Xref';
export const Label_ShipToContact = 'Out850Old.ShipToContact';
export const Label_ShipToName = 'Out850Old.ShipToName';
export const Label_ShipToName2 = 'Out850Old.ShipToName2';
export const Label_ShipToAddress = 'Out850Old.ShipToAddress';
export const Label_ShipToAddress2 = 'Out850Old.ShipToAddress2';
export const Label_ShipToCity = 'Out850Old.ShipToCity';
export const Label_ShipToState = 'Out850Old.ShipToState';
export const Label_ShipToZip = 'Out850Old.ShipToZip';
export const Label_Cust_Dept_Code = 'Out850Old.Cust_Dept_Code';
export const Label_Ship_Date = 'Out850Old.Ship_Date';
export const Label_Cancel_Date = 'Out850Old.Cancel_Date';
export const Label_Int_Item_No = 'Out850Old.Int_Item_No';
export const Label_Item_Qty = 'Out850Old.Item_Qty';
export const Label_Item_UM = 'Out850Old.Item_UM';
export const Label_Item_Price = 'Out850Old.Item_Price';
export const Label_PostStatus = 'Out850Old.PostStatus';
export const Label_ShipMethod = 'Out850Old.ShipMethod';
export const Label_ShipToCountry = 'Out850Old.ShipToCountry';
export const Label_PO1_LineNo = 'Out850Old.PO1_LineNo';
export const Label_vp_LineNo = 'Out850Old.vp_LineNo';
export const Label_docline = 'Out850Old.docline';
export const Label_etline_no = 'Out850Old.etline_no';
export const Label_ShipTo_DC_Xref = 'Out850Old.ShipTo_DC_Xref';
