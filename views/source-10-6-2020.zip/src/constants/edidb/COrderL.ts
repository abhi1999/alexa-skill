import { IOrderL } from '../edidb'
export class COrderL implements IOrderL {
    public Order_No:number = 0;
    public Line_No:number = 0;
    public TP_ID:string = '';
    public ShipTo_Xref:string = '';
    public Order_Date:string = '';
    public Ship_Date:string = '';
    public Cust_PO:string = '';
    public Cust_Dept:string = '';
    public Loc_ID:string = '';
    public Ship_To_ID:string = '';
    public Ship_To_Name:string = '';
    public Ship_To_Address1:string = '';
    public Ship_To_Address2:string = '';
    public Ship_To_City:string = '';
    public Ship_To_St:string = '';
    public Ship_To_Zip:string = '';
    public ShipFr_Name:string = '';
    public ShipFr_Addr1:string = '';
    public ShipFr_Add2:string = '';
    public ShipFr_City:string = '';
    public ShipFr_St:string = '';
    public ShipFr_Zip:string = '';
    public ShipFr_Country:string = '';
    public Int_Item_No:string = '';
    public Quantity:number = 0;
    public QtyPacked:number = 0;
    public Price:number = 0;
    public UnitofMeas:string = '';
    public Exp_Flag:string = '';
    public Stat_Flag:string = '';
    public Order_Wt:number = 0;
    public Acct_Line_No:number = 0;
    public User1:string = '';
    public User2:string = '';
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public Ship_To_Address3:string = '';
    public TP_PartID:string = '';
    public Acct_Order_No:string = '';
    public Ship_To_Country:string = '';
    public Pick_Date:string = '';
    public constructor(init?:Partial<COrderL>) { Object.assign(this, init); }
}
export const IOrderL_TP_ID_length = 30;
export const IOrderL_ShipTo_Xref_length = 30;
export const IOrderL_Order_Date_length = 8;
export const IOrderL_Ship_Date_length = 8;
export const IOrderL_Cust_PO_length = 30;
export const IOrderL_Cust_Dept_length = 30;
export const IOrderL_Loc_ID_length = 20;
export const IOrderL_Ship_To_ID_length = 40;
export const IOrderL_Ship_To_Name_length = 50;
export const IOrderL_Ship_To_Address1_length = 50;
export const IOrderL_Ship_To_Address2_length = 50;
export const IOrderL_Ship_To_City_length = 30;
export const IOrderL_Ship_To_St_length = 20;
export const IOrderL_Ship_To_Zip_length = 20;
export const IOrderL_ShipFr_Name_length = 50;
export const IOrderL_ShipFr_Addr1_length = 50;
export const IOrderL_ShipFr_Add2_length = 50;
export const IOrderL_ShipFr_City_length = 30;
export const IOrderL_ShipFr_St_length = 20;
export const IOrderL_ShipFr_Zip_length = 20;
export const IOrderL_ShipFr_Country_length = 30;
export const IOrderL_Int_Item_No_length = 500;
export const IOrderL_UnitofMeas_length = 10;
export const IOrderL_Exp_Flag_length = 1;
export const IOrderL_Stat_Flag_length = 1;
export const IOrderL_User1_length = 30;
export const IOrderL_User2_length = 30;
export const IOrderL_User3_length = 30;
export const IOrderL_User4_length = 30;
export const IOrderL_User5_length = 30;
export const IOrderL_Ship_To_Address3_length = 50;
export const IOrderL_TP_PartID_length = 30;
export const IOrderL_Acct_Order_No_length = 30;
export const IOrderL_Ship_To_Country_length = 30;
export const IOrderL_Pick_Date_length = 8;

export const kOrderL_Order_No="Order_No";
export const kOrderL_Line_No="Line_No";
export const kOrderL_TP_ID="TP_ID";
export const kOrderL_ShipTo_Xref="ShipTo_Xref";
export const kOrderL_Order_Date="Order_Date";
export const kOrderL_Ship_Date="Ship_Date";
export const kOrderL_Cust_PO="Cust_PO";
export const kOrderL_Cust_Dept="Cust_Dept";
export const kOrderL_Loc_ID="Loc_ID";
export const kOrderL_Ship_To_ID="Ship_To_ID";
export const kOrderL_Ship_To_Name="Ship_To_Name";
export const kOrderL_Ship_To_Address1="Ship_To_Address1";
export const kOrderL_Ship_To_Address2="Ship_To_Address2";
export const kOrderL_Ship_To_City="Ship_To_City";
export const kOrderL_Ship_To_St="Ship_To_St";
export const kOrderL_Ship_To_Zip="Ship_To_Zip";
export const kOrderL_ShipFr_Name="ShipFr_Name";
export const kOrderL_ShipFr_Addr1="ShipFr_Addr1";
export const kOrderL_ShipFr_Add2="ShipFr_Add2";
export const kOrderL_ShipFr_City="ShipFr_City";
export const kOrderL_ShipFr_St="ShipFr_St";
export const kOrderL_ShipFr_Zip="ShipFr_Zip";
export const kOrderL_ShipFr_Country="ShipFr_Country";
export const kOrderL_Int_Item_No="Int_Item_No";
export const kOrderL_Quantity="Quantity";
export const kOrderL_QtyPacked="QtyPacked";
export const kOrderL_Price="Price";
export const kOrderL_UnitofMeas="UnitofMeas";
export const kOrderL_Exp_Flag="Exp_Flag";
export const kOrderL_Stat_Flag="Stat_Flag";
export const kOrderL_Order_Wt="Order_Wt";
export const kOrderL_Acct_Line_No="Acct_Line_No";
export const kOrderL_User1="User1";
export const kOrderL_User2="User2";
export const kOrderL_User3="User3";
export const kOrderL_User4="User4";
export const kOrderL_User5="User5";
export const kOrderL_Ship_To_Address3="Ship_To_Address3";
export const kOrderL_TP_PartID="TP_PartID";
export const kOrderL_Acct_Order_No="Acct_Order_No";
export const kOrderL_Ship_To_Country="Ship_To_Country";
export const kOrderL_Pick_Date="Pick_Date";

/*
        'OrderL' : {
            'Order_No' : 'Order_No',
            'Line_No' : 'Line_No',
            'TP_ID' : 'TP_ID',
            'ShipTo_Xref' : 'ShipTo_Xref',
            'Order_Date' : 'Order_Date',
            'Ship_Date' : 'Ship_Date',
            'Cust_PO' : 'Cust_PO',
            'Cust_Dept' : 'Cust_Dept',
            'Loc_ID' : 'Loc_ID',
            'Ship_To_ID' : 'Ship_To_ID',
            'Ship_To_Name' : 'Ship_To_Name',
            'Ship_To_Address1' : 'Ship_To_Address1',
            'Ship_To_Address2' : 'Ship_To_Address2',
            'Ship_To_City' : 'Ship_To_City',
            'Ship_To_St' : 'Ship_To_St',
            'Ship_To_Zip' : 'Ship_To_Zip',
            'ShipFr_Name' : 'ShipFr_Name',
            'ShipFr_Addr1' : 'ShipFr_Addr1',
            'ShipFr_Add2' : 'ShipFr_Add2',
            'ShipFr_City' : 'ShipFr_City',
            'ShipFr_St' : 'ShipFr_St',
            'ShipFr_Zip' : 'ShipFr_Zip',
            'ShipFr_Country' : 'ShipFr_Country',
            'Int_Item_No' : 'Int_Item_No',
            'Quantity' : 'Quantity',
            'QtyPacked' : 'QtyPacked',
            'Price' : 'Price',
            'UnitofMeas' : 'UnitofMeas',
            'Exp_Flag' : 'Exp_Flag',
            'Stat_Flag' : 'Stat_Flag',
            'Order_Wt' : 'Order_Wt',
            'Acct_Line_No' : 'Acct_Line_No',
            'User1' : 'User1',
            'User2' : 'User2',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'Ship_To_Address3' : 'Ship_To_Address3',
            'TP_PartID' : 'TP_PartID',
            'Acct_Order_No' : 'Acct_Order_No',
            'Ship_To_Country' : 'Ship_To_Country',
            'Pick_Date' : 'Pick_Date',        },
*/

export const Label_Order_No = 'OrderL.Order_No';
export const Label_Line_No = 'OrderL.Line_No';
export const Label_TP_ID = 'OrderL.TP_ID';
export const Label_ShipTo_Xref = 'OrderL.ShipTo_Xref';
export const Label_Order_Date = 'OrderL.Order_Date';
export const Label_Ship_Date = 'OrderL.Ship_Date';
export const Label_Cust_PO = 'OrderL.Cust_PO';
export const Label_Cust_Dept = 'OrderL.Cust_Dept';
export const Label_Loc_ID = 'OrderL.Loc_ID';
export const Label_Ship_To_ID = 'OrderL.Ship_To_ID';
export const Label_Ship_To_Name = 'OrderL.Ship_To_Name';
export const Label_Ship_To_Address1 = 'OrderL.Ship_To_Address1';
export const Label_Ship_To_Address2 = 'OrderL.Ship_To_Address2';
export const Label_Ship_To_City = 'OrderL.Ship_To_City';
export const Label_Ship_To_St = 'OrderL.Ship_To_St';
export const Label_Ship_To_Zip = 'OrderL.Ship_To_Zip';
export const Label_ShipFr_Name = 'OrderL.ShipFr_Name';
export const Label_ShipFr_Addr1 = 'OrderL.ShipFr_Addr1';
export const Label_ShipFr_Add2 = 'OrderL.ShipFr_Add2';
export const Label_ShipFr_City = 'OrderL.ShipFr_City';
export const Label_ShipFr_St = 'OrderL.ShipFr_St';
export const Label_ShipFr_Zip = 'OrderL.ShipFr_Zip';
export const Label_ShipFr_Country = 'OrderL.ShipFr_Country';
export const Label_Int_Item_No = 'OrderL.Int_Item_No';
export const Label_Quantity = 'OrderL.Quantity';
export const Label_QtyPacked = 'OrderL.QtyPacked';
export const Label_Price = 'OrderL.Price';
export const Label_UnitofMeas = 'OrderL.UnitofMeas';
export const Label_Exp_Flag = 'OrderL.Exp_Flag';
export const Label_Stat_Flag = 'OrderL.Stat_Flag';
export const Label_Order_Wt = 'OrderL.Order_Wt';
export const Label_Acct_Line_No = 'OrderL.Acct_Line_No';
export const Label_User1 = 'OrderL.User1';
export const Label_User2 = 'OrderL.User2';
export const Label_User3 = 'OrderL.User3';
export const Label_User4 = 'OrderL.User4';
export const Label_User5 = 'OrderL.User5';
export const Label_Ship_To_Address3 = 'OrderL.Ship_To_Address3';
export const Label_TP_PartID = 'OrderL.TP_PartID';
export const Label_Acct_Order_No = 'OrderL.Acct_Order_No';
export const Label_Ship_To_Country = 'OrderL.Ship_To_Country';
export const Label_Pick_Date = 'OrderL.Pick_Date';
