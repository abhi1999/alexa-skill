import { IApiCarton2 } from '../edidb'
export class CApiCarton2 implements IApiCarton2 {
    public Asn_ID:number = 0;
    public Box_ID:number = 0;
    public Pack_Level:number = 0;
    public TrackingNo:string = '';
    public SSCC:string = '';
    public PKG_ID:string = '';
    public Pack_Wt:string = '';
    public constructor(init?:Partial<CApiCarton2>) { Object.assign(this, init); }
}
export const IApiCarton2_TrackingNo_length = 50;
export const IApiCarton2_SSCC_length = 30;
export const IApiCarton2_PKG_ID_length = 10;
export const IApiCarton2_Pack_Wt_length = 8000;

export const kApiCarton2_Asn_ID="Asn_ID";
export const kApiCarton2_Box_ID="Box_ID";
export const kApiCarton2_Pack_Level="Pack_Level";
export const kApiCarton2_TrackingNo="TrackingNo";
export const kApiCarton2_SSCC="SSCC";
export const kApiCarton2_PKG_ID="PKG_ID";
export const kApiCarton2_Pack_Wt="Pack_Wt";

/*
        'ApiCarton2' : {
            'Asn_ID' : 'Asn_ID',
            'Box_ID' : 'Box_ID',
            'Pack_Level' : 'Pack_Level',
            'TrackingNo' : 'TrackingNo',
            'SSCC' : 'SSCC',
            'PKG_ID' : 'PKG_ID',
            'Pack_Wt' : 'Pack_Wt',        },
*/

export const Label_Asn_ID = 'ApiCarton2.Asn_ID';
export const Label_Box_ID = 'ApiCarton2.Box_ID';
export const Label_Pack_Level = 'ApiCarton2.Pack_Level';
export const Label_TrackingNo = 'ApiCarton2.TrackingNo';
export const Label_SSCC = 'ApiCarton2.SSCC';
export const Label_PKG_ID = 'ApiCarton2.PKG_ID';
export const Label_Pack_Wt = 'ApiCarton2.Pack_Wt';
