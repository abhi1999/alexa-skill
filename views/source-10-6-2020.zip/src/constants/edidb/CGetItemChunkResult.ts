import { IGetItemChunkResult } from '../edidb'
export class CGetItemChunkResult implements IGetItemChunkResult {
    public LOCATION_IN_RECORD_SET:number = 0;
    public PAGE_NUMBER:number = 0;
    public Int_Item_No:string = '';
    public Item_Desc:string = '';
    public UPC:string = '';
    public Def_Pack_Qty:number = 0;
    public Item_Wt:number = 0;
    public Item_Um:string = '';
    public Item_UOM:string = '';
    public EDI_UOM:string = '';
    public RetailPrice:number = 0;
    public SellingPrice:number = 0;
    public SAC_Flag:boolean;
    public SAC_Qual:string = '';
    public Cube_Length:number = 0;
    public Cube_Width:number = 0;
    public Cube_Height:number = 0;
    public Cube_Qty:number = 0;
    public Cube_UOM:string = '';
    public User1:string = '';
    public User2:string = '';
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public Item_rfid:boolean;
    public locid:string = '';
    public PackingClass:string = '';
    public Item_Alt_No:string = '';
    public Item_Config:string = '';
    public Item_Size:string = '';
    public Item_Color:string = '';
    public Frt_Code:string = '';
    public GTIN:string = '';
    public EAN:string = '';
    public constructor(init?:Partial<CGetItemChunkResult>) { Object.assign(this, init); }
}
export const kGetItemChunkResult_LOCATION_IN_RECORD_SET="LOCATION_IN_RECORD_SET";
export const kGetItemChunkResult_PAGE_NUMBER="PAGE_NUMBER";
export const kGetItemChunkResult_Int_Item_No="Int_Item_No";
export const kGetItemChunkResult_Item_Desc="Item_Desc";
export const kGetItemChunkResult_UPC="UPC";
export const kGetItemChunkResult_Def_Pack_Qty="Def_Pack_Qty";
export const kGetItemChunkResult_Item_Wt="Item_Wt";
export const kGetItemChunkResult_Item_Um="Item_Um";
export const kGetItemChunkResult_Item_UOM="Item_UOM";
export const kGetItemChunkResult_EDI_UOM="EDI_UOM";
export const kGetItemChunkResult_RetailPrice="RetailPrice";
export const kGetItemChunkResult_SellingPrice="SellingPrice";
export const kGetItemChunkResult_SAC_Flag="SAC_Flag";
export const kGetItemChunkResult_SAC_Qual="SAC_Qual";
export const kGetItemChunkResult_Cube_Length="Cube_Length";
export const kGetItemChunkResult_Cube_Width="Cube_Width";
export const kGetItemChunkResult_Cube_Height="Cube_Height";
export const kGetItemChunkResult_Cube_Qty="Cube_Qty";
export const kGetItemChunkResult_Cube_UOM="Cube_UOM";
export const kGetItemChunkResult_User1="User1";
export const kGetItemChunkResult_User2="User2";
export const kGetItemChunkResult_User3="User3";
export const kGetItemChunkResult_User4="User4";
export const kGetItemChunkResult_User5="User5";
export const kGetItemChunkResult_Item_rfid="Item_rfid";
export const kGetItemChunkResult_locid="locid";
export const kGetItemChunkResult_PackingClass="PackingClass";
export const kGetItemChunkResult_Item_Alt_No="Item_Alt_No";
export const kGetItemChunkResult_Item_Config="Item_Config";
export const kGetItemChunkResult_Item_Size="Item_Size";
export const kGetItemChunkResult_Item_Color="Item_Color";
export const kGetItemChunkResult_Frt_Code="Frt_Code";
export const kGetItemChunkResult_GTIN="GTIN";
export const kGetItemChunkResult_EAN="EAN";

/*
        'GetItemChunkResult' : {
            'LOCATION_IN_RECORD_SET' : 'LOCATION_IN_RECORD_SET',
            'PAGE_NUMBER' : 'PAGE_NUMBER',
            'Int_Item_No' : 'Int_Item_No',
            'Item_Desc' : 'Item_Desc',
            'UPC' : 'UPC',
            'Def_Pack_Qty' : 'Def_Pack_Qty',
            'Item_Wt' : 'Item_Wt',
            'Item_Um' : 'Item_Um',
            'Item_UOM' : 'Item_UOM',
            'EDI_UOM' : 'EDI_UOM',
            'RetailPrice' : 'RetailPrice',
            'SellingPrice' : 'SellingPrice',
            'SAC_Flag' : 'SAC_Flag',
            'SAC_Qual' : 'SAC_Qual',
            'Cube_Length' : 'Cube_Length',
            'Cube_Width' : 'Cube_Width',
            'Cube_Height' : 'Cube_Height',
            'Cube_Qty' : 'Cube_Qty',
            'Cube_UOM' : 'Cube_UOM',
            'User1' : 'User1',
            'User2' : 'User2',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'Item_rfid' : 'Item_rfid',
            'locid' : 'locid',
            'PackingClass' : 'PackingClass',
            'Item_Alt_No' : 'Item_Alt_No',
            'Item_Config' : 'Item_Config',
            'Item_Size' : 'Item_Size',
            'Item_Color' : 'Item_Color',
            'Frt_Code' : 'Frt_Code',
            'GTIN' : 'GTIN',
            'EAN' : 'EAN',        },
*/

export const Label_LOCATION_IN_RECORD_SET = 'GetItemChunkResult.LOCATION_IN_RECORD_SET';
export const Label_PAGE_NUMBER = 'GetItemChunkResult.PAGE_NUMBER';
export const Label_Int_Item_No = 'GetItemChunkResult.Int_Item_No';
export const Label_Item_Desc = 'GetItemChunkResult.Item_Desc';
export const Label_UPC = 'GetItemChunkResult.UPC';
export const Label_Def_Pack_Qty = 'GetItemChunkResult.Def_Pack_Qty';
export const Label_Item_Wt = 'GetItemChunkResult.Item_Wt';
export const Label_Item_Um = 'GetItemChunkResult.Item_Um';
export const Label_Item_UOM = 'GetItemChunkResult.Item_UOM';
export const Label_EDI_UOM = 'GetItemChunkResult.EDI_UOM';
export const Label_RetailPrice = 'GetItemChunkResult.RetailPrice';
export const Label_SellingPrice = 'GetItemChunkResult.SellingPrice';
export const Label_SAC_Flag = 'GetItemChunkResult.SAC_Flag';
export const Label_SAC_Qual = 'GetItemChunkResult.SAC_Qual';
export const Label_Cube_Length = 'GetItemChunkResult.Cube_Length';
export const Label_Cube_Width = 'GetItemChunkResult.Cube_Width';
export const Label_Cube_Height = 'GetItemChunkResult.Cube_Height';
export const Label_Cube_Qty = 'GetItemChunkResult.Cube_Qty';
export const Label_Cube_UOM = 'GetItemChunkResult.Cube_UOM';
export const Label_User1 = 'GetItemChunkResult.User1';
export const Label_User2 = 'GetItemChunkResult.User2';
export const Label_User3 = 'GetItemChunkResult.User3';
export const Label_User4 = 'GetItemChunkResult.User4';
export const Label_User5 = 'GetItemChunkResult.User5';
export const Label_Item_rfid = 'GetItemChunkResult.Item_rfid';
export const Label_locid = 'GetItemChunkResult.locid';
export const Label_PackingClass = 'GetItemChunkResult.PackingClass';
export const Label_Item_Alt_No = 'GetItemChunkResult.Item_Alt_No';
export const Label_Item_Config = 'GetItemChunkResult.Item_Config';
export const Label_Item_Size = 'GetItemChunkResult.Item_Size';
export const Label_Item_Color = 'GetItemChunkResult.Item_Color';
export const Label_Frt_Code = 'GetItemChunkResult.Frt_Code';
export const Label_GTIN = 'GetItemChunkResult.GTIN';
export const Label_EAN = 'GetItemChunkResult.EAN';
