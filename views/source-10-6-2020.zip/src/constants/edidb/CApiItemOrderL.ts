import { IApiItemOrderL } from '../edidb'
export class CApiItemOrderL implements IApiItemOrderL {
    public Order_No:number = 0;
    public Line_No:number = 0;
    public TP_ID:string = '';
    public ShipTo_Xref:string = '';
    public Order_Date:string = '';
    public Ship_Date:string = '';
    public Cust_PO:string = '';
    public Cust_Dept:string = '';
    public Loc_ID:string = '';
    public Ship_To_ID:string = '';
    public Ship_To_Name:string = '';
    public Ship_To_Address1:string = '';
    public Ship_To_Address2:string = '';
    public Ship_To_City:string = '';
    public Ship_To_St:string = '';
    public Ship_To_Zip:string = '';
    public ShipFr_Name:string = '';
    public ShipFr_Addr1:string = '';
    public ShipFr_Add2:string = '';
    public ShipFr_City:string = '';
    public ShipFr_St:string = '';
    public ShipFr_Zip:string = '';
    public ShipFr_Country:string = '';
    public Int_Item_No:string = '';
    public Quantity:number = 0;
    public QtyPacked:number = 0;
    public Price:number = 0;
    public UnitofMeas:string = '';
    public Exp_Flag:string = '';
    public Stat_Flag:string = '';
    public Order_Wt:number = 0;
    public Acct_Line_No:number = 0;
    public User1:string = '';
    public User2:string = '';
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public Ship_To_Address3:string = '';
    public TP_PartID:string = '';
    public Acct_Order_No:string = '';
    public Ship_To_Country:string = '';
    public Pick_Date:string = '';
    public Item_Desc:string = '';
    public Item_Alt_No: string = '';
    public Item_No_Plus_Desc: string;
    public UPC: string;
    public constructor(init?:Partial<CApiItemOrderL>) { Object.assign(this, init); }
}
export const IApiItemOrderL_TP_ID_length = 30;
export const IApiItemOrderL_ShipTo_Xref_length = 30;
export const IApiItemOrderL_Order_Date_length = 8;
export const IApiItemOrderL_Ship_Date_length = 8;
export const IApiItemOrderL_Cust_PO_length = 30;
export const IApiItemOrderL_Cust_Dept_length = 30;
export const IApiItemOrderL_Loc_ID_length = 20;
export const IApiItemOrderL_Ship_To_ID_length = 40;
export const IApiItemOrderL_Ship_To_Name_length = 50;
export const IApiItemOrderL_Ship_To_Address1_length = 50;
export const IApiItemOrderL_Ship_To_Address2_length = 50;
export const IApiItemOrderL_Ship_To_City_length = 30;
export const IApiItemOrderL_Ship_To_St_length = 20;
export const IApiItemOrderL_Ship_To_Zip_length = 20;
export const IApiItemOrderL_ShipFr_Name_length = 50;
export const IApiItemOrderL_ShipFr_Addr1_length = 50;
export const IApiItemOrderL_ShipFr_Add2_length = 50;
export const IApiItemOrderL_ShipFr_City_length = 30;
export const IApiItemOrderL_ShipFr_St_length = 20;
export const IApiItemOrderL_ShipFr_Zip_length = 20;
export const IApiItemOrderL_ShipFr_Country_length = 30;
export const IApiItemOrderL_Int_Item_No_length = 500;
export const IApiItemOrderL_UnitofMeas_length = 10;
export const IApiItemOrderL_Exp_Flag_length = 1;
export const IApiItemOrderL_Stat_Flag_length = 1;
export const IApiItemOrderL_User1_length = 30;
export const IApiItemOrderL_User2_length = 30;
export const IApiItemOrderL_User3_length = 30;
export const IApiItemOrderL_User4_length = 30;
export const IApiItemOrderL_User5_length = 30;
export const IApiItemOrderL_Ship_To_Address3_length = 50;
export const IApiItemOrderL_TP_PartID_length = 30;
export const IApiItemOrderL_Acct_Order_No_length = 30;
export const IApiItemOrderL_Ship_To_Country_length = 30;
export const IApiItemOrderL_Pick_Date_length = 8;
export const IApiItemOrderL_Item_Desc_length = 80;
export const IApiItemOrderL_Item_Alt_No_length = 30;
export const IApiItemOrderL_Item_No_Plus_Desc_length = 110;
export const IApiItemOrderL_UPC_Length = 20;
export const IApiItemOrderL_Order_No_length = 10;
export const IApiItemOrderL_Quantity_length = 10;
export const IApiItemOrderL_QtyPacked_length = 10;
export const IApiItemOrderL_Price_length = 10;
export const IApiItemOrderL_Order_Wt_length = 10;
export const IApiItemOrderL_Acct_Line_No_length = 10;

export const kApiItemOrderL_Order_No="Order_No";
export const kApiItemOrderL_Line_No="Line_No";
export const kApiItemOrderL_TP_ID="TP_ID";
export const kApiItemOrderL_ShipTo_Xref="ShipTo_Xref";
export const kApiItemOrderL_Order_Date="Order_Date";
export const kApiItemOrderL_Ship_Date="Ship_Date";
export const kApiItemOrderL_Cust_PO="Cust_PO";
export const kApiItemOrderL_Cust_Dept="Cust_Dept";
export const kApiItemOrderL_Loc_ID="Loc_ID";
export const kApiItemOrderL_Ship_To_ID="Ship_To_ID";
export const kApiItemOrderL_Ship_To_Name="Ship_To_Name";
export const kApiItemOrderL_Ship_To_Address1="Ship_To_Address1";
export const kApiItemOrderL_Ship_To_Address2="Ship_To_Address2";
export const kApiItemOrderL_Ship_To_City="Ship_To_City";
export const kApiItemOrderL_Ship_To_St="Ship_To_St";
export const kApiItemOrderL_Ship_To_Zip="Ship_To_Zip";
export const kApiItemOrderL_ShipFr_Name="ShipFr_Name";
export const kApiItemOrderL_ShipFr_Addr1="ShipFr_Addr1";
export const kApiItemOrderL_ShipFr_Add2="ShipFr_Add2";
export const kApiItemOrderL_ShipFr_City="ShipFr_City";
export const kApiItemOrderL_ShipFr_St="ShipFr_St";
export const kApiItemOrderL_ShipFr_Zip="ShipFr_Zip";
export const kApiItemOrderL_ShipFr_Country="ShipFr_Country";
export const kApiItemOrderL_Int_Item_No="Int_Item_No";
export const kApiItemOrderL_Quantity="Quantity";
export const kApiItemOrderL_QtyPacked="QtyPacked";
export const kApiItemOrderL_Price="Price";
export const kApiItemOrderL_UnitofMeas="UnitofMeas";
export const kApiItemOrderL_Exp_Flag="Exp_Flag";
export const kApiItemOrderL_Stat_Flag="Stat_Flag";
export const kApiItemOrderL_Order_Wt="Order_Wt";
export const kApiItemOrderL_Acct_Line_No="Acct_Line_No";
export const kApiItemOrderL_User1="User1";
export const kApiItemOrderL_User2="User2";
export const kApiItemOrderL_User3="User3";
export const kApiItemOrderL_User4="User4";
export const kApiItemOrderL_User5="User5";
export const kApiItemOrderL_Ship_To_Address3="Ship_To_Address3";
export const kApiItemOrderL_TP_PartID="TP_PartID";
export const kApiItemOrderL_Acct_Order_No="Acct_Order_No";
export const kApiItemOrderL_Ship_To_Country="Ship_To_Country";
export const kApiItemOrderL_Pick_Date="Pick_Date";
export const kApiItemOrderL_Item_Desc="Item_Desc";
export const kApiItemOrderL_Item_Alt_No = "Item_Alt_No";
export const kApiItemOrderL_Item_No_Plus_Desc = "Item_No_Plus_Desc";
export const kApiItemOrderL_UPC = "UPC";

/*
        'ApiItemOrderL' : {
            'Order_No' : 'Order_No',
            'Line_No' : 'Line_No',
            'TP_ID' : 'TP_ID',
            'ShipTo_Xref' : 'ShipTo_Xref',
            'Order_Date' : 'Order_Date',
            'Ship_Date' : 'Ship_Date',
            'Cust_PO' : 'Cust_PO',
            'Cust_Dept' : 'Cust_Dept',
            'Loc_ID' : 'Loc_ID',
            'Ship_To_ID' : 'Ship_To_ID',
            'Ship_To_Name' : 'Ship_To_Name',
            'Ship_To_Address1' : 'Ship_To_Address1',
            'Ship_To_Address2' : 'Ship_To_Address2',
            'Ship_To_City' : 'Ship_To_City',
            'Ship_To_St' : 'Ship_To_St',
            'Ship_To_Zip' : 'Ship_To_Zip',
            'ShipFr_Name' : 'ShipFr_Name',
            'ShipFr_Addr1' : 'ShipFr_Addr1',
            'ShipFr_Add2' : 'ShipFr_Add2',
            'ShipFr_City' : 'ShipFr_City',
            'ShipFr_St' : 'ShipFr_St',
            'ShipFr_Zip' : 'ShipFr_Zip',
            'ShipFr_Country' : 'ShipFr_Country',
            'Int_Item_No' : 'Int_Item_No',
            'Quantity' : 'Quantity',
            'QtyPacked' : 'QtyPacked',
            'Price' : 'Price',
            'UnitofMeas' : 'UnitofMeas',
            'Exp_Flag' : 'Exp_Flag',
            'Stat_Flag' : 'Stat_Flag',
            'Order_Wt' : 'Order_Wt',
            'Acct_Line_No' : 'Acct_Line_No',
            'User1' : 'User1',
            'User2' : 'User2',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'Ship_To_Address3' : 'Ship_To_Address3',
            'TP_PartID' : 'TP_PartID',
            'Acct_Order_No' : 'Acct_Order_No',
            'Ship_To_Country' : 'Ship_To_Country',
            'Pick_Date' : 'Pick_Date',
            'Item_Desc' : 'Item_Desc',
            'Item_Alt_No' : 'Item_Alt_No',
        },
*/

export const Label_Order_No = 'ApiItemOrderL.Order_No';
export const Label_Line_No = 'ApiItemOrderL.Line_No';
export const Label_TP_ID = 'ApiItemOrderL.TP_ID';
export const Label_ShipTo_Xref = 'ApiItemOrderL.ShipTo_Xref';
export const Label_Order_Date = 'ApiItemOrderL.Order_Date';
export const Label_Ship_Date = 'ApiItemOrderL.Ship_Date';
export const Label_Cust_PO = 'ApiItemOrderL.Cust_PO';
export const Label_Cust_Dept = 'ApiItemOrderL.Cust_Dept';
export const Label_Loc_ID = 'ApiItemOrderL.Loc_ID';
export const Label_Ship_To_ID = 'ApiItemOrderL.Ship_To_ID';
export const Label_Ship_To_Name = 'ApiItemOrderL.Ship_To_Name';
export const Label_Ship_To_Address1 = 'ApiItemOrderL.Ship_To_Address1';
export const Label_Ship_To_Address2 = 'ApiItemOrderL.Ship_To_Address2';
export const Label_Ship_To_City = 'ApiItemOrderL.Ship_To_City';
export const Label_Ship_To_St = 'ApiItemOrderL.Ship_To_St';
export const Label_Ship_To_Zip = 'ApiItemOrderL.Ship_To_Zip';
export const Label_ShipFr_Name = 'ApiItemOrderL.ShipFr_Name';
export const Label_ShipFr_Addr1 = 'ApiItemOrderL.ShipFr_Addr1';
export const Label_ShipFr_Add2 = 'ApiItemOrderL.ShipFr_Add2';
export const Label_ShipFr_City = 'ApiItemOrderL.ShipFr_City';
export const Label_ShipFr_St = 'ApiItemOrderL.ShipFr_St';
export const Label_ShipFr_Zip = 'ApiItemOrderL.ShipFr_Zip';
export const Label_ShipFr_Country = 'ApiItemOrderL.ShipFr_Country';
export const Label_Int_Item_No = 'ApiItemOrderL.Int_Item_No';
export const Label_Quantity = 'ApiItemOrderL.Quantity';
export const Label_QtyPacked = 'ApiItemOrderL.QtyPacked';
export const Label_Price = 'ApiItemOrderL.Price';
export const Label_UnitofMeas = 'ApiItemOrderL.UnitofMeas';
export const Label_Exp_Flag = 'ApiItemOrderL.Exp_Flag';
export const Label_Stat_Flag = 'ApiItemOrderL.Stat_Flag';
export const Label_Order_Wt = 'ApiItemOrderL.Order_Wt';
export const Label_Acct_Line_No = 'ApiItemOrderL.Acct_Line_No';
export const Label_User1 = 'ApiItemOrderL.User1';
export const Label_User2 = 'ApiItemOrderL.User2';
export const Label_User3 = 'ApiItemOrderL.User3';
export const Label_User4 = 'ApiItemOrderL.User4';
export const Label_User5 = 'ApiItemOrderL.User5';
export const Label_Ship_To_Address3 = 'ApiItemOrderL.Ship_To_Address3';
export const Label_TP_PartID = 'ApiItemOrderL.TP_PartID';
export const Label_Acct_Order_No = 'ApiItemOrderL.Acct_Order_No';
export const Label_Ship_To_Country = 'ApiItemOrderL.Ship_To_Country';
export const Label_Pick_Date = 'ApiItemOrderL.Pick_Date';
export const Label_Item_Desc = 'ApiItemOrderL.Item_Desc';
export const Label_Item_Alt_No = 'ApiItemOrderL.Item_Alt_No';
export const Label_Item_No_Plus_Desc = "ApiItemOrderL.Item_No_Plus_Desc";
export const Label_UPC = "ApiItemOrderL.UPC Code";

