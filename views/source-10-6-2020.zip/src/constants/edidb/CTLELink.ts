import { ITLELink } from '../edidb'
export class CTLELink implements ITLELink {
    public TLELID:number = 0;
    public ParDataType:string = '';
    public ParDataKey:string = '';
    public ParDirection:string = '';
    public ChildDataType:string = '';
    public ChildDataKey:string = '';
    public ChildDirection:string = '';
    public CreatedDate:Date;
    public ParentID:string = '';
    public ChildID:string = '';
    public constructor(init?:Partial<CTLELink>) { Object.assign(this, init); }
}
export const ITLELink_ParDataType_length = 50;
export const ITLELink_ParDataKey_length = 50;
export const ITLELink_ParDirection_length = 1;
export const ITLELink_ChildDataType_length = 50;
export const ITLELink_ChildDataKey_length = 50;
export const ITLELink_ChildDirection_length = 1;
export const ITLELink_ParentID_length = 105;
export const ITLELink_ChildID_length = 105;

export const kTLELink_TLELID="TLELID";
export const kTLELink_ParDataType="ParDataType";
export const kTLELink_ParDataKey="ParDataKey";
export const kTLELink_ParDirection="ParDirection";
export const kTLELink_ChildDataType="ChildDataType";
export const kTLELink_ChildDataKey="ChildDataKey";
export const kTLELink_ChildDirection="ChildDirection";
export const kTLELink_CreatedDate="CreatedDate";
export const kTLELink_ParentID="ParentID";
export const kTLELink_ChildID="ChildID";

/*
        'TLELink' : {
            'TLELID' : 'TLELID',
            'ParDataType' : 'ParDataType',
            'ParDataKey' : 'ParDataKey',
            'ParDirection' : 'ParDirection',
            'ChildDataType' : 'ChildDataType',
            'ChildDataKey' : 'ChildDataKey',
            'ChildDirection' : 'ChildDirection',
            'CreatedDate' : 'CreatedDate',
            'ParentID' : 'ParentID',
            'ChildID' : 'ChildID',        },
*/

export const Label_TLELID = 'TLELink.TLELID';
export const Label_ParDataType = 'TLELink.ParDataType';
export const Label_ParDataKey = 'TLELink.ParDataKey';
export const Label_ParDirection = 'TLELink.ParDirection';
export const Label_ChildDataType = 'TLELink.ChildDataType';
export const Label_ChildDataKey = 'TLELink.ChildDataKey';
export const Label_ChildDirection = 'TLELink.ChildDirection';
export const Label_CreatedDate = 'TLELink.CreatedDate';
export const Label_ParentID = 'TLELink.ParentID';
export const Label_ChildID = 'TLELink.ChildID';
