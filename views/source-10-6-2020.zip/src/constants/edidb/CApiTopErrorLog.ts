import { IApiTopErrorLog } from '../edidb'
export class CApiTopErrorLog implements IApiTopErrorLog {
    public LogProcess:string = '';
    public Count:number = 0;
    public constructor(init?:Partial<CApiTopErrorLog>) { Object.assign(this, init); }
}
export const IApiTopErrorLog_LogProcess_length = 50;

export const kApiTopErrorLog_LogProcess="LogProcess";
export const kApiTopErrorLog_Count="Count";

/*
        'ApiTopErrorLog' : {
            'LogProcess' : 'LogProcess',
            'Count' : 'Count',        },
*/

export const Label_LogProcess = 'ApiTopErrorLog.LogProcess';
export const Label_Count = 'ApiTopErrorLog.Count';
