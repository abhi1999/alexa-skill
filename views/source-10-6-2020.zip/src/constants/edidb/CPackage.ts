import { IPackage } from '../edidb'
export class CPackage implements IPackage {
    public PKG_ID:string = '';
    public PKG_Desc:string = '';
    public PKG_EDI_Qual:string = '';
    public PKG_Cube_Uom:string = '';
    public PKG_Length:number = 0;
    public PKG_Width:number = 0;
    public PKG_Height:number = 0;
    public PKG_Tare_Wt:number = 0;
    public PKG_Tare_Wt_Uom:string = '';
    public PKG_Units_Per_Parent:number = 0;
    public Def_Pack_Level:number = 0;
    public PKG_Returnable:boolean;
    public PKG_Price:number = 0;
    public PKG_Type:number = 0;
    public PKG_AppIdentifier:string = '00';
    public PKG_ExtDigit:number = 0;
    public Label_ID:string = 'DEFAULT';
    public constructor(init?:Partial<CPackage>) { Object.assign(this, init); }
}
export const IPackage_PKG_ID_length = 10;
export const IPackage_PKG_Desc_length = 50;
export const IPackage_PKG_EDI_Qual_length = 10;
export const IPackage_PKG_Cube_Uom_length = 2;
export const IPackage_PKG_Tare_Wt_Uom_length = 2;
export const IPackage_PKG_AppIdentifier_length = 2;
export const IPackage_Label_ID_length = 20;

export const kPackage_PKG_ID="PKG_ID";
export const kPackage_PKG_Desc="PKG_Desc";
export const kPackage_PKG_EDI_Qual="PKG_EDI_Qual";
export const kPackage_PKG_Cube_Uom="PKG_Cube_Uom";
export const kPackage_PKG_Length="PKG_Length";
export const kPackage_PKG_Width="PKG_Width";
export const kPackage_PKG_Height="PKG_Height";
export const kPackage_PKG_Tare_Wt="PKG_Tare_Wt";
export const kPackage_PKG_Tare_Wt_Uom="PKG_Tare_Wt_Uom";
export const kPackage_PKG_Units_Per_Parent="PKG_Units_Per_Parent";
export const kPackage_Def_Pack_Level="Def_Pack_Level";
export const kPackage_PKG_Returnable="PKG_Returnable";
export const kPackage_PKG_Price="PKG_Price";
export const kPackage_PKG_Type="PKG_Type";
export const kPackage_PKG_AppIdentifier="PKG_AppIdentifier";
export const kPackage_PKG_ExtDigit="PKG_ExtDigit";
export const kPackage_Label_ID="Label_ID";

/*
        'Package' : {
            'PKG_ID' : 'PKG_ID',
            'PKG_Desc' : 'PKG_Desc',
            'PKG_EDI_Qual' : 'PKG_EDI_Qual',
            'PKG_Cube_Uom' : 'PKG_Cube_Uom',
            'PKG_Length' : 'PKG_Length',
            'PKG_Width' : 'PKG_Width',
            'PKG_Height' : 'PKG_Height',
            'PKG_Tare_Wt' : 'PKG_Tare_Wt',
            'PKG_Tare_Wt_Uom' : 'PKG_Tare_Wt_Uom',
            'PKG_Units_Per_Parent' : 'PKG_Units_Per_Parent',
            'Def_Pack_Level' : 'Def_Pack_Level',
            'PKG_Returnable' : 'PKG_Returnable',
            'PKG_Price' : 'PKG_Price',
            'PKG_Type' : 'PKG_Type',
            'PKG_AppIdentifier' : 'PKG_AppIdentifier',
            'PKG_ExtDigit' : 'PKG_ExtDigit',
            'Label_ID' : 'Label_ID',
        },
*/

export const Label_PKG_ID = 'Package.PKG_ID';
export const Label_PKG_Desc = 'Package.PKG_Desc';
export const Label_PKG_EDI_Qual = 'Package.PKG_EDI_Qual';
export const Label_PKG_Cube_Uom = 'Package.PKG_Cube_Uom';
export const Label_PKG_Length = 'Package.PKG_Length';
export const Label_PKG_Width = 'Package.PKG_Width';
export const Label_PKG_Height = 'Package.PKG_Height';
export const Label_PKG_Tare_Wt = 'Package.PKG_Tare_Wt';
export const Label_PKG_Tare_Wt_Uom = 'Package.PKG_Tare_Wt_Uom';
export const Label_PKG_Units_Per_Parent = 'Package.PKG_Units_Per_Parent';
export const Label_Def_Pack_Level = 'Package.Def_Pack_Level';
export const Label_PKG_Returnable = 'Package.PKG_Returnable';
export const Label_PKG_Price = 'Package.PKG_Price';
export const Label_PKG_Type = 'Package.PKG_Type';
export const Label_PKG_AppIdentifier = 'Package.PKG_AppIdentifier';
export const Label_PKG_ExtDigit = 'Package.PKG_ExtDigit';
export const Label_Label_ID = 'Package.Label_ID';
