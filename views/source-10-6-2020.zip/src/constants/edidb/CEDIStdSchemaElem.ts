import { IEDIStdSchemaElem } from '../edidb'
export class CEDIStdSchemaElem implements IEDIStdSchemaElem {
    public SSID:string = '';
    public Elem_No:number = 0;
    public Qual_Elem_No:number = 0;
    public Qual_Elem_Value:string = '';
    public Elem_Desc:string = '';
    public Token_Name:string = '';
    public Token_Format:string = '';
    public SSEID:string = '';
    public constructor(init?:Partial<CEDIStdSchemaElem>) { Object.assign(this, init); }
}
export const IEDIStdSchemaElem_Qual_Elem_Value_length = 50;
export const IEDIStdSchemaElem_Elem_Desc_length = 100;
export const IEDIStdSchemaElem_Token_Name_length = 50;
export const IEDIStdSchemaElem_Token_Format_length = 200;

export const kEDIStdSchemaElem_SSID="SSID";
export const kEDIStdSchemaElem_Elem_No="Elem_No";
export const kEDIStdSchemaElem_Qual_Elem_No="Qual_Elem_No";
export const kEDIStdSchemaElem_Qual_Elem_Value="Qual_Elem_Value";
export const kEDIStdSchemaElem_Elem_Desc="Elem_Desc";
export const kEDIStdSchemaElem_Token_Name="Token_Name";
export const kEDIStdSchemaElem_Token_Format="Token_Format";
export const kEDIStdSchemaElem_SSEID="SSEID";

/*
        'EDIStdSchemaElem' : {
            'SSID' : 'SSID',
            'Elem_No' : 'Elem_No',
            'Qual_Elem_No' : 'Qual_Elem_No',
            'Qual_Elem_Value' : 'Qual_Elem_Value',
            'Elem_Desc' : 'Elem_Desc',
            'Token_Name' : 'Token_Name',
            'Token_Format' : 'Token_Format',
            'SSEID' : 'SSEID',        },
*/

export const Label_SSID = 'EDIStdSchemaElem.SSID';
export const Label_Elem_No = 'EDIStdSchemaElem.Elem_No';
export const Label_Qual_Elem_No = 'EDIStdSchemaElem.Qual_Elem_No';
export const Label_Qual_Elem_Value = 'EDIStdSchemaElem.Qual_Elem_Value';
export const Label_Elem_Desc = 'EDIStdSchemaElem.Elem_Desc';
export const Label_Token_Name = 'EDIStdSchemaElem.Token_Name';
export const Label_Token_Format = 'EDIStdSchemaElem.Token_Format';
export const Label_SSEID = 'EDIStdSchemaElem.SSEID';
