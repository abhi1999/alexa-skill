import { IApiAsnView } from '../edidb'
export class CApiAsnView implements IApiAsnView {
    // public rownum:number = 0;
    public Asn_ID:number = 0;
    public Bol_No:string = '';
    public Pro_No:string = '';
    public ShipToPeps:boolean;
    public Ship_Weight:number = 0;
    public Ship_Date:string = '';
    public Del_Date:string = '';
    public Ship_Via_ID:string = '';
    public Asn_Complete:string = '';
    public Exp_Flag:string = '';
    public TP_PartID:string = '';
    public User1:string = '';
    public User2:string = '';
    public Trailer:string = '';
    public Collect:boolean;
    public AckID:string = '';
    public GCN:number = 0;
    public TCN:number = 0;
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public SealNo:string = '';
    public ExportDate:Date;
    public CreatedDate:Date;
    public PackImport:string = '';
    public VPIDFA:number = 0;
    public TP_Name:string = '';
    public NoteText:string = '';
    public constructor(init?:Partial<CApiAsnView>) { Object.assign(this, init); }
}
export const IApiAsnView_Bol_No_length = 30;
export const IApiAsnView_Pro_No_length = 30;
export const IApiAsnView_Ship_Date_length = 8;
export const IApiAsnView_Del_Date_length = 8;
export const IApiAsnView_Ship_Via_ID_length = 30;
export const IApiAsnView_Asn_Complete_length = 1;
export const IApiAsnView_Exp_Flag_length = 1;
export const IApiAsnView_TP_PartID_length = 30;
export const IApiAsnView_User1_length = 50;
export const IApiAsnView_User2_length = 50;
export const IApiAsnView_Trailer_length = 50;
export const IApiAsnView_AckID_length = 1;
export const IApiAsnView_User3_length = 50;
export const IApiAsnView_User4_length = 50;
export const IApiAsnView_User5_length = 50;
export const IApiAsnView_SealNo_length = 200;
export const IApiAsnView_PackImport_length = 1;
export const IApiAsnView_TP_Name_length = 30;
export const IApiAsnView_NoteText_length = 2000;

// export const kApiAsnView_rownum="rownum";
export const kApiAsnView_Asn_ID="Asn_ID";
export const kApiAsnView_Bol_No="Bol_No";
export const kApiAsnView_Pro_No="Pro_No";
export const kApiAsnView_ShipToPeps="ShipToPeps";
export const kApiAsnView_Ship_Weight="Ship_Weight";
export const kApiAsnView_Ship_Date="Ship_Date";
export const kApiAsnView_Del_Date="Del_Date";
export const kApiAsnView_Ship_Via_ID="Ship_Via_ID";
export const kApiAsnView_Asn_Complete="Asn_Complete";
export const kApiAsnView_Exp_Flag="Exp_Flag";
export const kApiAsnView_TP_PartID="TP_PartID";
export const kApiAsnView_User1="User1";
export const kApiAsnView_User2="User2";
export const kApiAsnView_Trailer="Trailer";
export const kApiAsnView_Collect="Collect";
export const kApiAsnView_AckID="AckID";
export const kApiAsnView_GCN="GCN";
export const kApiAsnView_TCN="TCN";
export const kApiAsnView_User3="User3";
export const kApiAsnView_User4="User4";
export const kApiAsnView_User5="User5";
export const kApiAsnView_SealNo="SealNo";
export const kApiAsnView_ExportDate="ExportDate";
export const kApiAsnView_CreatedDate="CreatedDate";
export const kApiAsnView_PackImport="PackImport";
export const kApiAsnView_VPIDFA="VPIDFA";
export const kApiAsnView_TP_Name="TP_Name";
export const kApiAsnView_NoteText="NoteText";

/*
        'ApiAsnView' : {
            'rownum' : 'rownum',
            'Asn_ID' : 'Asn_ID',
            'Bol_No' : 'Bol_No',
            'Pro_No' : 'Pro_No',
            'ShipToPeps' : 'ShipToPeps',
            'Ship_Weight' : 'Ship_Weight',
            'Ship_Date' : 'Ship_Date',
            'Del_Date' : 'Del_Date',
            'Ship_Via_ID' : 'Ship_Via_ID',
            'Asn_Complete' : 'Asn_Complete',
            'Exp_Flag' : 'Exp_Flag',
            'TP_PartID' : 'TP_PartID',
            'User1' : 'User1',
            'User2' : 'User2',
            'Trailer' : 'Trailer',
            'Collect' : 'Collect',
            'AckID' : 'AckID',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'SealNo' : 'SealNo',
            'ExportDate' : 'ExportDate',
            'CreatedDate' : 'CreatedDate',
            'PackImport' : 'PackImport',
            'VPIDFA' : 'VPIDFA',
            'TP_Name' : 'TP_Name',
            'NoteText' : 'NoteText',
        },
*/

// export const Label_rownum = 'ApiAsnView.rownum';
export const Label_Asn_ID = 'ApiAsnView.Asn_ID';
export const Label_Bol_No = 'ApiAsnView.Bol_No';
export const Label_Pro_No = 'ApiAsnView.Pro_No';
export const Label_ShipToPeps = 'ApiAsnView.ShipToPeps';
export const Label_Ship_Weight = 'ApiAsnView.Ship_Weight';
export const Label_Ship_Date = 'ApiAsnView.Ship_Date';
export const Label_Del_Date = 'ApiAsnView.Del_Date';
export const Label_Ship_Via_ID = 'ApiAsnView.Ship_Via_ID';
export const Label_Asn_Complete = 'ApiAsnView.Asn_Complete';
export const Label_Exp_Flag = 'ApiAsnView.Exp_Flag';
export const Label_TP_PartID = 'ApiAsnView.TP_PartID';
export const Label_User1 = 'ApiAsnView.User1';
export const Label_User2 = 'ApiAsnView.User2';
export const Label_Trailer = 'ApiAsnView.Trailer';
export const Label_Collect = 'ApiAsnView.Collect';
export const Label_AckID = 'ApiAsnView.AckID';
export const Label_GCN = 'ApiAsnView.GCN';
export const Label_TCN = 'ApiAsnView.TCN';
export const Label_User3 = 'ApiAsnView.User3';
export const Label_User4 = 'ApiAsnView.User4';
export const Label_User5 = 'ApiAsnView.User5';
export const Label_SealNo = 'ApiAsnView.SealNo';
export const Label_ExportDate = 'ApiAsnView.ExportDate';
export const Label_CreatedDate = 'ApiAsnView.CreatedDate';
export const Label_PackImport = 'ApiAsnView.PackImport';
export const Label_VPIDFA = 'ApiAsnView.VPIDFA';
export const Label_TP_Name = 'ApiAsnView.TP_Name';
export const Label_NoteText = 'ApiAsnView.NoteText';
