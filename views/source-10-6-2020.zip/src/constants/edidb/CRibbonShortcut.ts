import { IRibbonShortcut } from '../edidb'
export class CRibbonShortcut implements IRibbonShortcut {
    public ShortCutID:number = 0;
    public TabID:number = 0;
    public ShortcutOrder:number = 0;
    public Caption:string = '';
    public ImageFile:string = '';
    public Visible:boolean;
    public Enabled:boolean;
    public constructor(init?:Partial<CRibbonShortcut>) { Object.assign(this, init); }
}
export const IRibbonShortcut_Caption_length = 200;
export const IRibbonShortcut_ImageFile_length = 500;

export const kRibbonShortcut_ShortCutID="ShortCutID";
export const kRibbonShortcut_TabID="TabID";
export const kRibbonShortcut_ShortcutOrder="ShortcutOrder";
export const kRibbonShortcut_Caption="Caption";
export const kRibbonShortcut_ImageFile="ImageFile";
export const kRibbonShortcut_Visible="Visible";
export const kRibbonShortcut_Enabled="Enabled";

/*
        'RibbonShortcut' : {
            'ShortCutID' : 'ShortCutID',
            'TabID' : 'TabID',
            'ShortcutOrder' : 'ShortcutOrder',
            'Caption' : 'Caption',
            'ImageFile' : 'ImageFile',
            'Visible' : 'Visible',
            'Enabled' : 'Enabled',        },
*/

export const Label_ShortCutID = 'RibbonShortcut.ShortCutID';
export const Label_TabID = 'RibbonShortcut.TabID';
export const Label_ShortcutOrder = 'RibbonShortcut.ShortcutOrder';
export const Label_Caption = 'RibbonShortcut.Caption';
export const Label_ImageFile = 'RibbonShortcut.ImageFile';
export const Label_Visible = 'RibbonShortcut.Visible';
export const Label_Enabled = 'RibbonShortcut.Enabled';
