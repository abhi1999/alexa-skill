import { IDocLoadConfig } from '../edidb'
export class CDocLoadConfig implements IDocLoadConfig {
    public DLID:string = '';
    public DGID:string = '';
    public DocType:string = '';
    public TP_PartID:string = '';
    public ProcessFlag:number = 0;
    public constructor(init?:Partial<CDocLoadConfig>) { Object.assign(this, init); }
}
export const IDocLoadConfig_DGID_length = 5;
export const IDocLoadConfig_DocType_length = 10;
export const IDocLoadConfig_TP_PartID_length = 30;

export const kDocLoadConfig_DLID="DLID";
export const kDocLoadConfig_DGID="DGID";
export const kDocLoadConfig_DocType="DocType";
export const kDocLoadConfig_TP_PartID="TP_PartID";
export const kDocLoadConfig_ProcessFlag="ProcessFlag";

/*
        'DocLoadConfig' : {
            'DLID' : 'DLID',
            'DGID' : 'DGID',
            'DocType' : 'DocType',
            'TP_PartID' : 'TP_PartID',
            'ProcessFlag' : 'ProcessFlag',        },
*/

export const Label_DLID = 'DocLoadConfig.DLID';
export const Label_DGID = 'DocLoadConfig.DGID';
export const Label_DocType = 'DocLoadConfig.DocType';
export const Label_TP_PartID = 'DocLoadConfig.TP_PartID';
export const Label_ProcessFlag = 'DocLoadConfig.ProcessFlag';
