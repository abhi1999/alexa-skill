import { IProductActivity } from '../edidb'
export class CProductActivity implements IProductActivity {
    public ProductActID:number = 0;
    public EdiID:string = '';
    public RptFromCompany:string = '';
    public RptFromIDCode:string = '';
    public RptFromStoreName:string = '';
    public RptFromAddress1:string = '';
    public RptFromAddress2:string = '';
    public RptFromCity:string = '';
    public RptFromState:string = '';
    public RptFromZip:string = '';
    public RptFromCountry:string = '';
    public DestIDCode:string = '';
    public DestCompany:string = '';
    public DestStoreName:string = '';
    public DestAddress1:string = '';
    public DestAddress2:string = '';
    public DestCity:string = '';
    public DestState:string = '';
    public DestZip:string = '';
    public DestCountry:string = '';
    public StartDate:Date;
    public EndDate:Date;
    public ItemQual:string = '';
    public TPItemNumber:string = '';
    public ItemNumber:string = '';
    public ItemDesc:string = '';
    public ActivityCode:string = '';
    public ActivityDesc:string = '';
    public Uom:string = '';
    public AccountingUOM:string = '';
    public Qty:number = 0;
    public Factor:number = 0;
    public NetQty:number = 0;
    public UnitCostPrice:number = 0;
    public constructor(init?:Partial<CProductActivity>) { Object.assign(this, init); }
}
export const IProductActivity_EdiID_length = 30;
export const IProductActivity_RptFromCompany_length = 80;
export const IProductActivity_RptFromIDCode_length = 30;
export const IProductActivity_RptFromStoreName_length = 50;
export const IProductActivity_RptFromAddress1_length = 80;
export const IProductActivity_RptFromAddress2_length = 80;
export const IProductActivity_RptFromCity_length = 40;
export const IProductActivity_RptFromState_length = 20;
export const IProductActivity_RptFromZip_length = 15;
export const IProductActivity_RptFromCountry_length = 30;
export const IProductActivity_DestIDCode_length = 30;
export const IProductActivity_DestCompany_length = 80;
export const IProductActivity_DestStoreName_length = 50;
export const IProductActivity_DestAddress1_length = 80;
export const IProductActivity_DestAddress2_length = 80;
export const IProductActivity_DestCity_length = 40;
export const IProductActivity_DestState_length = 20;
export const IProductActivity_DestZip_length = 15;
export const IProductActivity_DestCountry_length = 30;
export const IProductActivity_ItemQual_length = 2;
export const IProductActivity_TPItemNumber_length = 500;
export const IProductActivity_ItemNumber_length = 500;
export const IProductActivity_ItemDesc_length = 80;
export const IProductActivity_ActivityCode_length = 3;
export const IProductActivity_ActivityDesc_length = 40;
export const IProductActivity_Uom_length = 4;
export const IProductActivity_AccountingUOM_length = 10;

export const kProductActivity_ProductActID="ProductActID";
export const kProductActivity_EdiID="EdiID";
export const kProductActivity_RptFromCompany="RptFromCompany";
export const kProductActivity_RptFromIDCode="RptFromIDCode";
export const kProductActivity_RptFromStoreName="RptFromStoreName";
export const kProductActivity_RptFromAddress1="RptFromAddress1";
export const kProductActivity_RptFromAddress2="RptFromAddress2";
export const kProductActivity_RptFromCity="RptFromCity";
export const kProductActivity_RptFromState="RptFromState";
export const kProductActivity_RptFromZip="RptFromZip";
export const kProductActivity_RptFromCountry="RptFromCountry";
export const kProductActivity_DestIDCode="DestIDCode";
export const kProductActivity_DestCompany="DestCompany";
export const kProductActivity_DestStoreName="DestStoreName";
export const kProductActivity_DestAddress1="DestAddress1";
export const kProductActivity_DestAddress2="DestAddress2";
export const kProductActivity_DestCity="DestCity";
export const kProductActivity_DestState="DestState";
export const kProductActivity_DestZip="DestZip";
export const kProductActivity_DestCountry="DestCountry";
export const kProductActivity_StartDate="StartDate";
export const kProductActivity_EndDate="EndDate";
export const kProductActivity_ItemQual="ItemQual";
export const kProductActivity_TPItemNumber="TPItemNumber";
export const kProductActivity_ItemNumber="ItemNumber";
export const kProductActivity_ItemDesc="ItemDesc";
export const kProductActivity_ActivityCode="ActivityCode";
export const kProductActivity_ActivityDesc="ActivityDesc";
export const kProductActivity_Uom="Uom";
export const kProductActivity_AccountingUOM="AccountingUOM";
export const kProductActivity_Qty="Qty";
export const kProductActivity_Factor="Factor";
export const kProductActivity_NetQty="NetQty";
export const kProductActivity_UnitCostPrice="UnitCostPrice";

/*
        'ProductActivity' : {
            'ProductActID' : 'ProductActID',
            'EdiID' : 'EdiID',
            'RptFromCompany' : 'RptFromCompany',
            'RptFromIDCode' : 'RptFromIDCode',
            'RptFromStoreName' : 'RptFromStoreName',
            'RptFromAddress1' : 'RptFromAddress1',
            'RptFromAddress2' : 'RptFromAddress2',
            'RptFromCity' : 'RptFromCity',
            'RptFromState' : 'RptFromState',
            'RptFromZip' : 'RptFromZip',
            'RptFromCountry' : 'RptFromCountry',
            'DestIDCode' : 'DestIDCode',
            'DestCompany' : 'DestCompany',
            'DestStoreName' : 'DestStoreName',
            'DestAddress1' : 'DestAddress1',
            'DestAddress2' : 'DestAddress2',
            'DestCity' : 'DestCity',
            'DestState' : 'DestState',
            'DestZip' : 'DestZip',
            'DestCountry' : 'DestCountry',
            'StartDate' : 'StartDate',
            'EndDate' : 'EndDate',
            'ItemQual' : 'ItemQual',
            'TPItemNumber' : 'TPItemNumber',
            'ItemNumber' : 'ItemNumber',
            'ItemDesc' : 'ItemDesc',
            'ActivityCode' : 'ActivityCode',
            'ActivityDesc' : 'ActivityDesc',
            'Uom' : 'Uom',
            'AccountingUOM' : 'AccountingUOM',
            'Qty' : 'Qty',
            'Factor' : 'Factor',
            'NetQty' : 'NetQty',
            'UnitCostPrice' : 'UnitCostPrice',        },
*/

export const Label_ProductActID = 'ProductActivity.ProductActID';
export const Label_EdiID = 'ProductActivity.EdiID';
export const Label_RptFromCompany = 'ProductActivity.RptFromCompany';
export const Label_RptFromIDCode = 'ProductActivity.RptFromIDCode';
export const Label_RptFromStoreName = 'ProductActivity.RptFromStoreName';
export const Label_RptFromAddress1 = 'ProductActivity.RptFromAddress1';
export const Label_RptFromAddress2 = 'ProductActivity.RptFromAddress2';
export const Label_RptFromCity = 'ProductActivity.RptFromCity';
export const Label_RptFromState = 'ProductActivity.RptFromState';
export const Label_RptFromZip = 'ProductActivity.RptFromZip';
export const Label_RptFromCountry = 'ProductActivity.RptFromCountry';
export const Label_DestIDCode = 'ProductActivity.DestIDCode';
export const Label_DestCompany = 'ProductActivity.DestCompany';
export const Label_DestStoreName = 'ProductActivity.DestStoreName';
export const Label_DestAddress1 = 'ProductActivity.DestAddress1';
export const Label_DestAddress2 = 'ProductActivity.DestAddress2';
export const Label_DestCity = 'ProductActivity.DestCity';
export const Label_DestState = 'ProductActivity.DestState';
export const Label_DestZip = 'ProductActivity.DestZip';
export const Label_DestCountry = 'ProductActivity.DestCountry';
export const Label_StartDate = 'ProductActivity.StartDate';
export const Label_EndDate = 'ProductActivity.EndDate';
export const Label_ItemQual = 'ProductActivity.ItemQual';
export const Label_TPItemNumber = 'ProductActivity.TPItemNumber';
export const Label_ItemNumber = 'ProductActivity.ItemNumber';
export const Label_ItemDesc = 'ProductActivity.ItemDesc';
export const Label_ActivityCode = 'ProductActivity.ActivityCode';
export const Label_ActivityDesc = 'ProductActivity.ActivityDesc';
export const Label_Uom = 'ProductActivity.Uom';
export const Label_AccountingUOM = 'ProductActivity.AccountingUOM';
export const Label_Qty = 'ProductActivity.Qty';
export const Label_Factor = 'ProductActivity.Factor';
export const Label_NetQty = 'ProductActivity.NetQty';
export const Label_UnitCostPrice = 'ProductActivity.UnitCostPrice';
