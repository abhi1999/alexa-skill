import { IDocStaging } from '../edidb'
export class CDocStaging implements IDocStaging {
    public DGID:string = '';
    public direction:string = '';
    public docno:string = '';
    public docnoint:number = 0;
    public recid:number = 0;
    public docdate:Date;
    public acctno:string = '';
    public acctname:string = '';
    public docamount:number = 0;
    public docref1:string = '';
    public docref2:string = '';
    public docref3:string = '';
    public docref4:string = '';
    public docref5:string = '';
    public exclude:boolean;
    public DSID:number = 0;
    public constructor(init?:Partial<CDocStaging>) { Object.assign(this, init); }
}
export const IDocStaging_DGID_length = 5;
export const IDocStaging_direction_length = 1;
export const IDocStaging_docno_length = 80;
export const IDocStaging_acctno_length = 80;
export const IDocStaging_acctname_length = 80;
export const IDocStaging_docref1_length = 80;
export const IDocStaging_docref2_length = 80;
export const IDocStaging_docref3_length = 80;
export const IDocStaging_docref4_length = 80;
export const IDocStaging_docref5_length = 80;

export const kDocStaging_DGID="DGID";
export const kDocStaging_direction="direction";
export const kDocStaging_docno="docno";
export const kDocStaging_docnoint="docnoint";
export const kDocStaging_recid="recid";
export const kDocStaging_docdate="docdate";
export const kDocStaging_acctno="acctno";
export const kDocStaging_acctname="acctname";
export const kDocStaging_docamount="docamount";
export const kDocStaging_docref1="docref1";
export const kDocStaging_docref2="docref2";
export const kDocStaging_docref3="docref3";
export const kDocStaging_docref4="docref4";
export const kDocStaging_docref5="docref5";
export const kDocStaging_exclude="exclude";
export const kDocStaging_DSID="DSID";

/*
        'DocStaging' : {
            'DGID' : 'DGID',
            'direction' : 'direction',
            'docno' : 'docno',
            'docnoint' : 'docnoint',
            'recid' : 'recid',
            'docdate' : 'docdate',
            'acctno' : 'acctno',
            'acctname' : 'acctname',
            'docamount' : 'docamount',
            'docref1' : 'docref1',
            'docref2' : 'docref2',
            'docref3' : 'docref3',
            'docref4' : 'docref4',
            'docref5' : 'docref5',
            'exclude' : 'exclude',
            'DSID' : 'DSID',        },
*/

export const Label_DGID = 'DocStaging.DGID';
export const Label_direction = 'DocStaging.direction';
export const Label_docno = 'DocStaging.docno';
export const Label_docnoint = 'DocStaging.docnoint';
export const Label_recid = 'DocStaging.recid';
export const Label_docdate = 'DocStaging.docdate';
export const Label_acctno = 'DocStaging.acctno';
export const Label_acctname = 'DocStaging.acctname';
export const Label_docamount = 'DocStaging.docamount';
export const Label_docref1 = 'DocStaging.docref1';
export const Label_docref2 = 'DocStaging.docref2';
export const Label_docref3 = 'DocStaging.docref3';
export const Label_docref4 = 'DocStaging.docref4';
export const Label_docref5 = 'DocStaging.docref5';
export const Label_exclude = 'DocStaging.exclude';
export const Label_DSID = 'DocStaging.DSID';
