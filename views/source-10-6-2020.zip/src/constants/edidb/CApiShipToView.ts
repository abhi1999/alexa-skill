import { IApiShipToView } from '../edidb'
export class CApiShipToView implements IApiShipToView {
    public TP_PartID: string = '';
    public ShipTo_ID: string = '';
    public TP_Name?: string = undefined;
    public TP_ID?: string = undefined;
    public ShipTo_Xref?: string = undefined;
    public ShipTo_Name?: string = undefined;
    public ShipTo_Address?: string = undefined;
    public ShipTo_Address2?: string = undefined;
    public ShipTo_City?: string = undefined;
    public ShipTo_State?: string = undefined;
    public ShipTo_Zip?: string = undefined;
    public ShipTo_Country?: string = undefined;
    public ShipTo_CustID?: string = undefined;
    public ShipTo_DC?: string = undefined;
    public ShipTo_ShipDateQual?: string = undefined;
    public ShipTo_StoreName?: string = undefined;
    public ShipTo_Carrier?: string = undefined;
    public User1?: string = undefined;
    public User2?: string = undefined;
    public User3?: string = undefined;
    public User4?: string = undefined;
    public User5?: string = undefined;
    public ShipTo_rfid: boolean;
    public ShipTo_GroupID?: string = undefined;
    public TransitDays: number = 0;
    public FrozenDays: number = 0;
    public ShipDlvPattern?: string = undefined;
    public Loc_Override?: string = undefined;
    public constructor(init?: Partial<CApiShipToView>) { Object.assign(this, init); }
}
export const IApiShipToView_TP_PartID_length = 30;
export const IApiShipToView_ShipTo_ID_length = 80;
export const IApiShipToView_TP_Name_length = 30;
export const IApiShipToView_TP_ID_length = 100;
export const IApiShipToView_ShipTo_Xref_length = 30;
export const IApiShipToView_ShipTo_Name_length = 80;
export const IApiShipToView_ShipTo_Address_length = 80;
export const IApiShipToView_ShipTo_Address2_length = 80;
export const IApiShipToView_ShipTo_City_length = 40;
export const IApiShipToView_ShipTo_State_length = 20;
export const IApiShipToView_ShipTo_Zip_length = 15;
export const IApiShipToView_ShipTo_Country_length = 30;
export const IApiShipToView_ShipTo_CustID_length = 30;
export const IApiShipToView_ShipTo_DC_length = 30;
export const IApiShipToView_ShipTo_ShipDateQual_length = 3;
export const IApiShipToView_ShipTo_StoreName_length = 50;
export const IApiShipToView_ShipTo_Carrier_length = 30;
export const IApiShipToView_User1_length = 50;
export const IApiShipToView_User2_length = 50;
export const IApiShipToView_User3_length = 50;
export const IApiShipToView_User4_length = 50;
export const IApiShipToView_User5_length = 50;
export const IApiShipToView_ShipTo_GroupID_length = 30;
export const IApiShipToView_ShipDlvPattern_length = 20;
export const IApiShipToView_Loc_Override_length = 20;

export const kApiShipToView_TP_PartID = "TP_PartID";
export const kApiShipToView_ShipTo_ID = "ShipTo_ID";
export const kApiShipToView_TP_Name = "TP_Name";
export const kApiShipToView_TP_ID = "TP_ID";
export const kApiShipToView_ShipTo_Xref = "ShipTo_Xref";
export const kApiShipToView_ShipTo_Name = "ShipTo_Name";
export const kApiShipToView_ShipTo_Address = "ShipTo_Address";
export const kApiShipToView_ShipTo_Address2 = "ShipTo_Address2";
export const kApiShipToView_ShipTo_City = "ShipTo_City";
export const kApiShipToView_ShipTo_State = "ShipTo_State";
export const kApiShipToView_ShipTo_Zip = "ShipTo_Zip";
export const kApiShipToView_ShipTo_Country = "ShipTo_Country";
export const kApiShipToView_ShipTo_CustID = "ShipTo_CustID";
export const kApiShipToView_ShipTo_DC = "ShipTo_DC";
export const kApiShipToView_ShipTo_ShipDateQual = "ShipTo_ShipDateQual";
export const kApiShipToView_ShipTo_StoreName = "ShipTo_StoreName";
export const kApiShipToView_ShipTo_Carrier = "ShipTo_Carrier";
export const kApiShipToView_User1 = "User1";
export const kApiShipToView_User2 = "User2";
export const kApiShipToView_User3 = "User3";
export const kApiShipToView_User4 = "User4";
export const kApiShipToView_User5 = "User5";
export const kApiShipToView_ShipTo_rfid = "ShipTo_rfid";
export const kApiShipToView_ShipTo_GroupID = "ShipTo_GroupID";
export const kApiShipToView_TransitDays = "TransitDays";
export const kApiShipToView_FrozenDays = "FrozenDays";
export const kApiShipToView_ShipDlvPattern = "ShipDlvPattern";
export const kApiShipToView_Loc_Override = "Loc_Override";

/*
        'ApiShipToView' : {
            'TP_PartID' : 'TP_PartID',
            'ShipTo_ID' : 'ShipTo_ID',
            'TP_Name' : 'TP_Name',
            'ShipTo_Xref' : 'ShipTo_Xref',
            'ShipTo_Name' : 'ShipTo_Name',
            'ShipTo_Address' : 'ShipTo_Address',
            'ShipTo_Address2' : 'ShipTo_Address2',
            'ShipTo_City' : 'ShipTo_City',
            'ShipTo_State' : 'ShipTo_State',
            'ShipTo_Zip' : 'ShipTo_Zip',
            'ShipTo_Country' : 'ShipTo_Country',
            'ShipTo_CustID' : 'ShipTo_CustID',
            'ShipTo_DC' : 'ShipTo_DC',
            'ShipTo_ShipDateQual' : 'ShipTo_ShipDateQual',
            'ShipTo_StoreName' : 'ShipTo_StoreName',
            'ShipTo_Carrier' : 'ShipTo_Carrier',
            'User1' : 'User1',
            'User2' : 'User2',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'ShipTo_rfid' : 'ShipTo_rfid',
            'ShipTo_GroupID' : 'ShipTo_GroupID',
            'TransitDays' : 'TransitDays',
            'FrozenDays' : 'FrozenDays',
            'ShipDlvPattern' : 'ShipDlvPattern',
            'Loc_Override' : 'Loc_Override',
        },
*/

export const Label_TP_PartID = 'ApiShipToView.TP_PartID';
export const Label_ShipTo_ID = 'ApiShipToView.ShipTo_ID';
export const Label_TP_Name = 'ApiShipToView.TP_Name';
export const Label_TP_ID = 'ApiShipToView.TP_ID';
export const Label_ShipTo_Xref = 'ApiShipToView.ShipTo_Xref';
export const Label_ShipTo_Name = 'ApiShipToView.ShipTo_Name';
export const Label_ShipTo_Address = 'ApiShipToView.ShipTo_Address';
export const Label_ShipTo_Address2 = 'ApiShipToView.ShipTo_Address2';
export const Label_ShipTo_City = 'ApiShipToView.ShipTo_City';
export const Label_ShipTo_State = 'ApiShipToView.ShipTo_State';
export const Label_ShipTo_Zip = 'ApiShipToView.ShipTo_Zip';
export const Label_ShipTo_Country = 'ApiShipToView.ShipTo_Country';
export const Label_ShipTo_CustID = 'ApiShipToView.ShipTo_CustID';
export const Label_ShipTo_DC = 'ApiShipToView.ShipTo_DC';
export const Label_ShipTo_ShipDateQual = 'ApiShipToView.ShipTo_ShipDateQual';
export const Label_ShipTo_StoreName = 'ApiShipToView.ShipTo_StoreName';
export const Label_ShipTo_Carrier = 'ApiShipToView.ShipTo_Carrier';
export const Label_User1 = 'ApiShipToView.User1';
export const Label_User2 = 'ApiShipToView.User2';
export const Label_User3 = 'ApiShipToView.User3';
export const Label_User4 = 'ApiShipToView.User4';
export const Label_User5 = 'ApiShipToView.User5';
export const Label_ShipTo_rfid = 'ApiShipToView.ShipTo_rfid';
export const Label_ShipTo_GroupID = 'ApiShipToView.ShipTo_GroupID';
export const Label_TransitDays = 'ApiShipToView.TransitDays';
export const Label_FrozenDays = 'ApiShipToView.FrozenDays';
export const Label_ShipDlvPattern = 'ApiShipToView.ShipDlvPattern';
export const Label_Loc_Override = 'ApiShipToView.Loc_Override';
