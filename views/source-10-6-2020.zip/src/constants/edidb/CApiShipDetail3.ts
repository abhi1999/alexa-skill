import { IApiShipDetail3 } from '../edidb'
export class CApiShipDetail3 implements IApiShipDetail3 {
    public Loc_ID:string = '';
    public ShipFr_Name:string = '';
    public ShipFr_Addr1:string = '';
    public ShipFr_Add2:string = '';
    public ShipFr_City:string = '';
    public ShipFr_St:string = '';
    public ShipFr_Zip:string = '';
    public ShipFr_Country:string = '';
    public Cust_PO:string = '';
    public ShipTo_Xref:string = '';
    public Source:string = '';
    public constructor(init?:Partial<CApiShipDetail3>) { Object.assign(this, init); }
}
export const IApiShipDetail3_Loc_ID_length = 20;
export const IApiShipDetail3_ShipFr_Name_length = 50;
export const IApiShipDetail3_ShipFr_Addr1_length = 50;
export const IApiShipDetail3_ShipFr_Add2_length = 50;
export const IApiShipDetail3_ShipFr_City_length = 30;
export const IApiShipDetail3_ShipFr_St_length = 20;
export const IApiShipDetail3_ShipFr_Zip_length = 20;
export const IApiShipDetail3_ShipFr_Country_length = 30;
export const IApiShipDetail3_Cust_PO_length = 30;
export const IApiShipDetail3_ShipTo_Xref_length = 30;
export const IApiShipDetail3_Source_length = 13;

export const kApiShipDetail3_Loc_ID="Loc_ID";
export const kApiShipDetail3_ShipFr_Name="ShipFr_Name";
export const kApiShipDetail3_ShipFr_Addr1="ShipFr_Addr1";
export const kApiShipDetail3_ShipFr_Add2="ShipFr_Add2";
export const kApiShipDetail3_ShipFr_City="ShipFr_City";
export const kApiShipDetail3_ShipFr_St="ShipFr_St";
export const kApiShipDetail3_ShipFr_Zip="ShipFr_Zip";
export const kApiShipDetail3_ShipFr_Country="ShipFr_Country";
export const kApiShipDetail3_Cust_PO="Cust_PO";
export const kApiShipDetail3_ShipTo_Xref="ShipTo_Xref";
export const kApiShipDetail3_Source="Source";

/*
        'ApiShipDetail3' : {
            'Loc_ID' : 'Loc_ID',
            'ShipFr_Name' : 'ShipFr_Name',
            'ShipFr_Addr1' : 'ShipFr_Addr1',
            'ShipFr_Add2' : 'ShipFr_Add2',
            'ShipFr_City' : 'ShipFr_City',
            'ShipFr_St' : 'ShipFr_St',
            'ShipFr_Zip' : 'ShipFr_Zip',
            'ShipFr_Country' : 'ShipFr_Country',
            'Cust_PO' : 'Cust_PO',
            'ShipTo_Xref' : 'ShipTo_Xref',
            'Source' : 'Source',        },
*/

export const Label_Loc_ID = 'ApiShipDetail3.Loc_ID';
export const Label_ShipFr_Name = 'ApiShipDetail3.ShipFr_Name';
export const Label_ShipFr_Addr1 = 'ApiShipDetail3.ShipFr_Addr1';
export const Label_ShipFr_Add2 = 'ApiShipDetail3.ShipFr_Add2';
export const Label_ShipFr_City = 'ApiShipDetail3.ShipFr_City';
export const Label_ShipFr_St = 'ApiShipDetail3.ShipFr_St';
export const Label_ShipFr_Zip = 'ApiShipDetail3.ShipFr_Zip';
export const Label_ShipFr_Country = 'ApiShipDetail3.ShipFr_Country';
export const Label_Cust_PO = 'ApiShipDetail3.Cust_PO';
export const Label_ShipTo_Xref = 'ApiShipDetail3.ShipTo_Xref';
export const Label_Source = 'ApiShipDetail3.Source';
