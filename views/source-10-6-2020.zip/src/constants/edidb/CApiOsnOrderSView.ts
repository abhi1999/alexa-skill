import { IApiOsnOrderSView } from '../edidb'
export class CApiOsnOrderSView implements IApiOsnOrderSView {
    public Asn_ID:number = 0;
    public Order_No:number = 0;
    public Line_No:number = 0;
    public Pack_ID:number = 0;
    public Pack_Level:number = 0;
    public Qty:number = 0;
    public SerLot_No:string = '';
    public Box_ID:number = 0;
    public MfgDate:Date;
    public ExpDate:Date;
    public UserDate1:Date;
    public UserDate2:Date;
    public User1:string = '';
    public User2:string = '';
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public constructor(init?:Partial<CApiOsnOrderSView>) { Object.assign(this, init); }
}
export const IApiOsnOrderSView_SerLot_No_length = 80;
export const IApiOsnOrderSView_User1_length = 50;
export const IApiOsnOrderSView_User2_length = 50;
export const IApiOsnOrderSView_User3_length = 50;
export const IApiOsnOrderSView_User4_length = 50;
export const IApiOsnOrderSView_User5_length = 50;

export const kApiOsnOrderSView_Asn_ID="Asn_ID";
export const kApiOsnOrderSView_Order_No="Order_No";
export const kApiOsnOrderSView_Line_No="Line_No";
export const kApiOsnOrderSView_Pack_ID="Pack_ID";
export const kApiOsnOrderSView_Pack_Level="Pack_Level";
export const kApiOsnOrderSView_Qty="Qty";
export const kApiOsnOrderSView_SerLot_No="SerLot_No";
export const kApiOsnOrderSView_Box_ID="Box_ID";
export const kApiOsnOrderSView_MfgDate="MfgDate";
export const kApiOsnOrderSView_ExpDate="ExpDate";
export const kApiOsnOrderSView_UserDate1="UserDate1";
export const kApiOsnOrderSView_UserDate2="UserDate2";
export const kApiOsnOrderSView_User1="User1";
export const kApiOsnOrderSView_User2="User2";
export const kApiOsnOrderSView_User3="User3";
export const kApiOsnOrderSView_User4="User4";
export const kApiOsnOrderSView_User5="User5";

/*
        'ApiOsnOrderSView' : {
            'Asn_ID' : 'Asn_ID',
            'Order_No' : 'Order_No',
            'Line_No' : 'Line_No',
            'Pack_ID' : 'Pack_ID',
            'Pack_Level' : 'Pack_Level',
            'Qty' : 'Qty',
            'SerLot_No' : 'SerLot_No',
            'Box_ID' : 'Box_ID',
            'MfgDate' : 'MfgDate',
            'ExpDate' : 'ExpDate',
            'UserDate1' : 'UserDate1',
            'UserDate2' : 'UserDate2',
            'User1' : 'User1',
            'User2' : 'User2',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',        },
*/

export const Label_Asn_ID = 'ApiOsnOrderSView.Asn_ID';
export const Label_Order_No = 'ApiOsnOrderSView.Order_No';
export const Label_Line_No = 'ApiOsnOrderSView.Line_No';
export const Label_Pack_ID = 'ApiOsnOrderSView.Pack_ID';
export const Label_Pack_Level = 'ApiOsnOrderSView.Pack_Level';
export const Label_Qty = 'ApiOsnOrderSView.Qty';
export const Label_SerLot_No = 'ApiOsnOrderSView.SerLot_No';
export const Label_Box_ID = 'ApiOsnOrderSView.Box_ID';
export const Label_MfgDate = 'ApiOsnOrderSView.MfgDate';
export const Label_ExpDate = 'ApiOsnOrderSView.ExpDate';
export const Label_UserDate1 = 'ApiOsnOrderSView.UserDate1';
export const Label_UserDate2 = 'ApiOsnOrderSView.UserDate2';
export const Label_User1 = 'ApiOsnOrderSView.User1';
export const Label_User2 = 'ApiOsnOrderSView.User2';
export const Label_User3 = 'ApiOsnOrderSView.User3';
export const Label_User4 = 'ApiOsnOrderSView.User4';
export const Label_User5 = 'ApiOsnOrderSView.User5';
