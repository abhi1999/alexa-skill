import { IAppRoleMap } from '../edidb'
export class CAppRoleMap implements IAppRoleMap {
    public id:number = 0;
    public roleID:number = 0;
    public loginID:number = 0;
    public constructor(init?:Partial<CAppRoleMap>) { Object.assign(this, init); }
}
export const kAppRoleMap_id="id";
export const kAppRoleMap_roleID="roleID";
export const kAppRoleMap_loginID="loginID";

/*
        'AppRoleMap' : {
            'id' : 'id',
            'roleID' : 'roleID',
            'loginID' : 'loginID',        },
*/

export const Label_id = 'AppRoleMap.id';
export const Label_roleID = 'AppRoleMap.roleID';
export const Label_loginID = 'AppRoleMap.loginID';
