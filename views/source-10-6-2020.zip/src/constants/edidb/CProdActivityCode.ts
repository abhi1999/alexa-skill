import { IProdActivityCode } from '../edidb'
export class CProdActivityCode implements IProdActivityCode {
    public ZA01:string = '';
    public ZADesc:string = '';
    public constructor(init?:Partial<CProdActivityCode>) { Object.assign(this, init); }
}
export const IProdActivityCode_ZA01_length = 3;
export const IProdActivityCode_ZADesc_length = 40;

export const kProdActivityCode_ZA01="ZA01";
export const kProdActivityCode_ZADesc="ZADesc";

/*
        'ProdActivityCode' : {
            'ZA01' : 'ZA01',
            'ZADesc' : 'ZADesc',        },
*/

export const Label_ZA01 = 'ProdActivityCode.ZA01';
export const Label_ZADesc = 'ProdActivityCode.ZADesc';
