import { IAuditViewer } from '../edidb'
export class CAuditViewer implements IAuditViewer {
  
  public AuditID:number = 0;
  public Type:string = '';
  public TableName:string = '';
  public PK:string = '';
  public DataType:string = '';
  public DataKey:string = '';
  
  public UpdateDate: string = '';
  public UserName: string = '';

  public Approved: boolean = false;
  public ApprovedBy: string = '';
  public ApprovedDate: string = '';

  public constructor(init?:Partial<CAuditViewer>) { Object.assign(this, init); }
}

export const IAuditViewer_AuditID_length = 30;
export const IAuditViewer_Type_length = 1;
export const IAuditViewer_TableName_length = 50;
export const IAuditViewer_PK_length = 30;
export const IAuditViewer_DataType = 30;
export const IAuditViewer_DataKey = 30;
export const IAuditViewer_UpdateDate_length = 8;
export const IAuditViewer_UserName_length = 50;

export const IAuditViewer_Approved_length = 5;
export const IAuditViewer_ApprovedBy_length = 100;
export const IAuditViewer_ApprovedDate_length = 8;

export const kAuditViewer_AuditID = 'AuditID';
export const kAuditViewer_Type = 'Type';
export const kAuditViewer_TableName = 'TableName';
export const kAuditViewer_PK = 'PK';
export const kAuditViewer_DataType = 'DataType';
export const kAuditViewer_DataKey = 'DataKey';
export const kAuditViewer_UpdateDate = 'UpdateDate'
export const kAuditViewer_UserName = 'UserName'

export const kAuditViewer_Approved = 'Approved'
export const kAuditViewer_ApprovedBy = 'ApprovedBy'
export const kAuditViewer_ApprovedDate = 'ApprovedDate'

export const Label_AuditID = 'AuditViewer.AuditID';
export const Label_Type = 'AuditViewer.Type';
export const Label_TableName = 'AuditViewer.TableName';
export const Label_PK = 'AuditViewer.PK';
export const Label_DataType = 'AuditViewer.DataType';
export const Label_DataKey = 'AuditViewer.DataKey';
export const Label_UpdateDate = 'AuditViewer.UpdateDate';
export const Label_UserName = 'AuditViewer.UserName';

export const Label_Approved = 'AuditViewer.Approved';
export const Label_ApprovedBy = 'AuditViewer.ApprovedBy';
export const Label_ApprovedDate = 'AuditViewer.ApprovedDate';
