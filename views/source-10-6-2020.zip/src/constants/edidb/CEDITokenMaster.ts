import { IEDITokenMaster } from '../edidb'
export class CEDITokenMaster implements IEDITokenMaster {
    public TID:string = '';
    public Token_Name:string = '';
    public Seq_No:number = 0;
    public Pkey:string = '';
    public constructor(init?:Partial<CEDITokenMaster>) { Object.assign(this, init); }
}
export const IEDITokenMaster_Token_Name_length = 50;

export const kEDITokenMaster_TID="TID";
export const kEDITokenMaster_Token_Name="Token_Name";
export const kEDITokenMaster_Seq_No="Seq_No";
export const kEDITokenMaster_Pkey="Pkey";

/*
        'EDITokenMaster' : {
            'TID' : 'TID',
            'Token_Name' : 'Token_Name',
            'Seq_No' : 'Seq_No',
            'Pkey' : 'Pkey',        },
*/

export const Label_TID = 'EDITokenMaster.TID';
export const Label_Token_Name = 'EDITokenMaster.Token_Name';
export const Label_Seq_No = 'EDITokenMaster.Seq_No';
export const Label_Pkey = 'EDITokenMaster.Pkey';
