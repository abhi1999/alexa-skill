import { IEDIDocStatu } from '../edidb'
export class CEDIDocStatu implements IEDIDocStatu {
    public UDID:string = '';
    public Direction:string = '';
    public Status:string = '';
    public constructor(init?:Partial<CEDIDocStatu>) { Object.assign(this, init); }
}
export const IEDIDocStatu_Direction_length = 1;
export const IEDIDocStatu_Status_length = 1;

export const kEDIDocStatu_UDID="UDID";
export const kEDIDocStatu_Direction="Direction";
export const kEDIDocStatu_Status="Status";

/*
        'EDIDocStatu' : {
            'UDID' : 'UDID',
            'Direction' : 'Direction',
            'Status' : 'Status',        },
*/

export const Label_UDID = 'EDIDocStatu.UDID';
export const Label_Direction = 'EDIDocStatu.Direction';
export const Label_Status = 'EDIDocStatu.Status';
