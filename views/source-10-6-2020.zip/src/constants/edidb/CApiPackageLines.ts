import { IApiPackageLines } from '../edidb'
export class CApiPackageLines implements IApiPackageLines {
    public PKG_ID:string = '';
    public Pack_ID:number = 0;
    public Line_No:number = 0;
    public Box_ID:number = 0;
    public PackQty:number = 0;
    public constructor(init?:Partial<CApiPackageLines>) { Object.assign(this, init); }
}
export const kApiPackageLines_PKG_ID="PKG_ID";
export const kApiPackageLines_Pack_ID="Pack_ID";
export const kApiPackageLines_Line_No="Line_No";
export const kApiPackageLines_Box_ID="Box_ID";
export const kApiPackageLines_PackQty="PackQty";

/*
        'ApiPackageLines' : {
            'PKG_ID' : 'PKG_ID',
            'Pack_ID' : 'Pack_ID',
            'Line_No' : 'Line_No',
            'Box_ID' : 'Box_ID',
            'PackQty' : 'PackQty',        },
*/

export const Label_PKG_ID = 'ApiPackageLines.PKG_ID';
export const Label_Pack_ID = 'ApiPackageLines.Pack_ID';
export const Label_Line_No = 'ApiPackageLines.Line_No';
export const Label_Box_ID = 'ApiPackageLines.Box_ID';
export const Label_PackQty = 'ApiPackageLines.PackQty';
