import { IApiItemPOAck } from '../edidb'
export class CApiItemPOAck implements IApiItemPOAck {
    public PO_ID:number = 0;
    public PO1_LineNo:string = '';
    public PO1_02:string = '';
    public PO1_03:string = '';
    public PO1_04:string = '';
    public PO1_05:string = '';
    public PO1_06:string = '';
    public PO1_07:string = '';
    public PO1_EDIqty:string = '';
    public PO1_EDIum:string = '';
    public PO1_EDIline:string = '';
    public CTP_02:string = '';
    public CTP_03:string = '';
    public CTP_04:string = '';
    public CTP_05:string = '';
    public CTP_06:string = '';
    public CTP_07:string = '';
    public PS_Type:string = '';
    public PS_Date:string = '';
    public Aut_LMThru:string = '';
    public Aut_MTThru:string = '';
    public PackSize:number = 0;
    public etline_no:number = 0;
    public docline:number = 0;
    public Loc_Override:string = '';
    public Expr1:number = 0;
    public Expr2:string = '';
    public Expr3:string = '';
    public Expr4:string = '';
    public ItemID:string = '';
    public ItemDesc:string = '';
    public NewQty:string = '';
    public constructor(init?:Partial<CApiItemPOAck>) { Object.assign(this, init); }
}
export const IApiItemPOAck_PO1_LineNo_length = 11;
export const IApiItemPOAck_PO1_02_length = 15;
export const IApiItemPOAck_PO1_03_length = 10;
export const IApiItemPOAck_PO1_04_length = 17;
export const IApiItemPOAck_PO1_05_length = 2;
export const IApiItemPOAck_PO1_06_length = 2;
export const IApiItemPOAck_PO1_07_length = 500;
export const IApiItemPOAck_PO1_EDIqty_length = 16;
export const IApiItemPOAck_PO1_EDIum_length = 2;
export const IApiItemPOAck_PO1_EDIline_length = 20;
export const IApiItemPOAck_CTP_02_length = 3;
export const IApiItemPOAck_CTP_03_length = 17;
export const IApiItemPOAck_CTP_04_length = 15;
export const IApiItemPOAck_CTP_05_length = 4;
export const IApiItemPOAck_CTP_06_length = 3;
export const IApiItemPOAck_CTP_07_length = 10;
export const IApiItemPOAck_PS_Type_length = 1;
export const IApiItemPOAck_PS_Date_length = 8;
export const IApiItemPOAck_Aut_LMThru_length = 8;
export const IApiItemPOAck_Aut_MTThru_length = 8;
export const IApiItemPOAck_Loc_Override_length = 20;
export const IApiItemPOAck_Expr2_length = 11;
export const IApiItemPOAck_Expr3_length = 2;
export const IApiItemPOAck_Expr4_length = 500;
export const IApiItemPOAck_ItemID_length = 500;
export const IApiItemPOAck_ItemDesc_length = 500;
export const IApiItemPOAck_NewQty_length = 16;

export const kApiItemPOAck_PO_ID="PO_ID";
export const kApiItemPOAck_PO1_LineNo="PO1_LineNo";
export const kApiItemPOAck_PO1_02="PO1_02";
export const kApiItemPOAck_PO1_03="PO1_03";
export const kApiItemPOAck_PO1_04="PO1_04";
export const kApiItemPOAck_PO1_05="PO1_05";
export const kApiItemPOAck_PO1_06="PO1_06";
export const kApiItemPOAck_PO1_07="PO1_07";
export const kApiItemPOAck_PO1_EDIqty="PO1_EDIqty";
export const kApiItemPOAck_PO1_EDIum="PO1_EDIum";
export const kApiItemPOAck_PO1_EDIline="PO1_EDIline";
export const kApiItemPOAck_CTP_02="CTP_02";
export const kApiItemPOAck_CTP_03="CTP_03";
export const kApiItemPOAck_CTP_04="CTP_04";
export const kApiItemPOAck_CTP_05="CTP_05";
export const kApiItemPOAck_CTP_06="CTP_06";
export const kApiItemPOAck_CTP_07="CTP_07";
export const kApiItemPOAck_PS_Type="PS_Type";
export const kApiItemPOAck_PS_Date="PS_Date";
export const kApiItemPOAck_Aut_LMThru="Aut_LMThru";
export const kApiItemPOAck_Aut_MTThru="Aut_MTThru";
export const kApiItemPOAck_PackSize="PackSize";
export const kApiItemPOAck_etline_no="etline_no";
export const kApiItemPOAck_docline="docline";
export const kApiItemPOAck_Loc_Override="Loc_Override";
export const kApiItemPOAck_Expr1="Expr1";
export const kApiItemPOAck_Expr2="Expr2";
export const kApiItemPOAck_Expr3="Expr3";
export const kApiItemPOAck_Expr4="Expr4";
export const kApiItemPOAck_ItemID="ItemID";
export const kApiItemPOAck_ItemDesc="ItemDesc";
export const kApiItemPOAck_NewQty="NewQty";

/*
        'ApiItemPOAck' : {
            'PO_ID' : 'PO_ID',
            'PO1_LineNo' : 'PO1_LineNo',
            'PO1_02' : 'PO1_02',
            'PO1_03' : 'PO1_03',
            'PO1_04' : 'PO1_04',
            'PO1_05' : 'PO1_05',
            'PO1_06' : 'PO1_06',
            'PO1_07' : 'PO1_07',
            'PO1_EDIqty' : 'PO1_EDIqty',
            'PO1_EDIum' : 'PO1_EDIum',
            'PO1_EDIline' : 'PO1_EDIline',
            'CTP_02' : 'CTP_02',
            'CTP_03' : 'CTP_03',
            'CTP_04' : 'CTP_04',
            'CTP_05' : 'CTP_05',
            'CTP_06' : 'CTP_06',
            'CTP_07' : 'CTP_07',
            'PS_Type' : 'PS_Type',
            'PS_Date' : 'PS_Date',
            'Aut_LMThru' : 'Aut_LMThru',
            'Aut_MTThru' : 'Aut_MTThru',
            'PackSize' : 'PackSize',
            'etline_no' : 'etline_no',
            'docline' : 'docline',
            'Loc_Override' : 'Loc_Override',
            'Expr1' : 'Expr1',
            'Expr2' : 'Expr2',
            'Expr3' : 'Expr3',
            'Expr4' : 'Expr4',
            'ItemID' : 'ItemID',
            'ItemDesc' : 'ItemDesc',
            'NewQty' : 'NewQty',        },
*/

export const Label_PO_ID = 'ApiItemPOAck.PO_ID';
export const Label_PO1_LineNo = 'ApiItemPOAck.PO1_LineNo';
export const Label_PO1_02 = 'ApiItemPOAck.PO1_02';
export const Label_PO1_03 = 'ApiItemPOAck.PO1_03';
export const Label_PO1_04 = 'ApiItemPOAck.PO1_04';
export const Label_PO1_05 = 'ApiItemPOAck.PO1_05';
export const Label_PO1_06 = 'ApiItemPOAck.PO1_06';
export const Label_PO1_07 = 'ApiItemPOAck.PO1_07';
export const Label_PO1_EDIqty = 'ApiItemPOAck.PO1_EDIqty';
export const Label_PO1_EDIum = 'ApiItemPOAck.PO1_EDIum';
export const Label_PO1_EDIline = 'ApiItemPOAck.PO1_EDIline';
export const Label_CTP_02 = 'ApiItemPOAck.CTP_02';
export const Label_CTP_03 = 'ApiItemPOAck.CTP_03';
export const Label_CTP_04 = 'ApiItemPOAck.CTP_04';
export const Label_CTP_05 = 'ApiItemPOAck.CTP_05';
export const Label_CTP_06 = 'ApiItemPOAck.CTP_06';
export const Label_CTP_07 = 'ApiItemPOAck.CTP_07';
export const Label_PS_Type = 'ApiItemPOAck.PS_Type';
export const Label_PS_Date = 'ApiItemPOAck.PS_Date';
export const Label_Aut_LMThru = 'ApiItemPOAck.Aut_LMThru';
export const Label_Aut_MTThru = 'ApiItemPOAck.Aut_MTThru';
export const Label_PackSize = 'ApiItemPOAck.PackSize';
export const Label_etline_no = 'ApiItemPOAck.etline_no';
export const Label_docline = 'ApiItemPOAck.docline';
export const Label_Loc_Override = 'ApiItemPOAck.Loc_Override';
export const Label_Expr1 = 'ApiItemPOAck.Expr1';
export const Label_Expr2 = 'ApiItemPOAck.Expr2';
export const Label_Expr3 = 'ApiItemPOAck.Expr3';
export const Label_Expr4 = 'ApiItemPOAck.Expr4';
export const Label_ItemID = 'ApiItemPOAck.ItemID';
export const Label_ItemDesc = 'ApiItemPOAck.ItemDesc';
export const Label_NewQty = 'ApiItemPOAck.NewQty';
