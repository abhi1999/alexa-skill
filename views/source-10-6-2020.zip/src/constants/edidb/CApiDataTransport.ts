import { IApiDataTransport } from '../edidb'
export class CApiDataTransport implements IApiDataTransport {
    public DTCID:string = '';
    public TransID:string = '';
    public TP_PartID:string = '';
    public TP_Name:string = '';
    public DTMethod:number = 0;
    public DTIn:string = '';
    public DTOut:string = '';
    public DTServer:string = '';
    public DTDomain:string = '';
    public DTUser:string = '';
    public DTPass:string = '';
    public DTWeb_ERP_Flag:boolean;
    public constructor(init?:Partial<CApiDataTransport>) { Object.assign(this, init); }
}
export const IApiDataTransport_TransID_length = 50;
export const IApiDataTransport_TP_PartID_length = 30;
export const IApiDataTransport_TP_Name_length = 30;
export const IApiDataTransport_DTIn_length = 256;
export const IApiDataTransport_DTOut_length = 256;
export const IApiDataTransport_DTServer_length = 256;
export const IApiDataTransport_DTDomain_length = 80;
export const IApiDataTransport_DTUser_length = 80;
export const IApiDataTransport_DTPass_length = 80;

export const kApiDataTransport_DTCID="DTCID";
export const kApiDataTransport_TransID="TransID";
export const kApiDataTransport_TP_PartID="TP_PartID";
export const kApiDataTransport_TP_Name="TP_Name";
export const kApiDataTransport_DTMethod="DTMethod";
export const kApiDataTransport_DTIn="DTIn";
export const kApiDataTransport_DTOut="DTOut";
export const kApiDataTransport_DTServer="DTServer";
export const kApiDataTransport_DTDomain="DTDomain";
export const kApiDataTransport_DTUser="DTUser";
export const kApiDataTransport_DTPass="DTPass";
export const kApiDataTransport_DTWeb_ERP_Flag="DTWeb_ERP_Flag";

/*
        'ApiDataTransport' : {
            'DTCID' : 'DTCID',
            'TransID' : 'TransID',
            'TP_PartID' : 'TP_PartID',
            'TP_Name' : 'TP_Name',
            'DTMethod' : 'DTMethod',
            'DTIn' : 'DTIn',
            'DTOut' : 'DTOut',
            'DTServer' : 'DTServer',
            'DTDomain' : 'DTDomain',
            'DTUser' : 'DTUser',
            'DTPass' : 'DTPass',
            'DTWeb_ERP_Flag' : 'DTWeb_ERP_Flag',
        },
*/

export const Label_DTCID = 'DataTransport.DTCID';
export const Label_TransID = 'DataTransport.TransID';
export const Label_TP_PartID = 'DataTransport.TP_PartID';
export const Label_TP_Name = 'DataTransport.TP_Name';
export const Label_DTMethod = 'DataTransport.DTMethod';
export const Label_DTIn = 'DataTransport.DTIn';
export const Label_DTOut = 'DataTransport.DTOut';
export const Label_DTServer = 'DataTransport.DTServer';
export const Label_DTDomain = 'DataTransport.DTDomain';
export const Label_DTUser = 'DataTransport.DTUser';
export const Label_DTPass = 'DataTransport.DTPass';
export const Label_DTWeb_ERP_Flag = 'DataTransport.DTWeb_ERP_Flag';
