import { IApiConfigRecords } from '../edidb'
export class CApiConfigRecords implements IApiConfigRecords {
    public xmlid: string = '';
    public vpid:number = 0;
    public dgid:string = '';
    public TP_PartID:string = '';
    public tp_name:string = '';
    public Doc_Group:string = '';
    public XMLRef:string = '';
    public CreatedDate?:Date;
    public ExportDate?:Date;
    public constructor(init?:Partial<CApiConfigRecords>) { Object.assign(this, init); }
}
export const IApiConfigRecords_dgid_length = 5;
export const IApiConfigRecords_TP_PartID_length = 30;
export const IApiConfigRecords_tp_name_length = 30;
export const IApiConfigRecords_Doc_Group_length = 50;
export const IApiConfigRecords_XMLRef_length = 1000;

export const kApiConfigRecords_xmlid = "xmlid";
export const kApiConfigRecords_vpid="vpid";
export const kApiConfigRecords_dgid="dgid";
export const kApiConfigRecords_TP_PartID="TP_PartID";
export const kApiConfigRecords_tp_name="tp_name";
export const kApiConfigRecords_Doc_Group="Doc_Group";
export const kApiConfigRecords_XMLRef="XMLRef";
export const kApiConfigRecords_CreatedDate="CreatedDate";
export const kApiConfigRecords_ExportDate="ExportDate";

/*
        'ApiConfigRecords' : {
            'vpid' : 'vpid',
            'dgid' : 'dgid',
            'TP_PartID' : 'TP_PartID',
            'tp_name' : 'tp_name',
            'Doc_Group' : 'Doc_Group',
            'XMLRef' : 'XMLRef',
            'CreatedDate' : 'CreatedDate',
            'ExportDate' : 'ExportDate',
        },
*/

export const Label_vpid = 'ApiConfigRecords.vpid';
export const Label_dgid = 'ApiConfigRecords.dgid';
export const Label_TP_PartID = 'ApiConfigRecords.TP_PartID';
export const Label_tp_name = 'ApiConfigRecords.tp_name';
export const Label_Doc_Group = 'ApiConfigRecords.Doc_Group';
export const Label_XMLRef = 'ApiConfigRecords.XMLRef';
export const Label_CreatedDate = 'ApiConfigRecords.CreatedDate';
export const Label_ExportDate = 'ApiConfigRecords.ExportDate';