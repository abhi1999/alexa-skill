import { IPackAndShipLineItem  } from '../edidb'

export class CPackAndShipLineItem implements IPackAndShipLineItem {
  
    // KB: NOTE: This Id is not in the table, but I added for a unique key, which is set in the reducer
    public Id: string = "";
    
    public Order_No: number = 0;
    public Line_No: number = 0;
    public Int_Item_No: string = '';
    public Quantity: number = 0;
    public QtyPacked: number = 0;
    public Item_No_Plus_Desc: string = '';

    public Price: number = 0;
    public Exp_Flag: string = '';
    public Stat_Flag: string = '';
    public Order_Wt: number = 0;
    public Acct_Order_No: string = '';
    public Item_Desc: string = '';
    public Item_Alt_No: string = '';
    public UPC: string = '';

    public constructor(init?:Partial<CPackAndShipLineItem>) { Object.assign(this, init); }
}

export const IPackAndShip_ERP_Order_No_length = 30;
export const IPackAndShip_Order_No_length = 30;
export const IPackAndShip_Line_No_length = 30;
export const IPackAndShip_Item_No_length = 30;
export const IPackAndShip_Quantity_length = 30;
export const IPackAndShip_Qty_Packed_length = 30;
export const IPackAndShip_Item_Desc_length = 80;
export const IPackAndShip_Item_Alt_No_length = 30;
export const IPackAndShip_Item_No_Plus_Desc = 110;
export const IPackAndShip_UPC = 20;

export const kPackAndShip_ERP_Order_No = 'Acct_Order_No';
export const kPackAndShip_Order_No = 'Order_No';
export const kPackAndShip_Line_No = 'Line_No';
export const kPackAndShip_Item_No = 'Int_Item_No';
export const kPackAndShip_Quantity = 'Quantity';
export const kPackAndShip_QtyPacked = 'QtyPacked';
export const kPackAndShip_Item_Desc = 'Item_Desc';
export const kPackAndShip_Item_Alt_No = 'Item_Alt_No';
export const kPackAndShip_Item_No_Plus_Desc = 'Item_No_Plus_Desc';
export const kPackAndShip_UPC = 'UPC';

export const Label_ERP_Order_No = 'PackAndShip.ERP_Order_No';
export const Label_Order_No = 'PackAndShip.Order_No';
export const Label_Line_No = 'PackAndShip.Line_No';
export const Label_Item_No = 'PackAndShip.Item_No';
export const Label_Qty_Ord = 'PackAndShip.QtyOrd';
export const Label_QtyPacked = 'PackAndShip.QtyPacked';
