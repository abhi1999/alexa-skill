import { IRibbonTab } from '../edidb'
export class CRibbonTab implements IRibbonTab {
    public TabID:number = 0;
    public FormName:string = '';
    public Caption:string = '';
    public TabOrder:number = 0;
    public Visible:boolean;
    public Enabled:boolean;
    public KeyboardTip:string = '';
    public FriendlyName:string = '';
    public constructor(init?:Partial<CRibbonTab>) { Object.assign(this, init); }
}
export const IRibbonTab_FormName_length = 200;
export const IRibbonTab_Caption_length = 200;
export const IRibbonTab_KeyboardTip_length = 500;

export const kRibbonTab_TabID="TabID";
export const kRibbonTab_FormName="FormName";
export const kRibbonTab_Caption="Caption";
export const kRibbonTab_TabOrder="TabOrder";
export const kRibbonTab_Visible="Visible";
export const kRibbonTab_Enabled="Enabled";
export const kRibbonTab_KeyboardTip="KeyboardTip";
export const kRibbonTab_FriendlyName="FriendlyName";

/*
        'RibbonTab' : {
            'TabID' : 'TabID',
            'FormName' : 'FormName',
            'Caption' : 'Caption',
            'TabOrder' : 'TabOrder',
            'Visible' : 'Visible',
            'Enabled' : 'Enabled',
            'KeyboardTip' : 'KeyboardTip',
            'FriendlyName' : 'FriendlyName',        },
*/

export const Label_TabID = 'RibbonTab.TabID';
export const Label_FormName = 'RibbonTab.FormName';
export const Label_Caption = 'RibbonTab.Caption';
export const Label_TabOrder = 'RibbonTab.TabOrder';
export const Label_Visible = 'RibbonTab.Visible';
export const Label_Enabled = 'RibbonTab.Enabled';
export const Label_KeyboardTip = 'RibbonTab.KeyboardTip';
export const Label_FriendlyName = 'RibbonTab.FriendlyName';
