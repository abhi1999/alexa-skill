import { IC303v850lb } from '../edidb'
export class CC303v850lb implements IC303v850lb {
    public PO_ID:number = 0;
    public PO1_LineNo:string = '';
    public PO1_06:string = '';
    public PO1_07:string = '';
    public constructor(init?:Partial<CC303v850lb>) { Object.assign(this, init); }
}
export const IC303v850lb_PO1_LineNo_length = 11;
export const IC303v850lb_PO1_06_length = 3;
export const IC303v850lb_PO1_07_length = 500;

export const kC303v850lb_PO_ID="PO_ID";
export const kC303v850lb_PO1_LineNo="PO1_LineNo";
export const kC303v850lb_PO1_06="PO1_06";
export const kC303v850lb_PO1_07="PO1_07";

/*
        'C303v850lb' : {
            'PO_ID' : 'PO_ID',
            'PO1_LineNo' : 'PO1_LineNo',
            'PO1_06' : 'PO1_06',
            'PO1_07' : 'PO1_07',
        },
*/

export const Label_PO_ID = 'C303v850lb.PO_ID';
export const Label_PO1_LineNo = 'C303v850lb.PO1_LineNo';
export const Label_PO1_06 = 'C303v850lb.PO1_06';
export const Label_PO1_07 = 'C303v850lb.PO1_07';
