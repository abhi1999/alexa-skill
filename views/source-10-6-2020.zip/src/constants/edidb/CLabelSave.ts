import { ILabelSave } from '../edidb'
export class CLabelSave implements ILabelSave {
    public Label_ID:string = '';
    public Object_ID:number = 0;
    public ObjType:string = '';
    public ObjName:string = '';
    public ObjValue:string = '';
    public ObjFontName:string = '';
    public ObjFontSize:number = 0;
    public ObjFontBold:boolean;
    public ObjLeft:number = 0;
    public ObjTop:number = 0;
    public ObjWidth:number = 0;
    public ObjHeight:number = 0;
    public bcObjName:string = '';
    public bcCaption:string = '';
    public bcType:number = 0;
    public bcHasText:boolean;
    public bcPadding:string = '';
    public bcPrepend:string = '';
    public bcShowPrepend:boolean;
    public bcRotation:number = 0;
    public constructor(init?:Partial<CLabelSave>) { Object.assign(this, init); }
}
export const ILabelSave_Label_ID_length = 20;
export const ILabelSave_ObjType_length = 50;
export const ILabelSave_ObjName_length = 50;
export const ILabelSave_ObjValue_length = 256;
export const ILabelSave_ObjFontName_length = 50;
export const ILabelSave_bcObjName_length = 50;
export const ILabelSave_bcCaption_length = 50;
export const ILabelSave_bcPadding_length = 50;
export const ILabelSave_bcPrepend_length = 50;

export const kLabelSave_Label_ID="Label_ID";
export const kLabelSave_Object_ID="Object_ID";
export const kLabelSave_ObjType="ObjType";
export const kLabelSave_ObjName="ObjName";
export const kLabelSave_ObjValue="ObjValue";
export const kLabelSave_ObjFontName="ObjFontName";
export const kLabelSave_ObjFontSize="ObjFontSize";
export const kLabelSave_ObjFontBold="ObjFontBold";
export const kLabelSave_ObjLeft="ObjLeft";
export const kLabelSave_ObjTop="ObjTop";
export const kLabelSave_ObjWidth="ObjWidth";
export const kLabelSave_ObjHeight="ObjHeight";
export const kLabelSave_bcObjName="bcObjName";
export const kLabelSave_bcCaption="bcCaption";
export const kLabelSave_bcType="bcType";
export const kLabelSave_bcHasText="bcHasText";
export const kLabelSave_bcPadding="bcPadding";
export const kLabelSave_bcPrepend="bcPrepend";
export const kLabelSave_bcShowPrepend="bcShowPrepend";
export const kLabelSave_bcRotation="bcRotation";

/*
        'LabelSave' : {
            'Label_ID' : 'Label_ID',
            'Object_ID' : 'Object_ID',
            'ObjType' : 'ObjType',
            'ObjName' : 'ObjName',
            'ObjValue' : 'ObjValue',
            'ObjFontName' : 'ObjFontName',
            'ObjFontSize' : 'ObjFontSize',
            'ObjFontBold' : 'ObjFontBold',
            'ObjLeft' : 'ObjLeft',
            'ObjTop' : 'ObjTop',
            'ObjWidth' : 'ObjWidth',
            'ObjHeight' : 'ObjHeight',
            'bcObjName' : 'bcObjName',
            'bcCaption' : 'bcCaption',
            'bcType' : 'bcType',
            'bcHasText' : 'bcHasText',
            'bcPadding' : 'bcPadding',
            'bcPrepend' : 'bcPrepend',
            'bcShowPrepend' : 'bcShowPrepend',
            'bcRotation' : 'bcRotation',        },
*/

export const Label_Label_ID = 'LabelSave.Label_ID';
export const Label_Object_ID = 'LabelSave.Object_ID';
export const Label_ObjType = 'LabelSave.ObjType';
export const Label_ObjName = 'LabelSave.ObjName';
export const Label_ObjValue = 'LabelSave.ObjValue';
export const Label_ObjFontName = 'LabelSave.ObjFontName';
export const Label_ObjFontSize = 'LabelSave.ObjFontSize';
export const Label_ObjFontBold = 'LabelSave.ObjFontBold';
export const Label_ObjLeft = 'LabelSave.ObjLeft';
export const Label_ObjTop = 'LabelSave.ObjTop';
export const Label_ObjWidth = 'LabelSave.ObjWidth';
export const Label_ObjHeight = 'LabelSave.ObjHeight';
export const Label_bcObjName = 'LabelSave.bcObjName';
export const Label_bcCaption = 'LabelSave.bcCaption';
export const Label_bcType = 'LabelSave.bcType';
export const Label_bcHasText = 'LabelSave.bcHasText';
export const Label_bcPadding = 'LabelSave.bcPadding';
export const Label_bcPrepend = 'LabelSave.bcPrepend';
export const Label_bcShowPrepend = 'LabelSave.bcShowPrepend';
export const Label_bcRotation = 'LabelSave.bcRotation';
