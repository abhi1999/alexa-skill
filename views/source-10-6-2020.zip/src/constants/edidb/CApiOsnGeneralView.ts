import { IApiOsnGeneralView } from '../edidb'
export class CApiOsnGeneralView implements IApiOsnGeneralView {
    public Asn_ID:number = 0;
    public Bol_No:string = '';
    public Pro_No:string = '';
    public ShipToPeps:boolean;
    public Ship_Weight:number = 0;
    public Ship_Date:string = '';
    public Del_Date:string = '';
    public Ship_Via_ID:string = '';
    public Asn_Complete:string = '';
    public Exp_Flag:string = '';
    public TP_PartID:string = '';
    public User1:string = '';
    public User2:string = '';
    public Trailer:string = '';
    public Collect:boolean;
    public AckID:string = '';
    public GCN:string = '';
    public TCN:string = '';
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public SealNo:string = '';
    public ExportDate:Date;
    public CreatedDate:Date;
    public PackImport:string = '';
    public VPIDFA:number = 0;
    public LabelPrinted:boolean;
    public TP_Name:string = '';
    public Ship_Via_Name:string = '';
    public Ship_Date_Full:Date;
    public Del_Date_Full:Date;
    public Exp:string = '';
    public AckDesc:string = '';
    public PackImportDesc:string = '';
    public constructor(init?:Partial<CApiOsnGeneralView>) { Object.assign(this, init); }
}
export const IApiOsnGeneralView_Bol_No_length = 30;
export const IApiOsnGeneralView_Pro_No_length = 30;
export const IApiOsnGeneralView_Ship_Date_length = 8;
export const IApiOsnGeneralView_Del_Date_length = 8;
export const IApiOsnGeneralView_Ship_Via_ID_length = 30;
export const IApiOsnGeneralView_Asn_Complete_length = 1;
export const IApiOsnGeneralView_Exp_Flag_length = 1;
export const IApiOsnGeneralView_TP_PartID_length = 30;
export const IApiOsnGeneralView_User1_length = 50;
export const IApiOsnGeneralView_User2_length = 50;
export const IApiOsnGeneralView_Trailer_length = 50;
export const IApiOsnGeneralView_AckID_length = 1;
export const IApiOsnGeneralView_GCN_length = 20;
export const IApiOsnGeneralView_TCN_length = 20;
export const IApiOsnGeneralView_User3_length = 50;
export const IApiOsnGeneralView_User4_length = 50;
export const IApiOsnGeneralView_User5_length = 50;
export const IApiOsnGeneralView_SealNo_length = 200;
export const IApiOsnGeneralView_PackImport_length = 1;
export const IApiOsnGeneralView_TP_Name_length = 30;
export const IApiOsnGeneralView_Ship_Via_Name_length = 30;
export const IApiOsnGeneralView_Exp_length = 500;
export const IApiOsnGeneralView_AckDesc_length = 10;
export const IApiOsnGeneralView_PackImportDesc_length = 500;

export const kApiOsnGeneralView_Asn_ID="Asn_ID";
export const kApiOsnGeneralView_Bol_No="Bol_No";
export const kApiOsnGeneralView_Pro_No="Pro_No";
export const kApiOsnGeneralView_ShipToPeps="ShipToPeps";
export const kApiOsnGeneralView_Ship_Weight="Ship_Weight";
export const kApiOsnGeneralView_Ship_Date="Ship_Date";
export const kApiOsnGeneralView_Del_Date="Del_Date";
export const kApiOsnGeneralView_Ship_Via_ID="Ship_Via_ID";
export const kApiOsnGeneralView_Asn_Complete="Asn_Complete";
export const kApiOsnGeneralView_Exp_Flag="Exp_Flag";
export const kApiOsnGeneralView_TP_PartID="TP_PartID";
export const kApiOsnGeneralView_User1="User1";
export const kApiOsnGeneralView_User2="User2";
export const kApiOsnGeneralView_Trailer="Trailer";
export const kApiOsnGeneralView_Collect="Collect";
export const kApiOsnGeneralView_AckID="AckID";
export const kApiOsnGeneralView_GCN="GCN";
export const kApiOsnGeneralView_TCN="TCN";
export const kApiOsnGeneralView_User3="User3";
export const kApiOsnGeneralView_User4="User4";
export const kApiOsnGeneralView_User5="User5";
export const kApiOsnGeneralView_SealNo="SealNo";
export const kApiOsnGeneralView_ExportDate="ExportDate";
export const kApiOsnGeneralView_CreatedDate="CreatedDate";
export const kApiOsnGeneralView_PackImport="PackImport";
export const kApiOsnGeneralView_VPIDFA="VPIDFA";
export const kApiOsnGeneralView_LabelPrinted="LabelPrinted";
export const kApiOsnGeneralView_TP_Name="TP_Name";
export const kApiOsnGeneralView_Ship_Via_Name="Ship_Via_Name";
export const kApiOsnGeneralView_Ship_Date_Full="Ship_Date_Full";
export const kApiOsnGeneralView_Del_Date_Full="Del_Date_Full";
export const kApiOsnGeneralView_Exp="Exp";
export const kApiOsnGeneralView_AckDesc="AckDesc";
export const kApiOsnGeneralView_PackImportDesc="PackImportDesc";

/*
        'ApiOsnGeneralView' : {
            'Asn_ID' : 'Asn_ID',
            'Bol_No' : 'Bol_No',
            'Pro_No' : 'Pro_No',
            'ShipToPeps' : 'ShipToPeps',
            'Ship_Weight' : 'Ship_Weight',
            'Ship_Date' : 'Ship_Date',
            'Del_Date' : 'Del_Date',
            'Ship_Via_ID' : 'Ship_Via_ID',
            'Asn_Complete' : 'Asn_Complete',
            'Exp_Flag' : 'Exp_Flag',
            'TP_PartID' : 'TP_PartID',
            'User1' : 'User1',
            'User2' : 'User2',
            'Trailer' : 'Trailer',
            'Collect' : 'Collect',
            'AckID' : 'AckID',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'SealNo' : 'SealNo',
            'ExportDate' : 'ExportDate',
            'CreatedDate' : 'CreatedDate',
            'PackImport' : 'PackImport',
            'VPIDFA' : 'VPIDFA',
            'LabelPrinted' : 'LabelPrinted',
            'TP_Name' : 'TP_Name',
            'Ship_Via_Name' : 'Ship_Via_Name',
            'Ship_Date_Full' : 'Ship_Date_Full',
            'Del_Date_Full' : 'Del_Date_Full',
            'Exp' : 'Exp',
            'AckDesc' : 'AckDesc',
            'PackImportDesc' : 'PackImportDesc',        },
*/

export const Label_Asn_ID = 'ApiOsnGeneralView.Asn_ID';
export const Label_Bol_No = 'ApiOsnGeneralView.Bol_No';
export const Label_Pro_No = 'ApiOsnGeneralView.Pro_No';
export const Label_ShipToPeps = 'ApiOsnGeneralView.ShipToPeps';
export const Label_Ship_Weight = 'ApiOsnGeneralView.Ship_Weight';
export const Label_Ship_Date = 'ApiOsnGeneralView.Ship_Date';
export const Label_Del_Date = 'ApiOsnGeneralView.Del_Date';
export const Label_Ship_Via_ID = 'ApiOsnGeneralView.Ship_Via_ID';
export const Label_Asn_Complete = 'ApiOsnGeneralView.Asn_Complete';
export const Label_Exp_Flag = 'ApiOsnGeneralView.Exp_Flag';
export const Label_TP_PartID = 'ApiOsnGeneralView.TP_PartID';
export const Label_User1 = 'ApiOsnGeneralView.User1';
export const Label_User2 = 'ApiOsnGeneralView.User2';
export const Label_Trailer = 'ApiOsnGeneralView.Trailer';
export const Label_Collect = 'ApiOsnGeneralView.Collect';
export const Label_AckID = 'ApiOsnGeneralView.AckID';
export const Label_GCN = 'ApiOsnGeneralView.GCN';
export const Label_TCN = 'ApiOsnGeneralView.TCN';
export const Label_User3 = 'ApiOsnGeneralView.User3';
export const Label_User4 = 'ApiOsnGeneralView.User4';
export const Label_User5 = 'ApiOsnGeneralView.User5';
export const Label_SealNo = 'ApiOsnGeneralView.SealNo';
export const Label_ExportDate = 'ApiOsnGeneralView.ExportDate';
export const Label_CreatedDate = 'ApiOsnGeneralView.CreatedDate';
export const Label_PackImport = 'ApiOsnGeneralView.PackImport';
export const Label_VPIDFA = 'ApiOsnGeneralView.VPIDFA';
export const Label_LabelPrinted = 'ApiOsnGeneralView.LabelPrinted';
export const Label_TP_Name = 'ApiOsnGeneralView.TP_Name';
export const Label_Ship_Via_Name = 'ApiOsnGeneralView.Ship_Via_Name';
export const Label_Ship_Date_Full = 'ApiOsnGeneralView.Ship_Date_Full';
export const Label_Del_Date_Full = 'ApiOsnGeneralView.Del_Date_Full';
export const Label_Exp = 'ApiOsnGeneralView.Exp';
export const Label_AckDesc = 'ApiOsnGeneralView.AckDesc';
export const Label_PackImportDesc = 'ApiOsnGeneralView.PackImportDesc';
