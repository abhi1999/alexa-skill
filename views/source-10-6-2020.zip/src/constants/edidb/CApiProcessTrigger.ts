import { IApiProcessTrigger } from '../edidb'
export class CApiProcessTrigger implements IApiProcessTrigger {
    public trigid:number = 0;
    public procid:string = '';
    public procname:string = '';
    public seqno:number = 0;
    public timing:string = '';
    public dataarea:string = '';
    public triggertype:number = 0;
    public triggeraction:string = '';
    public actionfocus:number = 0;
    public inactive:boolean;
    public subprocid:string = '';
    public subprocname:string = '';
    public notetext:string = '';
    public constructor(init?:Partial<CApiProcessTrigger>) { Object.assign(this, init); }
}
export const IApiProcessTrigger_procid_length = 20;
export const IApiProcessTrigger_procname_length = 50;
export const IApiProcessTrigger_timing_length = 6;
export const IApiProcessTrigger_dataarea_length = 4;
export const IApiProcessTrigger_triggeraction_length = 1000;
export const IApiProcessTrigger_subprocid_length = 20;
export const IApiProcessTrigger_subprocname_length = 50;
export const IApiProcessTrigger_notetext_length = 2000;

export const kApiProcessTrigger_trigid="trigid";
export const kApiProcessTrigger_procid="procid";
export const kApiProcessTrigger_procname="procname";
export const kApiProcessTrigger_seqno="seqno";
export const kApiProcessTrigger_timing="timing";
export const kApiProcessTrigger_dataarea="dataarea";
export const kApiProcessTrigger_triggertype="triggertype";
export const kApiProcessTrigger_triggeraction="triggeraction";
export const kApiProcessTrigger_actionfocus="actionfocus";
export const kApiProcessTrigger_inactive="inactive";
export const kApiProcessTrigger_subprocid="subprocid";
export const kApiProcessTrigger_subprocname="subprocname";
export const kApiProcessTrigger_notetext="notetext";

/*
        'ApiProcessTrigger' : {
            'trigid' : 'trigid',
            'procid' : 'procid',
            'procname' : 'procname',
            'seqno' : 'seqno',
            'timing' : 'timing',
            'dataarea' : 'dataarea',
            'triggertype' : 'triggertype',
            'triggeraction' : 'triggeraction',
            'actionfocus' : 'actionfocus',
            'inactive' : 'inactive',
            'subprocid' : 'subprocid',
            'subprocname' : 'subprocname',
            'notetext' : 'notetext',        },
*/

export const Label_trigid = 'ApiProcessTrigger.trigid';
export const Label_procid = 'ApiProcessTrigger.procid';
export const Label_procname = 'ApiProcessTrigger.procname';
export const Label_seqno = 'ApiProcessTrigger.seqno';
export const Label_timing = 'ApiProcessTrigger.timing';
export const Label_dataarea = 'ApiProcessTrigger.dataarea';
export const Label_triggertype = 'ApiProcessTrigger.triggertype';
export const Label_triggeraction = 'ApiProcessTrigger.triggeraction';
export const Label_actionfocus = 'ApiProcessTrigger.actionfocus';
export const Label_inactive = 'ApiProcessTrigger.inactive';
export const Label_subprocid = 'ApiProcessTrigger.subprocid';
export const Label_subprocname = 'ApiProcessTrigger.subprocname';
export const Label_notetext = 'ApiProcessTrigger.notetext';
