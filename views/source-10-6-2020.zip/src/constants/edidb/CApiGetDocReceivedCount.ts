import { IApiGetDocReceivedCount } from '../edidb'
export class CApiGetDocReceivedCount implements IApiGetDocReceivedCount {
    public ID:string = '';
    public Doc_Desc:string = '';
    public Mdate:string = '';
    public Count:number = 0;
    public constructor(init?:Partial<CApiGetDocReceivedCount>) { Object.assign(this, init); }
}
export const IApiGetDocReceivedCount_Doc_Desc_length = 50;
export const IApiGetDocReceivedCount_Mdate_length = 6;

export const kApiGetDocReceivedCount_ID="ID";
export const kApiGetDocReceivedCount_Doc_Desc="Doc_Desc";
export const kApiGetDocReceivedCount_Mdate="Mdate";
export const kApiGetDocReceivedCount_Count="Count";

/*
        'ApiGetDocReceivedCount' : {
            'ID' : 'ID',
            'Doc_Desc' : 'Doc_Desc',
            'Mdate' : 'Mdate',
            'Count' : 'Count',        },
*/

export const Label_ID = 'ApiGetDocReceivedCount.ID';
export const Label_Doc_Desc = 'ApiGetDocReceivedCount.Doc_Desc';
export const Label_Mdate = 'ApiGetDocReceivedCount.Mdate';
export const Label_Count = 'ApiGetDocReceivedCount.Count';
