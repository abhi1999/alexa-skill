import { IPlanSchedPO } from '../edidb'
export class CPlanSchedPO implements IPlanSchedPO {
    public tp_partid:string = '';
    public beg_01:string = '';
    public beg_02:string = '';
    public beg_03:string = '';
    public beg_04:string = '';
    public beg_05:string = '';
    public beg_06:string = '';
    public ctt_01:string = '';
    public exp_flag:string = '';
    public sdq_flag:string = '';
    public cur_02:number = 0;
    public importdate:Date;
    public exportdate:number = 0;
    public misc_id:number = 0;
    public shiptoid:string = '';
    public VPID:number = 0;
    public po1_02:number = 0;
    public po1_03:string = '';
    public po1_04:number = 0;
    public po1_05:string = '';
    public po1_06:string = '';
    public po1_07:string = '';
    public po1_ediqty:number = 0;
    public po1_edium:string = '';
    public po1_ediline:string = '';
    public docline:number = 0;
    public packsize:number = 0;
    public etline_no:number = 0;
    public fcdate1:string = '';
    public fcdate2:string = '';
    public PSHID:string = '';
    public PSIID:string = '';
    public constructor(init?:Partial<CPlanSchedPO>) { Object.assign(this, init); }
}
export const IPlanSchedPO_tp_partid_length = 30;
export const IPlanSchedPO_beg_01_length = 2;
export const IPlanSchedPO_beg_02_length = 2;
export const IPlanSchedPO_beg_03_length = 30;
export const IPlanSchedPO_beg_04_length = 30;
export const IPlanSchedPO_beg_05_length = 8;
export const IPlanSchedPO_beg_06_length = 30;
export const IPlanSchedPO_ctt_01_length = 1;
export const IPlanSchedPO_exp_flag_length = 1;
export const IPlanSchedPO_sdq_flag_length = 1;
export const IPlanSchedPO_shiptoid_length = 80;
export const IPlanSchedPO_po1_03_length = 10;
export const IPlanSchedPO_po1_05_length = 2;
export const IPlanSchedPO_po1_06_length = 10;
export const IPlanSchedPO_po1_07_length = 80;
export const IPlanSchedPO_po1_edium_length = 10;
export const IPlanSchedPO_po1_ediline_length = 1;
export const IPlanSchedPO_fcdate1_length = 8;
export const IPlanSchedPO_fcdate2_length = 8;

export const kPlanSchedPO_tp_partid="tp_partid";
export const kPlanSchedPO_beg_01="beg_01";
export const kPlanSchedPO_beg_02="beg_02";
export const kPlanSchedPO_beg_03="beg_03";
export const kPlanSchedPO_beg_04="beg_04";
export const kPlanSchedPO_beg_05="beg_05";
export const kPlanSchedPO_beg_06="beg_06";
export const kPlanSchedPO_ctt_01="ctt_01";
export const kPlanSchedPO_exp_flag="exp_flag";
export const kPlanSchedPO_sdq_flag="sdq_flag";
export const kPlanSchedPO_cur_02="cur_02";
export const kPlanSchedPO_importdate="importdate";
export const kPlanSchedPO_exportdate="exportdate";
export const kPlanSchedPO_misc_id="misc_id";
export const kPlanSchedPO_shiptoid="shiptoid";
export const kPlanSchedPO_VPID="VPID";
export const kPlanSchedPO_po1_02="po1_02";
export const kPlanSchedPO_po1_03="po1_03";
export const kPlanSchedPO_po1_04="po1_04";
export const kPlanSchedPO_po1_05="po1_05";
export const kPlanSchedPO_po1_06="po1_06";
export const kPlanSchedPO_po1_07="po1_07";
export const kPlanSchedPO_po1_ediqty="po1_ediqty";
export const kPlanSchedPO_po1_edium="po1_edium";
export const kPlanSchedPO_po1_ediline="po1_ediline";
export const kPlanSchedPO_docline="docline";
export const kPlanSchedPO_packsize="packsize";
export const kPlanSchedPO_etline_no="etline_no";
export const kPlanSchedPO_fcdate1="fcdate1";
export const kPlanSchedPO_fcdate2="fcdate2";
export const kPlanSchedPO_PSHID="PSHID";
export const kPlanSchedPO_PSIID="PSIID";

/*
        'PlanSchedPO' : {
            'tp_partid' : 'tp_partid',
            'beg_01' : 'beg_01',
            'beg_02' : 'beg_02',
            'beg_03' : 'beg_03',
            'beg_04' : 'beg_04',
            'beg_05' : 'beg_05',
            'beg_06' : 'beg_06',
            'ctt_01' : 'ctt_01',
            'exp_flag' : 'exp_flag',
            'sdq_flag' : 'sdq_flag',
            'cur_02' : 'cur_02',
            'importdate' : 'importdate',
            'exportdate' : 'exportdate',
            'misc_id' : 'misc_id',
            'shiptoid' : 'shiptoid',
            'VPID' : 'VPID',
            'po1_02' : 'po1_02',
            'po1_03' : 'po1_03',
            'po1_04' : 'po1_04',
            'po1_05' : 'po1_05',
            'po1_06' : 'po1_06',
            'po1_07' : 'po1_07',
            'po1_ediqty' : 'po1_ediqty',
            'po1_edium' : 'po1_edium',
            'po1_ediline' : 'po1_ediline',
            'docline' : 'docline',
            'packsize' : 'packsize',
            'etline_no' : 'etline_no',
            'fcdate1' : 'fcdate1',
            'fcdate2' : 'fcdate2',
            'PSHID' : 'PSHID',
            'PSIID' : 'PSIID',        },
*/

export const Label_tp_partid = 'PlanSchedPO.tp_partid';
export const Label_beg_01 = 'PlanSchedPO.beg_01';
export const Label_beg_02 = 'PlanSchedPO.beg_02';
export const Label_beg_03 = 'PlanSchedPO.beg_03';
export const Label_beg_04 = 'PlanSchedPO.beg_04';
export const Label_beg_05 = 'PlanSchedPO.beg_05';
export const Label_beg_06 = 'PlanSchedPO.beg_06';
export const Label_ctt_01 = 'PlanSchedPO.ctt_01';
export const Label_exp_flag = 'PlanSchedPO.exp_flag';
export const Label_sdq_flag = 'PlanSchedPO.sdq_flag';
export const Label_cur_02 = 'PlanSchedPO.cur_02';
export const Label_importdate = 'PlanSchedPO.importdate';
export const Label_exportdate = 'PlanSchedPO.exportdate';
export const Label_misc_id = 'PlanSchedPO.misc_id';
export const Label_shiptoid = 'PlanSchedPO.shiptoid';
export const Label_VPID = 'PlanSchedPO.VPID';
export const Label_po1_02 = 'PlanSchedPO.po1_02';
export const Label_po1_03 = 'PlanSchedPO.po1_03';
export const Label_po1_04 = 'PlanSchedPO.po1_04';
export const Label_po1_05 = 'PlanSchedPO.po1_05';
export const Label_po1_06 = 'PlanSchedPO.po1_06';
export const Label_po1_07 = 'PlanSchedPO.po1_07';
export const Label_po1_ediqty = 'PlanSchedPO.po1_ediqty';
export const Label_po1_edium = 'PlanSchedPO.po1_edium';
export const Label_po1_ediline = 'PlanSchedPO.po1_ediline';
export const Label_docline = 'PlanSchedPO.docline';
export const Label_packsize = 'PlanSchedPO.packsize';
export const Label_etline_no = 'PlanSchedPO.etline_no';
export const Label_fcdate1 = 'PlanSchedPO.fcdate1';
export const Label_fcdate2 = 'PlanSchedPO.fcdate2';
export const Label_PSHID = 'PlanSchedPO.PSHID';
export const Label_PSIID = 'PlanSchedPO.PSIID';
