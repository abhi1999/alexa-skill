import { IApiEdiStandardDescription } from '../edidb'
export class CApiEdiStandardDescription implements IApiEdiStandardDescription {
    public id:string = '';
    public description:string = '';
    public constructor(init?:Partial<CApiEdiStandardDescription>) { Object.assign(this, init); }
}
export const IApiEdiStandardDescription_id_length = 50;
export const IApiEdiStandardDescription_description_length = 65;

export const kApiEdiStandardDescription_id="id";
export const kApiEdiStandardDescription_description="description";

/*
        'ApiEdiStandardDescription' : {
            'id' : 'id',
            'description' : 'description',        },
*/

export const Label_id = 'ApiEdiStandardDescription.id';
export const Label_description = 'ApiEdiStandardDescription.description';
