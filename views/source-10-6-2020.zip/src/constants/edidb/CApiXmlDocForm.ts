import { IApiXmlDocForm } from '../edidb'
export class CApiXmlDocForm implements IApiXmlDocForm {
    public RowNum:number = 0;
    public VPID:number = 0;
    public CreatedDate:Date;
    public Doc_Group:string = '';
    public TP_Name:string = '';
    public Config:boolean;
    public ExportDate:Date;
    public XMLRef:string = '';
    public statuscode:string = '';
    public Status:string = '';
    public directioncode:string = '';
    public Direction:string = '';
    public TP_PartID:string = '';
    public XMLID:string = '';
    public GCN:string = '';
    public TCN:string = '';
    public misc_id:number = 0;
    public DGID:string = '';
    public ackdesc:string = '';
    public HoldID:number = 0;
    public NoteText:string = '';
    public ErrorID:string = '';
    public VPIDFA:number = 0;
    public TLE:number = 0;
    public TLEJump:string = '';
    public constructor(init?:Partial<CApiXmlDocForm>) { Object.assign(this, init); }
}
export const IApiXmlDocForm_Doc_Group_length = 50;
export const IApiXmlDocForm_TP_Name_length = 30;
export const IApiXmlDocForm_XMLRef_length = 1000;
export const IApiXmlDocForm_statuscode_length = 1;
export const IApiXmlDocForm_Status_length = 500;
export const IApiXmlDocForm_directioncode_length = 1;
export const IApiXmlDocForm_Direction_length = 500;
export const IApiXmlDocForm_TP_PartID_length = 30;
export const IApiXmlDocForm_GCN_length = 50;
export const IApiXmlDocForm_TCN_length = 50;
export const IApiXmlDocForm_DGID_length = 5;
export const IApiXmlDocForm_ackdesc_length = 10;
export const IApiXmlDocForm_NoteText_length = 2000;
export const IApiXmlDocForm_ErrorID_length = 50;
export const IApiXmlDocForm_TLEJump_length = 68;

export const kApiXmlDocForm_RowNum="RowNum";
export const kApiXmlDocForm_VPID="VPID";
export const kApiXmlDocForm_CreatedDate="CreatedDate";
export const kApiXmlDocForm_Doc_Group="Doc_Group";
export const kApiXmlDocForm_TP_Name="TP_Name";
export const kApiXmlDocForm_Config="Config";
export const kApiXmlDocForm_ExportDate="ExportDate";
export const kApiXmlDocForm_XMLRef="XMLRef";
export const kApiXmlDocForm_statuscode="statuscode";
export const kApiXmlDocForm_Status="Status";
export const kApiXmlDocForm_directioncode="directioncode";
export const kApiXmlDocForm_Direction="Direction";
export const kApiXmlDocForm_TP_PartID="TP_PartID";
export const kApiXmlDocForm_XMLID="XMLID";
export const kApiXmlDocForm_GCN="GCN";
export const kApiXmlDocForm_TCN="TCN";
export const kApiXmlDocForm_misc_id="misc_id";
export const kApiXmlDocForm_DGID="DGID";
export const kApiXmlDocForm_ackdesc="ackdesc";
export const kApiXmlDocForm_HoldID="HoldID";
export const kApiXmlDocForm_NoteText="NoteText";
export const kApiXmlDocForm_ErrorID="ErrorID";
export const kApiXmlDocForm_VPIDFA="VPIDFA";
export const kApiXmlDocForm_TLE="TLE";
export const kApiXmlDocForm_TLEJump="TLEJump";

/*
        'ApiXmlDocForm' : {
            'RowNum' : 'RowNum',
            'VPID' : 'VPID',
            'CreatedDate' : 'CreatedDate',
            'Doc_Group' : 'Doc_Group',
            'TP_Name' : 'TP_Name',
            'Config' : 'Config',
            'ExportDate' : 'ExportDate',
            'XMLRef' : 'XMLRef',
            'statuscode' : 'statuscode',
            'Status' : 'Status',
            'directioncode' : 'directioncode',
            'Direction' : 'Direction',
            'TP_PartID' : 'TP_PartID',
            'XMLID' : 'XMLID',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'misc_id' : 'misc_id',
            'DGID' : 'DGID',
            'ackdesc' : 'ackdesc',
            'HoldID' : 'HoldID',
            'NoteText' : 'NoteText',
            'ErrorID' : 'ErrorID',
            'VPIDFA' : 'VPIDFA',
            'TLE' : 'TLE',
            'TLEJump' : 'TLEJump',        },
*/

export const Label_RowNum = 'ApiXmlDocForm.RowNum';
export const Label_VPID = 'ApiXmlDocForm.VPID';
export const Label_CreatedDate = 'ApiXmlDocForm.CreatedDate';
export const Label_Doc_Group = 'ApiXmlDocForm.Doc_Group';
export const Label_TP_Name = 'ApiXmlDocForm.TP_Name';
export const Label_Config = 'ApiXmlDocForm.Config';
export const Label_ExportDate = 'ApiXmlDocForm.ExportDate';
export const Label_XMLRef = 'ApiXmlDocForm.XMLRef';
export const Label_statuscode = 'ApiXmlDocForm.statuscode';
export const Label_Status = 'ApiXmlDocForm.Status';
export const Label_directioncode = 'ApiXmlDocForm.directioncode';
export const Label_Direction = 'ApiXmlDocForm.Direction';
export const Label_TP_PartID = 'ApiXmlDocForm.TP_PartID';
export const Label_XMLID = 'ApiXmlDocForm.XMLID';
export const Label_GCN = 'ApiXmlDocForm.GCN';
export const Label_TCN = 'ApiXmlDocForm.TCN';
export const Label_misc_id = 'ApiXmlDocForm.misc_id';
export const Label_DGID = 'ApiXmlDocForm.DGID';
export const Label_ackdesc = 'ApiXmlDocForm.ackdesc';
export const Label_HoldID = 'ApiXmlDocForm.HoldID';
export const Label_NoteText = 'ApiXmlDocForm.NoteText';
export const Label_ErrorID = 'ApiXmlDocForm.ErrorID';
export const Label_VPIDFA = 'ApiXmlDocForm.VPIDFA';
export const Label_TLE = 'ApiXmlDocForm.TLE';
export const Label_TLEJump = 'ApiXmlDocForm.TLEJump';
