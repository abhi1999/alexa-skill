import { IApiExportFedexShipDate } from '../edidb'
export class CApiExportFedexShipDate implements IApiExportFedexShipDate {
    public Asn_ID:number = 0;
    public Bol_No:string = '';
    public Ship_Weight:number = 0;
    public Ship_Date:string = '';
    public Box_ID:number = 0;
    public Order_No:number = 0;
    public Acct_Order_No:string = '';
    public Line_No:number = 0;
    public Ship_To_Name:string = '';
    public Ship_To_Address1:string = '';
    public Ship_To_Address2:string = '';
    public Ship_To_City:string = '';
    public Ship_To_St:string = '';
    public Ship_To_Zip:string = '';
    public Cust_PO:string = '';
    public Int_Item_No:string = '';
    public Item_Desc:string = '';
    public QtyPacked:number = 0;
    public TotalCTNs:number = 0;
    public constructor(init?:Partial<CApiExportFedexShipDate>) { Object.assign(this, init); }
}
export const IApiExportFedexShipDate_Bol_No_length = 30;
export const IApiExportFedexShipDate_Ship_Date_length = 8;
export const IApiExportFedexShipDate_Acct_Order_No_length = 30;
export const IApiExportFedexShipDate_Ship_To_Name_length = 50;
export const IApiExportFedexShipDate_Ship_To_Address1_length = 50;
export const IApiExportFedexShipDate_Ship_To_Address2_length = 50;
export const IApiExportFedexShipDate_Ship_To_City_length = 30;
export const IApiExportFedexShipDate_Ship_To_St_length = 20;
export const IApiExportFedexShipDate_Ship_To_Zip_length = 20;
export const IApiExportFedexShipDate_Cust_PO_length = 30;
export const IApiExportFedexShipDate_Int_Item_No_length = 500;
export const IApiExportFedexShipDate_Item_Desc_length = 80;

export const kApiExportFedexShipDate_Asn_ID="Asn_ID";
export const kApiExportFedexShipDate_Bol_No="Bol_No";
export const kApiExportFedexShipDate_Ship_Weight="Ship_Weight";
export const kApiExportFedexShipDate_Ship_Date="Ship_Date";
export const kApiExportFedexShipDate_Box_ID="Box_ID";
export const kApiExportFedexShipDate_Order_No="Order_No";
export const kApiExportFedexShipDate_Acct_Order_No="Acct_Order_No";
export const kApiExportFedexShipDate_Line_No="Line_No";
export const kApiExportFedexShipDate_Ship_To_Name="Ship_To_Name";
export const kApiExportFedexShipDate_Ship_To_Address1="Ship_To_Address1";
export const kApiExportFedexShipDate_Ship_To_Address2="Ship_To_Address2";
export const kApiExportFedexShipDate_Ship_To_City="Ship_To_City";
export const kApiExportFedexShipDate_Ship_To_St="Ship_To_St";
export const kApiExportFedexShipDate_Ship_To_Zip="Ship_To_Zip";
export const kApiExportFedexShipDate_Cust_PO="Cust_PO";
export const kApiExportFedexShipDate_Int_Item_No="Int_Item_No";
export const kApiExportFedexShipDate_Item_Desc="Item_Desc";
export const kApiExportFedexShipDate_QtyPacked="QtyPacked";
export const kApiExportFedexShipDate_TotalCTNs="TotalCTNs";

/*
        'ApiExportFedexShipDate' : {
            'Asn_ID' : 'Asn_ID',
            'Bol_No' : 'Bol_No',
            'Ship_Weight' : 'Ship_Weight',
            'Ship_Date' : 'Ship_Date',
            'Box_ID' : 'Box_ID',
            'Order_No' : 'Order_No',
            'Acct_Order_No' : 'Acct_Order_No',
            'Line_No' : 'Line_No',
            'Ship_To_Name' : 'Ship_To_Name',
            'Ship_To_Address1' : 'Ship_To_Address1',
            'Ship_To_Address2' : 'Ship_To_Address2',
            'Ship_To_City' : 'Ship_To_City',
            'Ship_To_St' : 'Ship_To_St',
            'Ship_To_Zip' : 'Ship_To_Zip',
            'Cust_PO' : 'Cust_PO',
            'Int_Item_No' : 'Int_Item_No',
            'Item_Desc' : 'Item_Desc',
            'QtyPacked' : 'QtyPacked',
            'TotalCTNs' : 'TotalCTNs',        },
*/

export const Label_Asn_ID = 'ApiExportFedexShipDate.Asn_ID';
export const Label_Bol_No = 'ApiExportFedexShipDate.Bol_No';
export const Label_Ship_Weight = 'ApiExportFedexShipDate.Ship_Weight';
export const Label_Ship_Date = 'ApiExportFedexShipDate.Ship_Date';
export const Label_Box_ID = 'ApiExportFedexShipDate.Box_ID';
export const Label_Order_No = 'ApiExportFedexShipDate.Order_No';
export const Label_Acct_Order_No = 'ApiExportFedexShipDate.Acct_Order_No';
export const Label_Line_No = 'ApiExportFedexShipDate.Line_No';
export const Label_Ship_To_Name = 'ApiExportFedexShipDate.Ship_To_Name';
export const Label_Ship_To_Address1 = 'ApiExportFedexShipDate.Ship_To_Address1';
export const Label_Ship_To_Address2 = 'ApiExportFedexShipDate.Ship_To_Address2';
export const Label_Ship_To_City = 'ApiExportFedexShipDate.Ship_To_City';
export const Label_Ship_To_St = 'ApiExportFedexShipDate.Ship_To_St';
export const Label_Ship_To_Zip = 'ApiExportFedexShipDate.Ship_To_Zip';
export const Label_Cust_PO = 'ApiExportFedexShipDate.Cust_PO';
export const Label_Int_Item_No = 'ApiExportFedexShipDate.Int_Item_No';
export const Label_Item_Desc = 'ApiExportFedexShipDate.Item_Desc';
export const Label_QtyPacked = 'ApiExportFedexShipDate.QtyPacked';
export const Label_TotalCTNs = 'ApiExportFedexShipDate.TotalCTNs';
