import { IApiShipList } from '../edidb'
export class CApiShipList implements IApiShipList {
    public Asn_ID:number = 0;
    public Bol_No:string = '';
    public Pro_No:string = '';
    public ShipToPeps:boolean;
    public Ship_Weight:number = 0;
    public Ship_Date:string = '';
    public Del_Date:string = '';
    public Ship_Via_ID:string = '';
    public Asn_Complete:string = '';
    public Exp_Flag:string = '';
    public TP_PartID:string = '';
    public User1:string = '';
    public User2:string = '';
    public Trailer:string = '';
    public Collect:boolean;
    public AckID:string = '';
    public GCN:string = '';
    public TCN:string = '';
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public SealNo:string = '';
    public ExportDate:Date;
    public CreatedDate:Date;
    public PackImport:string = '';
    public VPIDFA:number = 0;
    public LabelPrinted:boolean;
    public TP_Name:string = '';
    public NoteText:string = '';
    public constructor(init?:Partial<CApiShipList>) { Object.assign(this, init); }
}
export const IApiShipList_Bol_No_length = 30;
export const IApiShipList_Pro_No_length = 30;
export const IApiShipList_Ship_Date_length = 8;
export const IApiShipList_Del_Date_length = 8;
export const IApiShipList_Ship_Via_ID_length = 30;
export const IApiShipList_Asn_Complete_length = 1;
export const IApiShipList_Exp_Flag_length = 1;
export const IApiShipList_TP_PartID_length = 30;
export const IApiShipList_User1_length = 50;
export const IApiShipList_User2_length = 50;
export const IApiShipList_Trailer_length = 50;
export const IApiShipList_AckID_length = 1;
export const IApiShipList_GCN_length = 20;
export const IApiShipList_TCN_length = 20;
export const IApiShipList_User3_length = 50;
export const IApiShipList_User4_length = 50;
export const IApiShipList_User5_length = 50;
export const IApiShipList_SealNo_length = 200;
export const IApiShipList_PackImport_length = 1;
export const IApiShipList_TP_Name_length = 30;
export const IApiShipList_NoteText_length = 2000;

export const kApiShipList_Asn_ID="Asn_ID";
export const kApiShipList_Bol_No="Bol_No";
export const kApiShipList_Pro_No="Pro_No";
export const kApiShipList_ShipToPeps="ShipToPeps";
export const kApiShipList_Ship_Weight="Ship_Weight";
export const kApiShipList_Ship_Date="Ship_Date";
export const kApiShipList_Del_Date="Del_Date";
export const kApiShipList_Ship_Via_ID="Ship_Via_ID";
export const kApiShipList_Asn_Complete="Asn_Complete";
export const kApiShipList_Exp_Flag="Exp_Flag";
export const kApiShipList_TP_PartID="TP_PartID";
export const kApiShipList_User1="User1";
export const kApiShipList_User2="User2";
export const kApiShipList_Trailer="Trailer";
export const kApiShipList_Collect="Collect";
export const kApiShipList_AckID="AckID";
export const kApiShipList_GCN="GCN";
export const kApiShipList_TCN="TCN";
export const kApiShipList_User3="User3";
export const kApiShipList_User4="User4";
export const kApiShipList_User5="User5";
export const kApiShipList_SealNo="SealNo";
export const kApiShipList_ExportDate="ExportDate";
export const kApiShipList_CreatedDate="CreatedDate";
export const kApiShipList_PackImport="PackImport";
export const kApiShipList_VPIDFA="VPIDFA";
export const kApiShipList_LabelPrinted="LabelPrinted";
export const kApiShipList_TP_Name="TP_Name";
export const kApiShipList_NoteText="NoteText";

/*
        'ApiShipList' : {
            'Asn_ID' : 'Asn_ID',
            'Bol_No' : 'Bol_No',
            'Pro_No' : 'Pro_No',
            'ShipToPeps' : 'ShipToPeps',
            'Ship_Weight' : 'Ship_Weight',
            'Ship_Date' : 'Ship_Date',
            'Del_Date' : 'Del_Date',
            'Ship_Via_ID' : 'Ship_Via_ID',
            'Asn_Complete' : 'Asn_Complete',
            'Exp_Flag' : 'Exp_Flag',
            'TP_PartID' : 'TP_PartID',
            'User1' : 'User1',
            'User2' : 'User2',
            'Trailer' : 'Trailer',
            'Collect' : 'Collect',
            'AckID' : 'AckID',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'SealNo' : 'SealNo',
            'ExportDate' : 'ExportDate',
            'CreatedDate' : 'CreatedDate',
            'PackImport' : 'PackImport',
            'VPIDFA' : 'VPIDFA',
            'LabelPrinted' : 'LabelPrinted',
            'TP_Name' : 'TP_Name',
            'NoteText' : 'NoteText',        },
*/

export const Label_Asn_ID = 'ApiShipList.Asn_ID';
export const Label_Bol_No = 'ApiShipList.Bol_No';
export const Label_Pro_No = 'ApiShipList.Pro_No';
export const Label_ShipToPeps = 'ApiShipList.ShipToPeps';
export const Label_Ship_Weight = 'ApiShipList.Ship_Weight';
export const Label_Ship_Date = 'ApiShipList.Ship_Date';
export const Label_Del_Date = 'ApiShipList.Del_Date';
export const Label_Ship_Via_ID = 'ApiShipList.Ship_Via_ID';
export const Label_Asn_Complete = 'ApiShipList.Asn_Complete';
export const Label_Exp_Flag = 'ApiShipList.Exp_Flag';
export const Label_TP_PartID = 'ApiShipList.TP_PartID';
export const Label_User1 = 'ApiShipList.User1';
export const Label_User2 = 'ApiShipList.User2';
export const Label_Trailer = 'ApiShipList.Trailer';
export const Label_Collect = 'ApiShipList.Collect';
export const Label_AckID = 'ApiShipList.AckID';
export const Label_GCN = 'ApiShipList.GCN';
export const Label_TCN = 'ApiShipList.TCN';
export const Label_User3 = 'ApiShipList.User3';
export const Label_User4 = 'ApiShipList.User4';
export const Label_User5 = 'ApiShipList.User5';
export const Label_SealNo = 'ApiShipList.SealNo';
export const Label_ExportDate = 'ApiShipList.ExportDate';
export const Label_CreatedDate = 'ApiShipList.CreatedDate';
export const Label_PackImport = 'ApiShipList.PackImport';
export const Label_VPIDFA = 'ApiShipList.VPIDFA';
export const Label_LabelPrinted = 'ApiShipList.LabelPrinted';
export const Label_TP_Name = 'ApiShipList.TP_Name';
export const Label_NoteText = 'ApiShipList.NoteText';
