import { IPackAndShipShipmentListSelectAsn as IPackAndShipShipmentList } from '../edidb'
export class CPackAndShipShipmentList  implements IPackAndShipShipmentList {
  
  public Asn_ID: number = 0;
  public Bol_No: string = "";
  public Pro_No: string = "";
  public Ship_Date?: Date = undefined;  

  public TP_PartID: string = ""; 
  public TP_Name: string = "";  
  public NoteText: string = "";  

  public constructor(init?: Partial<CPackAndShipShipmentList>) { Object.assign(this, init); }
}

export const IPackAndShipShipmentList_Asn_ID_length = 30;
export const IPackAndShipShipmentList_Bol_No_length = 30;
export const IPackAndShipShipmentList_Pro_No_length = 30;
export const IPackAndShipShipmentList_Ship_Date_length = 8;
export const IPackAndShipShipmentList_TP_PartID_length = 30;
export const IPackAndShipShipmentList_TP_Name_length = 30;
export const IPackAndShipShipmentList_NoteText_length = 100;

export const kPackAndShipShipmentList_Asn_ID = 'Asn_ID';
export const kPackAndShipShipmentList_Bol_No = 'Bol_No';
export const kPackAndShipShipmentList_Pro_No = 'Pro_No';
export const kPackAndShipShipmentList_Ship_Date = 'Ship_Date';
export const kPackAndShipShipmentList_TP_PartID = 'TP_PartID';
export const kPackAndShipShipmentList_TP_Name = 'TP_Name';
export const kPackAndShipShipmentList_NoteText = 'NoteText';

export const Label_Asn_ID = 'PackAndShip.Asn_ID';
export const Label_Bol_No = 'PackAndShip.Bol_No';
export const Label_Pro_No = 'PackAndShip.Pro_No';
export const Label_Ship_Date = 'PackAndShip.Ship_Date';
export const Label_TP_PartID = 'PackAndShip.TP_PartID';
export const Label_TP_Name = 'PackAndShip.TP_Name';
export const Label_NoteText = 'PackAndShip.NoteText';

