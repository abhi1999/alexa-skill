import { IApiOsnBaseView } from '../edidb'
export class CApiOsnBaseView implements IApiOsnBaseView {
    public Asn_ID:number = 0;
    public TP_Name:string = '';
    public Bol_No:string = '';
    public Asn_Complete:string = '';
    public Exp_Flag:string = '';
    public GCN:number = 0;
    public TCN:number = 0;
    public AckDesc:string = '';
    public HoldID:number = 0;
    public NoteText:string = '';
    public ErrorID:string = '';
    public Ship_Date:string = '';
    public TLE:number = 0;
    public VPIDFA:number = 0;
    public TP_PartID:string = '';
    public constructor(init?:Partial<CApiOsnBaseView>) { Object.assign(this, init); }
}
export const IApiOsnBaseView_TP_Name_length = 30;
export const IApiOsnBaseView_Bol_No_length = 30;
export const IApiOsnBaseView_Asn_Complete_length = 1;
export const IApiOsnBaseView_Exp_Flag_length = 1;
export const IApiOsnBaseView_AckDesc_length = 10;
export const IApiOsnBaseView_NoteText_length = 2000;
export const IApiOsnBaseView_ErrorID_length = 50;
export const IApiOsnBaseView_Ship_Date_length = 8;
export const IApiOsnBaseView_TP_PartID_length = 30;

export const kApiOsnBaseView_Asn_ID="Asn_ID";
export const kApiOsnBaseView_TP_Name="TP_Name";
export const kApiOsnBaseView_Bol_No="Bol_No";
export const kApiOsnBaseView_Asn_Complete="Asn_Complete";
export const kApiOsnBaseView_Exp_Flag="Exp_Flag";
export const kApiOsnBaseView_GCN="GCN";
export const kApiOsnBaseView_TCN="TCN";
export const kApiOsnBaseView_AckDesc="AckDesc";
export const kApiOsnBaseView_HoldID="HoldID";
export const kApiOsnBaseView_NoteText="NoteText";
export const kApiOsnBaseView_ErrorID="ErrorID";
export const kApiOsnBaseView_Ship_Date="Ship_Date";
export const kApiOsnBaseView_TLE="TLE";
export const kApiOsnBaseView_VPIDFA="VPIDFA";
export const kApiOsnBaseView_TP_PartID="TP_PartID";

/*
        'ApiOsnBaseView' : {
            'Asn_ID' : 'Asn_ID',
            'TP_Name' : 'TP_Name',
            'Bol_No' : 'Bol_No',
            'Asn_Complete' : 'Asn_Complete',
            'Exp_Flag' : 'Exp_Flag',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'AckDesc' : 'AckDesc',
            'HoldID' : 'HoldID',
            'NoteText' : 'NoteText',
            'ErrorID' : 'ErrorID',
            'Ship_Date' : 'Ship_Date',
            'TLE' : 'TLE',
            'VPIDFA' : 'VPIDFA',
            'TP_PartID' : 'TP_PartID',        },
*/

export const Label_Asn_ID = 'ApiOsnBaseView.Asn_ID';
export const Label_TP_Name = 'ApiOsnBaseView.TP_Name';
export const Label_Bol_No = 'ApiOsnBaseView.Bol_No';
export const Label_Asn_Complete = 'ApiOsnBaseView.Asn_Complete';
export const Label_Exp_Flag = 'ApiOsnBaseView.Exp_Flag';
export const Label_GCN = 'ApiOsnBaseView.GCN';
export const Label_TCN = 'ApiOsnBaseView.TCN';
export const Label_AckDesc = 'ApiOsnBaseView.AckDesc';
export const Label_HoldID = 'ApiOsnBaseView.HoldID';
export const Label_NoteText = 'ApiOsnBaseView.NoteText';
export const Label_ErrorID = 'ApiOsnBaseView.ErrorID';
export const Label_Ship_Date = 'ApiOsnBaseView.Ship_Date';
export const Label_TLE = 'ApiOsnBaseView.TLE';
export const Label_VPIDFA = 'ApiOsnBaseView.VPIDFA';
export const Label_TP_PartID = 'ApiOsnBaseView.TP_PartID';
