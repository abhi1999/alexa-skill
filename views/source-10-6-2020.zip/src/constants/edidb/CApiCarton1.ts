import { IApiCarton1 } from '../edidb'
export class CApiCarton1 implements IApiCarton1 {
    public Asn_ID:number = 0;
    public Box_ID:number = 0;
    public Pack_Level:number = 0;
    public TrackingNo:string = '';
    public SSCC:string = '';
    public PKG_ID:string = '';
    public Pack_Wt:string = '';
    public constructor(init?:Partial<CApiCarton1>) { Object.assign(this, init); }
}
export const IApiCarton1_TrackingNo_length = 50;
export const IApiCarton1_SSCC_length = 30;
export const IApiCarton1_PKG_ID_length = 10;
export const IApiCarton1_Pack_Wt_length = 8000;

export const kApiCarton1_Asn_ID="Asn_ID";
export const kApiCarton1_Box_ID="Box_ID";
export const kApiCarton1_Pack_Level="Pack_Level";
export const kApiCarton1_TrackingNo="TrackingNo";
export const kApiCarton1_SSCC="SSCC";
export const kApiCarton1_PKG_ID="PKG_ID";
export const kApiCarton1_Pack_Wt="Pack_Wt";

/*
        'ApiCarton1' : {
            'Asn_ID' : 'Asn_ID',
            'Box_ID' : 'Box_ID',
            'Pack_Level' : 'Pack_Level',
            'TrackingNo' : 'TrackingNo',
            'SSCC' : 'SSCC',
            'PKG_ID' : 'PKG_ID',
            'Pack_Wt' : 'Pack_Wt',        },
*/

export const Label_Asn_ID = 'ApiCarton1.Asn_ID';
export const Label_Box_ID = 'ApiCarton1.Box_ID';
export const Label_Pack_Level = 'ApiCarton1.Pack_Level';
export const Label_TrackingNo = 'ApiCarton1.TrackingNo';
export const Label_SSCC = 'ApiCarton1.SSCC';
export const Label_PKG_ID = 'ApiCarton1.PKG_ID';
export const Label_Pack_Wt = 'ApiCarton1.Pack_Wt';
