import { IAuditDetail } from '../edidb'
export class CAuditDetail implements IAuditDetail {
  
  public AuditDetailID:number = 0;
  public AuditID:number = 0;
  public FieldName:string = '';
  public OldValue:string = '';
  public NewValue:string = '';
  
  public constructor(init?:Partial<CAuditDetail>) { Object.assign(this, init); }
}

export const IAuditDetail_AuditDetailID_length = 30;
export const IAuditDetail_AuditID_length = 30;
export const IAuditDetail_FieldName_length = 50;
export const IAuditDetail_OldValue_length = 50;
export const IAuditDetail_NewValue_length = 50;

export const kAuditDetail_AuditDetailID = 'AuditDetailID';
export const kAuditDetail_AuditID = 'AuditID';
export const kAuditDetail_FieldName = 'FieldName';
export const kAuditDetail_OldValue = 'OldValue';
export const kAuditDetail_NewValue = 'NewValue';

export const Label_AuditDetailID = 'AuditViewer.AuditDetailID';
export const Label_AuditID = 'AuditViewer.AuditID';
export const Label_FieldName = 'AuditViewer.FieldName';
export const Label_OldValue = 'AuditViewer.OldValue';
export const Label_NewValue = 'AuditViewer.NewValue';

