import { IEDIStdElement } from '../edidb'
export class CEDIStdElement implements IEDIStdElement {
    public Std_ID:string = '';
    public Rel_No:string = '';
    public Seg_ID:string = '';
    public Elem_No:string = '';
    public Elem_Desc:string = '';
    public Elem_ID:string = '';
    public Elem_Type:string = '';
    public Group_ID:string = '';
    public SEID:string = '';
    public constructor(init?:Partial<CEDIStdElement>) { Object.assign(this, init); }
}
export const IEDIStdElement_Std_ID_length = 20;
export const IEDIStdElement_Rel_No_length = 20;
export const IEDIStdElement_Seg_ID_length = 20;
export const IEDIStdElement_Elem_No_length = 6;
export const IEDIStdElement_Elem_Desc_length = 65;
export const IEDIStdElement_Elem_ID_length = 5;
export const IEDIStdElement_Elem_Type_length = 2;
export const IEDIStdElement_Group_ID_length = 5;

export const kEDIStdElement_Std_ID="Std_ID";
export const kEDIStdElement_Rel_No="Rel_No";
export const kEDIStdElement_Seg_ID="Seg_ID";
export const kEDIStdElement_Elem_No="Elem_No";
export const kEDIStdElement_Elem_Desc="Elem_Desc";
export const kEDIStdElement_Elem_ID="Elem_ID";
export const kEDIStdElement_Elem_Type="Elem_Type";
export const kEDIStdElement_Group_ID="Group_ID";
export const kEDIStdElement_SEID="SEID";

/*
        'EDIStdElement' : {
            'Std_ID' : 'Std_ID',
            'Rel_No' : 'Rel_No',
            'Seg_ID' : 'Seg_ID',
            'Elem_No' : 'Elem_No',
            'Elem_Desc' : 'Elem_Desc',
            'Elem_ID' : 'Elem_ID',
            'Elem_Type' : 'Elem_Type',
            'Group_ID' : 'Group_ID',
            'SEID' : 'SEID',
        },
*/

export const Label_Std_ID = 'EDIStdElement.Std_ID';
export const Label_Rel_No = 'EDIStdElement.Rel_No';
export const Label_Seg_ID = 'EDIStdElement.Seg_ID';
export const Label_Elem_No = 'EDIStdElement.Elem_No';
export const Label_Elem_Desc = 'EDIStdElement.Elem_Desc';
export const Label_Elem_ID = 'EDIStdElement.Elem_ID';
export const Label_Elem_Type = 'EDIStdElement.Elem_Type';
export const Label_Group_ID = 'EDIStdElement.Group_ID';
export const Label_SEID = 'EDIStdElement.SEID';
