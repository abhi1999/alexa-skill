import { IApiCumulativeQuantity } from '../edidb'
export class CApiCumulativeQuantity implements IApiCumulativeQuantity {
    public TP_PartID:string = '';
    public cusno:string = '';
    public TP_Name:string = '';
    public TP_ID:string = '';
    public shiptoid:string = '';
    public ShipTo_Name:string = '';
    public itemid:string = '';
    public purchaseorderno:string = '';
    public cmqty:number = 0;
    public constructor(init?:Partial<CApiCumulativeQuantity>) { Object.assign(this, init); }
}
export const IApiCumulativeQuantity_TP_PartID_length = 30;
export const IApiCumulativeQuantity_cusno_length = 100;
export const IApiCumulativeQuantity_TP_Name_length = 30;
export const IApiCumulativeQuantity_TP_ID_length = 100;
export const IApiCumulativeQuantity_shiptoid_length = 80;
export const IApiCumulativeQuantity_ShipTo_Name_length = 80;
export const IApiCumulativeQuantity_itemid_length = 500;
export const IApiCumulativeQuantity_purchaseorderno_length = 30;

export const kApiCumulativeQuantity_TP_PartID="TP_PartID";
export const kApiCumulativeQuantity_cusno="cusno";
export const kApiCumulativeQuantity_TP_Name="TP_Name";
export const kApiCumulativeQuantity_TP_ID="TP_ID";
export const kApiCumulativeQuantity_shiptoid="shiptoid";
export const kApiCumulativeQuantity_ShipTo_Name="ShipTo_Name";
export const kApiCumulativeQuantity_itemid="itemid";
export const kApiCumulativeQuantity_purchaseorderno="purchaseorderno";
export const kApiCumulativeQuantity_cmqty="cmqty";

/*
        'ApiCumulativeQuantity' : {
            'TP_PartID' : 'TP_PartID',
            'cusno' : 'cusno',
            'TP_Name' : 'TP_Name',
            'shiptoid' : 'shiptoid',
            'ShipTo_Name' : 'ShipTo_Name',
            'itemid' : 'itemid',
            'purchaseorderno' : 'purchaseorderno',
            'cmqty' : 'cmqty',
        },
*/

export const Label_TP_PartID = 'ApiCumulativeQuantity.TP_PartID';
export const Label_cusno = 'ApiCumulativeQuantity.cusno';
export const Label_TP_Name = 'ApiCumulativeQuantity.TP_Name';
export const Label_TP_ID = 'ApiCumulativeQuantity.TP_ID';
export const Label_shiptoid = 'ApiCumulativeQuantity.shiptoid';
export const Label_ShipTo_Name = 'ApiCumulativeQuantity.ShipTo_Name';
export const Label_itemid = 'ApiCumulativeQuantity.itemid';
export const Label_purchaseorderno = 'ApiCumulativeQuantity.purchaseorderno';
export const Label_cmqty = 'ApiCumulativeQuantity.cmqty';
