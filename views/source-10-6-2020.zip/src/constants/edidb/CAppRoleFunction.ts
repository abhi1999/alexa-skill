import { IAppRoleFunction } from '../edidb'
export class CAppRoleFunction implements IAppRoleFunction {
    public id:number = 0;
    public RoleID:number = 0;
    public RoleCode:string = '';
    public constructor(init?:Partial<CAppRoleFunction>) { Object.assign(this, init); }
}
export const IAppRoleFunction_RoleCode_length = 3;

export const kAppRoleFunction_id="id";
export const kAppRoleFunction_RoleID="RoleID";
export const kAppRoleFunction_RoleCode="RoleCode";

/*
        'AppRoleFunction' : {
            'id' : 'id',
            'RoleID' : 'RoleID',
            'RoleCode' : 'RoleCode',        },
*/

export const Label_id = 'AppRoleFunction.id';
export const Label_RoleID = 'AppRoleFunction.RoleID';
export const Label_RoleCode = 'AppRoleFunction.RoleCode';
