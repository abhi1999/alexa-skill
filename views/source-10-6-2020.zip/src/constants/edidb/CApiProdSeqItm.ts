import { IApiProdSeqItm } from '../edidb'
export class CApiProdSeqItm implements IApiProdSeqItm {
    public PSIID:string = '';
    public PSHID:string = '';
    public VPID:number = 0;
    public processtype:string = '';
    public processdate:Date;
    public itmdocline:number = 0;
    public fcdocline:number = 0;
    public fcqual:string = '';
    public fctqual:string = '';
    public fcqty:number = 0;
    public fcdate1:string = '';
    public fcdate2:string = '';
    public fcdtqual:string = '';
    public fcdtid:string = '';
    public itemuom:string = '';
    public importdate:Date;
    public status:string = '';
    public price:number = 0;
    public custitemno:string = '';
    public po:string = '';
    public poline:string = '';
    public shipto:string = '';
    public shipfrom:string = '';
    public supplier:string = '';
    public psdoctype:string = '';
    public tp_partid:string = '';
    public tp_id:string = '';
    public releaseno:string = '';
    public dlvdate:string = '';
    public shipdate:string = '';
    public dock:string = '';
    public linefeed:string = '';
    public vin:string = '';
    public jobseqno:string = '';
    public jobno:string = '';
    public laborgrp:string = '';
    public commodity:string = '';
    public linesetno:string = '';
    public storageid:string = '';
    public assembly:string = '';
    public engchg:string = '';
    public chassissn:string = '';
    public color:string = '';
    public position:string = '';
    public ctlno:string = '';
    public producttype:string = '';
    public kanban:string = '';
    public custorderno:string = '';
    public proddesc:string = '';
    public pscreatedate:string = '';
    public GSSenderID:string = '';
    public Expr1:number = 0;
    public Expr2:string = '';
    public Expr3:string = '';
    public Expr4:string = '';
    public tspurposecode:string = '';
    public pstypequal:string = '';
    public psqtyqual:string = '';
    public pstypecode:string = '';
    public purchaseorder:string = '';
    public Expr5:string = '';
    public contractno:string = '';
    public hrznstartdate:string = '';
    public hrznenddate:string = '';
    public Expr6:string = '';
    public psupddate:string = '';
    public hdrdocline:number = 0;
    public XMLID:string = '';
    public CreatedDate:Date;
    public Expr7:string = '';
    public DGID:string = '';
    public Config:boolean;
    public URECID:string = '';
    public Exp_Flag:string = '';
    public ExportDate:Date;
    public XMLText:string = '';
    public Expr8:string = '';
    public Misc_ID:number = 0;
    public XMLRef:string = '';
    public GCN:string = '';
    public TCN:string = '';
    public Direction:string = '';
    public Expr9:number = 0;
    public AckID:string = '';
    public VPIDFA:number = 0;
    public constructor(init?:Partial<CApiProdSeqItm>) { Object.assign(this, init); }
}
export const IApiProdSeqItm_processtype_length = 2;
export const IApiProdSeqItm_fcqual_length = 1;
export const IApiProdSeqItm_fctqual_length = 1;
export const IApiProdSeqItm_fcdate1_length = 8;
export const IApiProdSeqItm_fcdate2_length = 8;
export const IApiProdSeqItm_fcdtqual_length = 3;
export const IApiProdSeqItm_fcdtid_length = 8;
export const IApiProdSeqItm_itemuom_length = 10;
export const IApiProdSeqItm_status_length = 1;
export const IApiProdSeqItm_custitemno_length = 30;
export const IApiProdSeqItm_po_length = 30;
export const IApiProdSeqItm_poline_length = 10;
export const IApiProdSeqItm_shipto_length = 30;
export const IApiProdSeqItm_shipfrom_length = 30;
export const IApiProdSeqItm_supplier_length = 30;
export const IApiProdSeqItm_psdoctype_length = 2;
export const IApiProdSeqItm_tp_partid_length = 30;
export const IApiProdSeqItm_tp_id_length = 15;
export const IApiProdSeqItm_releaseno_length = 30;
export const IApiProdSeqItm_dlvdate_length = 8;
export const IApiProdSeqItm_shipdate_length = 8;
export const IApiProdSeqItm_dock_length = 30;
export const IApiProdSeqItm_linefeed_length = 30;
export const IApiProdSeqItm_vin_length = 30;
export const IApiProdSeqItm_jobseqno_length = 30;
export const IApiProdSeqItm_jobno_length = 30;
export const IApiProdSeqItm_laborgrp_length = 30;
export const IApiProdSeqItm_commodity_length = 30;
export const IApiProdSeqItm_linesetno_length = 30;
export const IApiProdSeqItm_storageid_length = 30;
export const IApiProdSeqItm_assembly_length = 30;
export const IApiProdSeqItm_engchg_length = 30;
export const IApiProdSeqItm_chassissn_length = 30;
export const IApiProdSeqItm_color_length = 30;
export const IApiProdSeqItm_position_length = 30;
export const IApiProdSeqItm_ctlno_length = 30;
export const IApiProdSeqItm_producttype_length = 30;
export const IApiProdSeqItm_kanban_length = 30;
export const IApiProdSeqItm_custorderno_length = 50;
export const IApiProdSeqItm_proddesc_length = 50;
export const IApiProdSeqItm_pscreatedate_length = 30;
export const IApiProdSeqItm_GSSenderID_length = 50;
export const IApiProdSeqItm_Expr3_length = 30;
export const IApiProdSeqItm_Expr4_length = 2;
export const IApiProdSeqItm_tspurposecode_length = 2;
export const IApiProdSeqItm_pstypequal_length = 2;
export const IApiProdSeqItm_psqtyqual_length = 1;
export const IApiProdSeqItm_pstypecode_length = 2;
export const IApiProdSeqItm_purchaseorder_length = 30;
export const IApiProdSeqItm_Expr5_length = 30;
export const IApiProdSeqItm_contractno_length = 30;
export const IApiProdSeqItm_hrznstartdate_length = 8;
export const IApiProdSeqItm_hrznenddate_length = 8;
export const IApiProdSeqItm_Expr6_length = 8;
export const IApiProdSeqItm_psupddate_length = 8;
export const IApiProdSeqItm_Expr7_length = 30;
export const IApiProdSeqItm_DGID_length = 5;
export const IApiProdSeqItm_Exp_Flag_length = 1;
export const IApiProdSeqItm_XMLText_length = 1073741823;
export const IApiProdSeqItm_XMLRef_length = 1000;
export const IApiProdSeqItm_GCN_length = 50;
export const IApiProdSeqItm_TCN_length = 50;
export const IApiProdSeqItm_Direction_length = 1;
export const IApiProdSeqItm_AckID_length = 10;

export const kApiProdSeqItm_PSIID="PSIID";
export const kApiProdSeqItm_PSHID="PSHID";
export const kApiProdSeqItm_VPID="VPID";
export const kApiProdSeqItm_processtype="processtype";
export const kApiProdSeqItm_processdate="processdate";
export const kApiProdSeqItm_itmdocline="itmdocline";
export const kApiProdSeqItm_fcdocline="fcdocline";
export const kApiProdSeqItm_fcqual="fcqual";
export const kApiProdSeqItm_fctqual="fctqual";
export const kApiProdSeqItm_fcqty="fcqty";
export const kApiProdSeqItm_fcdate1="fcdate1";
export const kApiProdSeqItm_fcdate2="fcdate2";
export const kApiProdSeqItm_fcdtqual="fcdtqual";
export const kApiProdSeqItm_fcdtid="fcdtid";
export const kApiProdSeqItm_itemuom="itemuom";
export const kApiProdSeqItm_importdate="importdate";
export const kApiProdSeqItm_status="status";
export const kApiProdSeqItm_price="price";
export const kApiProdSeqItm_custitemno="custitemno";
export const kApiProdSeqItm_po="po";
export const kApiProdSeqItm_poline="poline";
export const kApiProdSeqItm_shipto="shipto";
export const kApiProdSeqItm_shipfrom="shipfrom";
export const kApiProdSeqItm_supplier="supplier";
export const kApiProdSeqItm_psdoctype="psdoctype";
export const kApiProdSeqItm_tp_partid="tp_partid";
export const kApiProdSeqItm_tp_id="tp_id";
export const kApiProdSeqItm_releaseno="releaseno";
export const kApiProdSeqItm_dlvdate="dlvdate";
export const kApiProdSeqItm_shipdate="shipdate";
export const kApiProdSeqItm_dock="dock";
export const kApiProdSeqItm_linefeed="linefeed";
export const kApiProdSeqItm_vin="vin";
export const kApiProdSeqItm_jobseqno="jobseqno";
export const kApiProdSeqItm_jobno="jobno";
export const kApiProdSeqItm_laborgrp="laborgrp";
export const kApiProdSeqItm_commodity="commodity";
export const kApiProdSeqItm_linesetno="linesetno";
export const kApiProdSeqItm_storageid="storageid";
export const kApiProdSeqItm_assembly="assembly";
export const kApiProdSeqItm_engchg="engchg";
export const kApiProdSeqItm_chassissn="chassissn";
export const kApiProdSeqItm_color="color";
export const kApiProdSeqItm_position="position";
export const kApiProdSeqItm_ctlno="ctlno";
export const kApiProdSeqItm_producttype="producttype";
export const kApiProdSeqItm_kanban="kanban";
export const kApiProdSeqItm_custorderno="custorderno";
export const kApiProdSeqItm_proddesc="proddesc";
export const kApiProdSeqItm_pscreatedate="pscreatedate";
export const kApiProdSeqItm_GSSenderID="GSSenderID";
export const kApiProdSeqItm_Expr1="Expr1";
export const kApiProdSeqItm_Expr2="Expr2";
export const kApiProdSeqItm_Expr3="Expr3";
export const kApiProdSeqItm_Expr4="Expr4";
export const kApiProdSeqItm_tspurposecode="tspurposecode";
export const kApiProdSeqItm_pstypequal="pstypequal";
export const kApiProdSeqItm_psqtyqual="psqtyqual";
export const kApiProdSeqItm_pstypecode="pstypecode";
export const kApiProdSeqItm_purchaseorder="purchaseorder";
export const kApiProdSeqItm_Expr5="Expr5";
export const kApiProdSeqItm_contractno="contractno";
export const kApiProdSeqItm_hrznstartdate="hrznstartdate";
export const kApiProdSeqItm_hrznenddate="hrznenddate";
export const kApiProdSeqItm_Expr6="Expr6";
export const kApiProdSeqItm_psupddate="psupddate";
export const kApiProdSeqItm_hdrdocline="hdrdocline";
export const kApiProdSeqItm_XMLID="XMLID";
export const kApiProdSeqItm_CreatedDate="CreatedDate";
export const kApiProdSeqItm_Expr7="Expr7";
export const kApiProdSeqItm_DGID="DGID";
export const kApiProdSeqItm_Config="Config";
export const kApiProdSeqItm_URECID="URECID";
export const kApiProdSeqItm_Exp_Flag="Exp_Flag";
export const kApiProdSeqItm_ExportDate="ExportDate";
export const kApiProdSeqItm_XMLText="XMLText";
export const kApiProdSeqItm_Expr8="Expr8";
export const kApiProdSeqItm_Misc_ID="Misc_ID";
export const kApiProdSeqItm_XMLRef="XMLRef";
export const kApiProdSeqItm_GCN="GCN";
export const kApiProdSeqItm_TCN="TCN";
export const kApiProdSeqItm_Direction="Direction";
export const kApiProdSeqItm_Expr9="Expr9";
export const kApiProdSeqItm_AckID="AckID";
export const kApiProdSeqItm_VPIDFA="VPIDFA";

/*
        'ApiProdSeqItm' : {
            'PSIID' : 'PSIID',
            'PSHID' : 'PSHID',
            'VPID' : 'VPID',
            'processtype' : 'processtype',
            'processdate' : 'processdate',
            'itmdocline' : 'itmdocline',
            'fcdocline' : 'fcdocline',
            'fcqual' : 'fcqual',
            'fctqual' : 'fctqual',
            'fcqty' : 'fcqty',
            'fcdate1' : 'fcdate1',
            'fcdate2' : 'fcdate2',
            'fcdtqual' : 'fcdtqual',
            'fcdtid' : 'fcdtid',
            'itemuom' : 'itemuom',
            'importdate' : 'importdate',
            'status' : 'status',
            'price' : 'price',
            'custitemno' : 'custitemno',
            'po' : 'po',
            'poline' : 'poline',
            'shipto' : 'shipto',
            'shipfrom' : 'shipfrom',
            'supplier' : 'supplier',
            'psdoctype' : 'psdoctype',
            'tp_partid' : 'tp_partid',
            'tp_id' : 'tp_id',
            'releaseno' : 'releaseno',
            'dlvdate' : 'dlvdate',
            'shipdate' : 'shipdate',
            'dock' : 'dock',
            'linefeed' : 'linefeed',
            'vin' : 'vin',
            'jobseqno' : 'jobseqno',
            'jobno' : 'jobno',
            'laborgrp' : 'laborgrp',
            'commodity' : 'commodity',
            'linesetno' : 'linesetno',
            'storageid' : 'storageid',
            'assembly' : 'assembly',
            'engchg' : 'engchg',
            'chassissn' : 'chassissn',
            'color' : 'color',
            'position' : 'position',
            'ctlno' : 'ctlno',
            'producttype' : 'producttype',
            'kanban' : 'kanban',
            'custorderno' : 'custorderno',
            'proddesc' : 'proddesc',
            'pscreatedate' : 'pscreatedate',
            'GSSenderID' : 'GSSenderID',
            'Expr1' : 'Expr1',
            'Expr2' : 'Expr2',
            'Expr3' : 'Expr3',
            'Expr4' : 'Expr4',
            'tspurposecode' : 'tspurposecode',
            'pstypequal' : 'pstypequal',
            'psqtyqual' : 'psqtyqual',
            'pstypecode' : 'pstypecode',
            'purchaseorder' : 'purchaseorder',
            'Expr5' : 'Expr5',
            'contractno' : 'contractno',
            'hrznstartdate' : 'hrznstartdate',
            'hrznenddate' : 'hrznenddate',
            'Expr6' : 'Expr6',
            'psupddate' : 'psupddate',
            'hdrdocline' : 'hdrdocline',
            'XMLID' : 'XMLID',
            'CreatedDate' : 'CreatedDate',
            'Expr7' : 'Expr7',
            'DGID' : 'DGID',
            'Config' : 'Config',
            'URECID' : 'URECID',
            'Exp_Flag' : 'Exp_Flag',
            'ExportDate' : 'ExportDate',
            'XMLText' : 'XMLText',
            'Expr8' : 'Expr8',
            'Misc_ID' : 'Misc_ID',
            'XMLRef' : 'XMLRef',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'Direction' : 'Direction',
            'Expr9' : 'Expr9',
            'AckID' : 'AckID',
            'VPIDFA' : 'VPIDFA',        },
*/

export const Label_PSIID = 'ApiProdSeqItm.PSIID';
export const Label_PSHID = 'ApiProdSeqItm.PSHID';
export const Label_VPID = 'ApiProdSeqItm.VPID';
export const Label_processtype = 'ApiProdSeqItm.processtype';
export const Label_processdate = 'ApiProdSeqItm.processdate';
export const Label_itmdocline = 'ApiProdSeqItm.itmdocline';
export const Label_fcdocline = 'ApiProdSeqItm.fcdocline';
export const Label_fcqual = 'ApiProdSeqItm.fcqual';
export const Label_fctqual = 'ApiProdSeqItm.fctqual';
export const Label_fcqty = 'ApiProdSeqItm.fcqty';
export const Label_fcdate1 = 'ApiProdSeqItm.fcdate1';
export const Label_fcdate2 = 'ApiProdSeqItm.fcdate2';
export const Label_fcdtqual = 'ApiProdSeqItm.fcdtqual';
export const Label_fcdtid = 'ApiProdSeqItm.fcdtid';
export const Label_itemuom = 'ApiProdSeqItm.itemuom';
export const Label_importdate = 'ApiProdSeqItm.importdate';
export const Label_status = 'ApiProdSeqItm.status';
export const Label_price = 'ApiProdSeqItm.price';
export const Label_custitemno = 'ApiProdSeqItm.custitemno';
export const Label_po = 'ApiProdSeqItm.po';
export const Label_poline = 'ApiProdSeqItm.poline';
export const Label_shipto = 'ApiProdSeqItm.shipto';
export const Label_shipfrom = 'ApiProdSeqItm.shipfrom';
export const Label_supplier = 'ApiProdSeqItm.supplier';
export const Label_psdoctype = 'ApiProdSeqItm.psdoctype';
export const Label_tp_partid = 'ApiProdSeqItm.tp_partid';
export const Label_tp_id = 'ApiProdSeqItm.tp_id';
export const Label_releaseno = 'ApiProdSeqItm.releaseno';
export const Label_dlvdate = 'ApiProdSeqItm.dlvdate';
export const Label_shipdate = 'ApiProdSeqItm.shipdate';
export const Label_dock = 'ApiProdSeqItm.dock';
export const Label_linefeed = 'ApiProdSeqItm.linefeed';
export const Label_vin = 'ApiProdSeqItm.vin';
export const Label_jobseqno = 'ApiProdSeqItm.jobseqno';
export const Label_jobno = 'ApiProdSeqItm.jobno';
export const Label_laborgrp = 'ApiProdSeqItm.laborgrp';
export const Label_commodity = 'ApiProdSeqItm.commodity';
export const Label_linesetno = 'ApiProdSeqItm.linesetno';
export const Label_storageid = 'ApiProdSeqItm.storageid';
export const Label_assembly = 'ApiProdSeqItm.assembly';
export const Label_engchg = 'ApiProdSeqItm.engchg';
export const Label_chassissn = 'ApiProdSeqItm.chassissn';
export const Label_color = 'ApiProdSeqItm.color';
export const Label_position = 'ApiProdSeqItm.position';
export const Label_ctlno = 'ApiProdSeqItm.ctlno';
export const Label_producttype = 'ApiProdSeqItm.producttype';
export const Label_kanban = 'ApiProdSeqItm.kanban';
export const Label_custorderno = 'ApiProdSeqItm.custorderno';
export const Label_proddesc = 'ApiProdSeqItm.proddesc';
export const Label_pscreatedate = 'ApiProdSeqItm.pscreatedate';
export const Label_GSSenderID = 'ApiProdSeqItm.GSSenderID';
export const Label_Expr1 = 'ApiProdSeqItm.Expr1';
export const Label_Expr2 = 'ApiProdSeqItm.Expr2';
export const Label_Expr3 = 'ApiProdSeqItm.Expr3';
export const Label_Expr4 = 'ApiProdSeqItm.Expr4';
export const Label_tspurposecode = 'ApiProdSeqItm.tspurposecode';
export const Label_pstypequal = 'ApiProdSeqItm.pstypequal';
export const Label_psqtyqual = 'ApiProdSeqItm.psqtyqual';
export const Label_pstypecode = 'ApiProdSeqItm.pstypecode';
export const Label_purchaseorder = 'ApiProdSeqItm.purchaseorder';
export const Label_Expr5 = 'ApiProdSeqItm.Expr5';
export const Label_contractno = 'ApiProdSeqItm.contractno';
export const Label_hrznstartdate = 'ApiProdSeqItm.hrznstartdate';
export const Label_hrznenddate = 'ApiProdSeqItm.hrznenddate';
export const Label_Expr6 = 'ApiProdSeqItm.Expr6';
export const Label_psupddate = 'ApiProdSeqItm.psupddate';
export const Label_hdrdocline = 'ApiProdSeqItm.hdrdocline';
export const Label_XMLID = 'ApiProdSeqItm.XMLID';
export const Label_CreatedDate = 'ApiProdSeqItm.CreatedDate';
export const Label_Expr7 = 'ApiProdSeqItm.Expr7';
export const Label_DGID = 'ApiProdSeqItm.DGID';
export const Label_Config = 'ApiProdSeqItm.Config';
export const Label_URECID = 'ApiProdSeqItm.URECID';
export const Label_Exp_Flag = 'ApiProdSeqItm.Exp_Flag';
export const Label_ExportDate = 'ApiProdSeqItm.ExportDate';
export const Label_XMLText = 'ApiProdSeqItm.XMLText';
export const Label_Expr8 = 'ApiProdSeqItm.Expr8';
export const Label_Misc_ID = 'ApiProdSeqItm.Misc_ID';
export const Label_XMLRef = 'ApiProdSeqItm.XMLRef';
export const Label_GCN = 'ApiProdSeqItm.GCN';
export const Label_TCN = 'ApiProdSeqItm.TCN';
export const Label_Direction = 'ApiProdSeqItm.Direction';
export const Label_Expr9 = 'ApiProdSeqItm.Expr9';
export const Label_AckID = 'ApiProdSeqItm.AckID';
export const Label_VPIDFA = 'ApiProdSeqItm.VPIDFA';
