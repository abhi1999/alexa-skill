import { IApiOsnDepartureView } from '../edidb'
export class CApiOsnDepartureView implements IApiOsnDepartureView {
    public Asn_ID:number = 0;
    public Loc_ID:string = '';
    public ShipFr_Name:string = '';
    public ShipFr_Addr1:string = '';
    public ShipFr_Add2:string = '';
    public ShipFr_City:string = '';
    public ShipFr_St:string = '';
    public ShipFr_Zip:string = '';
    public ShipFr_Country:string = '';
    public Cust_PO:string = '';
    public ShipTo_Xref:string = '';
    public Source:string = '';
    public constructor(init?:Partial<CApiOsnDepartureView>) { Object.assign(this, init); }
}
export const IApiOsnDepartureView_Loc_ID_length = 20;
export const IApiOsnDepartureView_ShipFr_Name_length = 50;
export const IApiOsnDepartureView_ShipFr_Addr1_length = 50;
export const IApiOsnDepartureView_ShipFr_Add2_length = 50;
export const IApiOsnDepartureView_ShipFr_City_length = 30;
export const IApiOsnDepartureView_ShipFr_St_length = 20;
export const IApiOsnDepartureView_ShipFr_Zip_length = 20;
export const IApiOsnDepartureView_ShipFr_Country_length = 30;
export const IApiOsnDepartureView_Cust_PO_length = 30;
export const IApiOsnDepartureView_ShipTo_Xref_length = 30;
export const IApiOsnDepartureView_Source_length = 13;

export const kApiOsnDepartureView_Asn_ID="Asn_ID";
export const kApiOsnDepartureView_Loc_ID="Loc_ID";
export const kApiOsnDepartureView_ShipFr_Name="ShipFr_Name";
export const kApiOsnDepartureView_ShipFr_Addr1="ShipFr_Addr1";
export const kApiOsnDepartureView_ShipFr_Add2="ShipFr_Add2";
export const kApiOsnDepartureView_ShipFr_City="ShipFr_City";
export const kApiOsnDepartureView_ShipFr_St="ShipFr_St";
export const kApiOsnDepartureView_ShipFr_Zip="ShipFr_Zip";
export const kApiOsnDepartureView_ShipFr_Country="ShipFr_Country";
export const kApiOsnDepartureView_Cust_PO="Cust_PO";
export const kApiOsnDepartureView_ShipTo_Xref="ShipTo_Xref";
export const kApiOsnDepartureView_Source="Source";

/*
        'ApiOsnDepartureView' : {
            'Asn_ID' : 'Asn_ID',
            'Loc_ID' : 'Loc_ID',
            'ShipFr_Name' : 'ShipFr_Name',
            'ShipFr_Addr1' : 'ShipFr_Addr1',
            'ShipFr_Add2' : 'ShipFr_Add2',
            'ShipFr_City' : 'ShipFr_City',
            'ShipFr_St' : 'ShipFr_St',
            'ShipFr_Zip' : 'ShipFr_Zip',
            'ShipFr_Country' : 'ShipFr_Country',
            'Cust_PO' : 'Cust_PO',
            'ShipTo_Xref' : 'ShipTo_Xref',
            'Source' : 'Source',        },
*/

export const Label_Asn_ID = 'ApiOsnDepartureView.Asn_ID';
export const Label_Loc_ID = 'ApiOsnDepartureView.Loc_ID';
export const Label_ShipFr_Name = 'ApiOsnDepartureView.ShipFr_Name';
export const Label_ShipFr_Addr1 = 'ApiOsnDepartureView.ShipFr_Addr1';
export const Label_ShipFr_Add2 = 'ApiOsnDepartureView.ShipFr_Add2';
export const Label_ShipFr_City = 'ApiOsnDepartureView.ShipFr_City';
export const Label_ShipFr_St = 'ApiOsnDepartureView.ShipFr_St';
export const Label_ShipFr_Zip = 'ApiOsnDepartureView.ShipFr_Zip';
export const Label_ShipFr_Country = 'ApiOsnDepartureView.ShipFr_Country';
export const Label_Cust_PO = 'ApiOsnDepartureView.Cust_PO';
export const Label_ShipTo_Xref = 'ApiOsnDepartureView.ShipTo_Xref';
export const Label_Source = 'ApiOsnDepartureView.Source';
