import { IShipViaCustTrade } from '../edidb'
export class CShipViaCustTrade implements IShipViaCustTrade {
    public TP_Name:string = '';
    public Ship_Via_ID:string = '';
    public TP_PartID:string = '';
    public Cust_Ship_Via_ID:string = '';
    public User1:string = '';
    public User2:string = '';
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public constructor(init?:Partial<CShipViaCustTrade>) { Object.assign(this, init); }
}
export const IShipViaCustTrade_TP_Name_length = 30;
export const IShipViaCustTrade_Ship_Via_ID_length = 30;
export const IShipViaCustTrade_TP_PartID_length = 30;
export const IShipViaCustTrade_Cust_Ship_Via_ID_length = 50;
export const IShipViaCustTrade_User1_length = 50;
export const IShipViaCustTrade_User2_length = 50;
export const IShipViaCustTrade_User3_length = 50;
export const IShipViaCustTrade_User4_length = 50;
export const IShipViaCustTrade_User5_length = 50;

export const kShipViaCustTrade_TP_Name="TP_Name";
export const kShipViaCustTrade_Ship_Via_ID="Ship_Via_ID";
export const kShipViaCustTrade_TP_PartID="TP_PartID";
export const kShipViaCustTrade_Cust_Ship_Via_ID="Cust_Ship_Via_ID";
export const kShipViaCustTrade_User1="User1";
export const kShipViaCustTrade_User2="User2";
export const kShipViaCustTrade_User3="User3";
export const kShipViaCustTrade_User4="User4";
export const kShipViaCustTrade_User5="User5";

/*
        'ShipViaCustTrade' : {
            'TP_Name' : 'TP_Name',
            'Ship_Via_ID' : 'Ship_Via_ID',
            'TP_PartID' : 'TP_PartID',
            'Cust_Ship_Via_ID' : 'Cust_Ship_Via_ID',
            'User1' : 'User1',
            'User2' : 'User2',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',        },
*/

export const Label_TP_Name = 'ShipViaCustTrade.TP_Name';
export const Label_Ship_Via_ID = 'ShipViaCustTrade.Ship_Via_ID';
export const Label_TP_PartID = 'ShipViaCustTrade.TP_PartID';
export const Label_Cust_Ship_Via_ID = 'ShipViaCustTrade.Cust_Ship_Via_ID';
export const Label_User1 = 'ShipViaCustTrade.User1';
export const Label_User2 = 'ShipViaCustTrade.User2';
export const Label_User3 = 'ShipViaCustTrade.User3';
export const Label_User4 = 'ShipViaCustTrade.User4';
export const Label_User5 = 'ShipViaCustTrade.User5';
