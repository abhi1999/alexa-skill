import { IShippedToTrade } from '../edidb'
export class CShippedToTrade implements IShippedToTrade {
    public TP_PartID:string = '';
    public TP_Name:string = '';
    public cusno:string = '';
    public shiptoid:string = '';
    public itemid:string = '';
    public purchaseorderno:string = '';
    public shipdate:string = '';
    public reason:string = '';
    public reference:string = '';
    public userid:string = '';
    public machineid:string = '';
    public qty:number = 0;
    public cm:number = 0;
    public constructor(init?:Partial<CShippedToTrade>) { Object.assign(this, init); }
}
export const IShippedToTrade_TP_PartID_length = 30;
export const IShippedToTrade_TP_Name_length = 30;
export const IShippedToTrade_cusno_length = 100;
export const IShippedToTrade_shiptoid_length = 80;
export const IShippedToTrade_itemid_length = 500;
export const IShippedToTrade_purchaseorderno_length = 30;
export const IShippedToTrade_shipdate_length = 30;
export const IShippedToTrade_reason_length = 80;
export const IShippedToTrade_reference_length = 60;
export const IShippedToTrade_userid_length = 50;
export const IShippedToTrade_machineid_length = 50;

export const kShippedToTrade_TP_PartID="TP_PartID";
export const kShippedToTrade_TP_Name="TP_Name";
export const kShippedToTrade_cusno="cusno";
export const kShippedToTrade_shiptoid="shiptoid";
export const kShippedToTrade_itemid="itemid";
export const kShippedToTrade_purchaseorderno="purchaseorderno";
export const kShippedToTrade_shipdate="shipdate";
export const kShippedToTrade_reason="reason";
export const kShippedToTrade_reference="reference";
export const kShippedToTrade_userid="userid";
export const kShippedToTrade_machineid="machineid";
export const kShippedToTrade_qty="qty";
export const kShippedToTrade_cm="cm";

/*
        'ShippedToTrade' : {
            'TP_PartID' : 'TP_PartID',
            'TP_Name' : 'TP_Name',
            'cusno' : 'cusno',
            'shiptoid' : 'shiptoid',
            'itemid' : 'itemid',
            'purchaseorderno' : 'purchaseorderno',
            'shipdate' : 'shipdate',
            'reason' : 'reason',
            'reference' : 'reference',
            'userid' : 'userid',
            'machineid' : 'machineid',
            'qty' : 'qty',
            'cm' : 'cm',        },
*/

export const Label_TP_PartID = 'ShippedToTrade.TP_PartID';
export const Label_TP_Name = 'ShippedToTrade.TP_Name';
export const Label_cusno = 'ShippedToTrade.cusno';
export const Label_shiptoid = 'ShippedToTrade.shiptoid';
export const Label_itemid = 'ShippedToTrade.itemid';
export const Label_purchaseorderno = 'ShippedToTrade.purchaseorderno';
export const Label_shipdate = 'ShippedToTrade.shipdate';
export const Label_reason = 'ShippedToTrade.reason';
export const Label_reference = 'ShippedToTrade.reference';
export const Label_userid = 'ShippedToTrade.userid';
export const Label_machineid = 'ShippedToTrade.machineid';
export const Label_qty = 'ShippedToTrade.qty';
export const Label_cm = 'ShippedToTrade.cm';
