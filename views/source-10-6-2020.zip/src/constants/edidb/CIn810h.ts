import { IIn810h } from '../edidb'
export class CIn810h implements IIn810h {
    public In810_ID:number = 0;
    public TP_PartID:string = '';
    public InvoiceNo:string = '';
    public InvoiceDate:Date;
    public PurchaseOrder:string = '';
    public FreightAmt:number = 0;
    public MiscAmt:number = 0;
    public TaxAmt:number = 0;
    public InvoiceAmt:number = 0;
    public Exp_Flag:string = '';
    public constructor(init?:Partial<CIn810h>) { Object.assign(this, init); }
}
export const IIn810h_TP_PartID_length = 30;
export const IIn810h_InvoiceNo_length = 20;
export const IIn810h_PurchaseOrder_length = 30;
export const IIn810h_Exp_Flag_length = 1;

export const kIn810h_In810_ID="In810_ID";
export const kIn810h_TP_PartID="TP_PartID";
export const kIn810h_InvoiceNo="InvoiceNo";
export const kIn810h_InvoiceDate="InvoiceDate";
export const kIn810h_PurchaseOrder="PurchaseOrder";
export const kIn810h_FreightAmt="FreightAmt";
export const kIn810h_MiscAmt="MiscAmt";
export const kIn810h_TaxAmt="TaxAmt";
export const kIn810h_InvoiceAmt="InvoiceAmt";
export const kIn810h_Exp_Flag="Exp_Flag";

/*
        'In810h' : {
            'In810_ID' : 'In810_ID',
            'TP_PartID' : 'TP_PartID',
            'InvoiceNo' : 'InvoiceNo',
            'InvoiceDate' : 'InvoiceDate',
            'PurchaseOrder' : 'PurchaseOrder',
            'FreightAmt' : 'FreightAmt',
            'MiscAmt' : 'MiscAmt',
            'TaxAmt' : 'TaxAmt',
            'InvoiceAmt' : 'InvoiceAmt',
            'Exp_Flag' : 'Exp_Flag',        },
*/

export const Label_In810_ID = 'In810h.In810_ID';
export const Label_TP_PartID = 'In810h.TP_PartID';
export const Label_InvoiceNo = 'In810h.InvoiceNo';
export const Label_InvoiceDate = 'In810h.InvoiceDate';
export const Label_PurchaseOrder = 'In810h.PurchaseOrder';
export const Label_FreightAmt = 'In810h.FreightAmt';
export const Label_MiscAmt = 'In810h.MiscAmt';
export const Label_TaxAmt = 'In810h.TaxAmt';
export const Label_InvoiceAmt = 'In810h.InvoiceAmt';
export const Label_Exp_Flag = 'In810h.Exp_Flag';
