import { IApiTradeTransObject } from '../edidb'
export class CApiTradeTransObject implements IApiTradeTransObject {
    public TP_PartID:string = '';
    public TP_Name:string = '';
    public constructor(init?:Partial<CApiTradeTransObject>) { Object.assign(this, init); }
}
export const IApiTradeTransObject_TP_PartID_length = 30;
export const IApiTradeTransObject_TP_Name_length = 30;

export const kApiTradeTransObject_TP_PartID="TP_PartID";
export const kApiTradeTransObject_TP_Name="TP_Name";

/*
        'ApiTradeTransObject' : {
            'TP_PartID' : 'TP_PartID',
            'TP_Name' : 'TP_Name',        },
*/

export const Label_TP_PartID = 'ApiTradeTransObject.TP_PartID';
export const Label_TP_Name = 'ApiTradeTransObject.TP_Name';
