import { IC303v810f } from '../edidb'
export class CC303v810f implements IC303v810f {
    public Ord_ID:number = 0;
    public SAC_Qual:string = '';
    public Amount:number = 0;
    public Line_No:string = '';
    public Acct_RecID:string = '';
    public Mast_RecID:string = '';
    public URECID:string = '';
    public constructor(init?:Partial<CC303v810f>) { Object.assign(this, init); }
}
export const IC303v810f_SAC_Qual_length = 4;
export const IC303v810f_Line_No_length = 11;
export const IC303v810f_Acct_RecID_length = 30;
export const IC303v810f_Mast_RecID_length = 30;

export const kC303v810f_Ord_ID="Ord_ID";
export const kC303v810f_SAC_Qual="SAC_Qual";
export const kC303v810f_Amount="Amount";
export const kC303v810f_Line_No="Line_No";
export const kC303v810f_Acct_RecID="Acct_RecID";
export const kC303v810f_Mast_RecID="Mast_RecID";
export const kC303v810f_URECID="URECID";

/*
        'C303v810f' : {
            'Ord_ID' : 'Ord_ID',
            'SAC_Qual' : 'SAC_Qual',
            'Amount' : 'Amount',
            'Line_No' : 'Line_No',
            'Acct_RecID' : 'Acct_RecID',
            'Mast_RecID' : 'Mast_RecID',
            'URECID' : 'URECID',        },
*/

export const Label_Ord_ID = 'C303v810f.Ord_ID';
export const Label_SAC_Qual = 'C303v810f.SAC_Qual';
export const Label_Amount = 'C303v810f.Amount';
export const Label_Line_No = 'C303v810f.Line_No';
export const Label_Acct_RecID = 'C303v810f.Acct_RecID';
export const Label_Mast_RecID = 'C303v810f.Mast_RecID';
export const Label_URECID = 'C303v810f.URECID';
