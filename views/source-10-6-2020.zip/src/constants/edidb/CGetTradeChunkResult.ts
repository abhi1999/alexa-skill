import { IGetTradeChunkResult } from '../edidb'
export class CGetTradeChunkResult implements IGetTradeChunkResult {
    public LOCATION_IN_RECORD_SET:number = 0;
    public PAGE_NUMBER:number = 0;
    public TP_PartID:string = '';
    public TP_PartQ:string = '';
    public TP_ID:string = '';
    public TP_Name:string = '';
    public TP_GroupID:string = '';
    public TP_Asn:string = '';
    public TP_ItemCode:string = '';
    public TP_UseN1BY:string = '';
    public TP_UseDept:string = '';
    public TP_UseN1ST:string = '';
    public TP_STQUAL:string = '';
    public TP_In850:string = '';
    public TP_In810:string = '';
    public TP_Out850:string = '';
    public TP_Out810:string = '';
    public TP_864ID:string = '';
    public TP_ShipDateQual:string = '';
    public TP_CancelDateQual:string = '';
    public Std_ID:string = '';
    public Term_Days:string = '';
    public Disc_Perc:string = '';
    public Disc_Days:string = '';
    public TP_VendID:string = '';
    public TP_MapIn_850:string = '';
    public TP_UCC128:string = '';
    public TP_BarcodeType:string = '';
    public TP_User1:string = '';
    public TP_User2:string = '';
    public TP_User3:string = '';
    public TP_User4:string = '';
    public TP_User5:string = '';
    public TP_User6:string = '';
    public TP_User7:string = '';
    public TP_User8:string = '';
    public TP_User9:string = '';
    public TP_ItemCode2:string = '';
    public TP_STformat:number = 0;
    public TP_SendQ:string = '';
    public TP_SendID:string = '';
    public TP_SendGID:string = '';
    public TP_EleSep:number = 0;
    public TP_SubEleSep:number = 0;
    public TP_SegTerm:number = 0;
    public CreateFA:boolean;
    public Create856:boolean;
    public Van:string = '';
    public UseAltAdr:boolean;
    public ISA14Y:boolean;
    public Exp_Date:Date;
    public CipherKey:string = '';
    public TP_Out753:boolean;
    public CalcLineTax:boolean;
    public UseCurrency:boolean;
    public PrcMethod:number = 0;
    public SerLotFlag:boolean;
    public TP_ShipDateQual1:string = '';
    public TP_ShipDateQual2:string = '';
    public TP_CancelDateQual1:string = '';
    public TP_CancelDateQual2:string = '';
    public PostSAC:boolean;
    public Pseudo_ID:string = '';
    public Pseudo_Segname:string = '';
    public Pseudo_Qual_Elem_No:number = 0;
    public Pseudo_Qual_Elem_Value:string = '';
    public Pseudo_Vendor_Elem_No:number = 0;
    public Pseudo_Vendor_Elem_Value:string = '';
    public Pseudo_TPPartID:string = '';
    public ForceSerLot:boolean;
    public PO_Exclude_Types:string = '';
    public PKG_ID:string = '';
    public KitTypeID:number = 0;
    public PackSizeLookupSeq:string = '';
    public TP_RepSep:number = 0;
    public TP_QuoteOrder:boolean;
    public PSPOMethod:number = 0;
    public TP_STQUAL2:string = '';
    public PostCommentsToAcct:boolean;
    public CreditMemoAsInvoice:boolean;
    public AddlAdrQual1:string = '';
    public AddlAdrQual2:string = '';
    public UsePackingClass:boolean;
    public TransitDays:number = 0;
    public FrozenDays:number = 0;
    public ShipDlvPattern:string = '';
    public TP_GS1Prefix:string = '';
    public TP_UseGS1Prefix:boolean;
    public Loc_Override:string = '';
    public TP_Status:string = '';
    public constructor(init?:Partial<CGetTradeChunkResult>) { Object.assign(this, init); }
}
export const kGetTradeChunkResult_LOCATION_IN_RECORD_SET="LOCATION_IN_RECORD_SET";
export const kGetTradeChunkResult_PAGE_NUMBER="PAGE_NUMBER";
export const kGetTradeChunkResult_TP_PartID="TP_PartID";
export const kGetTradeChunkResult_TP_PartQ="TP_PartQ";
export const kGetTradeChunkResult_TP_ID="TP_ID";
export const kGetTradeChunkResult_TP_Name="TP_Name";
export const kGetTradeChunkResult_TP_GroupID="TP_GroupID";
export const kGetTradeChunkResult_TP_Asn="TP_Asn";
export const kGetTradeChunkResult_TP_ItemCode="TP_ItemCode";
export const kGetTradeChunkResult_TP_UseN1BY="TP_UseN1BY";
export const kGetTradeChunkResult_TP_UseDept="TP_UseDept";
export const kGetTradeChunkResult_TP_UseN1ST="TP_UseN1ST";
export const kGetTradeChunkResult_TP_STQUAL="TP_STQUAL";
export const kGetTradeChunkResult_TP_In850="TP_In850";
export const kGetTradeChunkResult_TP_In810="TP_In810";
export const kGetTradeChunkResult_TP_Out850="TP_Out850";
export const kGetTradeChunkResult_TP_Out810="TP_Out810";
export const kGetTradeChunkResult_TP_864ID="TP_864ID";
export const kGetTradeChunkResult_TP_ShipDateQual="TP_ShipDateQual";
export const kGetTradeChunkResult_TP_CancelDateQual="TP_CancelDateQual";
export const kGetTradeChunkResult_Std_ID="Std_ID";
export const kGetTradeChunkResult_Term_Days="Term_Days";
export const kGetTradeChunkResult_Disc_Perc="Disc_Perc";
export const kGetTradeChunkResult_Disc_Days="Disc_Days";
export const kGetTradeChunkResult_TP_VendID="TP_VendID";
export const kGetTradeChunkResult_TP_MapIn_850="TP_MapIn_850";
export const kGetTradeChunkResult_TP_UCC128="TP_UCC128";
export const kGetTradeChunkResult_TP_BarcodeType="TP_BarcodeType";
export const kGetTradeChunkResult_TP_User1="TP_User1";
export const kGetTradeChunkResult_TP_User2="TP_User2";
export const kGetTradeChunkResult_TP_User3="TP_User3";
export const kGetTradeChunkResult_TP_User4="TP_User4";
export const kGetTradeChunkResult_TP_User5="TP_User5";
export const kGetTradeChunkResult_TP_User6="TP_User6";
export const kGetTradeChunkResult_TP_User7="TP_User7";
export const kGetTradeChunkResult_TP_User8="TP_User8";
export const kGetTradeChunkResult_TP_User9="TP_User9";
export const kGetTradeChunkResult_TP_ItemCode2="TP_ItemCode2";
export const kGetTradeChunkResult_TP_STformat="TP_STformat";
export const kGetTradeChunkResult_TP_SendQ="TP_SendQ";
export const kGetTradeChunkResult_TP_SendID="TP_SendID";
export const kGetTradeChunkResult_TP_SendGID="TP_SendGID";
export const kGetTradeChunkResult_TP_EleSep="TP_EleSep";
export const kGetTradeChunkResult_TP_SubEleSep="TP_SubEleSep";
export const kGetTradeChunkResult_TP_SegTerm="TP_SegTerm";
export const kGetTradeChunkResult_CreateFA="CreateFA";
export const kGetTradeChunkResult_Create856="Create856";
export const kGetTradeChunkResult_Van="Van";
export const kGetTradeChunkResult_UseAltAdr="UseAltAdr";
export const kGetTradeChunkResult_ISA14Y="ISA14Y";
export const kGetTradeChunkResult_Exp_Date="Exp_Date";
export const kGetTradeChunkResult_CipherKey="CipherKey";
export const kGetTradeChunkResult_TP_Out753="TP_Out753";
export const kGetTradeChunkResult_CalcLineTax="CalcLineTax";
export const kGetTradeChunkResult_UseCurrency="UseCurrency";
export const kGetTradeChunkResult_PrcMethod="PrcMethod";
export const kGetTradeChunkResult_SerLotFlag="SerLotFlag";
export const kGetTradeChunkResult_TP_ShipDateQual1="TP_ShipDateQual1";
export const kGetTradeChunkResult_TP_ShipDateQual2="TP_ShipDateQual2";
export const kGetTradeChunkResult_TP_CancelDateQual1="TP_CancelDateQual1";
export const kGetTradeChunkResult_TP_CancelDateQual2="TP_CancelDateQual2";
export const kGetTradeChunkResult_PostSAC="PostSAC";
export const kGetTradeChunkResult_Pseudo_ID="Pseudo_ID";
export const kGetTradeChunkResult_Pseudo_Segname="Pseudo_Segname";
export const kGetTradeChunkResult_Pseudo_Qual_Elem_No="Pseudo_Qual_Elem_No";
export const kGetTradeChunkResult_Pseudo_Qual_Elem_Value="Pseudo_Qual_Elem_Value";
export const kGetTradeChunkResult_Pseudo_Vendor_Elem_No="Pseudo_Vendor_Elem_No";
export const kGetTradeChunkResult_Pseudo_Vendor_Elem_Value="Pseudo_Vendor_Elem_Value";
export const kGetTradeChunkResult_Pseudo_TPPartID="Pseudo_TPPartID";
export const kGetTradeChunkResult_ForceSerLot="ForceSerLot";
export const kGetTradeChunkResult_PO_Exclude_Types="PO_Exclude_Types";
export const kGetTradeChunkResult_PKG_ID="PKG_ID";
export const kGetTradeChunkResult_KitTypeID="KitTypeID";
export const kGetTradeChunkResult_PackSizeLookupSeq="PackSizeLookupSeq";
export const kGetTradeChunkResult_TP_RepSep="TP_RepSep";
export const kGetTradeChunkResult_TP_QuoteOrder="TP_QuoteOrder";
export const kGetTradeChunkResult_PSPOMethod="PSPOMethod";
export const kGetTradeChunkResult_TP_STQUAL2="TP_STQUAL2";
export const kGetTradeChunkResult_PostCommentsToAcct="PostCommentsToAcct";
export const kGetTradeChunkResult_CreditMemoAsInvoice="CreditMemoAsInvoice";
export const kGetTradeChunkResult_AddlAdrQual1="AddlAdrQual1";
export const kGetTradeChunkResult_AddlAdrQual2="AddlAdrQual2";
export const kGetTradeChunkResult_UsePackingClass="UsePackingClass";
export const kGetTradeChunkResult_TransitDays="TransitDays";
export const kGetTradeChunkResult_FrozenDays="FrozenDays";
export const kGetTradeChunkResult_ShipDlvPattern="ShipDlvPattern";
export const kGetTradeChunkResult_TP_GS1Prefix="TP_GS1Prefix";
export const kGetTradeChunkResult_TP_UseGS1Prefix="TP_UseGS1Prefix";
export const kGetTradeChunkResult_Loc_Override="Loc_Override";
export const kGetTradeChunkResult_TP_Status="TP_Status";

/*
        'GetTradeChunkResult' : {
            'LOCATION_IN_RECORD_SET' : 'LOCATION_IN_RECORD_SET',
            'PAGE_NUMBER' : 'PAGE_NUMBER',
            'TP_PartID' : 'TP_PartID',
            'TP_PartQ' : 'TP_PartQ',
            'TP_ID' : 'TP_ID',
            'TP_Name' : 'TP_Name',
            'TP_GroupID' : 'TP_GroupID',
            'TP_Asn' : 'TP_Asn',
            'TP_ItemCode' : 'TP_ItemCode',
            'TP_UseN1BY' : 'TP_UseN1BY',
            'TP_UseDept' : 'TP_UseDept',
            'TP_UseN1ST' : 'TP_UseN1ST',
            'TP_STQUAL' : 'TP_STQUAL',
            'TP_In850' : 'TP_In850',
            'TP_In810' : 'TP_In810',
            'TP_Out850' : 'TP_Out850',
            'TP_Out810' : 'TP_Out810',
            'TP_864ID' : 'TP_864ID',
            'TP_ShipDateQual' : 'TP_ShipDateQual',
            'TP_CancelDateQual' : 'TP_CancelDateQual',
            'Std_ID' : 'Std_ID',
            'Term_Days' : 'Term_Days',
            'Disc_Perc' : 'Disc_Perc',
            'Disc_Days' : 'Disc_Days',
            'TP_VendID' : 'TP_VendID',
            'TP_MapIn_850' : 'TP_MapIn_850',
            'TP_UCC128' : 'TP_UCC128',
            'TP_BarcodeType' : 'TP_BarcodeType',
            'TP_User1' : 'TP_User1',
            'TP_User2' : 'TP_User2',
            'TP_User3' : 'TP_User3',
            'TP_User4' : 'TP_User4',
            'TP_User5' : 'TP_User5',
            'TP_User6' : 'TP_User6',
            'TP_User7' : 'TP_User7',
            'TP_User8' : 'TP_User8',
            'TP_User9' : 'TP_User9',
            'TP_ItemCode2' : 'TP_ItemCode2',
            'TP_STformat' : 'TP_STformat',
            'TP_SendQ' : 'TP_SendQ',
            'TP_SendID' : 'TP_SendID',
            'TP_SendGID' : 'TP_SendGID',
            'TP_EleSep' : 'TP_EleSep',
            'TP_SubEleSep' : 'TP_SubEleSep',
            'TP_SegTerm' : 'TP_SegTerm',
            'CreateFA' : 'CreateFA',
            'Create856' : 'Create856',
            'Van' : 'Van',
            'UseAltAdr' : 'UseAltAdr',
            'ISA14Y' : 'ISA14Y',
            'Exp_Date' : 'Exp_Date',
            'CipherKey' : 'CipherKey',
            'TP_Out753' : 'TP_Out753',
            'CalcLineTax' : 'CalcLineTax',
            'UseCurrency' : 'UseCurrency',
            'PrcMethod' : 'PrcMethod',
            'SerLotFlag' : 'SerLotFlag',
            'TP_ShipDateQual1' : 'TP_ShipDateQual1',
            'TP_ShipDateQual2' : 'TP_ShipDateQual2',
            'TP_CancelDateQual1' : 'TP_CancelDateQual1',
            'TP_CancelDateQual2' : 'TP_CancelDateQual2',
            'PostSAC' : 'PostSAC',
            'Pseudo_ID' : 'Pseudo_ID',
            'Pseudo_Segname' : 'Pseudo_Segname',
            'Pseudo_Qual_Elem_No' : 'Pseudo_Qual_Elem_No',
            'Pseudo_Qual_Elem_Value' : 'Pseudo_Qual_Elem_Value',
            'Pseudo_Vendor_Elem_No' : 'Pseudo_Vendor_Elem_No',
            'Pseudo_Vendor_Elem_Value' : 'Pseudo_Vendor_Elem_Value',
            'Pseudo_TPPartID' : 'Pseudo_TPPartID',
            'ForceSerLot' : 'ForceSerLot',
            'PO_Exclude_Types' : 'PO_Exclude_Types',
            'PKG_ID' : 'PKG_ID',
            'KitTypeID' : 'KitTypeID',
            'PackSizeLookupSeq' : 'PackSizeLookupSeq',
            'TP_RepSep' : 'TP_RepSep',
            'TP_QuoteOrder' : 'TP_QuoteOrder',
            'PSPOMethod' : 'PSPOMethod',
            'TP_STQUAL2' : 'TP_STQUAL2',
            'PostCommentsToAcct' : 'PostCommentsToAcct',
            'CreditMemoAsInvoice' : 'CreditMemoAsInvoice',
            'AddlAdrQual1' : 'AddlAdrQual1',
            'AddlAdrQual2' : 'AddlAdrQual2',
            'UsePackingClass' : 'UsePackingClass',
            'TransitDays' : 'TransitDays',
            'FrozenDays' : 'FrozenDays',
            'ShipDlvPattern' : 'ShipDlvPattern',
            'TP_GS1Prefix' : 'TP_GS1Prefix',
            'TP_UseGS1Prefix' : 'TP_UseGS1Prefix',
            'Loc_Override' : 'Loc_Override',
            'TP_Status' : 'TP_Status',        },
*/

export const Label_LOCATION_IN_RECORD_SET = 'GetTradeChunkResult.LOCATION_IN_RECORD_SET';
export const Label_PAGE_NUMBER = 'GetTradeChunkResult.PAGE_NUMBER';
export const Label_TP_PartID = 'GetTradeChunkResult.TP_PartID';
export const Label_TP_PartQ = 'GetTradeChunkResult.TP_PartQ';
export const Label_TP_ID = 'GetTradeChunkResult.TP_ID';
export const Label_TP_Name = 'GetTradeChunkResult.TP_Name';
export const Label_TP_GroupID = 'GetTradeChunkResult.TP_GroupID';
export const Label_TP_Asn = 'GetTradeChunkResult.TP_Asn';
export const Label_TP_ItemCode = 'GetTradeChunkResult.TP_ItemCode';
export const Label_TP_UseN1BY = 'GetTradeChunkResult.TP_UseN1BY';
export const Label_TP_UseDept = 'GetTradeChunkResult.TP_UseDept';
export const Label_TP_UseN1ST = 'GetTradeChunkResult.TP_UseN1ST';
export const Label_TP_STQUAL = 'GetTradeChunkResult.TP_STQUAL';
export const Label_TP_In850 = 'GetTradeChunkResult.TP_In850';
export const Label_TP_In810 = 'GetTradeChunkResult.TP_In810';
export const Label_TP_Out850 = 'GetTradeChunkResult.TP_Out850';
export const Label_TP_Out810 = 'GetTradeChunkResult.TP_Out810';
export const Label_TP_864ID = 'GetTradeChunkResult.TP_864ID';
export const Label_TP_ShipDateQual = 'GetTradeChunkResult.TP_ShipDateQual';
export const Label_TP_CancelDateQual = 'GetTradeChunkResult.TP_CancelDateQual';
export const Label_Std_ID = 'GetTradeChunkResult.Std_ID';
export const Label_Term_Days = 'GetTradeChunkResult.Term_Days';
export const Label_Disc_Perc = 'GetTradeChunkResult.Disc_Perc';
export const Label_Disc_Days = 'GetTradeChunkResult.Disc_Days';
export const Label_TP_VendID = 'GetTradeChunkResult.TP_VendID';
export const Label_TP_MapIn_850 = 'GetTradeChunkResult.TP_MapIn_850';
export const Label_TP_UCC128 = 'GetTradeChunkResult.TP_UCC128';
export const Label_TP_BarcodeType = 'GetTradeChunkResult.TP_BarcodeType';
export const Label_TP_User1 = 'GetTradeChunkResult.TP_User1';
export const Label_TP_User2 = 'GetTradeChunkResult.TP_User2';
export const Label_TP_User3 = 'GetTradeChunkResult.TP_User3';
export const Label_TP_User4 = 'GetTradeChunkResult.TP_User4';
export const Label_TP_User5 = 'GetTradeChunkResult.TP_User5';
export const Label_TP_User6 = 'GetTradeChunkResult.TP_User6';
export const Label_TP_User7 = 'GetTradeChunkResult.TP_User7';
export const Label_TP_User8 = 'GetTradeChunkResult.TP_User8';
export const Label_TP_User9 = 'GetTradeChunkResult.TP_User9';
export const Label_TP_ItemCode2 = 'GetTradeChunkResult.TP_ItemCode2';
export const Label_TP_STformat = 'GetTradeChunkResult.TP_STformat';
export const Label_TP_SendQ = 'GetTradeChunkResult.TP_SendQ';
export const Label_TP_SendID = 'GetTradeChunkResult.TP_SendID';
export const Label_TP_SendGID = 'GetTradeChunkResult.TP_SendGID';
export const Label_TP_EleSep = 'GetTradeChunkResult.TP_EleSep';
export const Label_TP_SubEleSep = 'GetTradeChunkResult.TP_SubEleSep';
export const Label_TP_SegTerm = 'GetTradeChunkResult.TP_SegTerm';
export const Label_CreateFA = 'GetTradeChunkResult.CreateFA';
export const Label_Create856 = 'GetTradeChunkResult.Create856';
export const Label_Van = 'GetTradeChunkResult.Van';
export const Label_UseAltAdr = 'GetTradeChunkResult.UseAltAdr';
export const Label_ISA14Y = 'GetTradeChunkResult.ISA14Y';
export const Label_Exp_Date = 'GetTradeChunkResult.Exp_Date';
export const Label_CipherKey = 'GetTradeChunkResult.CipherKey';
export const Label_TP_Out753 = 'GetTradeChunkResult.TP_Out753';
export const Label_CalcLineTax = 'GetTradeChunkResult.CalcLineTax';
export const Label_UseCurrency = 'GetTradeChunkResult.UseCurrency';
export const Label_PrcMethod = 'GetTradeChunkResult.PrcMethod';
export const Label_SerLotFlag = 'GetTradeChunkResult.SerLotFlag';
export const Label_TP_ShipDateQual1 = 'GetTradeChunkResult.TP_ShipDateQual1';
export const Label_TP_ShipDateQual2 = 'GetTradeChunkResult.TP_ShipDateQual2';
export const Label_TP_CancelDateQual1 = 'GetTradeChunkResult.TP_CancelDateQual1';
export const Label_TP_CancelDateQual2 = 'GetTradeChunkResult.TP_CancelDateQual2';
export const Label_PostSAC = 'GetTradeChunkResult.PostSAC';
export const Label_Pseudo_ID = 'GetTradeChunkResult.Pseudo_ID';
export const Label_Pseudo_Segname = 'GetTradeChunkResult.Pseudo_Segname';
export const Label_Pseudo_Qual_Elem_No = 'GetTradeChunkResult.Pseudo_Qual_Elem_No';
export const Label_Pseudo_Qual_Elem_Value = 'GetTradeChunkResult.Pseudo_Qual_Elem_Value';
export const Label_Pseudo_Vendor_Elem_No = 'GetTradeChunkResult.Pseudo_Vendor_Elem_No';
export const Label_Pseudo_Vendor_Elem_Value = 'GetTradeChunkResult.Pseudo_Vendor_Elem_Value';
export const Label_Pseudo_TPPartID = 'GetTradeChunkResult.Pseudo_TPPartID';
export const Label_ForceSerLot = 'GetTradeChunkResult.ForceSerLot';
export const Label_PO_Exclude_Types = 'GetTradeChunkResult.PO_Exclude_Types';
export const Label_PKG_ID = 'GetTradeChunkResult.PKG_ID';
export const Label_KitTypeID = 'GetTradeChunkResult.KitTypeID';
export const Label_PackSizeLookupSeq = 'GetTradeChunkResult.PackSizeLookupSeq';
export const Label_TP_RepSep = 'GetTradeChunkResult.TP_RepSep';
export const Label_TP_QuoteOrder = 'GetTradeChunkResult.TP_QuoteOrder';
export const Label_PSPOMethod = 'GetTradeChunkResult.PSPOMethod';
export const Label_TP_STQUAL2 = 'GetTradeChunkResult.TP_STQUAL2';
export const Label_PostCommentsToAcct = 'GetTradeChunkResult.PostCommentsToAcct';
export const Label_CreditMemoAsInvoice = 'GetTradeChunkResult.CreditMemoAsInvoice';
export const Label_AddlAdrQual1 = 'GetTradeChunkResult.AddlAdrQual1';
export const Label_AddlAdrQual2 = 'GetTradeChunkResult.AddlAdrQual2';
export const Label_UsePackingClass = 'GetTradeChunkResult.UsePackingClass';
export const Label_TransitDays = 'GetTradeChunkResult.TransitDays';
export const Label_FrozenDays = 'GetTradeChunkResult.FrozenDays';
export const Label_ShipDlvPattern = 'GetTradeChunkResult.ShipDlvPattern';
export const Label_TP_GS1Prefix = 'GetTradeChunkResult.TP_GS1Prefix';
export const Label_TP_UseGS1Prefix = 'GetTradeChunkResult.TP_UseGS1Prefix';
export const Label_Loc_Override = 'GetTradeChunkResult.Loc_Override';
export const Label_TP_Status = 'GetTradeChunkResult.TP_Status';
