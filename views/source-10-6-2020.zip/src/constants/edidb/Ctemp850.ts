import { Itemp850 } from '../edidb'
export class Ctemp850 implements Itemp850 {
    public ID:number = 0;
    public TP_ID:string = '';
    public PO_NO:string = '';
    public PO_Date:string = '';
    public PO_ID:string = '';
    public ShipTo_Xref:string = '';
    public ShipToContact:string = '';
    public ShipToName:string = '';
    public ShipToName2:string = '';
    public ShipToAddress:string = '';
    public ShipToAddress2:string = '';
    public ShipToCity:string = '';
    public ShipToState:string = '';
    public ShipToZip:string = '';
    public Cust_Dept_Code:string = '';
    public Ship_Date:string = '';
    public Cancel_Date:string = '';
    public Int_Item_No:string = '';
    public Item_Qty:string = '';
    public Item_UM:string = '';
    public Item_Price:string = '';
    public PostStatus:string = '';
    public ShipMethod:string = '';
    public ShipToCountry:string = '';
    public PO1_LineNo:string = '';
    public vp_LineNo:string = '';
    public docline:number = 0;
    public etline_no:number = 0;
    public ShipTo_DC_Xref:string = '';
    public constructor(init?:Partial<Ctemp850>) { Object.assign(this, init); }
}
export const Itemp850_TP_ID_length = 30;
export const Itemp850_PO_NO_length = 22;
export const Itemp850_PO_Date_length = 8;
export const Itemp850_PO_ID_length = 10;
export const Itemp850_ShipTo_Xref_length = 30;
export const Itemp850_ShipToContact_length = 50;
export const Itemp850_ShipToName_length = 80;
export const Itemp850_ShipToName2_length = 80;
export const Itemp850_ShipToAddress_length = 80;
export const Itemp850_ShipToAddress2_length = 80;
export const Itemp850_ShipToCity_length = 40;
export const Itemp850_ShipToState_length = 20;
export const Itemp850_ShipToZip_length = 15;
export const Itemp850_Cust_Dept_Code_length = 30;
export const Itemp850_Ship_Date_length = 8;
export const Itemp850_Cancel_Date_length = 8;
export const Itemp850_Int_Item_No_length = 30;
export const Itemp850_Item_Qty_length = 16;
export const Itemp850_Item_UM_length = 10;
export const Itemp850_Item_Price_length = 16;
export const Itemp850_PostStatus_length = 1;
export const Itemp850_ShipMethod_length = 2;
export const Itemp850_ShipToCountry_length = 30;
export const Itemp850_PO1_LineNo_length = 20;
export const Itemp850_vp_LineNo_length = 11;
export const Itemp850_ShipTo_DC_Xref_length = 30;

export const ktemp850_ID="ID";
export const ktemp850_TP_ID="TP_ID";
export const ktemp850_PO_NO="PO_NO";
export const ktemp850_PO_Date="PO_Date";
export const ktemp850_PO_ID="PO_ID";
export const ktemp850_ShipTo_Xref="ShipTo_Xref";
export const ktemp850_ShipToContact="ShipToContact";
export const ktemp850_ShipToName="ShipToName";
export const ktemp850_ShipToName2="ShipToName2";
export const ktemp850_ShipToAddress="ShipToAddress";
export const ktemp850_ShipToAddress2="ShipToAddress2";
export const ktemp850_ShipToCity="ShipToCity";
export const ktemp850_ShipToState="ShipToState";
export const ktemp850_ShipToZip="ShipToZip";
export const ktemp850_Cust_Dept_Code="Cust_Dept_Code";
export const ktemp850_Ship_Date="Ship_Date";
export const ktemp850_Cancel_Date="Cancel_Date";
export const ktemp850_Int_Item_No="Int_Item_No";
export const ktemp850_Item_Qty="Item_Qty";
export const ktemp850_Item_UM="Item_UM";
export const ktemp850_Item_Price="Item_Price";
export const ktemp850_PostStatus="PostStatus";
export const ktemp850_ShipMethod="ShipMethod";
export const ktemp850_ShipToCountry="ShipToCountry";
export const ktemp850_PO1_LineNo="PO1_LineNo";
export const ktemp850_vp_LineNo="vp_LineNo";
export const ktemp850_docline="docline";
export const ktemp850_etline_no="etline_no";
export const ktemp850_ShipTo_DC_Xref="ShipTo_DC_Xref";

/*
        'temp850' : {
            'ID' : 'ID',
            'TP_ID' : 'TP_ID',
            'PO_NO' : 'PO_NO',
            'PO_Date' : 'PO_Date',
            'PO_ID' : 'PO_ID',
            'ShipTo_Xref' : 'ShipTo_Xref',
            'ShipToContact' : 'ShipToContact',
            'ShipToName' : 'ShipToName',
            'ShipToName2' : 'ShipToName2',
            'ShipToAddress' : 'ShipToAddress',
            'ShipToAddress2' : 'ShipToAddress2',
            'ShipToCity' : 'ShipToCity',
            'ShipToState' : 'ShipToState',
            'ShipToZip' : 'ShipToZip',
            'Cust_Dept_Code' : 'Cust_Dept_Code',
            'Ship_Date' : 'Ship_Date',
            'Cancel_Date' : 'Cancel_Date',
            'Int_Item_No' : 'Int_Item_No',
            'Item_Qty' : 'Item_Qty',
            'Item_UM' : 'Item_UM',
            'Item_Price' : 'Item_Price',
            'PostStatus' : 'PostStatus',
            'ShipMethod' : 'ShipMethod',
            'ShipToCountry' : 'ShipToCountry',
            'PO1_LineNo' : 'PO1_LineNo',
            'vp_LineNo' : 'vp_LineNo',
            'docline' : 'docline',
            'etline_no' : 'etline_no',
            'ShipTo_DC_Xref' : 'ShipTo_DC_Xref',        },
*/

export const Label_ID = 'temp850.ID';
export const Label_TP_ID = 'temp850.TP_ID';
export const Label_PO_NO = 'temp850.PO_NO';
export const Label_PO_Date = 'temp850.PO_Date';
export const Label_PO_ID = 'temp850.PO_ID';
export const Label_ShipTo_Xref = 'temp850.ShipTo_Xref';
export const Label_ShipToContact = 'temp850.ShipToContact';
export const Label_ShipToName = 'temp850.ShipToName';
export const Label_ShipToName2 = 'temp850.ShipToName2';
export const Label_ShipToAddress = 'temp850.ShipToAddress';
export const Label_ShipToAddress2 = 'temp850.ShipToAddress2';
export const Label_ShipToCity = 'temp850.ShipToCity';
export const Label_ShipToState = 'temp850.ShipToState';
export const Label_ShipToZip = 'temp850.ShipToZip';
export const Label_Cust_Dept_Code = 'temp850.Cust_Dept_Code';
export const Label_Ship_Date = 'temp850.Ship_Date';
export const Label_Cancel_Date = 'temp850.Cancel_Date';
export const Label_Int_Item_No = 'temp850.Int_Item_No';
export const Label_Item_Qty = 'temp850.Item_Qty';
export const Label_Item_UM = 'temp850.Item_UM';
export const Label_Item_Price = 'temp850.Item_Price';
export const Label_PostStatus = 'temp850.PostStatus';
export const Label_ShipMethod = 'temp850.ShipMethod';
export const Label_ShipToCountry = 'temp850.ShipToCountry';
export const Label_PO1_LineNo = 'temp850.PO1_LineNo';
export const Label_vp_LineNo = 'temp850.vp_LineNo';
export const Label_docline = 'temp850.docline';
export const Label_etline_no = 'temp850.etline_no';
export const Label_ShipTo_DC_Xref = 'temp850.ShipTo_DC_Xref';
