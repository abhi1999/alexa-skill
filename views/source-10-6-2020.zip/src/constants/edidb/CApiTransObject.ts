import { IApiTransObject } from '../edidb'
export class CApiTransObject implements IApiTransObject {
    public TOID:string = '';
    public DGID:string = '';
    public TransID:string = '';
    public TP_PartID:string = '';
    public TDocName:string = '';
    public FilenameLayout:string = '';
    public PackageSeparately:boolean;
    public UseControlNums:boolean;
    public TransIDImportDate:Date;
    public TransIDObj_Date:Date;
    public TDocNameImportDate:Date;
    public TDocNameObj_Date:Date;
    public constructor(init?:Partial<CApiTransObject>) { Object.assign(this, init); }
}
export const IApiTransObject_DGID_length = 5;
export const IApiTransObject_TransID_length = 50;
export const IApiTransObject_TP_PartID_length = 30;
export const IApiTransObject_TDocName_length = 80;
export const IApiTransObject_FilenameLayout_length = 200;

export const kApiTransObject_TOID="TOID";
export const kApiTransObject_DGID="DGID";
export const kApiTransObject_TransID="TransID";
export const kApiTransObject_TP_PartID="TP_PartID";
export const kApiTransObject_TDocName="TDocName";
export const kApiTransObject_FilenameLayout="FilenameLayout";
export const kApiTransObject_PackageSeparately="PackageSeparately";
export const kApiTransObject_UseControlNums="UseControlNums";
export const kApiTransObject_TransIDImportDate="TransIDImportDate";
export const kApiTransObject_TransIDObj_Date="TransIDObj_Date";
export const kApiTransObject_TDocNameImportDate="TDocNameImportDate";
export const kApiTransObject_TDocNameObj_Date="TDocNameObj_Date";

/*
        'ApiTransObject' : {
            'TOID' : 'TOID',
            'DGID' : 'DGID',
            'TransID' : 'TransID',
            'TP_PartID' : 'TP_PartID',
            'TDocName' : 'TDocName',
            'FilenameLayout' : 'FilenameLayout',
            'PackageSeparately' : 'PackageSeparately',
            'UseControlNums' : 'UseControlNums',
            'TransIDImportDate' : 'TransIDImportDate',
            'TransIDObj_Date' : 'TransIDObj_Date',
            'TDocNameImportDate' : 'TDocNameImportDate',
            'TDocNameObj_Date' : 'TDocNameObj_Date',        },
*/

export const Label_TOID = 'ApiTransObject.TOID';
export const Label_DGID = 'ApiTransObject.DGID';
export const Label_TransID = 'ApiTransObject.TransID';
export const Label_TP_PartID = 'ApiTransObject.TP_PartID';
export const Label_TDocName = 'ApiTransObject.TDocName';
export const Label_FilenameLayout = 'ApiTransObject.FilenameLayout';
export const Label_PackageSeparately = 'ApiTransObject.PackageSeparately';
export const Label_UseControlNums = 'ApiTransObject.UseControlNums';
export const Label_TransIDImportDate = 'ApiTransObject.TransIDImportDate';
export const Label_TransIDObj_Date = 'ApiTransObject.TransIDObj_Date';
export const Label_TDocNameImportDate = 'ApiTransObject.TDocNameImportDate';
export const Label_TDocNameObj_Date = 'ApiTransObject.TDocNameObj_Date';
