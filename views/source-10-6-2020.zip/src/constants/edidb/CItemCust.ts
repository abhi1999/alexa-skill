import { IItemCust } from '../edidb'
export class CItemCust implements IItemCust {
    public Int_Item_No:string = '';
    public TP_PartID:string = '';
    public Cust_Item_Qual:string = '';
    public Cust_Item_ID:string = '';
    public Cust_Item_UM:string = '';
    public Cust_Item_SizeWidth:string = '';
    public Cust_Item_Pack_Qty:number = 0;
    public Cust_Item_UMout:string = '';
    public Cust_Item_UMfactor:number = 0;
    public Cust_Item_UMoperin:string = '';
    public Cust_Item_UMoperout:string = '';
    public pricecode:string = '';
    public price:number = 0;
    public locid:string = '';
    public ICID:string = '';
    public GenericRef:boolean;
    public User1:string = '';
    public User2:string = '';
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public Loc_Override:string = '';
    public constructor(init?:Partial<CItemCust>) { Object.assign(this, init); }
}
export const IItemCust_Int_Item_No_length = 500;
export const IItemCust_TP_PartID_length = 30;
export const IItemCust_Cust_Item_Qual_length = 3;
export const IItemCust_Cust_Item_ID_length = 50;
export const IItemCust_Cust_Item_UM_length = 10;
export const IItemCust_Cust_Item_SizeWidth_length = 5;
export const IItemCust_Cust_Item_UMout_length = 10;
export const IItemCust_Cust_Item_UMoperin_length = 1;
export const IItemCust_Cust_Item_UMoperout_length = 1;
export const IItemCust_pricecode_length = 30;
export const IItemCust_locid_length = 20;
export const IItemCust_User1_length = 50;
export const IItemCust_User2_length = 50;
export const IItemCust_User3_length = 50;
export const IItemCust_User4_length = 50;
export const IItemCust_User5_length = 50;
export const IItemCust_Loc_Override_length = 20;

export const kItemCust_Int_Item_No="Int_Item_No";
export const kItemCust_TP_PartID="TP_PartID";
export const kItemCust_Cust_Item_Qual="Cust_Item_Qual";
export const kItemCust_Cust_Item_ID="Cust_Item_ID";
export const kItemCust_Cust_Item_UM="Cust_Item_UM";
export const kItemCust_Cust_Item_SizeWidth="Cust_Item_SizeWidth";
export const kItemCust_Cust_Item_Pack_Qty="Cust_Item_Pack_Qty";
export const kItemCust_Cust_Item_UMout="Cust_Item_UMout";
export const kItemCust_Cust_Item_UMfactor="Cust_Item_UMfactor";
export const kItemCust_Cust_Item_UMoperin="Cust_Item_UMoperin";
export const kItemCust_Cust_Item_UMoperout="Cust_Item_UMoperout";
export const kItemCust_pricecode="pricecode";
export const kItemCust_price="price";
export const kItemCust_locid="locid";
export const kItemCust_ICID="ICID";
export const kItemCust_GenericRef="GenericRef";
export const kItemCust_User1="User1";
export const kItemCust_User2="User2";
export const kItemCust_User3="User3";
export const kItemCust_User4="User4";
export const kItemCust_User5="User5";
export const kItemCust_Loc_Override="Loc_Override";

/*
        'ItemCust' : {
            'Int_Item_No' : 'Int_Item_No',
            'TP_PartID' : 'TP_PartID',
            'Cust_Item_Qual' : 'Cust_Item_Qual',
            'Cust_Item_ID' : 'Cust_Item_ID',
            'Cust_Item_UM' : 'Cust_Item_UM',
            'Cust_Item_SizeWidth' : 'Cust_Item_SizeWidth',
            'Cust_Item_Pack_Qty' : 'Cust_Item_Pack_Qty',
            'Cust_Item_UMout' : 'Cust_Item_UMout',
            'Cust_Item_UMfactor' : 'Cust_Item_UMfactor',
            'Cust_Item_UMoperin' : 'Cust_Item_UMoperin',
            'Cust_Item_UMoperout' : 'Cust_Item_UMoperout',
            'pricecode' : 'pricecode',
            'price' : 'price',
            'locid' : 'locid',
            'ICID' : 'ICID',
            'GenericRef' : 'GenericRef',
            'User1' : 'User1',
            'User2' : 'User2',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'Loc_Override' : 'Loc_Override',
        },
*/

export const Label_Int_Item_No = 'ItemCust.Int_Item_No';
export const Label_TP_PartID = 'ItemCust.TP_PartID';
export const Label_Cust_Item_Qual = 'ItemCust.Cust_Item_Qual';
export const Label_Cust_Item_ID = 'ItemCust.Cust_Item_ID';
export const Label_Cust_Item_UM = 'ItemCust.Cust_Item_UM';
export const Label_Cust_Item_SizeWidth = 'ItemCust.Cust_Item_SizeWidth';
export const Label_Cust_Item_Pack_Qty = 'ItemCust.Cust_Item_Pack_Qty';
export const Label_Cust_Item_UMout = 'ItemCust.Cust_Item_UMout';
export const Label_Cust_Item_UMfactor = 'ItemCust.Cust_Item_UMfactor';
export const Label_Cust_Item_UMoperin = 'ItemCust.Cust_Item_UMoperin';
export const Label_Cust_Item_UMoperout = 'ItemCust.Cust_Item_UMoperout';
export const Label_pricecode = 'ItemCust.pricecode';
export const Label_price = 'ItemCust.price';
export const Label_locid = 'ItemCust.locid';
export const Label_ICID = 'ItemCust.ICID';
export const Label_GenericRef = 'ItemCust.GenericRef';
export const Label_User1 = 'ItemCust.User1';
export const Label_User2 = 'ItemCust.User2';
export const Label_User3 = 'ItemCust.User3';
export const Label_User4 = 'ItemCust.User4';
export const Label_User5 = 'ItemCust.User5';
export const Label_Loc_Override = 'ItemCust.Loc_Override';
