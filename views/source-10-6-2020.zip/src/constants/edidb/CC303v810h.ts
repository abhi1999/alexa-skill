import { IC303v810h } from '../edidb'
export class CC303v810h implements IC303v810h {
    public ORD_ID:number = 0;
    public TP_PartID:string = '';
    public BIG_01:string = '';
    public BIG_02:string = '';
    public BIG_03:string = '';
    public BIG_04:string = '';
    public MISC_Charge:string = '';
    public FRT_Charge:string = '';
    public Sls_Tax:string = '';
    public Ship_Via_ID:string = '';
    public TDS_01:string = '';
    public CTT_01:string = '';
    public Exp_Flag:string = '';
    public TotCartons:number = 0;
    public Bol_No:string = '';
    public TotWeight:number = 0;
    public ImportDate:Date;
    public ExportDate:Date;
    public AcctInvTotal:number = 0;
    public CUR_02:string = '';
    public AckID:string = '';
    public GCN:string = '';
    public TCN:string = '';
    public TaxableAmt:number = 0;
    public FrtTaxAmt:number = 0;
    public Acct_RecID:string = '';
    public Acct_CusNo:string = '';
    public constructor(init?:Partial<CC303v810h>) { Object.assign(this, init); }
}
export const IC303v810h_TP_PartID_length = 30;
export const IC303v810h_BIG_01_length = 8;
export const IC303v810h_BIG_02_length = 22;
export const IC303v810h_BIG_03_length = 8;
export const IC303v810h_BIG_04_length = 22;
export const IC303v810h_MISC_Charge_length = 10;
export const IC303v810h_FRT_Charge_length = 10;
export const IC303v810h_Sls_Tax_length = 10;
export const IC303v810h_Ship_Via_ID_length = 30;
export const IC303v810h_TDS_01_length = 11;
export const IC303v810h_CTT_01_length = 6;
export const IC303v810h_Exp_Flag_length = 1;
export const IC303v810h_Bol_No_length = 30;
export const IC303v810h_CUR_02_length = 3;
export const IC303v810h_AckID_length = 1;
export const IC303v810h_Acct_RecID_length = 30;
export const IC303v810h_Acct_CusNo_length = 50;

export const kC303v810h_ORD_ID="ORD_ID";
export const kC303v810h_TP_PartID="TP_PartID";
export const kC303v810h_BIG_01="BIG_01";
export const kC303v810h_BIG_02="BIG_02";
export const kC303v810h_BIG_03="BIG_03";
export const kC303v810h_BIG_04="BIG_04";
export const kC303v810h_MISC_Charge="MISC_Charge";
export const kC303v810h_FRT_Charge="FRT_Charge";
export const kC303v810h_Sls_Tax="Sls_Tax";
export const kC303v810h_Ship_Via_ID="Ship_Via_ID";
export const kC303v810h_TDS_01="TDS_01";
export const kC303v810h_CTT_01="CTT_01";
export const kC303v810h_Exp_Flag="Exp_Flag";
export const kC303v810h_TotCartons="TotCartons";
export const kC303v810h_Bol_No="Bol_No";
export const kC303v810h_TotWeight="TotWeight";
export const kC303v810h_ImportDate="ImportDate";
export const kC303v810h_ExportDate="ExportDate";
export const kC303v810h_AcctInvTotal="AcctInvTotal";
export const kC303v810h_CUR_02="CUR_02";
export const kC303v810h_AckID="AckID";
export const kC303v810h_GCN="GCN";
export const kC303v810h_TCN="TCN";
export const kC303v810h_TaxableAmt="TaxableAmt";
export const kC303v810h_FrtTaxAmt="FrtTaxAmt";
export const kC303v810h_Acct_RecID="Acct_RecID";
export const kC303v810h_Acct_CusNo="Acct_CusNo";

/*
        'C303v810h' : {
            'ORD_ID' : 'ORD_ID',
            'TP_PartID' : 'TP_PartID',
            'BIG_01' : 'BIG_01',
            'BIG_02' : 'BIG_02',
            'BIG_03' : 'BIG_03',
            'BIG_04' : 'BIG_04',
            'MISC_Charge' : 'MISC_Charge',
            'FRT_Charge' : 'FRT_Charge',
            'Sls_Tax' : 'Sls_Tax',
            'Ship_Via_ID' : 'Ship_Via_ID',
            'TDS_01' : 'TDS_01',
            'CTT_01' : 'CTT_01',
            'Exp_Flag' : 'Exp_Flag',
            'TotCartons' : 'TotCartons',
            'Bol_No' : 'Bol_No',
            'TotWeight' : 'TotWeight',
            'ImportDate' : 'ImportDate',
            'ExportDate' : 'ExportDate',
            'AcctInvTotal' : 'AcctInvTotal',
            'CUR_02' : 'CUR_02',
            'AckID' : 'AckID',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'TaxableAmt' : 'TaxableAmt',
            'FrtTaxAmt' : 'FrtTaxAmt',
            'Acct_RecID' : 'Acct_RecID',
            'Acct_CusNo' : 'Acct_CusNo',        },
*/

export const Label_ORD_ID = 'C303v810h.ORD_ID';
export const Label_TP_PartID = 'C303v810h.TP_PartID';
export const Label_BIG_01 = 'C303v810h.BIG_01';
export const Label_BIG_02 = 'C303v810h.BIG_02';
export const Label_BIG_03 = 'C303v810h.BIG_03';
export const Label_BIG_04 = 'C303v810h.BIG_04';
export const Label_MISC_Charge = 'C303v810h.MISC_Charge';
export const Label_FRT_Charge = 'C303v810h.FRT_Charge';
export const Label_Sls_Tax = 'C303v810h.Sls_Tax';
export const Label_Ship_Via_ID = 'C303v810h.Ship_Via_ID';
export const Label_TDS_01 = 'C303v810h.TDS_01';
export const Label_CTT_01 = 'C303v810h.CTT_01';
export const Label_Exp_Flag = 'C303v810h.Exp_Flag';
export const Label_TotCartons = 'C303v810h.TotCartons';
export const Label_Bol_No = 'C303v810h.Bol_No';
export const Label_TotWeight = 'C303v810h.TotWeight';
export const Label_ImportDate = 'C303v810h.ImportDate';
export const Label_ExportDate = 'C303v810h.ExportDate';
export const Label_AcctInvTotal = 'C303v810h.AcctInvTotal';
export const Label_CUR_02 = 'C303v810h.CUR_02';
export const Label_AckID = 'C303v810h.AckID';
export const Label_GCN = 'C303v810h.GCN';
export const Label_TCN = 'C303v810h.TCN';
export const Label_TaxableAmt = 'C303v810h.TaxableAmt';
export const Label_FrtTaxAmt = 'C303v810h.FrtTaxAmt';
export const Label_Acct_RecID = 'C303v810h.Acct_RecID';
export const Label_Acct_CusNo = 'C303v810h.Acct_CusNo';
