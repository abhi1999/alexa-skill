import { IApiOsnOrderView } from '../edidb'
export class CApiOsnOrderView implements IApiOsnOrderView {
    public Asn_ID:number = 0;
    public Order_No:number = 0;
    public Line_No:number = 0;
    public TP_ID:string = '';
    public ShipTo_Xref:string = '';
    public Order_Date:string = '';
    public Ship_Date:string = '';
    public Cust_PO:string = '';
    public Cust_Dept:string = '';
    public Loc_ID:string = '';
    public Ship_To_ID:string = '';
    public Ship_To_Name:string = '';
    public Ship_To_Address1:string = '';
    public Ship_To_Address2:string = '';
    public Ship_To_City:string = '';
    public Ship_To_St:string = '';
    public Ship_To_Zip:string = '';
    public ShipFr_Name:string = '';
    public ShipFr_Addr1:string = '';
    public ShipFr_Add2:string = '';
    public ShipFr_City:string = '';
    public ShipFr_St:string = '';
    public ShipFr_Zip:string = '';
    public ShipFr_Country:string = '';
    public Int_Item_No:string = '';
    public Quantity:number = 0;
    public QtyPacked:number = 0;
    public Price:number = 0;
    public UnitofMeas:string = '';
    public Exp_Flag:string = '';
    public Stat_Flag:string = '';
    public Order_Wt:number = 0;
    public Acct_Line_No:number = 0;
    public User1:string = '';
    public User2:string = '';
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public Ship_To_Address3:string = '';
    public TP_PartID:string = '';
    public Acct_Order_No:string = '';
    public Ship_To_Country:string = '';
    public Pick_Date:string = '';
    public QtyPackedS:string = '';
    public QuantityS:string = '';
    public PackQty:string = '';
    public Box_ID:number = 0;
    public Pack_Level:number = 0;
    public SSCC:string = '';
    public PriceC:number = 0;
    public Order_DateF:Date;
    public constructor(init?:Partial<CApiOsnOrderView>) { Object.assign(this, init); }
}
export const IApiOsnOrderView_TP_ID_length = 30;
export const IApiOsnOrderView_ShipTo_Xref_length = 30;
export const IApiOsnOrderView_Order_Date_length = 8;
export const IApiOsnOrderView_Ship_Date_length = 8;
export const IApiOsnOrderView_Cust_PO_length = 30;
export const IApiOsnOrderView_Cust_Dept_length = 30;
export const IApiOsnOrderView_Loc_ID_length = 20;
export const IApiOsnOrderView_Ship_To_ID_length = 40;
export const IApiOsnOrderView_Ship_To_Name_length = 50;
export const IApiOsnOrderView_Ship_To_Address1_length = 50;
export const IApiOsnOrderView_Ship_To_Address2_length = 50;
export const IApiOsnOrderView_Ship_To_City_length = 30;
export const IApiOsnOrderView_Ship_To_St_length = 20;
export const IApiOsnOrderView_Ship_To_Zip_length = 20;
export const IApiOsnOrderView_ShipFr_Name_length = 50;
export const IApiOsnOrderView_ShipFr_Addr1_length = 50;
export const IApiOsnOrderView_ShipFr_Add2_length = 50;
export const IApiOsnOrderView_ShipFr_City_length = 30;
export const IApiOsnOrderView_ShipFr_St_length = 20;
export const IApiOsnOrderView_ShipFr_Zip_length = 20;
export const IApiOsnOrderView_ShipFr_Country_length = 30;
export const IApiOsnOrderView_Int_Item_No_length = 500;
export const IApiOsnOrderView_UnitofMeas_length = 10;
export const IApiOsnOrderView_Exp_Flag_length = 1;
export const IApiOsnOrderView_Stat_Flag_length = 1;
export const IApiOsnOrderView_User1_length = 30;
export const IApiOsnOrderView_User2_length = 30;
export const IApiOsnOrderView_User3_length = 30;
export const IApiOsnOrderView_User4_length = 30;
export const IApiOsnOrderView_User5_length = 30;
export const IApiOsnOrderView_Ship_To_Address3_length = 50;
export const IApiOsnOrderView_TP_PartID_length = 30;
export const IApiOsnOrderView_Acct_Order_No_length = 30;
export const IApiOsnOrderView_Ship_To_Country_length = 30;
export const IApiOsnOrderView_Pick_Date_length = 8;
export const IApiOsnOrderView_QtyPackedS_length = 8000;
export const IApiOsnOrderView_QuantityS_length = 8000;
export const IApiOsnOrderView_PackQty_length = 8000;
export const IApiOsnOrderView_SSCC_length = 30;

export const kApiOsnOrderView_Asn_ID="Asn_ID";
export const kApiOsnOrderView_Order_No="Order_No";
export const kApiOsnOrderView_Line_No="Line_No";
export const kApiOsnOrderView_TP_ID="TP_ID";
export const kApiOsnOrderView_ShipTo_Xref="ShipTo_Xref";
export const kApiOsnOrderView_Order_Date="Order_Date";
export const kApiOsnOrderView_Ship_Date="Ship_Date";
export const kApiOsnOrderView_Cust_PO="Cust_PO";
export const kApiOsnOrderView_Cust_Dept="Cust_Dept";
export const kApiOsnOrderView_Loc_ID="Loc_ID";
export const kApiOsnOrderView_Ship_To_ID="Ship_To_ID";
export const kApiOsnOrderView_Ship_To_Name="Ship_To_Name";
export const kApiOsnOrderView_Ship_To_Address1="Ship_To_Address1";
export const kApiOsnOrderView_Ship_To_Address2="Ship_To_Address2";
export const kApiOsnOrderView_Ship_To_City="Ship_To_City";
export const kApiOsnOrderView_Ship_To_St="Ship_To_St";
export const kApiOsnOrderView_Ship_To_Zip="Ship_To_Zip";
export const kApiOsnOrderView_ShipFr_Name="ShipFr_Name";
export const kApiOsnOrderView_ShipFr_Addr1="ShipFr_Addr1";
export const kApiOsnOrderView_ShipFr_Add2="ShipFr_Add2";
export const kApiOsnOrderView_ShipFr_City="ShipFr_City";
export const kApiOsnOrderView_ShipFr_St="ShipFr_St";
export const kApiOsnOrderView_ShipFr_Zip="ShipFr_Zip";
export const kApiOsnOrderView_ShipFr_Country="ShipFr_Country";
export const kApiOsnOrderView_Int_Item_No="Int_Item_No";
export const kApiOsnOrderView_Quantity="Quantity";
export const kApiOsnOrderView_QtyPacked="QtyPacked";
export const kApiOsnOrderView_Price="Price";
export const kApiOsnOrderView_UnitofMeas="UnitofMeas";
export const kApiOsnOrderView_Exp_Flag="Exp_Flag";
export const kApiOsnOrderView_Stat_Flag="Stat_Flag";
export const kApiOsnOrderView_Order_Wt="Order_Wt";
export const kApiOsnOrderView_Acct_Line_No="Acct_Line_No";
export const kApiOsnOrderView_User1="User1";
export const kApiOsnOrderView_User2="User2";
export const kApiOsnOrderView_User3="User3";
export const kApiOsnOrderView_User4="User4";
export const kApiOsnOrderView_User5="User5";
export const kApiOsnOrderView_Ship_To_Address3="Ship_To_Address3";
export const kApiOsnOrderView_TP_PartID="TP_PartID";
export const kApiOsnOrderView_Acct_Order_No="Acct_Order_No";
export const kApiOsnOrderView_Ship_To_Country="Ship_To_Country";
export const kApiOsnOrderView_Pick_Date="Pick_Date";
export const kApiOsnOrderView_QtyPackedS="QtyPackedS";
export const kApiOsnOrderView_QuantityS="QuantityS";
export const kApiOsnOrderView_PackQty="PackQty";
export const kApiOsnOrderView_Box_ID="Box_ID";
export const kApiOsnOrderView_Pack_Level="Pack_Level";
export const kApiOsnOrderView_SSCC="SSCC";
export const kApiOsnOrderView_PriceC="PriceC";
export const kApiOsnOrderView_Order_DateF="Order_DateF";

/*
        'ApiOsnOrderView' : {
            'Asn_ID' : 'Asn_ID',
            'Order_No' : 'Order_No',
            'Line_No' : 'Line_No',
            'TP_ID' : 'TP_ID',
            'ShipTo_Xref' : 'ShipTo_Xref',
            'Order_Date' : 'Order_Date',
            'Ship_Date' : 'Ship_Date',
            'Cust_PO' : 'Cust_PO',
            'Cust_Dept' : 'Cust_Dept',
            'Loc_ID' : 'Loc_ID',
            'Ship_To_ID' : 'Ship_To_ID',
            'Ship_To_Name' : 'Ship_To_Name',
            'Ship_To_Address1' : 'Ship_To_Address1',
            'Ship_To_Address2' : 'Ship_To_Address2',
            'Ship_To_City' : 'Ship_To_City',
            'Ship_To_St' : 'Ship_To_St',
            'Ship_To_Zip' : 'Ship_To_Zip',
            'ShipFr_Name' : 'ShipFr_Name',
            'ShipFr_Addr1' : 'ShipFr_Addr1',
            'ShipFr_Add2' : 'ShipFr_Add2',
            'ShipFr_City' : 'ShipFr_City',
            'ShipFr_St' : 'ShipFr_St',
            'ShipFr_Zip' : 'ShipFr_Zip',
            'ShipFr_Country' : 'ShipFr_Country',
            'Int_Item_No' : 'Int_Item_No',
            'Quantity' : 'Quantity',
            'QtyPacked' : 'QtyPacked',
            'Price' : 'Price',
            'UnitofMeas' : 'UnitofMeas',
            'Exp_Flag' : 'Exp_Flag',
            'Stat_Flag' : 'Stat_Flag',
            'Order_Wt' : 'Order_Wt',
            'Acct_Line_No' : 'Acct_Line_No',
            'User1' : 'User1',
            'User2' : 'User2',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'Ship_To_Address3' : 'Ship_To_Address3',
            'TP_PartID' : 'TP_PartID',
            'Acct_Order_No' : 'Acct_Order_No',
            'Ship_To_Country' : 'Ship_To_Country',
            'Pick_Date' : 'Pick_Date',
            'QtyPackedS' : 'QtyPackedS',
            'QuantityS' : 'QuantityS',
            'PackQty' : 'PackQty',
            'Box_ID' : 'Box_ID',
            'Pack_Level' : 'Pack_Level',
            'SSCC' : 'SSCC',
            'PriceC' : 'PriceC',
            'Order_DateF' : 'Order_DateF',        },
*/

export const Label_Asn_ID = 'ApiOsnOrderView.Asn_ID';
export const Label_Order_No = 'ApiOsnOrderView.Order_No';
export const Label_Line_No = 'ApiOsnOrderView.Line_No';
export const Label_TP_ID = 'ApiOsnOrderView.TP_ID';
export const Label_ShipTo_Xref = 'ApiOsnOrderView.ShipTo_Xref';
export const Label_Order_Date = 'ApiOsnOrderView.Order_Date';
export const Label_Ship_Date = 'ApiOsnOrderView.Ship_Date';
export const Label_Cust_PO = 'ApiOsnOrderView.Cust_PO';
export const Label_Cust_Dept = 'ApiOsnOrderView.Cust_Dept';
export const Label_Loc_ID = 'ApiOsnOrderView.Loc_ID';
export const Label_Ship_To_ID = 'ApiOsnOrderView.Ship_To_ID';
export const Label_Ship_To_Name = 'ApiOsnOrderView.Ship_To_Name';
export const Label_Ship_To_Address1 = 'ApiOsnOrderView.Ship_To_Address1';
export const Label_Ship_To_Address2 = 'ApiOsnOrderView.Ship_To_Address2';
export const Label_Ship_To_City = 'ApiOsnOrderView.Ship_To_City';
export const Label_Ship_To_St = 'ApiOsnOrderView.Ship_To_St';
export const Label_Ship_To_Zip = 'ApiOsnOrderView.Ship_To_Zip';
export const Label_ShipFr_Name = 'ApiOsnOrderView.ShipFr_Name';
export const Label_ShipFr_Addr1 = 'ApiOsnOrderView.ShipFr_Addr1';
export const Label_ShipFr_Add2 = 'ApiOsnOrderView.ShipFr_Add2';
export const Label_ShipFr_City = 'ApiOsnOrderView.ShipFr_City';
export const Label_ShipFr_St = 'ApiOsnOrderView.ShipFr_St';
export const Label_ShipFr_Zip = 'ApiOsnOrderView.ShipFr_Zip';
export const Label_ShipFr_Country = 'ApiOsnOrderView.ShipFr_Country';
export const Label_Int_Item_No = 'ApiOsnOrderView.Int_Item_No';
export const Label_Quantity = 'ApiOsnOrderView.Quantity';
export const Label_QtyPacked = 'ApiOsnOrderView.QtyPacked';
export const Label_Price = 'ApiOsnOrderView.Price';
export const Label_UnitofMeas = 'ApiOsnOrderView.UnitofMeas';
export const Label_Exp_Flag = 'ApiOsnOrderView.Exp_Flag';
export const Label_Stat_Flag = 'ApiOsnOrderView.Stat_Flag';
export const Label_Order_Wt = 'ApiOsnOrderView.Order_Wt';
export const Label_Acct_Line_No = 'ApiOsnOrderView.Acct_Line_No';
export const Label_User1 = 'ApiOsnOrderView.User1';
export const Label_User2 = 'ApiOsnOrderView.User2';
export const Label_User3 = 'ApiOsnOrderView.User3';
export const Label_User4 = 'ApiOsnOrderView.User4';
export const Label_User5 = 'ApiOsnOrderView.User5';
export const Label_Ship_To_Address3 = 'ApiOsnOrderView.Ship_To_Address3';
export const Label_TP_PartID = 'ApiOsnOrderView.TP_PartID';
export const Label_Acct_Order_No = 'ApiOsnOrderView.Acct_Order_No';
export const Label_Ship_To_Country = 'ApiOsnOrderView.Ship_To_Country';
export const Label_Pick_Date = 'ApiOsnOrderView.Pick_Date';
export const Label_QtyPackedS = 'ApiOsnOrderView.QtyPackedS';
export const Label_QuantityS = 'ApiOsnOrderView.QuantityS';
export const Label_PackQty = 'ApiOsnOrderView.PackQty';
export const Label_Box_ID = 'ApiOsnOrderView.Box_ID';
export const Label_Pack_Level = 'ApiOsnOrderView.Pack_Level';
export const Label_SSCC = 'ApiOsnOrderView.SSCC';
export const Label_PriceC = 'ApiOsnOrderView.PriceC';
export const Label_Order_DateF = 'ApiOsnOrderView.Order_DateF';
