import { IPlanSchedGrp } from '../edidb'
export class CPlanSchedGrp implements IPlanSchedGrp {
    public PSGID:string = '';
    public PSIID:string = '';
    public psglevel:number = 0;
    public psgtype:string = '';
    public psgdocline:number = 0;
    public pardocline:number = 0;
    public psgqual:string = '';
    public psgtext:string = '';
    public constructor(init?:Partial<CPlanSchedGrp>) { Object.assign(this, init); }
}
export const IPlanSchedGrp_psgtype_length = 1;
export const IPlanSchedGrp_psgqual_length = 10;
export const IPlanSchedGrp_psgtext_length = 80;

export const kPlanSchedGrp_PSGID="PSGID";
export const kPlanSchedGrp_PSIID="PSIID";
export const kPlanSchedGrp_psglevel="psglevel";
export const kPlanSchedGrp_psgtype="psgtype";
export const kPlanSchedGrp_psgdocline="psgdocline";
export const kPlanSchedGrp_pardocline="pardocline";
export const kPlanSchedGrp_psgqual="psgqual";
export const kPlanSchedGrp_psgtext="psgtext";

/*
        'PlanSchedGrp' : {
            'PSGID' : 'PSGID',
            'PSIID' : 'PSIID',
            'psglevel' : 'psglevel',
            'psgtype' : 'psgtype',
            'psgdocline' : 'psgdocline',
            'pardocline' : 'pardocline',
            'psgqual' : 'psgqual',
            'psgtext' : 'psgtext',        },
*/

export const Label_PSGID = 'PlanSchedGrp.PSGID';
export const Label_PSIID = 'PlanSchedGrp.PSIID';
export const Label_psglevel = 'PlanSchedGrp.psglevel';
export const Label_psgtype = 'PlanSchedGrp.psgtype';
export const Label_psgdocline = 'PlanSchedGrp.psgdocline';
export const Label_pardocline = 'PlanSchedGrp.pardocline';
export const Label_psgqual = 'PlanSchedGrp.psgqual';
export const Label_psgtext = 'PlanSchedGrp.psgtext';
