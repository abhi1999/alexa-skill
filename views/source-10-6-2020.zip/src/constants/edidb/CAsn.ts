import { IAsn } from '../edidb'
export class CAsn implements IAsn {
    public Asn_ID:number = 0;
    public Bol_No:string = '';
    public Pro_No:string = '';
    public ShipToPeps:boolean;
    public Ship_Weight:number = 0;
    public Ship_Date:string = '';
    public Del_Date:string = '';
    public Ship_Via_ID:string = '';
    public Asn_Complete:string = '';
    public Exp_Flag:string = '';
    public TP_PartID:string = '';
    public User1:string = '';
    public User2:string = '';
    public Trailer:string = '';
    public Collect:boolean;
    public AckID:string = '';
    public GCN:string = '';
    public TCN:string = '';
    public User3:string = '';
    public User4:string = '';
    public User5:string = '';
    public SealNo:string = '';
    public ExportDate:Date;
    public CreatedDate:Date;
    public PackImport:string = '';
    public VPIDFA:number = 0;
    public AutoCalcWeight:boolean;
    public constructor(init?:Partial<CAsn>) { Object.assign(this, init); }
}
export const IAsn_Bol_No_length = 30;
export const IAsn_Pro_No_length = 30;
export const IAsn_Ship_Date_length = 8;
export const IAsn_Del_Date_length = 8;
export const IAsn_Ship_Via_ID_length = 30;
export const IAsn_Asn_Complete_length = 1;
export const IAsn_Exp_Flag_length = 1;
export const IAsn_TP_PartID_length = 30;
export const IAsn_User1_length = 50;
export const IAsn_User2_length = 50;
export const IAsn_Trailer_length = 50;
export const IAsn_AckID_length = 1;
export const IAsn_GCN_length = 20;
export const IAsn_TCN_length = 20;
export const IAsn_User3_length = 50;
export const IAsn_User4_length = 50;
export const IAsn_User5_length = 50;
export const IAsn_SealNo_length = 200;
export const IAsn_PackImport_length = 1;

export const kAsn_Asn_ID="Asn_ID";
export const kAsn_Bol_No="Bol_No";
export const kAsn_Pro_No="Pro_No";
export const kAsn_ShipToPeps="ShipToPeps";
export const kAsn_Ship_Weight="Ship_Weight";
export const kAsn_Ship_Date="Ship_Date";
export const kAsn_Del_Date="Del_Date";
export const kAsn_Ship_Via_ID="Ship_Via_ID";
export const kAsn_Asn_Complete="Asn_Complete";
export const kAsn_Exp_Flag="Exp_Flag";
export const kAsn_TP_PartID="TP_PartID";
export const kAsn_User1="User1";
export const kAsn_User2="User2";
export const kAsn_Trailer="Trailer";
export const kAsn_Collect="Collect";
export const kAsn_AckID="AckID";
export const kAsn_GCN="GCN";
export const kAsn_TCN="TCN";
export const kAsn_User3="User3";
export const kAsn_User4="User4";
export const kAsn_User5="User5";
export const kAsn_SealNo="SealNo";
export const kAsn_ExportDate="ExportDate";
export const kAsn_CreatedDate="CreatedDate";
export const kAsn_PackImport="PackImport";
export const kAsn_VPIDFA="VPIDFA";
export const kAsn_AutoCalcWeight="AutoCalcWeight";

/*
        'Asn' : {
            'Asn_ID' : 'Asn_ID',
            'Bol_No' : 'Bol_No',
            'Pro_No' : 'Pro_No',
            'ShipToPeps' : 'ShipToPeps',
            'Ship_Weight' : 'Ship_Weight',
            'Ship_Date' : 'Ship_Date',
            'Del_Date' : 'Del_Date',
            'Ship_Via_ID' : 'Ship_Via_ID',
            'Asn_Complete' : 'Asn_Complete',
            'Exp_Flag' : 'Exp_Flag',
            'TP_PartID' : 'TP_PartID',
            'User1' : 'User1',
            'User2' : 'User2',
            'Trailer' : 'Trailer',
            'Collect' : 'Collect',
            'AckID' : 'AckID',
            'GCN' : 'GCN',
            'TCN' : 'TCN',
            'User3' : 'User3',
            'User4' : 'User4',
            'User5' : 'User5',
            'SealNo' : 'SealNo',
            'ExportDate' : 'ExportDate',
            'CreatedDate' : 'CreatedDate',
            'PackImport' : 'PackImport',
            'VPIDFA' : 'VPIDFA',
        },
*/

export const Label_Asn_ID = 'Asn.Asn_ID';
export const Label_Bol_No = 'Asn.Bol_No';
export const Label_Pro_No = 'Asn.Pro_No';
export const Label_ShipToPeps = 'Asn.ShipToPeps';
export const Label_Ship_Weight = 'Asn.Ship_Weight';
export const Label_Ship_Date = 'Asn.Ship_Date';
export const Label_Del_Date = 'Asn.Del_Date';
export const Label_Ship_Via_ID = 'Asn.Ship_Via_ID';
export const Label_Asn_Complete = 'Asn.Asn_Complete';
export const Label_Exp_Flag = 'Asn.Exp_Flag';
export const Label_TP_PartID = 'Asn.TP_PartID';
export const Label_User1 = 'Asn.User1';
export const Label_User2 = 'Asn.User2';
export const Label_Trailer = 'Asn.Trailer';
export const Label_Collect = 'Asn.Collect';
export const Label_AckID = 'Asn.AckID';
export const Label_GCN = 'Asn.GCN';
export const Label_TCN = 'Asn.TCN';
export const Label_User3 = 'Asn.User3';
export const Label_User4 = 'Asn.User4';
export const Label_User5 = 'Asn.User5';
export const Label_SealNo = 'Asn.SealNo';
export const Label_ExportDate = 'Asn.ExportDate';
export const Label_CreatedDate = 'Asn.CreatedDate';
export const Label_PackImport = 'Asn.PackImport';
export const Label_VPIDFA = 'Asn.VPIDFA';
export const Label_AutoCalcWeight = 'Asn.AutoCalcWeight';
