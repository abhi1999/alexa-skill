import { IAutomotiveProcessParams, eProcessFunction } from '../DMS.EDI.Shared.Interfaces';

export class CAutomotiveProcessParams implements IAutomotiveProcessParams {
    public ProcessFunction : eProcessFunction.ProcessPlanSchedule;
    public ProcessType : '';
    public DocGroup : '';
    public Pid: '';
    public TpPartID : '';

    public constructor(init?:Partial<CAutomotiveProcessParams>) { Object.assign(this, init); }
}

export const KAutomotiveProcessParams_ProcessFunction = "ProcessFunction";
export const KAutomotiveProcessParams_ProcessType = "ProcessType";
export const KAutomotiveProcessParams_DocGroup = "DocGroup";
export const KAutomotiveProcessParams_Pid = "Pid";
export const KAutomotiveProcessParams_TpPartID = "TpPartID";