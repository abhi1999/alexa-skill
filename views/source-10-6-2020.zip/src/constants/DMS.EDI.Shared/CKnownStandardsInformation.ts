import { IKnownStandardsInformation } from '../DMS.EDI.Shared.Interfaces';
import { IEdiStandardsStatusErrorLog } from'../../constants/ApiStructs';

export class CKnownStandardsInformation implements IKnownStandardsInformation {
    public Downloaded : null;
    public FileName : '';
    public FileSize : 0;
    public Installed : false;
    public IsInstalling : false;
    public IsDownloading : false;
    public JobStatus : { IsDownloading : false, IsInstalling : false, 
        PID : '', ProcessID : -1, CPUTime : '', Downloaded : null, 
        Installed: false, Std_ID: '', Rel_No : '', ErrorLogList : IEdiStandardsStatusErrorLog[]
    }
    public ReleaseNumber : '';
    public StandardID : '';
    public constructor(init?:Partial<CKnownStandardsInformation>) { Object.assign(this, init); }
}

export const KKnownStandardsInformation_Downloaded = "Downloaded";
export const KKnownStandardsInformation_FileName = "FileName";
export const KKnownStandardsInformation_FileSize = "FileSize";
export const KKnownStandardsInformation_Installed = "Installed";
export const KKnownStandardsInformation_IsInstalling = "IsInstalling";
export const KKnownStandardsInformation_IsDownloading = "IsDownloading";
export const KKnownStandardsInformation_JobStatus = "JobStatus";
export const KKnownStandardsInformation_ReleaseNumber = "ReleaseNumber";
export const KKnownStandardsInformation_StandardID = "StandardID";
