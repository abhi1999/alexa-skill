// Common lookup for Plannng Schedule and Production Sequence
import KeyValuePair from '../constants/params/keyValuePair';

export const automotiveTypesLoookup : KeyValuePair[] = [ 
    // new KeyValuePair({key:'all', value:'Global.All'}),
    new KeyValuePair({key:'1', value:'AutomotiveTypes.1'}),
    new KeyValuePair({key:'4', value:'AutomotiveTypes.4'}),
    new KeyValuePair({key:'10', value:'AutomotiveTypes.10'}),
    new KeyValuePair({key:'15', value:'AutomotiveTypes.15'}),
    new KeyValuePair({key:'A', value:'AutomotiveTypes.A'}),
    new KeyValuePair({key:'B', value:'AutomotiveTypes.B'}),
    new KeyValuePair({key:'C', value:'AutomotiveTypes.C'}),
    new KeyValuePair({key:'D', value:'AutomotiveTypes.D'}),
    new KeyValuePair({key:'E', value:'AutomotiveTypes.E'}),
    new KeyValuePair({key:'F', value:'AutomotiveTypes.F'}),
    new KeyValuePair({key:'G', value:'AutomotiveTypes.G'}),
    new KeyValuePair({key:'H', value:'AutomotiveTypes.H'}),
    new KeyValuePair({key:'K', value:'AutomotiveTypes.K'}),
    new KeyValuePair({key:'L', value:'AutomotiveTypes.L'}),
    new KeyValuePair({key:'M', value:'AutomotiveTypes.M'}),
    new KeyValuePair({key:'N', value:'AutomotiveTypes.N'}),
    new KeyValuePair({key:'P', value:'AutomotiveTypes.P'}),
    new KeyValuePair({key:'Q', value:'AutomotiveTypes.Q'}),
    new KeyValuePair({key:'S', value:'AutomotiveTypes.S'}),
    new KeyValuePair({key:'T', value:'AutomotiveTypes.T'}),
    new KeyValuePair({key:'U', value:'AutomotiveTypes.U'}),
    new KeyValuePair({key:'V', value:'AutomotiveTypes.V'}),
    new KeyValuePair({key:'W', value:'AutomotiveTypes.W'}),
    new KeyValuePair({key:'X', value:'AutomotiveTypes.X'}),
    new KeyValuePair({key:'Z', value:'AutomotiveTypes.Z'})
]