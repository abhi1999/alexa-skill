export const ICON_SMALL:number = 16;
export const ICON_SIZE:number = 24;
export const ICON_COLOR:string = '#1890ff';
export const ROW_HIGHLIGHT_COLOR:string ="#deecf9";
