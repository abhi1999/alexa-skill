import { IEdiStandardsStatusErrorLog } from'../constants/ApiStructs';

export interface IKnownStandardsStatusReturn {
    IsDownloading : boolean,
    IsInstalling : boolean,
    PID : string,
    ProcessID : number,
    CPUTime : string,
    Downloaded : Date | null,
    Installed : boolean,
    Std_ID : string,
    Rel_No : string,
    ErrorLogList : IEdiStandardsStatusErrorLog[]
}

export interface IKnownStandardsInformation {
    Downloaded : Date | null,
    FileName : string,
    FileSize : number,
    Installed : boolean,
    IsInstalling : boolean,
    IsDownloading : boolean,
    JobStatus : IKnownStandardsStatusReturn,
    ReleaseNumber: string,
    StandardID : string
}

export enum eProcessFunction
{
    ProcessPlanSchedule,
    ProcessProductionSequence
}

export interface IAutomotiveProcessParams {
    ProcessFunction : eProcessFunction,
    ProcessType : string,
    DocGroup : string,
    Pid: string,
    TpPartID : string 
}

export interface IAutomotiveProcessResult
{
    commonResult : ICommonResult,
    Pid : string,
    RecordsToProcess : number,
    RecordsProcessed : number
}

export interface ICommonResult
{
    Message : string,
    Status : boolean
}

export interface ICreateOrderResult
{
    CommonResult : ICommonResult,
    Pid : string,
    RecordsProcessed : number
}
