import { IDmsEDOTokenMaster } from '../DMSDatamasons'
export class CDmsEDOTokenMaster implements IDmsEDOTokenMaster {
    public TMID:string = '';
    public Token_Name:string = '';
    public ErrCode:string = '';
    public DataKey:string = '';
    public UserID:string = '';
    public MachineID:string = '';
    public ModDate:Date;
    public DataAreaID:string = '';
    public constructor(init?:Partial<CDmsEDOTokenMaster>) { Object.assign(this, init); }
}
export const IDmsEDOTokenMaster_Token_Name_length = 50;
export const IDmsEDOTokenMaster_ErrCode_length = 50;
export const IDmsEDOTokenMaster_DataKey_length = 50;
export const IDmsEDOTokenMaster_UserID_length = 50;
export const IDmsEDOTokenMaster_MachineID_length = 50;
export const IDmsEDOTokenMaster_DataAreaID_length = 10;

export const kDmsEDOTokenMaster_TMID="TMID";
export const kDmsEDOTokenMaster_Token_Name="Token_Name";
export const kDmsEDOTokenMaster_ErrCode="ErrCode";
export const kDmsEDOTokenMaster_DataKey="DataKey";
export const kDmsEDOTokenMaster_UserID="UserID";
export const kDmsEDOTokenMaster_MachineID="MachineID";
export const kDmsEDOTokenMaster_ModDate="ModDate";
export const kDmsEDOTokenMaster_DataAreaID="DataAreaID";
