import { IDmsAcctObjectsCurrent } from '../DMSDatamasons'
export class CDmsAcctObjectsCurrent implements IDmsAcctObjectsCurrent {
    public AOID:string = '';
    public ObjID:string = '';
    public CompanyID:number = 0;
    public ObjDesc:string = '';
    public ObjType:string = '';
    public CreateSeq:number = 0;
    public Revision:number = 0;
    public RevDate:Date;
    public RevDesc:string = '';
    public SQLSelect:string = '';
    public ExecScript:boolean;
    public ExecDate:Date;
    public constructor(init?:Partial<CDmsAcctObjectsCurrent>) { Object.assign(this, init); }
}
export const IDmsAcctObjectsCurrent_ObjID_length = 80;
export const IDmsAcctObjectsCurrent_ObjDesc_length = 200;
export const IDmsAcctObjectsCurrent_ObjType_length = 1;
export const IDmsAcctObjectsCurrent_RevDesc_length = 200;

export const kDmsAcctObjectsCurrent_AOID="AOID";
export const kDmsAcctObjectsCurrent_ObjID="ObjID";
export const kDmsAcctObjectsCurrent_CompanyID="CompanyID";
export const kDmsAcctObjectsCurrent_ObjDesc="ObjDesc";
export const kDmsAcctObjectsCurrent_ObjType="ObjType";
export const kDmsAcctObjectsCurrent_CreateSeq="CreateSeq";
export const kDmsAcctObjectsCurrent_Revision="Revision";
export const kDmsAcctObjectsCurrent_RevDate="RevDate";
export const kDmsAcctObjectsCurrent_RevDesc="RevDesc";
export const kDmsAcctObjectsCurrent_SQLSelect="SQLSelect";
export const kDmsAcctObjectsCurrent_ExecScript="ExecScript";
export const kDmsAcctObjectsCurrent_ExecDate="ExecDate";
