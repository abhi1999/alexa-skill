import { IDmsEDOTokenRule } from '../DMSDatamasons'
export class CDmsEDOTokenRule implements IDmsEDOTokenRule {
    public TRID:string = '';
    public DGID:string = '';
    public TMID:string = '';
    public Seq_No:number = 0;
    public SQL_Alias:string = '';
    public SQL_Select:string = '';
    public UserID:string = '';
    public MachineID:string = '';
    public ModDate:Date;
    public DataAreaID:string = '';
    public constructor(init?:Partial<CDmsEDOTokenRule>) { Object.assign(this, init); }
}
export const IDmsEDOTokenRule_DGID_length = 5;
export const IDmsEDOTokenRule_SQL_Alias_length = 50;
export const IDmsEDOTokenRule_SQL_Select_length = 4000;
export const IDmsEDOTokenRule_UserID_length = 50;
export const IDmsEDOTokenRule_MachineID_length = 50;
export const IDmsEDOTokenRule_DataAreaID_length = 10;

export const kDmsEDOTokenRule_TRID="TRID";
export const kDmsEDOTokenRule_DGID="DGID";
export const kDmsEDOTokenRule_TMID="TMID";
export const kDmsEDOTokenRule_Seq_No="Seq_No";
export const kDmsEDOTokenRule_SQL_Alias="SQL_Alias";
export const kDmsEDOTokenRule_SQL_Select="SQL_Select";
export const kDmsEDOTokenRule_UserID="UserID";
export const kDmsEDOTokenRule_MachineID="MachineID";
export const kDmsEDOTokenRule_ModDate="ModDate";
export const kDmsEDOTokenRule_DataAreaID="DataAreaID";
