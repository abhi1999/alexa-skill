import { IDmsStdPosition } from '../DMSDatamasons'
export class CDmsStdPosition implements IDmsStdPosition {
    public Std_ID:string = '';
    public Doc_ID:string = '';
    public Seg_ID:string = '';
    public Ele_No:number = 0;
    public Ele_Pos:number = 0;
    public constructor(init?:Partial<CDmsStdPosition>) { Object.assign(this, init); }
}
export const IDmsStdPosition_Std_ID_length = 10;
export const IDmsStdPosition_Doc_ID_length = 10;
export const IDmsStdPosition_Seg_ID_length = 10;

export const kDmsStdPosition_Std_ID="Std_ID";
export const kDmsStdPosition_Doc_ID="Doc_ID";
export const kDmsStdPosition_Seg_ID="Seg_ID";
export const kDmsStdPosition_Ele_No="Ele_No";
export const kDmsStdPosition_Ele_Pos="Ele_Pos";
