import { IDmsXMLDoc } from '../DMSDatamasons'
export class CDmsXMLDoc implements IDmsXMLDoc {
    public CreatedDate:Date;
    public TP_PartID:string = '';
    public DGID:string = '';
    public Config:boolean;
    public URECID:string = '';
    public Exp_Flag:string = '';
    public ExportDate:Date;
    public XMLText:string = '';
    public XMLID:string = '';
    public constructor(init?:Partial<CDmsXMLDoc>) { Object.assign(this, init); }
}
export const IDmsXMLDoc_TP_PartID_length = 30;
export const IDmsXMLDoc_DGID_length = 5;
export const IDmsXMLDoc_Exp_Flag_length = 1;

export const kDmsXMLDoc_CreatedDate="CreatedDate";
export const kDmsXMLDoc_TP_PartID="TP_PartID";
export const kDmsXMLDoc_DGID="DGID";
export const kDmsXMLDoc_Config="Config";
export const kDmsXMLDoc_URECID="URECID";
export const kDmsXMLDoc_Exp_Flag="Exp_Flag";
export const kDmsXMLDoc_ExportDate="ExportDate";
export const kDmsXMLDoc_XMLText="XMLText";
export const kDmsXMLDoc_XMLID="XMLID";
