import { IDmsEDODoc } from '../DMSDatamasons'
export class CDmsEDODoc implements IDmsEDODoc {
    public TDID:string = '';
    public DocName:string = '';
    public DocDesc:string = '';
    public TradingPartner:string = '';
    public DGID:string = '';
    public DocType:string = '';
    public XMLText:string = '';
    public UserID:string = '';
    public MachineID:string = '';
    public ModDate:Date;
    public DataAreaID:string = '';
    public Status:number = 0;
    public constructor(init?:Partial<CDmsEDODoc>) { Object.assign(this, init); }
}
export const IDmsEDODoc_DocName_length = 80;
export const IDmsEDODoc_DocDesc_length = 200;
export const IDmsEDODoc_TradingPartner_length = 80;
export const IDmsEDODoc_DGID_length = 5;
export const IDmsEDODoc_DocType_length = 20;
export const IDmsEDODoc_UserID_length = 50;
export const IDmsEDODoc_MachineID_length = 50;
export const IDmsEDODoc_DataAreaID_length = 10;

export const kDmsEDODoc_TDID="TDID";
export const kDmsEDODoc_DocName="DocName";
export const kDmsEDODoc_DocDesc="DocDesc";
export const kDmsEDODoc_TradingPartner="TradingPartner";
export const kDmsEDODoc_DGID="DGID";
export const kDmsEDODoc_DocType="DocType";
export const kDmsEDODoc_XMLText="XMLText";
export const kDmsEDODoc_UserID="UserID";
export const kDmsEDODoc_MachineID="MachineID";
export const kDmsEDODoc_ModDate="ModDate";
export const kDmsEDODoc_DataAreaID="DataAreaID";
export const kDmsEDODoc_Status="Status";
