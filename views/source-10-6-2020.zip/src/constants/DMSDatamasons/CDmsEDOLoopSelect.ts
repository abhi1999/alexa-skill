import { IDmsEDOLoopSelect } from '../DMSDatamasons'
export class CDmsEDOLoopSelect implements IDmsEDOLoopSelect {
    public LSID:string = '';
    public TransID:string = '';
    public Trans_Seq_No:number = 0;
    public DGID:string = '';
    public Loop_Ind:string = '';
    public Seq_No:number = 0;
    public SQL_Alias:string = '';
    public ConnectionClient:string = '';
    public ConnectionString:string = '';
    public SQL_Select:string = '';
    public Err_Level:number = 0;
    public DataKey:string = '';
    public UserID:string = '';
    public MachineID:string = '';
    public ModDate:Date;
    public DataAreaID:string = '';
    public constructor(init?:Partial<CDmsEDOLoopSelect>) { Object.assign(this, init); }
}
export const IDmsEDOLoopSelect_TransID_length = 20;
export const IDmsEDOLoopSelect_DGID_length = 5;
export const IDmsEDOLoopSelect_Loop_Ind_length = 50;
export const IDmsEDOLoopSelect_SQL_Alias_length = 50;
export const IDmsEDOLoopSelect_ConnectionClient_length = 10;
export const IDmsEDOLoopSelect_ConnectionString_length = 400;
export const IDmsEDOLoopSelect_SQL_Select_length = 4000;
export const IDmsEDOLoopSelect_DataKey_length = 50;
export const IDmsEDOLoopSelect_UserID_length = 50;
export const IDmsEDOLoopSelect_MachineID_length = 50;
export const IDmsEDOLoopSelect_DataAreaID_length = 10;

export const kDmsEDOLoopSelect_LSID="LSID";
export const kDmsEDOLoopSelect_TransID="TransID";
export const kDmsEDOLoopSelect_Trans_Seq_No="Trans_Seq_No";
export const kDmsEDOLoopSelect_DGID="DGID";
export const kDmsEDOLoopSelect_Loop_Ind="Loop_Ind";
export const kDmsEDOLoopSelect_Seq_No="Seq_No";
export const kDmsEDOLoopSelect_SQL_Alias="SQL_Alias";
export const kDmsEDOLoopSelect_ConnectionClient="ConnectionClient";
export const kDmsEDOLoopSelect_ConnectionString="ConnectionString";
export const kDmsEDOLoopSelect_SQL_Select="SQL_Select";
export const kDmsEDOLoopSelect_Err_Level="Err_Level";
export const kDmsEDOLoopSelect_DataKey="DataKey";
export const kDmsEDOLoopSelect_UserID="UserID";
export const kDmsEDOLoopSelect_MachineID="MachineID";
export const kDmsEDOLoopSelect_ModDate="ModDate";
export const kDmsEDOLoopSelect_DataAreaID="DataAreaID";
