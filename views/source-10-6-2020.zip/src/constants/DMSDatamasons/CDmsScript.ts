import { IDmsScript } from '../DMSDatamasons'
export class CDmsScript implements IDmsScript {
    public StatementID:string = '';
    public GroupID:string = '';
    public Seq:number = 0;
    public Statement:string = '';
    public constructor(init?:Partial<CDmsScript>) { Object.assign(this, init); }
}
export const IDmsScript_StatementID_length = 50;
export const IDmsScript_GroupID_length = 50;
export const IDmsScript_Statement_length = 8000;

export const kDmsScript_StatementID="StatementID";
export const kDmsScript_GroupID="GroupID";
export const kDmsScript_Seq="Seq";
export const kDmsScript_Statement="Statement";
