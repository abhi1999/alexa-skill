import { IDmsEDIDocGroup } from '../DMSDatamasons'
export class CDmsEDIDocGroup implements IDmsEDIDocGroup {
    public DGID:string = '';
    public Doc_Group:string = '';
    public constructor(init?:Partial<CDmsEDIDocGroup>) { Object.assign(this, init); }
}
export const IDmsEDIDocGroup_DGID_length = 5;
export const IDmsEDIDocGroup_Doc_Group_length = 50;

export const kDmsEDIDocGroup_DGID="DGID";
export const kDmsEDIDocGroup_Doc_Group="Doc_Group";
