import { IDmsNetwork } from '../DMSDatamasons'
export class CDmsNetwork implements IDmsNetwork {
    public Van_ID:string = '';
    public VanExt:string = '';
    public VanFTPsite:string = '';
    public VanMailbox:string = '';
    public VanPass:string = '';
    public VanPassive:boolean;
    public VanBinary:boolean;
    public VanSdown:string = '';
    public VanAppendCRLF:number = 0;
    public VanSdir:string = '';
    public VanSup:string = '';
    public constructor(init?:Partial<CDmsNetwork>) { Object.assign(this, init); }
}
export const IDmsNetwork_Van_ID_length = 10;
export const IDmsNetwork_VanExt_length = 3;
export const IDmsNetwork_VanFTPsite_length = 75;
export const IDmsNetwork_VanMailbox_length = 20;
export const IDmsNetwork_VanPass_length = 20;
export const IDmsNetwork_VanSdown_length = 80;
export const IDmsNetwork_VanSdir_length = 50;
export const IDmsNetwork_VanSup_length = 80;

export const kDmsNetwork_Van_ID="Van_ID";
export const kDmsNetwork_VanExt="VanExt";
export const kDmsNetwork_VanFTPsite="VanFTPsite";
export const kDmsNetwork_VanMailbox="VanMailbox";
export const kDmsNetwork_VanPass="VanPass";
export const kDmsNetwork_VanPassive="VanPassive";
export const kDmsNetwork_VanBinary="VanBinary";
export const kDmsNetwork_VanSdown="VanSdown";
export const kDmsNetwork_VanAppendCRLF="VanAppendCRLF";
export const kDmsNetwork_VanSdir="VanSdir";
export const kDmsNetwork_VanSup="VanSup";
