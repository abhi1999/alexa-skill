import { IDmsAcctPackage } from '../DMSDatamasons'
export class CDmsAcctPackage implements IDmsAcctPackage {
    public AcctPackageID:string = '';
    public AcctDesc:string = '';
    public ObjectsUsed:boolean;
    public constructor(init?:Partial<CDmsAcctPackage>) { Object.assign(this, init); }
}
export const IDmsAcctPackage_AcctPackageID_length = 50;
export const IDmsAcctPackage_AcctDesc_length = 80;

export const kDmsAcctPackage_AcctPackageID="AcctPackageID";
export const kDmsAcctPackage_AcctDesc="AcctDesc";
export const kDmsAcctPackage_ObjectsUsed="ObjectsUsed";
