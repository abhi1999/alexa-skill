import { IDmsAcctObjectsRev } from '../DMSDatamasons'
export class CDmsAcctObjectsRev implements IDmsAcctObjectsRev {
    public AOID:string = '';
    public Revision:number = 0;
    public RevDesc:string = '';
    public RevDate:Date;
    public SQLSelect:string = '';
    public Inactive:boolean;
    public constructor(init?:Partial<CDmsAcctObjectsRev>) { Object.assign(this, init); }
}
export const IDmsAcctObjectsRev_RevDesc_length = 200;

export const kDmsAcctObjectsRev_AOID="AOID";
export const kDmsAcctObjectsRev_Revision="Revision";
export const kDmsAcctObjectsRev_RevDesc="RevDesc";
export const kDmsAcctObjectsRev_RevDate="RevDate";
export const kDmsAcctObjectsRev_SQLSelect="SQLSelect";
export const kDmsAcctObjectsRev_Inactive="Inactive";
