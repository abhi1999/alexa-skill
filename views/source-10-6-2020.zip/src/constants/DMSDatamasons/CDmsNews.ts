import { IDmsNews } from '../DMSDatamasons'
export class CDmsNews implements IDmsNews {
    public NewsID:number = 0;
    public NewsDate:Date;
    public NewsDesc:string = '';
    public NewsUrl:string = '';
    public constructor(init?:Partial<CDmsNews>) { Object.assign(this, init); }
}
export const IDmsNews_NewsUrl_length = 200;

export const kDmsNews_NewsID="NewsID";
export const kDmsNews_NewsDate="NewsDate";
export const kDmsNews_NewsDesc="NewsDesc";
export const kDmsNews_NewsUrl="NewsUrl";
