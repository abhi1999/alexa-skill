import { IDmsLicense } from '../DMSDatamasons'
export class CDmsLicense implements IDmsLicense {
    public LicenseCode:string = '';
    public AppName:string = '';
    public Licensee:string = '';
    public ExpDate:Date;
    public constructor(init?:Partial<CDmsLicense>) { Object.assign(this, init); }
}
export const IDmsLicense_LicenseCode_length = 80;
export const IDmsLicense_AppName_length = 80;
export const IDmsLicense_Licensee_length = 80;

export const kDmsLicense_LicenseCode="LicenseCode";
export const kDmsLicense_AppName="AppName";
export const kDmsLicense_Licensee="Licensee";
export const kDmsLicense_ExpDate="ExpDate";
