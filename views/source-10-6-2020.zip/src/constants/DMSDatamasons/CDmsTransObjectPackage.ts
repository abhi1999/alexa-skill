import { IDmsTransObjectPackage } from '../DMSDatamasons'
export class CDmsTransObjectPackage implements IDmsTransObjectPackage {
    public TOID:string = '';
    public AcctPackageID:string = '';
    public DGID:string = '';
    public TransID:string = '';
    public TP_PartID:string = '';
    public TDocName:string = '';
    public FilenameLayout:string = '';
    public PackageSeparately:boolean;
    public UseControlNums:boolean;
    public CompanyID:number = 0;
    public constructor(init?:Partial<CDmsTransObjectPackage>) { Object.assign(this, init); }
}
export const IDmsTransObjectPackage_AcctPackageID_length = 50;
export const IDmsTransObjectPackage_DGID_length = 5;
export const IDmsTransObjectPackage_TransID_length = 50;
export const IDmsTransObjectPackage_TP_PartID_length = 30;
export const IDmsTransObjectPackage_TDocName_length = 80;
export const IDmsTransObjectPackage_FilenameLayout_length = 200;

export const kDmsTransObjectPackage_TOID="TOID";
export const kDmsTransObjectPackage_AcctPackageID="AcctPackageID";
export const kDmsTransObjectPackage_DGID="DGID";
export const kDmsTransObjectPackage_TransID="TransID";
export const kDmsTransObjectPackage_TP_PartID="TP_PartID";
export const kDmsTransObjectPackage_TDocName="TDocName";
export const kDmsTransObjectPackage_FilenameLayout="FilenameLayout";
export const kDmsTransObjectPackage_PackageSeparately="PackageSeparately";
export const kDmsTransObjectPackage_UseControlNums="UseControlNums";
export const kDmsTransObjectPackage_CompanyID="CompanyID";
