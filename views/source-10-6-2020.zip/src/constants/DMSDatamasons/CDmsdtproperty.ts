import { IDmsdtproperty } from '../DMSDatamasons'
export class CDmsdtproperty implements IDmsdtproperty {
    public id:number = 0;
    public objectid:number = 0;
    public property:string = '';
    public value:string = '';
    public uvalue:string = '';
    public lvalue:number[];
    public version:number = 0;
    public constructor(init?:Partial<CDmsdtproperty>) { Object.assign(this, init); }
}
export const IDmsdtproperty_property_length = 64;
export const IDmsdtproperty_value_length = 255;
export const IDmsdtproperty_uvalue_length = 255;

export const kDmsdtproperty_id="id";
export const kDmsdtproperty_objectid="objectid";
export const kDmsdtproperty_property="property";
export const kDmsdtproperty_value="value";
export const kDmsdtproperty_uvalue="uvalue";
export const kDmsdtproperty_lvalue="lvalue";
export const kDmsdtproperty_version="version";
