import { IDmsAckCode } from '../DMSDatamasons'
export class CDmsAckCode implements IDmsAckCode {
    public AckID:string = '';
    public AckDesc:string = '';
    public constructor(init?:Partial<CDmsAckCode>) { Object.assign(this, init); }
}
export const IDmsAckCode_AckID_length = 1;
export const IDmsAckCode_AckDesc_length = 10;

export const kDmsAckCode_AckID="AckID";
export const kDmsAckCode_AckDesc="AckDesc";
