import { IDmsEDOTokenParm } from '../DMSDatamasons'
export class CDmsEDOTokenParm implements IDmsEDOTokenParm {
    public TPID:string = '';
    public TRID:string = '';
    public Seq_No:number = 0;
    public SQL_Alias:string = '';
    public SQL_Select:string = '';
    public FieldList:string = '';
    public Expression:string = '';
    public UserID:string = '';
    public MachineID:string = '';
    public ModDate:Date;
    public DataAreaID:string = '';
    public constructor(init?:Partial<CDmsEDOTokenParm>) { Object.assign(this, init); }
}
export const IDmsEDOTokenParm_SQL_Alias_length = 50;
export const IDmsEDOTokenParm_SQL_Select_length = 4000;
export const IDmsEDOTokenParm_FieldList_length = 200;
export const IDmsEDOTokenParm_Expression_length = 50;
export const IDmsEDOTokenParm_UserID_length = 50;
export const IDmsEDOTokenParm_MachineID_length = 50;
export const IDmsEDOTokenParm_DataAreaID_length = 10;

export const kDmsEDOTokenParm_TPID="TPID";
export const kDmsEDOTokenParm_TRID="TRID";
export const kDmsEDOTokenParm_Seq_No="Seq_No";
export const kDmsEDOTokenParm_SQL_Alias="SQL_Alias";
export const kDmsEDOTokenParm_SQL_Select="SQL_Select";
export const kDmsEDOTokenParm_FieldList="FieldList";
export const kDmsEDOTokenParm_Expression="Expression";
export const kDmsEDOTokenParm_UserID="UserID";
export const kDmsEDOTokenParm_MachineID="MachineID";
export const kDmsEDOTokenParm_ModDate="ModDate";
export const kDmsEDOTokenParm_DataAreaID="DataAreaID";
