import { IDmsEDOTransID } from '../DMSDatamasons'
export class CDmsEDOTransID implements IDmsEDOTransID {
    public TransID:string = '';
    public TransDesc:string = '';
    public UserID:string = '';
    public MachineID:string = '';
    public ModDate:Date;
    public DataAreaID:string = '';
    public constructor(init?:Partial<CDmsEDOTransID>) { Object.assign(this, init); }
}
export const IDmsEDOTransID_TransID_length = 20;
export const IDmsEDOTransID_TransDesc_length = 100;
export const IDmsEDOTransID_UserID_length = 50;
export const IDmsEDOTransID_MachineID_length = 50;
export const IDmsEDOTransID_DataAreaID_length = 10;

export const kDmsEDOTransID_TransID="TransID";
export const kDmsEDOTransID_TransDesc="TransDesc";
export const kDmsEDOTransID_UserID="UserID";
export const kDmsEDOTransID_MachineID="MachineID";
export const kDmsEDOTransID_ModDate="ModDate";
export const kDmsEDOTransID_DataAreaID="DataAreaID";
