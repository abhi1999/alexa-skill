import { IDmsEDOExpression } from '../DMSDatamasons'
export class CDmsEDOExpression implements IDmsEDOExpression {
    public Expressions:string = '';
    public UserID:string = '';
    public MachineID:string = '';
    public ModDate:Date;
    public DataAreaID:string = '';
    public constructor(init?:Partial<CDmsEDOExpression>) { Object.assign(this, init); }
}
export const IDmsEDOExpression_Expressions_length = 100;
export const IDmsEDOExpression_UserID_length = 50;
export const IDmsEDOExpression_MachineID_length = 50;
export const IDmsEDOExpression_DataAreaID_length = 10;

export const kDmsEDOExpression_Expressions="Expressions";
export const kDmsEDOExpression_UserID="UserID";
export const kDmsEDOExpression_MachineID="MachineID";
export const kDmsEDOExpression_ModDate="ModDate";
export const kDmsEDOExpression_DataAreaID="DataAreaID";
