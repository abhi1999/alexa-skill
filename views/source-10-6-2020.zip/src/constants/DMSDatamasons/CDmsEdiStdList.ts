import { IDmsEdiStdList } from '../DMSDatamasons'
export class CDmsEdiStdList implements IDmsEdiStdList {
    public std_id:string = '';
    public rel_no:string = '';
    public std_desc:string = '';
    public std_filename:string = '';
    public std_filesize:number = 0;
    public constructor(init?:Partial<CDmsEdiStdList>) { Object.assign(this, init); }
}
export const IDmsEdiStdList_std_id_length = 50;
export const IDmsEdiStdList_rel_no_length = 50;
export const IDmsEdiStdList_std_desc_length = 50;
export const IDmsEdiStdList_std_filename_length = 50;

export const kDmsEdiStdList_std_id="std_id";
export const kDmsEdiStdList_rel_no="rel_no";
export const kDmsEdiStdList_std_desc="std_desc";
export const kDmsEdiStdList_std_filename="std_filename";
export const kDmsEdiStdList_std_filesize="std_filesize";
