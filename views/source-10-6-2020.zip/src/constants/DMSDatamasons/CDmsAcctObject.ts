import { IDmsAcctObject } from '../DMSDatamasons'
export class CDmsAcctObject implements IDmsAcctObject {
    public AcctPackageID:string = '';
    public ObjID:string = '';
    public CompanyID:number = 0;
    public ObjDesc:string = '';
    public ObjType:string = '';
    public CreateSeq:number = 0;
    public Inactive:boolean;
    public AOID:string = '';
    public constructor(init?:Partial<CDmsAcctObject>) { Object.assign(this, init); }
}
export const IDmsAcctObject_AcctPackageID_length = 10;
export const IDmsAcctObject_ObjID_length = 80;
export const IDmsAcctObject_ObjDesc_length = 80;
export const IDmsAcctObject_ObjType_length = 1;

export const kDmsAcctObject_AcctPackageID="AcctPackageID";
export const kDmsAcctObject_ObjID="ObjID";
export const kDmsAcctObject_CompanyID="CompanyID";
export const kDmsAcctObject_ObjDesc="ObjDesc";
export const kDmsAcctObject_ObjType="ObjType";
export const kDmsAcctObject_CreateSeq="CreateSeq";
export const kDmsAcctObject_Inactive="Inactive";
export const kDmsAcctObject_AOID="AOID";
