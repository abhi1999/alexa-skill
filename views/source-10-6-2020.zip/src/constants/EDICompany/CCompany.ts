import { ICompany } from '../EDICompany'
export class CCompany implements ICompany {
    public Company_ID:number = 0;
    public YourCompany_Name:string = '';
    public YourCompany_DispName:string = '';
    public YourCompany_Qual:string = '';
    public YourCompany_ID:string = '';
    public YourCompany_Duns:string = '';
    public YourCompany_Add1:string = '';
    public YourCompany_Add2:string = '';
    public YourCompany_City:string = '';
    public YourCompany_State:string = '';
    public YourCompany_Zip:string = '';
    public YourCompany_Country:string = '';
    public YourCompany_BillName:string = '';
    public YourCompany_BillAdd1:string = '';
    public YourCompany_BillAdd2:string = '';
    public YourCompany_BillCity:string = '';
    public YourCompany_BillState:string = '';
    public YourCompany_BillZip:string = '';
    public YourCompany_BillCountry:string = '';
    public YourCompany_Contact:string = '';
    public YourCompany_Phone:string = '';
    public YourCompany_Email:string = '';
    public YourMan_ID:string = '';
    public YourContType:string = '';
    public Acct_Package:string = '';
    public CO_UseGroupID:string = '';
    public CO_Multi:string = '';
    public ACCTdirect:string = '';
    public EDIdirect:string = '';
    public vpEDIdirect:string = '';
    public vpSharedirect:string = '';
    public Exp_Date:Date;
    public SupExp:Date;
    public AcctVer:string = '';
    public vpEDIver:string = '';
    public dbVer:number = 0;
    public DecSize:number = 0;
    public AcctCompID:string = '';
    public ODBClogin:string = '';
    public ODBCpass:string = '';
    public DatabaseName:string = '';
    public vpEDIDatabaseName:string = '';
    public ServerIP:string = '';
    public vpEDIServerIP:string = '';
    public ServerPort:number = 0;
    public UseISA:boolean;
    public UpdateASN:boolean;
    public VerifyAcctInvTotal:boolean;
    public UseOldMenu:boolean;
    public Licenses:number = 0;
    public LinkDelDate:boolean;
    public OEM_Layout:string = '';
    public CanGstTax_ID:string = '';
    public FedTax_ID:string = '';
    public EurTax_ID:string = '';
    public Lang_ID:string = '';
    public Axa_UsePackingList:boolean;
    public PostItemSeq:number = 0;
    public MapServer:boolean;
    public Primary_MapServer:string = '';
    public Backup_MapServer:string = '';
    public MacBarcodeInterface:boolean;
    public SecurityEnabled:boolean;
    public mod850:boolean;
    public mod852:boolean;
    public mod856:boolean;
    public mod940:boolean;
    public mod830:boolean;
    public mod862:boolean;
    public mod820:boolean;
    public mod870:boolean;
    public mod810i:boolean;
    public mod856i:boolean;
    public mod855:boolean;
    public mod753:boolean;
    public AxaptaExpandedPO:number = 0;
    public AxaptaSalesTypes:string = '';
    public mWriteToUserFlds:boolean;
    public AuthType:number = 0;
    public ConnString:string = '';
    public AcctPackageID:string = '';
    public TestServer:boolean;
    public AcctSqlObjOwnr:string = '';
    public AutoHoldDoc:boolean;
    public DocCaching:boolean;
    public WMSImportType:number = 0;
    public wfUser:string = '';
    public eODBCpass:string = '';
    public PurgePass:string = '';
    public YourCompany_EDIContact:string = '';
    public YourCompany_EDIPhone:string = '';
    public YourCompany_EDIEmail:string = '';
    public WSAuthority:string = '';
    public WSResource:string = '';
    public WSEndpoint:string = '';
    public WSClientID:string = '';
    public WSLogin:string = '';
    public WSPassword:string = '';
    public constructor(init?:Partial<CCompany>) { Object.assign(this, init); }
}
export const ICompany_YourCompany_Name_length = 40;
export const ICompany_YourCompany_DispName_length = 40;
export const ICompany_YourCompany_Qual_length = 3;
export const ICompany_YourCompany_ID_length = 30;
export const ICompany_YourCompany_Duns_length = 10;
export const ICompany_YourCompany_Add1_length = 40;
export const ICompany_YourCompany_Add2_length = 40;
export const ICompany_YourCompany_City_length = 30;
export const ICompany_YourCompany_State_length = 10;
export const ICompany_YourCompany_Zip_length = 10;
export const ICompany_YourCompany_Country_length = 30;
export const ICompany_YourCompany_BillName_length = 40;
export const ICompany_YourCompany_BillAdd1_length = 40;
export const ICompany_YourCompany_BillAdd2_length = 40;
export const ICompany_YourCompany_BillCity_length = 30;
export const ICompany_YourCompany_BillState_length = 10;
export const ICompany_YourCompany_BillZip_length = 10;
export const ICompany_YourCompany_BillCountry_length = 30;
export const ICompany_YourCompany_Contact_length = 40;
export const ICompany_YourCompany_Phone_length = 20;
export const ICompany_YourCompany_Email_length = 50;
export const ICompany_YourMan_ID_length = 10;
export const ICompany_YourContType_length = 10;
export const ICompany_Acct_Package_length = 20;
export const ICompany_CO_UseGroupID_length = 1;
export const ICompany_CO_Multi_length = 1;
export const ICompany_ACCTdirect_length = 80;
export const ICompany_EDIdirect_length = 80;
export const ICompany_vpEDIdirect_length = 80;
export const ICompany_vpSharedirect_length = 80;
export const ICompany_AcctVer_length = 10;
export const ICompany_vpEDIver_length = 1;
export const ICompany_AcctCompID_length = 1000;
export const ICompany_ODBClogin_length = 80;
export const ICompany_ODBCpass_length = 100;
export const ICompany_DatabaseName_length = 60;
export const ICompany_vpEDIDatabaseName_length = 60;
export const ICompany_ServerIP_length = 50;
export const ICompany_vpEDIServerIP_length = 50;
export const ICompany_OEM_Layout_length = 10;
export const ICompany_CanGstTax_ID_length = 15;
export const ICompany_FedTax_ID_length = 15;
export const ICompany_EurTax_ID_length = 15;
export const ICompany_Lang_ID_length = 3;
export const ICompany_Primary_MapServer_length = 200;
export const ICompany_Backup_MapServer_length = 200;
export const ICompany_AxaptaSalesTypes_length = 50;
export const ICompany_ConnString_length = 400;
export const ICompany_AcctPackageID_length = 10;
export const ICompany_AcctSqlObjOwnr_length = 30;
export const ICompany_wfUser_length = 80;
export const ICompany_eODBCpass_length = 100;
export const ICompany_PurgePass_length = 100;
export const ICompany_YourCompany_EDIContact_length = 40;
export const ICompany_YourCompany_EDIPhone_length = 20;
export const ICompany_YourCompany_EDIEmail_length = 50;
export const ICompany_WSAuthority_length = 200;
export const ICompany_WSResource_length = 200;
export const ICompany_WSEndpoint_length = 200;
export const ICompany_WSClientID_length = 80;
export const ICompany_WSLogin_length = 100;
export const ICompany_WSPassword_length = 50;

export const kCompany_Company_ID="Company_ID";
export const kCompany_YourCompany_Name="YourCompany_Name";
export const kCompany_YourCompany_DispName="YourCompany_DispName";
export const kCompany_YourCompany_Qual="YourCompany_Qual";
export const kCompany_YourCompany_ID="YourCompany_ID";
export const kCompany_YourCompany_Duns="YourCompany_Duns";
export const kCompany_YourCompany_Add1="YourCompany_Add1";
export const kCompany_YourCompany_Add2="YourCompany_Add2";
export const kCompany_YourCompany_City="YourCompany_City";
export const kCompany_YourCompany_State="YourCompany_State";
export const kCompany_YourCompany_Zip="YourCompany_Zip";
export const kCompany_YourCompany_Country="YourCompany_Country";
export const kCompany_YourCompany_BillName="YourCompany_BillName";
export const kCompany_YourCompany_BillAdd1="YourCompany_BillAdd1";
export const kCompany_YourCompany_BillAdd2="YourCompany_BillAdd2";
export const kCompany_YourCompany_BillCity="YourCompany_BillCity";
export const kCompany_YourCompany_BillState="YourCompany_BillState";
export const kCompany_YourCompany_BillZip="YourCompany_BillZip";
export const kCompany_YourCompany_BillCountry="YourCompany_BillCountry";
export const kCompany_YourCompany_Contact="YourCompany_Contact";
export const kCompany_YourCompany_Phone="YourCompany_Phone";
export const kCompany_YourCompany_Email="YourCompany_Email";
export const kCompany_YourMan_ID="YourMan_ID";
export const kCompany_YourContType="YourContType";
export const kCompany_Acct_Package="Acct_Package";
export const kCompany_CO_UseGroupID="CO_UseGroupID";
export const kCompany_CO_Multi="CO_Multi";
export const kCompany_ACCTdirect="ACCTdirect";
export const kCompany_EDIdirect="EDIdirect";
export const kCompany_vpEDIdirect="vpEDIdirect";
export const kCompany_vpSharedirect="vpSharedirect";
export const kCompany_Exp_Date="Exp_Date";
export const kCompany_SupExp="SupExp";
export const kCompany_AcctVer="AcctVer";
export const kCompany_vpEDIver="vpEDIver";
export const kCompany_dbVer="dbVer";
export const kCompany_DecSize="DecSize";
export const kCompany_AcctCompID="AcctCompID";
export const kCompany_ODBClogin="ODBClogin";
export const kCompany_ODBCpass="ODBCpass";
export const kCompany_DatabaseName="DatabaseName";
export const kCompany_vpEDIDatabaseName="vpEDIDatabaseName";
export const kCompany_ServerIP="ServerIP";
export const kCompany_vpEDIServerIP="vpEDIServerIP";
export const kCompany_ServerPort="ServerPort";
export const kCompany_UseISA="UseISA";
export const kCompany_UpdateASN="UpdateASN";
export const kCompany_VerifyAcctInvTotal="VerifyAcctInvTotal";
export const kCompany_UseOldMenu="UseOldMenu";
export const kCompany_Licenses="Licenses";
export const kCompany_LinkDelDate="LinkDelDate";
export const kCompany_OEM_Layout="OEM_Layout";
export const kCompany_CanGstTax_ID="CanGstTax_ID";
export const kCompany_FedTax_ID="FedTax_ID";
export const kCompany_EurTax_ID="EurTax_ID";
export const kCompany_Lang_ID="Lang_ID";
export const kCompany_Axa_UsePackingList="Axa_UsePackingList";
export const kCompany_PostItemSeq="PostItemSeq";
export const kCompany_MapServer="MapServer";
export const kCompany_Primary_MapServer="Primary_MapServer";
export const kCompany_Backup_MapServer="Backup_MapServer";
export const kCompany_MacBarcodeInterface="MacBarcodeInterface";
export const kCompany_SecurityEnabled="SecurityEnabled";
export const kCompany_mod850="mod850";
export const kCompany_mod852="mod852";
export const kCompany_mod856="mod856";
export const kCompany_mod940="mod940";
export const kCompany_mod830="mod830";
export const kCompany_mod862="mod862";
export const kCompany_mod820="mod820";
export const kCompany_mod870="mod870";
export const kCompany_mod810i="mod810i";
export const kCompany_mod856i="mod856i";
export const kCompany_mod855="mod855";
export const kCompany_mod753="mod753";
export const kCompany_AxaptaExpandedPO="AxaptaExpandedPO";
export const kCompany_AxaptaSalesTypes="AxaptaSalesTypes";
export const kCompany_mWriteToUserFlds="mWriteToUserFlds";
export const kCompany_AuthType="AuthType";
export const kCompany_ConnString="ConnString";
export const kCompany_AcctPackageID="AcctPackageID";
export const kCompany_TestServer="TestServer";
export const kCompany_AcctSqlObjOwnr="AcctSqlObjOwnr";
export const kCompany_AutoHoldDoc="AutoHoldDoc";
export const kCompany_DocCaching="DocCaching";
export const kCompany_WMSImportType="WMSImportType";
export const kCompany_wfUser="wfUser";
export const kCompany_eODBCpass="eODBCpass";
export const kCompany_PurgePass="PurgePass";
export const kCompany_YourCompany_EDIContact="YourCompany_EDIContact";
export const kCompany_YourCompany_EDIPhone="YourCompany_EDIPhone";
export const kCompany_YourCompany_EDIEmail="YourCompany_EDIEmail";
export const kCompany_WSAuthority="WSAuthority";
export const kCompany_WSResource="WSResource";
export const kCompany_WSEndpoint="WSEndpoint";
export const kCompany_WSClientID="WSClientID";
export const kCompany_WSLogin="WSLogin";
export const kCompany_WSPassword="WSPassword";

export const kCompany__LicenseKey='LicenseKey'

/*
        'Company' : {
            'Company_ID' : 'Company_ID',
            'YourCompany_Name' : 'YourCompany_Name',
            'YourCompany_DispName' : 'YourCompany_DispName',
            'YourCompany_Qual' : 'YourCompany_Qual',
            'YourCompany_ID' : 'YourCompany_ID',
            'YourCompany_Duns' : 'YourCompany_Duns',
            'YourCompany_Add1' : 'YourCompany_Add1',
            'YourCompany_Add2' : 'YourCompany_Add2',
            'YourCompany_City' : 'YourCompany_City',
            'YourCompany_State' : 'YourCompany_State',
            'YourCompany_Zip' : 'YourCompany_Zip',
            'YourCompany_Country' : 'YourCompany_Country',
            'YourCompany_BillName' : 'YourCompany_BillName',
            'YourCompany_BillAdd1' : 'YourCompany_BillAdd1',
            'YourCompany_BillAdd2' : 'YourCompany_BillAdd2',
            'YourCompany_BillCity' : 'YourCompany_BillCity',
            'YourCompany_BillState' : 'YourCompany_BillState',
            'YourCompany_BillZip' : 'YourCompany_BillZip',
            'YourCompany_BillCountry' : 'YourCompany_BillCountry',
            'YourCompany_Contact' : 'YourCompany_Contact',
            'YourCompany_Phone' : 'YourCompany_Phone',
            'YourCompany_Email' : 'YourCompany_Email',
            'YourMan_ID' : 'YourMan_ID',
            'YourContType' : 'YourContType',
            'Acct_Package' : 'Acct_Package',
            'CO_UseGroupID' : 'CO_UseGroupID',
            'CO_Multi' : 'CO_Multi',
            'ACCTdirect' : 'ACCTdirect',
            'EDIdirect' : 'EDIdirect',
            'vpEDIdirect' : 'vpEDIdirect',
            'vpSharedirect' : 'vpSharedirect',
            'Exp_Date' : 'Exp_Date',
            'SupExp' : 'SupExp',
            'AcctVer' : 'AcctVer',
            'vpEDIver' : 'vpEDIver',
            'dbVer' : 'dbVer',
            'DecSize' : 'DecSize',
            'AcctCompID' : 'AcctCompID',
            'ODBClogin' : 'ODBClogin',
            'ODBCpass' : 'ODBCpass',
            'DatabaseName' : 'DatabaseName',
            'vpEDIDatabaseName' : 'vpEDIDatabaseName',
            'ServerIP' : 'ServerIP',
            'vpEDIServerIP' : 'vpEDIServerIP',
            'ServerPort' : 'ServerPort',
            'UseISA' : 'UseISA',
            'UpdateASN' : 'UpdateASN',
            'VerifyAcctInvTotal' : 'VerifyAcctInvTotal',
            'UseOldMenu' : 'UseOldMenu',
            'Licenses' : 'Licenses',
            'LinkDelDate' : 'LinkDelDate',
            'OEM_Layout' : 'OEM_Layout',
            'CanGstTax_ID' : 'CanGstTax_ID',
            'FedTax_ID' : 'FedTax_ID',
            'EurTax_ID' : 'EurTax_ID',
            'Lang_ID' : 'Lang_ID',
            'Axa_UsePackingList' : 'Axa_UsePackingList',
            'PostItemSeq' : 'PostItemSeq',
            'MapServer' : 'MapServer',
            'Primary_MapServer' : 'Primary_MapServer',
            'Backup_MapServer' : 'Backup_MapServer',
            'MacBarcodeInterface' : 'MacBarcodeInterface',
            'SecurityEnabled' : 'SecurityEnabled',
            'mod850' : 'mod850',
            'mod852' : 'mod852',
            'mod856' : 'mod856',
            'mod940' : 'mod940',
            'mod830' : 'mod830',
            'mod862' : 'mod862',
            'mod820' : 'mod820',
            'mod870' : 'mod870',
            'mod810i' : 'mod810i',
            'mod856i' : 'mod856i',
            'mod855' : 'mod855',
            'mod753' : 'mod753',
            'AxaptaExpandedPO' : 'AxaptaExpandedPO',
            'AxaptaSalesTypes' : 'AxaptaSalesTypes',
            'mWriteToUserFlds' : 'mWriteToUserFlds',
            'AuthType' : 'AuthType',
            'ConnString' : 'ConnString',
            'AcctPackageID' : 'AcctPackageID',
            'TestServer' : 'TestServer',
            'AcctSqlObjOwnr' : 'AcctSqlObjOwnr',
            'AutoHoldDoc' : 'AutoHoldDoc',
            'DocCaching' : 'DocCaching',
            'WMSImportType' : 'WMSImportType',
            'wfUser' : 'wfUser',
            'eODBCpass' : 'eODBCpass',
            'PurgePass' : 'PurgePass',
            'YourCompany_EDIContact' : 'YourCompany_EDIContact',
            'YourCompany_EDIPhone' : 'YourCompany_EDIPhone',
            'YourCompany_EDIEmail' : 'YourCompany_EDIEmail',
            'WSAuthority' : 'WSAuthority',
            'WSResource' : 'WSResource',
            'WSEndpoint' : 'WSEndpoint',
            'WSClientID' : 'WSClientID',
            'WSLogin' : 'WSLogin',
            'WSPassword' : 'WSPassword',
        },
*/

export const Label_Company_ID = 'Company.Company_ID';
export const Label_YourCompany_Name = 'Company.YourCompany_Name';
export const Label_YourCompany_DispName = 'Company.YourCompany_DispName';
export const Label_YourCompany_Qual = 'Company.YourCompany_Qual';
export const Label_YourCompany_ID = 'Company.YourCompany_ID';
export const Label_YourCompany_Duns = 'Company.YourCompany_Duns';
export const Label_YourCompany_Add1 = 'Company.YourCompany_Add1';
export const Label_YourCompany_Add2 = 'Company.YourCompany_Add2';
export const Label_YourCompany_City = 'Company.YourCompany_City';
export const Label_YourCompany_State = 'Company.YourCompany_State';
export const Label_YourCompany_Zip = 'Company.YourCompany_Zip';
export const Label_YourCompany_Country = 'Company.YourCompany_Country';
export const Label_YourCompany_BillName = 'Company.YourCompany_BillName';
export const Label_YourCompany_BillAdd1 = 'Company.YourCompany_BillAdd1';
export const Label_YourCompany_BillAdd2 = 'Company.YourCompany_BillAdd2';
export const Label_YourCompany_BillCity = 'Company.YourCompany_BillCity';
export const Label_YourCompany_BillState = 'Company.YourCompany_BillState';
export const Label_YourCompany_BillZip = 'Company.YourCompany_BillZip';
export const Label_YourCompany_BillCountry = 'Company.YourCompany_BillCountry';
export const Label_YourCompany_Contact = 'Company.YourCompany_Contact';
export const Label_YourCompany_Phone = 'Company.YourCompany_Phone';
export const Label_YourCompany_Email = 'Company.YourCompany_Email';
export const Label_YourMan_ID = 'Company.YourMan_ID';
export const Label_YourContType = 'Company.YourContType';
export const Label_Acct_Package = 'Company.Acct_Package';
export const Label_CO_UseGroupID = 'Company.CO_UseGroupID';
export const Label_CO_Multi = 'Company.CO_Multi';
export const Label_ACCTdirect = 'Company.ACCTdirect';
export const Label_EDIdirect = 'Company.EDIdirect';
export const Label_vpEDIdirect = 'Company.vpEDIdirect';
export const Label_vpSharedirect = 'Company.vpSharedirect';
export const Label_Exp_Date = 'Company.Exp_Date';
export const Label_SupExp = 'Company.SupExp';
export const Label_AcctVer = 'Company.AcctVer';
export const Label_vpEDIver = 'Company.vpEDIver';
export const Label_dbVer = 'Company.dbVer';
export const Label_DecSize = 'Company.DecSize';
export const Label_AcctCompID = 'Company.AcctCompID';
export const Label_ODBClogin = 'Company.ODBClogin';
export const Label_ODBCpass = 'Company.ODBCpass';
export const Label_DatabaseName = 'Company.DatabaseName';
export const Label_vpEDIDatabaseName = 'Company.vpEDIDatabaseName';
export const Label_ServerIP = 'Company.ServerIP';
export const Label_vpEDIServerIP = 'Company.vpEDIServerIP';
export const Label_ServerPort = 'Company.ServerPort';
export const Label_UseISA = 'Company.UseISA';
export const Label_UpdateASN = 'Company.UpdateASN';
export const Label_VerifyAcctInvTotal = 'Company.VerifyAcctInvTotal';
export const Label_UseOldMenu = 'Company.UseOldMenu';
export const Label_Licenses = 'Company.Licenses';
export const Label_LinkDelDate = 'Company.LinkDelDate';
export const Label_OEM_Layout = 'Company.OEM_Layout';
export const Label_CanGstTax_ID = 'Company.CanGstTax_ID';
export const Label_FedTax_ID = 'Company.FedTax_ID';
export const Label_EurTax_ID = 'Company.EurTax_ID';
export const Label_Lang_ID = 'Company.Lang_ID';
export const Label_Axa_UsePackingList = 'Company.Axa_UsePackingList';
export const Label_PostItemSeq = 'Company.PostItemSeq';
export const Label_MapServer = 'Company.MapServer';
export const Label_Primary_MapServer = 'Company.Primary_MapServer';
export const Label_Backup_MapServer = 'Company.Backup_MapServer';
export const Label_MacBarcodeInterface = 'Company.MacBarcodeInterface';
export const Label_SecurityEnabled = 'Company.SecurityEnabled';
export const Label_mod850 = 'Company.mod850';
export const Label_mod852 = 'Company.mod852';
export const Label_mod856 = 'Company.mod856';
export const Label_mod940 = 'Company.mod940';
export const Label_mod830 = 'Company.mod830';
export const Label_mod862 = 'Company.mod862';
export const Label_mod820 = 'Company.mod820';
export const Label_mod870 = 'Company.mod870';
export const Label_mod810i = 'Company.mod810i';
export const Label_mod856i = 'Company.mod856i';
export const Label_mod855 = 'Company.mod855';
export const Label_mod753 = 'Company.mod753';
export const Label_AxaptaExpandedPO = 'Company.AxaptaExpandedPO';
export const Label_AxaptaSalesTypes = 'Company.AxaptaSalesTypes';
export const Label_mWriteToUserFlds = 'Company.mWriteToUserFlds';
export const Label_AuthType = 'Company.AuthType';
export const Label_ConnString = 'Company.ConnString';
export const Label_AcctPackageID = 'Company.AcctPackageID';
export const Label_TestServer = 'Company.TestServer';
export const Label_AcctSqlObjOwnr = 'Company.AcctSqlObjOwnr';
export const Label_AutoHoldDoc = 'Company.AutoHoldDoc';
export const Label_DocCaching = 'Company.DocCaching';
export const Label_WMSImportType = 'Company.WMSImportType';
export const Label_wfUser = 'Company.wfUser';
export const Label_eODBCpass = 'Company.eODBCpass';
export const Label_PurgePass = 'Company.PurgePass';
export const Label_YourCompany_EDIContact = 'Company.YourCompany_EDIContact';
export const Label_YourCompany_EDIPhone = 'Company.YourCompany_EDIPhone';
export const Label_YourCompany_EDIEmail = 'Company.YourCompany_EDIEmail';
export const Label_WSAuthority = 'Company.WSAuthority';
export const Label_WSResource = 'Company.WSResource';
export const Label_WSEndpoint = 'Company.WSEndpoint';
export const Label_WSClientID = 'Company.WSClientID';
export const Label_WSLogin = 'Company.WSLogin';
export const Label_WSPassword = 'Company.WSPassword';
