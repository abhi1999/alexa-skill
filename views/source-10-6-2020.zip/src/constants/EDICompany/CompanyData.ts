import { ICompanyData } from './ICompanyData'
export class CompanyData implements ICompanyData {
    public CompanyID: string = '';
    public EdiDb: string = '';
    public DisplayName: string = '';
    public AcctDirect: string = 'C:\\DataMasons\\vpEDI';
    public EDIDirect: string = 'C:\\DataMasons\\vpEDI';
    public vpEDIDirect: string = 'C:\\DataMasons\\vpEDI';
    public vpShareDirect: string = 'C:\\DataMasons\\vpEDI';
    public User: string = '';
    public Password: string = '';
    public StartupMode: string = 'Automatic';
    public SQLServer: string = '';
    public SQLPort: string = '';
    public SQLSecurity: string = 'SSPI';
    public SQLUser: string = '';
    public SQLPassword: string = '';
    public TempDir: string = 'C:\\Temp';
    public Template: string = 'templateXMLDefVP5';
    public WebSite: string = '';
    public AppPool: string = '';
    public WebPort: string = '';
    public SSL: boolean = true;
    public Thumbprint: string = '';
    public CopySchedulerObjects:boolean = false;
    public constructor(init?: Partial<CompanyData>) { Object.assign(this, init); }
}

export const kCompanyData_CompanyID = "CompanyID";
export const kCompanyData_NextCompany = "NextCompany";
export const kCompanyData_EdiDb = "EdiDb";
export const kCompanyData_DisplayName = "DisplayName";
export const kCompanyData_AcctDirect = "AcctDirect";
export const kCompanyData_EDIDirect = "EDIDirect";
export const kCompanyData_vpEDIDirect = "vpEDIDirect";
export const kCompanyData_vpShareDirect = "vpShareDirect";
export const kCompanyData_User = "User";
export const kCompanyData_Password = "Password";
export const kCompanyData_StartupMode = "StartupMode";
export const kCompanyData_Template = "Template";
export const kCompanyData_TemplateOther = "TemplateOther";
export const kCompanyData_TempDir = "TempDir";
export const kCompanyData_SqlServer = "SQLServer";
export const kCompanyData_SqlPort = "SQLPort";
export const kCompanyData_SqlSecurity = "SQLSecurity";
export const kCompanyData_SqlUser = "SQLUser";
export const kCompanyData_SqlPassword = "SQLPassword";
export const kCompanyData_SSL = "SSL";
export const kCompanyData_Thumbprint= "Thumbprint";
export const kCompanyData_CopySchedulerObjects = "CopySchedulerObjects";

export const Label_CompanyID = "CompanyData.CompanyID";
export const Label_NextCompany = "CompanyData.NextCompany";
export const Label_EdiDb = "CompanyData.EdiDb";
export const Label_DisplayName = "CompanyData.DisplayName";
export const Label_AcctDirect = "Company.ACCTdirect";
export const Label_EDIDirect = "Company.EDIdirect";
export const Label_vpEDIDirect = "Company.vpEDIdirect";
export const Label_vpShareDirect = "Company.vpSharedirect";
export const Label_User = 'CompanyData.User';
export const Label_Password = 'CompanyData.Password';
export const Label_StartupMode = 'CompanyData.StartupMode';
export const Label_Template = "CompanyData.Template";
export const Label_Other = "CompanyData.TemplateOther";
export const Label_TempDir = "CompanyData.TempDir";
export const Label_SqlServer = 'CompanyData.SQLServer';
export const Label_SqlPort = 'CompanyData.SQLPort';
export const Label_SqlSecurity = 'CompanyData.SQLSecurity';
export const Label_SqlUser = 'CompanyData.SQLUser';
export const Label_SqlPassword = 'CompanyData.SQLPassword';
export const Label_SSL = 'CompanyData.SSL';
export const Label_Thumbprint = 'CompanyData.Thumbprint';
export const Label_CopySchedulerObjects = 'CompanyData.CopySchedulerObjects';

