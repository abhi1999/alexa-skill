import { ICloneTradingPartner } from './ApiStructs'

export class CloneTradingPartner implements ICloneTradingPartner {

    public ISA: string;
    public Qual: string;
    public Name: string;
    public DestAcct: string;
    public GS: string;

    public constructor(init?: Partial<CloneTradingPartner>) {
        Object.assign(this, init);
    }
}
