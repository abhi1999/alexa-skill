import * as React from 'react';
import LoadingComponent from "../components/widgets/LoadingComponent";
import Loadable from 'react-loadable';
import BusinessProcessFlowView from './../views/scheduler/businessProcessFlow';
import withUserPermissions from "./../components/hoc/withUserPermissions";
import * as MenuInfo from '../reducers/businessFlowReducer';

const Loading = () => {
  // return<div><FormattedMessage id='Global.Loading' /></div>;
  return (<LoadingComponent />);
}
const businessProcess = ({ ...props }) => {
  // workflowMetaTaskSetMenuID(props.match.params.MenuID);
  return <BusinessProcessFlowView {...props} businessMenu={props.match.params.MenuID} />;
}

const DashboardWithDraggableWidgets = Loadable({ loader: () => import("../views/dashboard"), loading: Loading })

const Favorites = Loadable({ loader: () => import("../views/favorites"), loading: Loading })
const ConfigListView = Loadable({ loader: () => import('../views/scheduler/ConfigListView'), loading: Loading })
const TaskStatusListView = Loadable({ loader: () => import('../views/scheduler/TaskStatusListView'), loading: Loading })
const WorkflowListView = Loadable({ loader: () => import("../views/scheduler/WorkflowListView"), loading: Loading })
const WorkflowEditView = Loadable({ loader: () => import("../views/scheduler/WorkflowEditView"), loading: Loading })
const TaskListView = Loadable({ loader: () => import("../views/scheduler/TaskListView"), loading: Loading })
const TaskEditView = Loadable({ loader: () => import("../views/scheduler/TaskEditView"), loading: Loading })
const SchedulerListView = Loadable({ loader: () => import("../views/scheduler/SchedulerListView"), loading: Loading })
const SchedulerEditView = Loadable({ loader: () => import("../views/scheduler/SchedulerEditView"), loading: Loading })
const NetworkListView = Loadable({ loader: () => import("../views/scheduler/NetworkListView"), loading: Loading })
const NetworkEditView = Loadable({ loader: () => import("../views/scheduler/NetworkEditView"), loading: Loading })
const DatabaseListView = Loadable({ loader: () => import("../views/scheduler/DatabaseListView"), loading: Loading })
const DatabaseEditView = Loadable({ loader: () => import("../views/scheduler/DatabaseEditView"), loading: Loading })
const FolderListView = Loadable({ loader: () => import("../views/scheduler/FolderListView"), loading: Loading })
const FolderEditView = Loadable({ loader: () => import("../views/scheduler/FolderEditView"), loading: Loading })
const VariableListView = Loadable({ loader: () => import("../views/scheduler/VariableListView"), loading: Loading })
const VariableEditView = Loadable({ loader: () => import("../views/scheduler/VariableEditView"), loading: Loading })
const BPFormTaskListView = Loadable({ loader: () => import("../views/scheduler/BPFormTaskView"), loading: Loading })
const BPFormTaskDetailView = Loadable({ loader: () => import("../views/scheduler/BPFormTaskDetailView"), loading: Loading })
const SchedulerConfigView = Loadable({ loader: () => import("../views/Cache/CacheView"), loading: Loading })
const SchedulerReportView = Loadable({ loader: () => import("../views/Cache/CacheReportView"), loading: Loading })
const TLEJumperPage =  Loadable({loader: () => import("../views/TLE/TLEJump"),loading: Loading})

const CarrierListView = Loadable({ loader: () => import("../views/carrier/CarrierListView"), loading: Loading })
const CarrierView = Loadable({ loader: () => import('../views/carrier/CarrierView'), loading: Loading })
const CarrierXrefListView = Loadable({ loader: () => import('../views/carrier/CarrierXRefListView'), loading: Loading })
const CarrierXrefDetailsView = Loadable({ loader: () => import('../views/carrier/CarrierXRefDetailsView'), loading: Loading })
// KB: Adding new Audit Viewer
const AuditViewerListView = Loadable({ loader: () => import("../views/audit/viewer/AuditViewerListView"), loading: Loading })
const AuditViewerView = Loadable({ loader: () => import("../views/audit/viewer/AuditViewerView"), loading: Loading })

// KB: 07/02/2020 - Removed new Trade Maps feature for now per Debbie's request
// const TradeMapsView = Loadable({ loader: () => import("../views/TradeMaps/TradeMapView"), loading: Loading })
const DocumentListView = Loadable({ loader: () => import("../views/document/DocumentListView"), loading: Loading })
const ErrorCodeView = Loadable({ loader: () => import("../views/ErrorCode/ErrorCodeView"), loading: Loading })
const ErrorLogView = Loadable({ loader: () => import("../views/ErrorLog/ErrorLogView"), loading: Loading })
const FreightCodeView = Loadable({ loader: () => import("../views/FreightCode/FreightCodeView"), loading: Loading })
const FreightCodeDetailView = Loadable({ loader: () => import("../views/FreightCode/FreightCodeDetailView"), loading: Loading })
const TradeView = Loadable({ loader: () => import("../views/Trade/TradeView"), loading: Loading })
const TradeDetailView = Loadable({ loader: () => import('../views/Trade/TradeDetailView'), loading: Loading })
const TradeCloneView = Loadable({ loader: () => import('../views/Trade/TradeCloneView'), loading: Loading })
const ShipToView = Loadable({ loader: () => import("../views/ShipTo/ShipToView"), loading: Loading })
const ShipToDetailView = Loadable({ loader: () => import("../views/ShipTo/ShipToDetailView"), loading: Loading })
const VPNetworkListView = Loadable({ loader: () => import("../views/vpNetwork/NetworkListView"), loading: Loading })
const VPNetworkView = Loadable({ loader: () => import('../views/vpNetwork/NetworkView'), loading: Loading })
const LocalErrorLogView = Loadable({ loader: () => import("../views/LocalErrorLog/LocalErrorLogView"), loading: Loading })
const MapView = Loadable({ loader: () => import("../views/Maps/MapView"), loading: Loading })
const DocumentSentView = Loadable({ loader: () => import("../views/DocumentSent/DocumentSentView"), loading: Loading })
const DocumentReceivedView = Loadable({ loader: () => import("../views/DocumentReceived/DocumentReceivedView"), loading: Loading })
const TransObjectView = Loadable({ loader: () => import("../views/TransObject/TransObjectView"), loading: Loading })
const TransObjectDetailView = Loadable({ loader: () => import("../views/TransObject/TransObjectDetailView"), loading: Loading })
const TransDefView = Loadable({ loader: () => import("../views/TransDef/TransDefView"), loading: Loading })
const TransDefDetailView = Loadable({ loader: () => import("../views/TransDef/TransDefDetailView"), loading: Loading })
const ItemListView = Loadable({ loader: () => import('../views/Item/ItemListView'), loading: Loading })
const ItemView = Loadable({ loader: () => import('../views/Item/ItemView'), loading: Loading })
const ItemXrefList = Loadable({ loader: () => import('../views/Item/ItemXrefList'), loading: Loading })
const ItemXrefView = Loadable({ loader: () => import('../views/Item/ItemXrefView'), loading: Loading })
const ItemSacList = Loadable({ loader: () => import('../views/Item/ItemSacList'), loading: Loading })
const ItemSacView = Loadable({ loader: () => import('../views/Item/ItemSacView'), loading: Loading })
const EdiStandardsView = Loadable({ loader: () => import('../views/EdiStandardsView'), loading: Loading })
const DocLoadView = Loadable({ loader: () => import('../views/DocLoad/DocLoadView'), loading: Loading })
const DocLoadDetailView = Loadable({ loader: () => import('../views/DocLoad/DocLoadDetailView'), loading: Loading })
const CompanySettingsView = Loadable({ loader: () => import("../views/companySettings/CompanySettingsView"), loading: Loading })
// const JsonEdit = Loadable({loader: () => import('../views/document/JsonEdit'),loading: Loading})
// const JsonEdit = Loadable({loader: () => import('../views/document/JsonEditView'),loading: Loading})
const JsonEditView = Loadable({ loader: () => import('../views/document/JsonEditView'), loading: Loading })
const RequestRouteView = Loadable({ loader: () => import('../views/RequestRouting/RequestRoutingView'), loading: Loading })
const LastNumbersView = Loadable({ loader: () => import('../views/LastNumbers/LastNumbersView'), loading: Loading })
const RouteInstrView = Loadable({ loader: () => import('../views/RouteInstr/RouteInstrView'), loading: Loading })
const ProcessTriggerView = Loadable({ loader: () => import('../views/ProcessTrigger/ProcessTriggerView'), loading: Loading })
const C303v850sView = Loadable({ loader: () => import('../views/C303v850s/C303v850sView'), loading: Loading })
const C303v850lbView = Loadable({ loader: () => import('../views/C303v850lb/C303v850lbView'), loading: Loading })
const C303v850cView = Loadable({ loader: () => import('../views/C303v850c/C303v850cView'), loading: Loading })
const C303v850fView = Loadable({ loader: () => import('../views/C303v850f/C303v850fView'), loading: Loading })
const C303v850dView = Loadable({ loader: () => import('../views/C303v850d/C303v850dView'), loading: Loading })
const C303v850rView = Loadable({ loader: () => import('../views/C303v850r/C303v850rView'), loading: Loading })
const C303v850nView = Loadable({ loader: () => import('../views/C303v850n/C303v850nView'), loading: Loading })
const C303v850lView = Loadable({ loader: () => import('../views/C303v850l/C303v850lView'), loading: Loading })
const C303v850hView = Loadable({ loader: () => import('../views/C303v850h/C303v850hView'), loading: Loading })
const POAckView = Loadable({ loader: () => import('../views/C303v850h/PurchaseOrderAckView'), loading: Loading })
const POAckEdit = Loadable({ loader: () => import('../views/C303v850h/PurchaseOrderAckEdit'), loading: Loading })
const POStatusView = Loadable({ loader: () => import('../views/C303v850h/PurchaseOrderStatusView'), loading: Loading })
const POStatusEdit = Loadable({ loader: () => import('../views/C303v850h/PurchaseOrderStatusEdit'), loading: Loading })
const TaxCodeView = Loadable({ loader: () => import('../views/TaxCode/TaxCodeView'), loading: Loading })
const DataTransportView = Loadable({ loader: () => import('../views/DataTransport/DataTransportView'), loading: Loading })
const LocationView = Loadable({ loader: () => import('../views/Location/LocationView'), loading: Loading })
const ControlNumView = Loadable({ loader: () => import('../views/ControlNum/ControlNumView'), loading: Loading })
const CarbonCopyView = Loadable({ loader: () => import('../views/CarbonCopy/CarbonCopyView'), loading: Loading })
const OsnListView = Loadable({ loader: () => import('../views/OutboundShipNotices/OsnListView'), loading: Loading })
const OsnDetailView = Loadable({ loader: () => import('../views/OutboundShipNotices/OSNDetailView'), loading: Loading })
const PlanSchedListView = Loadable({ loader: () => import('../views/PlanningSchedule/PlanningScheduleListView'), loading: Loading })
const ProductionSequenceListView = Loadable({ loader: () => import('../views/ProductionSequence/ProductionSequenceListView'), loading: Loading })
const FromERP = Loadable({ loader: () => import("../views/SendAndReceive/FromErp"), loading: Loading })
const UserLabels = Loadable({ loader: () => import('../views/UserLabelsView'), loading: Loading })
const EditUserLabels = Loadable({ loader: () => import('../views/EditUserLabels/EditUserLabelsView'), loading: Loading })
const Login = Loadable({ loader: () => import('../views/Login/Login'), loading: Loading })
const MenuConfigView = Loadable({ loader: () => import('../views/Menu/MenuConfigView'), loading: Loading });
const NewMenuConfigView = Loadable({ loader: () => import('../views/Menu/NewMenuConfig'), loading: Loading })
const CumulativeQtyView = Loadable({ loader: () => import('../views/CumulativeQty/CumulativeQtyView'), loading: Loading })
const CumulativeQtyDetailView = Loadable({ loader: () => import('../views/CumulativeQty/CumulativeQtyDetailView'), loading: Loading })
const CumulativeQtyDetailAddView = Loadable({ loader: () => import('../views/CumulativeQty/CumulativeQtyAddView'), loading: Loading })
const TradeMaintenanceView = Loadable({ loader: () => import('../views/Maintenance/TradeMaintenanceView'), loading: Loading })
const ConfigRecordsListView = Loadable({ loader: () => import('../views/ConfigRecords/ConfigRecordsListView'), loading: Loading })
const ConnfigRecordEdit = Loadable({ loader: () => import('../views/ConfigRecords/ConfigRecordsView'), loading: Loading })
const ImportConfigRecs = Loadable({ loader: () => import('../views/ImportConfigRecs/ImportConfigRecs'), loading: Loading })
const ExceptionReports = Loadable({ loader: () => import('../views/ExceptionReports/ExceptionReportsView'), loading: Loading })
const HTMLReports = Loadable({ loader: () => import('../views/ExceptionReports/HTMLReportsView'), loading: Loading })
const CopyCompany = Loadable({ loader: () => import('../views/companySettings/CompanyCopyView'), loading: Loading })
const DeleteCompany = Loadable({ loader: () => import('../views/companySettings/CompanyDeleteView'), loading: Loading })

const CustomDashboard = Loadable({ loader: () => import('../views/CustomDashboard/CustomDashboard'), loading: Loading })
const RoleAdmin = Loadable({ loader: () => import('../views/RoleAdministration/RoleAdministration'), loading: Loading });
const CustomizeTermsView = Loadable({ loader: () => import("../views/CustomizeTerms/CustomizeTermsView"), loading: Loading })
const CustomizeTermsDetailView = Loadable({ loader: () => import("../views/CustomizeTerms/CustomizeTermsDetailView"), loading: Loading })

const PackAndShipSelectOrdersView = Loadable({ loader: () => import("../views/PackAndShip/PackAndShipSelectOrdersView"), loading: Loading });
const PackAndShipView = Loadable({ loader: () => import("../views/PackAndShip/PackAndShipView"), loading: Loading });
const PackAndShipViewAlt = Loadable({ loader: () => import("../views/PackAndShip/PackAndShipViewAlt"), loading: Loading });
const PackAndShipEditOrderView = Loadable({ loader: () => import("../views/PackAndShip/PackAndShipEditOrderView"), loading: Loading });

const PackAndShipMultiLevelView = Loadable({ loader: () => import("../views/PackAndShip/PackAndShipMultiLevelView"), loading: Loading });
const PackAndShipShipmentListView = Loadable({ loader: () => import("../views/PackAndShip/PackAndShipShipmentListView"), loading: Loading });
const PackAndShipShipmentView = Loadable({ loader: () => import("../views/PackAndShip/PackAndShipShipmentView"), loading: Loading });
const PackAndShipLabels = Loadable({ loader: () => import("../views/PackAndShip/PackAndShipLabels"), loading: Loading });
const PackAndShipUpdateTrackingNumberView = Loadable({ loader: () => import("../views/PackAndShip/PackAndShipUpdateTrackingNumberView"), loading: Loading });

const TLEListView = Loadable({ loader: () => import("../views/TLE/TLEListView"), loading: Loading })
const TLEReportView = Loadable({ loader: () => import("../views/TLE/TLEReport"), loading: Loading })
const TLERawDatatView = Loadable({ loader: () => import("../views/TLE/TLERawData"), loading: Loading })
const TLEErrorView = Loadable({ loader: () => import("../views/TLE/TLEErrorDetails"), loading: Loading })
const TLEStatusDetailsView = Loadable({ loader: () => import("../views/TLE/TLEStatusDetails"), loading: Loading })
const TLEErrorCodeView = Loadable({ loader: () => import("../views/TLE/TLEErrorCodeDetails"), loading: Loading })

const ShippingLabel = Loadable({ loader: () => import("../views/ShippingLabel/V1"), loading: Loading })
const BarcodeSamples = Loadable({ loader: () => import("../views/ShippingLabel/barcodeSamples"), loading: Loading })
const ShippingLabelV2 = Loadable({ loader: () => import("../views/ShippingLabel"), loading: Loading })

const PackageView = Loadable({ loader: () => import("../views/Package/PackageView"), loading: Loading });
const PackageDetailView = Loadable({ loader: () => import("../views/Package/PackageDetailView"), loading: Loading })

const routes = [
  // { path: '/', exact: true, name: companyName },
  { path: '/login', name: 'Data Masons EDI', component: Login },
  // { path: '/RoleAdmin', name: 'User & Role Administration', component: RoleAdmin },
  { path: MenuInfo.urlRoleAdmin, intlId: MenuInfo.nameRoleAdmin, component: RoleAdmin },
  { path: '/dashboard', intlId: 'Menu.Dashboard', component: DashboardWithDraggableWidgets },
  { path: "/dashboard1", intlId: 'Menu.Dashboard', component: DashboardWithDraggableWidgets },
  { path: '/CustomDashboard', name: 'Custom Dashboard', component: CustomDashboard },
  { path: '/favorites', intlId: 'Menu.Favorites', component: Favorites },
  { path: '/QTC', intlId: 'Menu.QuoteToCash', component: Favorites },
  { path: '/ProcureToPay', intlId: 'Menu.ProcureToPay', component: Favorites },
  { path: '/logistics', intlId: 'Menu.Logistics', component: Favorites },
  { path: '/automotiveplanning', intlId: 'Menu.Automotive', component: Favorites },
  { path: '/product', intlId: 'Menu.Product', component: Favorites },
  { path: '/businessProcess/:MenuID', name: '', component: businessProcess },
  { path: '/status', intlId: 'Menu.Scheduler.Status', component: TaskStatusListView },
  { path: MenuInfo.urlWorkflows, intlId: MenuInfo.nameWorkflows, component: WorkflowListView },
  { path: MenuInfo.urlWorkflowAdd, intlId: MenuInfo.nameWorkflowAdd, component: WorkflowEditView, parentId: MenuInfo.nameWorkflows },
  { path: MenuInfo.urlWorkflowEdit, intlId: MenuInfo.nameWorkflowEdit, component: WorkflowEditView, parentId: MenuInfo.nameWorkflows },
  { path: MenuInfo.urlWorkflowClone, intlId: MenuInfo.nameWorkflowClone, component: WorkflowEditView, parentId: MenuInfo.nameWorkflows },
  { path: MenuInfo.urlTasks, intlId: MenuInfo.nameTasks, component: TaskListView },
  { path: MenuInfo.urlTaskAdd, intlId: MenuInfo.nameTaskAdd, component: TaskEditView, parentId: MenuInfo.nameTasks },
  { path: MenuInfo.urlTaskEdit, intlId: MenuInfo.nameTaskEdit, component: TaskEditView, parentId: MenuInfo.nameTasks },
  { path: MenuInfo.urlTaskClone, intlId: MenuInfo.nameTaskClone, component: TaskEditView, parentId: MenuInfo.nameTasks },
  { path: MenuInfo.urlSchedules, intlId: MenuInfo.nameSchedules, component: SchedulerListView },
  { path: MenuInfo.urlScheduleAdd, intlId: MenuInfo.nameScheduleAdd, component: SchedulerEditView, parentId: MenuInfo.nameSchedules },
  { path: MenuInfo.urlScheduleEdit, intlId: MenuInfo.nameScheduleEdit, component: SchedulerEditView, parentId: MenuInfo.nameSchedules },
  { path: MenuInfo.urlScheduleClone, intlId: MenuInfo.nameScheduleClone, component: SchedulerEditView, parentId: MenuInfo.nameSchedules },
  { path: MenuInfo.urlNetworks, intlId: MenuInfo.nameNetworks, component: NetworkListView },
  { path: MenuInfo.urlNetworkAdd, intlId: MenuInfo.nameNetworkAdd, component: NetworkEditView, parentId: MenuInfo.nameNetworks },
  { path: MenuInfo.urlNetworkEdit, intlId: MenuInfo.nameNetworkEdit, component: NetworkEditView, parentId: MenuInfo.nameNetworks },
  { path: MenuInfo.urlNetworkClone, intlId: MenuInfo.nameNetworkClone, component: NetworkEditView, parentId: MenuInfo.nameNetworks },
  { path: MenuInfo.urlDatabases, intlId: MenuInfo.nameDatabases, component: DatabaseListView },
  { path: MenuInfo.urlDatabaseAdd, intlId: MenuInfo.nameDatabaseAdd, component: DatabaseEditView, parentId: MenuInfo.nameDatabases },
  { path: MenuInfo.urlDatabaseEdit, intlId: MenuInfo.nameDatabaseEdit, component: DatabaseEditView, parentId: MenuInfo.nameDatabases },
  { path: MenuInfo.urlDatabaseClone, intlId: MenuInfo.nameDatabaseClone, component: DatabaseEditView, parentId: MenuInfo.nameDatabases },
  { path: MenuInfo.urlFolders, intlId: MenuInfo.nameFolders, component: FolderListView },
  { path: MenuInfo.urlFolderAdd, intlId: MenuInfo.nameFolderAdd, component: FolderEditView, parentId: MenuInfo.nameFolders },
  { path: MenuInfo.urlFolderEdit, intlId: MenuInfo.nameFolderEdit, component: FolderEditView, parentId: MenuInfo.nameFolders },
  { path: MenuInfo.urlFolderClone, intlId: MenuInfo.nameFolderClone, component: FolderEditView, parentId: MenuInfo.nameFolders },
  { path: MenuInfo.urlVariables, intlId: MenuInfo.nameVariables, component: VariableListView },
  { path: MenuInfo.urlVariableAdd, intlId: MenuInfo.nameVariableAdd, component: VariableEditView, parentId: MenuInfo.nameVariables },
  { path: MenuInfo.urlVariableEdit, intlId: MenuInfo.nameVariableEdit, component: VariableEditView, parentId: MenuInfo.nameVariables },
  { path: MenuInfo.urlVariableClone, intlId: MenuInfo.nameVariableClone, component: VariableEditView, parentId: MenuInfo.nameVariables },
  { path: MenuInfo.urlBPFormTasks, intlId: MenuInfo.nameBPFormTasks, component: BPFormTaskListView, parentId: MenuInfo.nameBPFormTasks },
  { path: MenuInfo.urlBPFormTaskDetailsAdd, intlId: MenuInfo.nameBPFormTaskDetailsAdd, component: BPFormTaskDetailView, parentId: MenuInfo.nameBPFormTasks },
  { path: MenuInfo.urlBPFormTaskDetailsEdit, intlId: MenuInfo.nameBPFormTaskDetailsEdit, component: BPFormTaskDetailView, parentId: MenuInfo.nameBPFormTasks },
  { path: MenuInfo.urlSchedulerConfig, intlId: MenuInfo.nameSchedulerConfig, component: SchedulerConfigView },
  { path: MenuInfo.urlSchedulerReport, intlId: MenuInfo.nameSchedulerReport, component: SchedulerReportView },

  // { path: '/configs', name: 'Configs', component: ConfigListView },
  { path: MenuInfo.urlCarriers, intlId: MenuInfo.nameCarriers, component: CarrierListView },
  { path: MenuInfo.urlCarrierDetailsEdit, intlId: MenuInfo.nameCarrierDetailsEdit, component: CarrierView, parentId: MenuInfo.nameCarriers },
  { path: MenuInfo.urlCarrierDetailsAdd, intlId: MenuInfo.nameCarrierDetailsAdd, component: CarrierView, parentId: MenuInfo.nameCarriers },
  { path: MenuInfo.urlCarrierXref, intlId: MenuInfo.nameCarrierXRef, component: CarrierXrefListView },
  { path: MenuInfo.urlCarrierXrefDetails, intlId: MenuInfo.nameCarrierXRefDetails, component: CarrierXrefDetailsView, parentId: MenuInfo.nameCarrierXRef },
  { path: MenuInfo.urlCarrierXrefDetailsAdd, intlId: MenuInfo.nameCarrierXRefAdd, component: CarrierXrefDetailsView, parentId: MenuInfo.nameCarrierXRef },
  // KB: Adding new menu for AuditViewer
  { path: MenuInfo.urlAuditViewer, intlId: MenuInfo.nameAuditViewer, component: AuditViewerListView },
  { path: MenuInfo.urlAuditViewerDetailsEdit, intlId: MenuInfo.nameAuditViewerDetailsEdit, component: AuditViewerView, parentId: MenuInfo.nameAuditViewer },

  { path: MenuInfo.urlErrorCodes, intlId: MenuInfo.nameErrorCodes, component: ErrorCodeView },
  { path: MenuInfo.urlErrorCodesAdd, intlId: MenuInfo.nameErrorCodesAdd, component: ErrorCodeView, parentId: MenuInfo.nameErrorCodes },
  { path: MenuInfo.urlErrorCodesEdit, intlId: MenuInfo.nameErrorCodesEdit, component: ErrorCodeView, parentId: MenuInfo.nameErrorCodes },
  { path: MenuInfo.urlErrorCodesClone, intlId: MenuInfo.nameErrorCodesClone, component: ErrorCodeView, parentId: MenuInfo.nameErrorCodes },
  { path: MenuInfo.urlLocalErrorLog, intlId: MenuInfo.nameLocalErrorLog, component: LocalErrorLogView, parentId: MenuInfo.nameErrorLog },
  { path: MenuInfo.urlErrorLog, intlId: MenuInfo.nameErrorLog, component: ErrorLogView },
  { path: MenuInfo.urlErrorLogEdit, intlId: MenuInfo.nameErrorLogEdit, component: ErrorLogView, parentId: MenuInfo.nameErrorLog },
  { path: MenuInfo.urlFreightCodes, intlId: MenuInfo.nameFreightCodes, component: FreightCodeView },
  // KB: Testing using new parentId parameter on our appRoute to designate a parent menu to be used for role permissions
  //     This is needed since only have one entry in the Permissions db for the top level route and we can access the 
  //     child / sub components directly which bypasses the parent, thus breaking the chain of our solution where
  //     the parent is hit first and passes the permission prop to the child.
  { path: MenuInfo.urlFreightCodeDetailsEdit, intlId: MenuInfo.nameFreightCodeDetailsEdit, component: FreightCodeDetailView, parentId: MenuInfo.nameFreightCodes },
  { path: MenuInfo.urlFreightCodeDetailsAdd, intlId: MenuInfo.nameFreightCodeDetailsAdd, component: FreightCodeDetailView, parentId: MenuInfo.nameFreightCodes },
  { path: MenuInfo.urlConfigRecords, intlId: MenuInfo.nameConfigRecords, component: ConfigRecordsListView },
  { path: MenuInfo.urlEditConfigRecord, intlId: MenuInfo.nameEditConfigRecord, component: ConnfigRecordEdit, parentId: MenuInfo.nameConfigRecords },
  { path: MenuInfo.urlEditConfigRecordCopy, intlId: MenuInfo.nameEditConfigRecord, component: ConnfigRecordEdit, parentId: MenuInfo.nameConfigRecords },
  // { path: MenuInfo.urlImportConfigRecs, intlId: MenuInfo.nameImportConfigRecs , component: ImportConfigRecs },
  { path: MenuInfo.urlTrades, intlId: MenuInfo.nameTrades, component: TradeView },
  { path: MenuInfo.urlTradingPartner, intlId: MenuInfo.nameTrades, component: TradeView },
  { path: MenuInfo.urlTradeEdit, intlId: MenuInfo.nameTradeEdit, component: TradeView, parentId: MenuInfo.nameTrades },
  { path: MenuInfo.urlTradeClone, intlId: MenuInfo.nameTradeClone, component: TradeView, parentId: MenuInfo.nameTrades },
  { path: MenuInfo.urlTradeItemCrossReference, intlId: MenuInfo.nameItemCrossRefEdit, component: ItemXrefList },
  { path: MenuInfo.urlTradeShipTo, intlId: MenuInfo.nameShipTo, component: ShipToView },
  { path: MenuInfo.urlTradeDocuments, intlId: MenuInfo.nameDocExp, component: DocumentListView },
  { exact: true, path: MenuInfo.urlDocExp, intlId: MenuInfo.nameDocExp, component: DocumentListView },
  { path: MenuInfo.urlDocExpMenu, intlId: MenuInfo.nameDocExp, component: DocumentListView },
  { path: MenuInfo.urlDocExpAlert, intlId: MenuInfo.nameDocExp, component: DocumentListView },
  { path: MenuInfo.urlDocExpRejected, intlId: MenuInfo.nameDocExp, component: DocumentListView },
  { path: MenuInfo.urlDocExpVPID, intlId: MenuInfo.nameDocExp, component: DocumentListView },
  { exact: true, path: MenuInfo.urlDocExpTleWorkflowDetails, intlId: MenuInfo.nameDocExpTleWorkflowDetails, component: TLEListView },

  { exact: true, path: MenuInfo.urlDocExpTleWorkflowRawData, intlId: MenuInfo.nameDocExpTleWorkflowRawData, component: TLERawDatatView },
  { exact: true, path: MenuInfo.urlDocExpTleWorkflowReport, intlId: MenuInfo.nameDocExpTleWorkflowReport, component: TLEReportView },
  { exact: true, path: MenuInfo.urlDocExpTleWorkflowStatusDetails, intlId: MenuInfo.nameDocExpTleWorkflowStatusDetails, component: TLEStatusDetailsView },
  { exact: true, path: MenuInfo.urlDocExpTleWorkflowErrorDetails, intlId: MenuInfo.nameDocExpTleWorkflowErrorDetails, component: TLEErrorView },
  { exact: true, path: MenuInfo.urlDocExpTleWorkflowErrorCodeDetails, intlId: MenuInfo.nameDocExpTleWorkflowErrorCodeDetails, component: TLEErrorCodeView },
  { exact: true, path: MenuInfo.urlTleExternalLink, intlId: MenuInfo.nameTleExternalLink, component: TLEJumperPage },


  { path: MenuInfo.urlVPNetworks, intlId: MenuInfo.nameVPNetworks, component: VPNetworkListView },
  { path: MenuInfo.urlVPNetworkDetailEdit, intlId: MenuInfo.nameVPNetworkDetailEdit, component: VPNetworkView, parentId: MenuInfo.nameVPNetworks },
  { path: MenuInfo.urlVPNetworkDetailAdd, intlId: MenuInfo.nameVPNetworkDetailAdd, component: VPNetworkView, parentId: MenuInfo.nameVPNetworks },
  { path: MenuInfo.urlCompany, intlId: MenuInfo.nameCompany, component: CompanySettingsView },
  { path: MenuInfo.urlItems, intlId: MenuInfo.nameItems, component: ItemListView },
  { path: MenuInfo.urlItemDetails, intlId: MenuInfo.nameItemDetails, component: ItemView, parentId: MenuInfo.nameItems },
  { path: MenuInfo.urlItemDetailsEdit, intlId: MenuInfo.nameItemDetailsEdit, component: ItemView, parentId: MenuInfo.nameItems },
  { path: MenuInfo.urlItemDetailsAdd, intlId: MenuInfo.nameItemDetailsAdd, component: ItemView, parentId: MenuInfo.nameItemDetails },
  { path: MenuInfo.urlItemCrossRefEdit, intlId: MenuInfo.nameItemCrossRefEdit, component: ItemXrefView, parentId: MenuInfo.nameItemCrossRefList },
  { path: MenuInfo.urlItemCrossRefList, intlId: MenuInfo.nameItemCrossRefList, component: ItemXrefList },
  { path: MenuInfo.urlItemCrossRefListMenu, intlId: MenuInfo.nameItemCrossRefListMenu, component: ItemXrefList },
  { path: MenuInfo.urlItemXRefListMenu, intlId: MenuInfo.nameItemCrossRefListMenu, component: ItemXrefList },
  { path: MenuInfo.urlItemCrossRefAdd, intlId: MenuInfo.nameItemCrossRefAdd, component: ItemXrefView, parentId: MenuInfo.nameItemCrossRefList },
  { path: MenuInfo.urlItemSacRef, intlId: MenuInfo.nameItemSacRef, component: ItemSacList },
  { path: MenuInfo.urlItemSacRefList, intlId: MenuInfo.nameItemSacRefList, component: ItemSacList, parentId: MenuInfo.nameItemSacRef },
  { path: MenuInfo.urlItemSacRefListMenu, intlId: MenuInfo.nameItemSacRefListMenu, component: ItemSacList, parentId: MenuInfo.nameItemSacRef },
  { path: MenuInfo.urlItemSacRefEdit, intlId: MenuInfo.nameItemSacRefEdit, component: ItemSacView, parentId: MenuInfo.nameItemSacRef },
  { path: MenuInfo.urlItemSacRefAdd, intlId: MenuInfo.nameItemSacRefAdd, component: ItemSacView, parentId: MenuInfo.nameItemSacRef },
  { path: MenuInfo.urlEdiStandards, intlId: MenuInfo.nameEdiStandards, component: EdiStandardsView },
  { path: MenuInfo.urlOsn, exact: true, intlId: MenuInfo.nameOsn, component: OsnListView },
  { path: MenuInfo.urlOsnDetails, intlId: MenuInfo.nameOsnDetails, component: OsnDetailView, parentId: MenuInfo.nameOsn },
  { path: MenuInfo.urlOsnInvoice1, intlId: MenuInfo.nameDocExp, component: DocumentListView, parentId: MenuInfo.nameOsn },
  { path: MenuInfo.urlOsnInvoice2, intlId: MenuInfo.nameDocExp, component: DocumentListView, parentId: MenuInfo.nameOsn },

  { path: MenuInfo.urlOsnDetailsOld, intlId: MenuInfo.nameOsnDetailsOld, component: OsnDetailView, parentId: MenuInfo.nameOsn },

  { path: MenuInfo.urlOsnTleWorkflowDetails, exact: true, intlId: MenuInfo.nameOsnTleWorkflowDetails, component: TLEListView, parentId: MenuInfo.nameOsn },

  { path: MenuInfo.urlOsnById, intlId: MenuInfo.nameOsn, component: OsnListView, parentId: MenuInfo.nameOsn },
  { path: MenuInfo.urlAsnAlert, intlId: MenuInfo.nameOsn, component: OsnListView, parentId: MenuInfo.nameOsn },
  { path: MenuInfo.urlPlanningSched, intlId: MenuInfo.namePlanningSched, component: PlanSchedListView },
  { path: MenuInfo.urlPlanningScheduleMenu, intlId: MenuInfo.namePlanningSched, component: PlanSchedListView },
  { path: MenuInfo.urlProdSequence, intlId: MenuInfo.nameProdSequence, component: ProductionSequenceListView },
  { path: MenuInfo.urlProdSequenceMenu, intlId: MenuInfo.nameProdSequence, component: ProductionSequenceListView, parentId: MenuInfo.nameProdSequence },
  { path: MenuInfo.urlUserLabels, intlId: MenuInfo.nameUserLabels, component: UserLabels },
  { path: MenuInfo.urlEditUserLabels, intlId: MenuInfo.nameEditUserLabels, component: EditUserLabels, parentId: MenuInfo.nameUserLabels },
  { path: MenuInfo.urlUserTPLabels, intlId: MenuInfo.nameUserTPLabels, component: UserLabels, parentId: MenuInfo.nameUserLabels },
  { path: MenuInfo.urlMaps, intlId: MenuInfo.nameMaps, component: MapView },
  { path: MenuInfo.urlMapEdit, intlId: MenuInfo.nameMapEdit, component: MapView, parentId: MenuInfo.nameMaps },
  { path: MenuInfo.urlMapTrade, intlId: MenuInfo.nameMapTrade, component: MapView, parentId: MenuInfo.nameMaps },
  { path: MenuInfo.urlMapNameEdit, intlId: MenuInfo.nameMapNameEdit, component: MapView, parentId: MenuInfo.nameMaps },
  // { path: '/jsonEdit/:vpid', name: '', component: JsonEdit },
  // { path: '/jsonEdit/:vpid', name: '', component: JsonEditView },
  { path: MenuInfo.urlDocExpEdit, name: '', component: JsonEditView, parentId: MenuInfo.nameDocExp },
  { path: MenuInfo.urlDocumentsSent, intlId: MenuInfo.nameDocumentsSent, component: DocumentSentView },
  { path: MenuInfo.urlDocumentsSentASN, intlId: MenuInfo.nameDocumentsSent, component: DocumentSentView, parentId: MenuInfo.nameDocumentsSent },
  { path: MenuInfo.urlDocumentsSentDetail, intlId: MenuInfo.nameDocumentsSent, component: DocumentSentView, parentId: MenuInfo.nameDocumentsSent },
  { path: MenuInfo.urlDocumentsSentPrint, intlId: MenuInfo.nameDocumentsSent, component: DocumentSentView, parentId: MenuInfo.nameDocumentsSent },
  { path: MenuInfo.urlDocumentsReceived, intlId: MenuInfo.nameDocumentsReceived, component: DocumentReceivedView },
  { path: MenuInfo.urlDocumentsReceivedById, intlId: MenuInfo.nameDocumentsReceived, component: DocumentReceivedView, parentId: MenuInfo.nameDocumentsReceived },
  { path: MenuInfo.urlDocumentsReceivedDetail, intlId: MenuInfo.nameDocumentsReceived, component: DocumentReceivedView, parentId: MenuInfo.nameDocumentsReceived },
  { path: MenuInfo.urlDocumentsReceivedPrint, intlId: MenuInfo.nameDocumentsReceived, component: DocumentReceivedView, parentId: MenuInfo.nameDocumentsReceived },
  { path: MenuInfo.urlDocumentsReceivedHTMLReport, intlId: MenuInfo.nameDocumentsReceived, component: DocumentReceivedView, parentId: MenuInfo.nameDocumentsReceived },
  { path: MenuInfo.urlDocumentsReceivedEDIReport, intlId: MenuInfo.nameDocumentsReceived, component: DocumentReceivedView, parentId: MenuInfo.nameDocumentsReceived },
  { path: MenuInfo.urlDocumentErrors, intlId: MenuInfo.nameErrorLog, component: ErrorLogView },
  { path: MenuInfo.urlTransObjects, intlId: MenuInfo.nameTransObjects, component: TransObjectView },
  { path: MenuInfo.urlTransObjectEdit, intlId: MenuInfo.nameTransObjectEdit, component: TransObjectDetailView, parentId: MenuInfo.nameTransObjects },
  { path: MenuInfo.urlTranDefs, intlId: MenuInfo.nameTransDefs, component: TransDefView },
  { path: MenuInfo.urlTransDefAdd, intlId: MenuInfo.nameTransDefAdd, component: TransDefDetailView, parentId: MenuInfo.nameTransDefs },
  { path: MenuInfo.urlTransDefEdit, intlId: MenuInfo.nameTransDefEdit, component: TransDefDetailView, parentId: MenuInfo.nameTransDefs },
  { path: MenuInfo.urlDocLoadConfig, intlId: MenuInfo.nameDocLoadConfig, component: DocLoadView },
  { path: MenuInfo.urlDocLoadConfigDetailsEdit, intlId: MenuInfo.nameDocLoadConfigDetailsEdit, component: DocLoadDetailView, parentId: MenuInfo.nameDocLoadConfig },
  { path: MenuInfo.urlDocLoadConfigDetailsAdd, intlId: MenuInfo.nameDocLoadConfigDetailsAdd, component: DocLoadDetailView, parentId: MenuInfo.nameDocLoadConfig },
  // TODO: KB: Menu.RequestRouting is missing a BPMenu entry, Mike thinks these are not used yet and are part of Pack and Ship
  { path: MenuInfo.urlRequestRouting, intlId: MenuInfo.nameRequestRouting, component: RequestRouteView },
  { path: MenuInfo.urlLastNumbers, intlId: MenuInfo.nameLastNumbers, component: LastNumbersView },
  { path: MenuInfo.urlCarbonCopy, intlId: MenuInfo.nameCarbonCopy, component: CarbonCopyView },
  { path: MenuInfo.urlCarbonCopyAdd, intlId: MenuInfo.nameCarbonCopyAdd, component: CarbonCopyView, parentId: MenuInfo.nameCarbonCopy },
  { path: MenuInfo.urlCarbonCopyEdit + ':id', intlId: MenuInfo.nameCarbonCopyEdit, component: CarbonCopyView, parentId: MenuInfo.nameCarbonCopy },
  { path: MenuInfo.urlCarbonCopyClone + ':id', intlId: MenuInfo.nameCarbonCopyClone, component: CarbonCopyView, parentId: MenuInfo.nameCarbonCopy },
  { path: MenuInfo.urlShipTo, intlId: MenuInfo.nameShipTo, component: ShipToView },
  { path: MenuInfo.urlShipToFromErpMenu, intlId: MenuInfo.nameShipTo, component: ShipToView, parentId: MenuInfo.nameShipTo },
  { path: MenuInfo.urlShipToAdd, intlId: MenuInfo.nameShipToAdd, component: ShipToDetailView, parentId: MenuInfo.nameShipTo },
  { path: MenuInfo.urlShipToEdit, intlId: MenuInfo.nameShipToEdit, component: ShipToDetailView, parentId: MenuInfo.nameShipTo },
  // NOTE: MenuInfo.nameC303v850h is the ONLY entry in the BPMenus table, thus all of these related paths will get the parent id set to MenuInfo.nameC303v850h
  { path: MenuInfo.urlC303v850s, intlId: MenuInfo.nameC303v850s, component: C303v850sView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850sAdd + ':lineno', intlId: MenuInfo.nameC303v850sAdd, component: C303v850sView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850sEdit + ':lineno/:sdqlineno', intlId: MenuInfo.nameC303v850sEdit, component: C303v850sView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850sClone + ':id', intlId: MenuInfo.nameC303v850sClone, component: C303v850sView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850lb, intlId: MenuInfo.nameC303v850lb, component: C303v850lbView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850lbAdd + ':lineno', intlId: MenuInfo.nameC303v850lbAdd, component: C303v850lbView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850lbEdit + ':lineno/:p06', intlId: MenuInfo.nameC303v850lbEdit, component: C303v850lbView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850lbClone + ':id', intlId: MenuInfo.nameC303v850lbClone, component: C303v850lbView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850c, intlId: MenuInfo.nameC303v850c, component: C303v850cView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850cAdd, intlId: MenuInfo.nameC303v850cAdd, component: C303v850cView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850cEdit + ':lineno/:seqno', intlId: MenuInfo.nameC303v850cEdit, component: C303v850cView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850cClone + ':id', intlId: MenuInfo.nameC303v850cClone, component: C303v850cView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850f, intlId: MenuInfo.nameC303v850f, component: C303v850fView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850fAdd, intlId: MenuInfo.nameC303v850fAdd, component: C303v850fView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850fEdit + ':id', intlId: MenuInfo.nameC303v850fEdit, component: C303v850fView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850fClone + ':id', intlId: MenuInfo.nameC303v850fClone, component: C303v850fView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850d, intlId: MenuInfo.nameC303v850d, component: C303v850dView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850dAdd, intlId: MenuInfo.nameC303v850dAdd, component: C303v850dView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850dEdit + ':lineno/:dtm01/:dtm02', intlId: MenuInfo.nameC303v850dEdit, component: C303v850dView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850dClone + ':id', intlId: MenuInfo.nameC303v850dClone, component: C303v850dView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850r, intlId: MenuInfo.nameC303v850r, component: C303v850rView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850rAdd, intlId: MenuInfo.nameC303v850rAdd, component: C303v850rView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850rEdit + ':lineno/:ref01/:ref02/:ref03', intlId: MenuInfo.nameC303v850rEdit, component: C303v850rView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850rClone + ':id', intlId: MenuInfo.nameC303v850rClone, component: C303v850rView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850n, intlId: MenuInfo.nameC303v850n, component: C303v850nView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850nAdd, intlId: MenuInfo.nameC303v850nAdd, component: C303v850nView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850nEdit + ':lineno/:n101', intlId: MenuInfo.nameC303v850nEdit, component: C303v850nView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850nClone + ':id', intlId: MenuInfo.nameC303v850nClone, component: C303v850nView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850l, intlId: MenuInfo.nameC303v850l, component: C303v850lView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850lAdd, intlId: MenuInfo.nameC303v850lAdd, component: C303v850lView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850lEdit + ':id', intlId: MenuInfo.nameC303v850lEdit, component: C303v850lView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850lClone + ':poid/:id', intlId: MenuInfo.nameC303v850lClone, component: C303v850lView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850h, intlId: MenuInfo.nameC303v850h, component: C303v850hView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850hDoc, intlId: MenuInfo.nameC303v850h, component: C303v850hView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850hASN, intlId: MenuInfo.nameC303v850h, component: C303v850hView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlC303v850hAdd, intlId: MenuInfo.nameC303v850hAdd, component: C303v850hView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850hEdit, intlId: MenuInfo.nameC303v850hEdit, component: C303v850hView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: MenuInfo.urlC303v850hEditNew, intlId: MenuInfo.nameC303v850hEditNew, component: C303v850hView, parentId: MenuInfo.nameC303v850h },
  // NOTE: There is no Menu.POAckForm in the BPMenus table, solved, the parent item is MenuInfo.nameC303v850h
  { exact: true, path: '/PurchaseOrders/PurchaseOrderAckView/:dgid/:poid/:new', intlId: MenuInfo.namePOAckForm, component: POAckView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: '/PurchaseOrders/PurchaseOrderAckView/:dgid/:poid/:new/PurchaseOrderAckEdit', intlId: MenuInfo.namePOAckEdit, component: POAckEdit, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: '/PurchaseOrders/PurchaseOrderAckView/:dgid/:poid/:new/PODateEdit', intlId: MenuInfo.namePODateEdit, component: POAckEdit, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: '/PurchaseOrders/PurchaseOrderAckView/:dgid/:poid/:new/POLineEdit', intlId: MenuInfo.namePOLineEdit, component: POAckEdit, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: '/PurchaseOrders/PurchaseOrderAckView/:dgid/:poid/:new/POLineAdd', intlId: MenuInfo.namePOLineAdd, component: POAckEdit, parentId: MenuInfo.nameC303v850h },

  { exact: true, path: '/PurchaseOrders/PurchaseOrderChangeAckView/:dgid/:poid/:new', intlId: MenuInfo.namePOChangeAckForm, component: POAckView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: '/PurchaseOrders/PurchaseOrderChangeAckView/:dgid/:poid/:new/PurchaseOrderChangeAckEdit', intlId: MenuInfo.namePOChangeAckEdit, component: POAckEdit, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: '/PurchaseOrders/PurchaseOrderChangeAckView/:dgid/:poid/:new/POLineEdit', intlId: MenuInfo.namePOChangeLineEdit, component: POAckEdit, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: '/PurchaseOrders/PurchaseOrderChangeAckView/:dgid/:poid/:new/POLineAdd', intlId: MenuInfo.namePOChangeLineAdd, component: POAckEdit, parentId: MenuInfo.nameC303v850h },

  { exact: true, path: '/PurchaseOrders/PurchaseOrderStatusView/:dgid/:poid/:new', intlId: MenuInfo.namePOStatusForm, component: POStatusView, parentId: MenuInfo.nameC303v850h },
  { exact: true, path: '/PurchaseOrders/PurchaseOrderStatusView/:dgid/:poid/:new/PurchaseOrderStatusEdit', intlId: MenuInfo.namePOStatusEdit, component: POStatusEdit, parentId: MenuInfo.nameC303v850h },
  //  { path: MenuInfo.urlC303v850hEdit2  + ':id', intlId:MenuInfo.nameC303v850hEdit, component: C303v850hView},
  { path: MenuInfo.urlC303v850hClone + ':id', intlId: MenuInfo.nameC303v850hClone, component: C303v850hView, parentId: MenuInfo.nameC303v850h },
  // { path: MenuInfo.urlC303v850POEdit  + ':id', intlId:MenuInfo.nameC303v850POEdit, component: C303v850hView},
  { exact: true, path: MenuInfo.urlC303v850hTleWorkflowDetails, intlId: MenuInfo.nameC303v850hTleWorkflowDetails, component: TLEListView },

  { path: MenuInfo.urlPOAlert, intlId: MenuInfo.nameC303v850h, component: C303v850hView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlTradePO, intlId: MenuInfo.nameC303v850h, component: C303v850hView, parentId: MenuInfo.nameC303v850h },
  { path: MenuInfo.urlTaxCode, intlId: MenuInfo.nameTaxCode, component: TaxCodeView },
  { path: MenuInfo.urlTaxCodeAdd, intlId: MenuInfo.nameTaxCodeAdd, component: TaxCodeView, parentId: MenuInfo.nameTaxCode },
  { path: MenuInfo.urlTaxCodeEdit + ':id', intlId: MenuInfo.nameTaxCodeEdit, component: TaxCodeView, parentId: MenuInfo.nameTaxCode },
  { path: MenuInfo.urlTaxCodeTradeEdit + ':id/:tpid', intlId: MenuInfo.nameTaxCodeEdit, component: TaxCodeView, parentId: MenuInfo.nameTaxCode },
  { path: MenuInfo.urlDataTransport, intlId: MenuInfo.nameDataTransport, component: DataTransportView },
  { path: MenuInfo.urlDataTransportAdd, intlId: MenuInfo.nameDataTransportAdd, component: DataTransportView, parentId: MenuInfo.nameDataTransport },
  { path: MenuInfo.urlDataTransportEdit + ':id', intlId: MenuInfo.nameDataTransportEdit, component: DataTransportView, parentId: MenuInfo.nameDataTransport },
  { path: MenuInfo.urlDataTransportClone + ':id', intlId: MenuInfo.nameDataTransportClone, component: DataTransportView, parentId: MenuInfo.nameDataTransport },
  { path: MenuInfo.urlLocation, intlId: MenuInfo.nameLocation, component: LocationView },
  { path: MenuInfo.urlLocationAdd, intlId: MenuInfo.nameLocationAdd, component: LocationView, parentId: MenuInfo.nameLocation },
  { path: MenuInfo.urlLocationEdit + ':id', intlId: MenuInfo.nameLocationEdit, component: LocationView, parentId: MenuInfo.nameLocation },
  { path: MenuInfo.urlLocationClone + ':id', intlId: MenuInfo.nameLocationClone, component: LocationView, parentId: MenuInfo.nameLocation },
  { path: '/controlNum', intlId: MenuInfo.nameControlNum, component: ControlNumView },
  { path: '/controlNumAdd', intlId: MenuInfo.nameControlNumAdd, component: ControlNumView, parentId: MenuInfo.nameControlNum },
  { path: '/controlNumEdit/:id', intlId: MenuInfo.nameControlNumEdit, component: ControlNumView, parentId: MenuInfo.nameControlNum },
  { path: '/controlNumClone/:id', intlId: MenuInfo.nameControlNumClone, component: ControlNumView, parentId: MenuInfo.nameControlNum },
  { path: MenuInfo.urlMenuConfig, intlId: MenuInfo.nameMenuConfig, component: NewMenuConfigView },
  // { path: MenuInfo.urlNewMenuConfig, intlId: MenuInfo.nameNewMenuConfig , component: NewMenuConfigView },
  // TODO: KB: Menu.RouteInstr is missing a BP Menu entry, Mike thinks these are not used yet and are part of Pack and Ship
  { path: MenuInfo.urlRouteInstr, intlId: MenuInfo.nameRouteInstr, component: RouteInstrView },
  // { path: MenuInfo.urlRouteInstrAdd, intlId: MenuInfo.nameRouteInstrAdd, component: RouteInstrView, parentId: MenuInfo.nameRouteInstr },
  // { path: MenuInfo.urlRouteInstrEdit + ':id', intlId: MenuInfo.nameRouteInstrEdit, component: RouteInstrView , parentId: MenuInfo.nameRouteInstr },
  // { path: MenuInfo.urlRouteInstrClone + ':id', intlId: MenuInfo.nameRouteInstrClone, component: RouteInstrView, parentId: MenuInfo.nameRouteInstr },
  { path: MenuInfo.urlCumulativeQty, intlId: MenuInfo.nameCumulativeQty, component: CumulativeQtyView },
  { path: MenuInfo.urlCumulativeQtyDetail, intlId: MenuInfo.nameCumulativeQtyEdit, component: CumulativeQtyDetailView, parentId: MenuInfo.nameCumulativeQty },
  { path: MenuInfo.urlCumulativeQtyAdd, intlId: MenuInfo.nameCumulativeQtyAdd, component: CumulativeQtyDetailAddView, parentId: MenuInfo.nameCumulativeQty },
  { path: MenuInfo.urlCumulativeQtyAddTPPartID, intlId: MenuInfo.nameCumulativeQtyAdd, component: CumulativeQtyDetailAddView, parentId: MenuInfo.nameCumulativeQty },
  { path: MenuInfo.urlCumulativeQtyEdit, intlId: MenuInfo.nameCumulativeQtyAdd, component: CumulativeQtyDetailAddView, parentId: MenuInfo.nameCumulativeQty },
  { path: MenuInfo.urlCumulativeQtyMenu, intlId: MenuInfo.nameCumulativeQty, component: CumulativeQtyView, parentId: MenuInfo.nameCumulativeQty },
  // { path: MenuInfo.urlTradeMaintenance, intlId: MenuInfo.nameTradeMaintenance , component: TradeMaintenanceView },
  { path: MenuInfo.urlProcessTrigger, intlId: MenuInfo.nameProcessTrigger, component: ProcessTriggerView },
  { path: MenuInfo.urlProcessTriggerAdd, intlId: MenuInfo.nameProcessTriggerAdd, component: ProcessTriggerView, parentId: MenuInfo.nameProcessTrigger },
  { path: MenuInfo.urlProcessTriggerEdit + ':id', intlId: MenuInfo.nameProcessTriggerEdit, component: ProcessTriggerView, parentId: MenuInfo.nameProcessTrigger },
  // NOTE: Exception Reports are handled as a SPECIAL CASE, no need for ParentId here
  { path: MenuInfo.urlExceptionReportInboundAsn, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportFunctionAck, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportInboundFreightInvoice, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportInboundInvoice, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportSalesOrder, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportDocHold, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportOutboundASN, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportOutboundInvoice, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportPurchaseOrder, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportPurchaseOrderAck, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportOutboundReturnMerchandiseAuthorization, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportOutboundLogisticsServiceRequest, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportInboundLogisticsServiceResponse, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportInboundCarrierShipmentStatus, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  { path: MenuInfo.urlExceptionReportWarehouseShippingOrder, intlId: MenuInfo.nameExceptionReports, component: ExceptionReports },
  // { path: MenuInfo.urlHTMLReportPostingLog, intlId: MenuInfo.nameHTMLReport, component: HTMLReports },
  { path: MenuInfo.urlHTMLReport, intlId: MenuInfo.nameHTMLReport, component: HTMLReports },
  { path: MenuInfo.urlViewHTMLReport, name: '', component: HTMLReports },
  { path: MenuInfo.urlCompanyCopy, intlId: MenuInfo.nameCompanyCopy, component: CopyCompany },
  { path: MenuInfo.urlCompanyDelete, intlId: MenuInfo.nameCompanyDelete, component: DeleteCompany },
  { path: MenuInfo.urlCustomizeTerms, intlId: MenuInfo.nameCustomizeTerms, component: CustomizeTermsView },
  { path: MenuInfo.urlCustomizeTermsEdit, intlId: MenuInfo.nameCustomizeTermsEdit, component: CustomizeTermsDetailView, parentId: MenuInfo.nameCustomizeTerms },
  { path: MenuInfo.urlCustomizeTermsAdd, intlId: MenuInfo.nameCustomizeTermsAdd, component: CustomizeTermsDetailView, parentId: MenuInfo.nameCustomizeTerms },
  // Pack & Ship
  { exact: true, path: MenuInfo.urlPackAndShipMenu, intlId: MenuInfo.namePackAndShipMenu },
  { exact: true, path: MenuInfo.urlPackAndShipSelectOrders, intlId: MenuInfo.namePackAndShipSelectOrders, component: PackAndShipSelectOrdersView },
  { exact: true, path: MenuInfo.urlPackAndShipEditOrder, intlId: MenuInfo.namePackAndShipEditOrder, component: PackAndShipEditOrderView, parentId: MenuInfo.namePackAndShipSelectOrders },
  { exact: true, path: MenuInfo.urlPackAndShip, intlId: MenuInfo.namePackAndShip, component: PackAndShipView, parentId: MenuInfo.namePackAndShipSelectOrders },
  // Just for testing
  { exact: true, path: MenuInfo.urlPackAndShipAlt, intlId: MenuInfo.namePackAndShip, component: PackAndShipViewAlt },

  { exact: true, path: MenuInfo.urlPackAndShipMultiLevel, intlId: MenuInfo.namePackAndShipMultiLevel, component: PackAndShipMultiLevelView, parentId: MenuInfo.namePackAndShipSelectOrders },
  { exact: true, path: MenuInfo.urlPackAndShipShipmentList, intlId: MenuInfo.namePackAndShipShipmentList, component: PackAndShipShipmentListView },
  { exact: true, path: MenuInfo.urlPackAndShipShipment, intlId: MenuInfo.namePackAndShipShipment, component: PackAndShipShipmentView, parentId: MenuInfo.namePackAndShipShipmentList },
  { exact: true, path: MenuInfo.urlPackAndShipShipmentLabels, intlId: MenuInfo.namePackAndShipShipmentLabels, component: PackAndShipLabels },
  // NOTE: Tracking Numbers, Per Debbie: put under Utilities menu
  { exact: true, path: MenuInfo.urlPackAndShipUpdateTrackingNumber, intlId: MenuInfo.namePackAndShipUpdateTrackingNumber, component: PackAndShipUpdateTrackingNumberView, parentId: MenuInfo.namePackAndShipShipmentList },

  { path: MenuInfo.urlPackage, intlId: MenuInfo.namePackages, component: PackageView },
  { path: MenuInfo.urlPackageDetailsEdit, intlId: MenuInfo.namePackageDetailsEdit, component: PackageDetailView, parentId: MenuInfo.namePackages },
  { path: MenuInfo.urlPackageDetailsAdd, intlId: MenuInfo.namePackageDetailsAdd, component: PackageDetailView, parentId: MenuInfo.namePackages },
  { path: MenuInfo.urlShippingLabel, intlId: MenuInfo.nameShippingLabel, component: ShippingLabel },
  { path: "/barcodes", intlId: MenuInfo.nameShippingLabel, component: BarcodeSamples },
  { path: MenuInfo.urlShippingLabelV2, intlId: MenuInfo.nameShippingLabel, component: ShippingLabelV2 },
  
  // KB: 07/02/2020 - Removed new Trade Maps feature for now per Debbie's request
  // { path: MenuInfo.urlTradeMaps, intlId: MenuInfo.nameTradeMaps, component: TradeMapsView },
  { path: MenuInfo.urlShippingLabel, intlId: MenuInfo.nameShippingLabel, component: ShippingLabel },
  { path: "/barcodes", intlId: MenuInfo.nameShippingLabel, component: BarcodeSamples },
  { path: MenuInfo.urlShippingLabelV2, intlId: MenuInfo.nameShippingLabel, component: ShippingLabelV2 },
];

// NOTE: This protects all TOP-level routes with permissions and hands each view a hasPermission props
// Each top-level view should pass the hasPermission props into any child components
routes.forEach(r => {
    if(r.component){
      r.component = withUserPermissions(r.component)
    }
});

// Testing if the wrapper is causing me issues, it IS NOT
// routes.forEach(r => {
//   if (r.path !== MenuInfo.urlPackAndShipSelectOrders) {
//     r.component = withUserPermissions(r.component)
//   } else {
//     console.log(r.path + ' - NOT wrapped');
//   }
// });

export default routes;

