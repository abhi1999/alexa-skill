//
// NOT USED
//
export const urlUserLabelsItems : string = '/UserLabels/AIU01';
export const nameUserLabelsItems : string = 'Item User Labels';

export const urlUserLabelsCarriers : string = '/UserLabels/AIU02';
export const nameUserLabelsCarriers : string = 'Carrier User Labels';

export const urlUserLabelsCarrierXref : string = '/UserLabels/AIU03';
export const nameUserLabelsCarrierXref : string = 'Carrier Cross Reference User Labels';

export const urlUserLabelsLocation : string = '/UserLabels/AIU04';
export const nameUserLabelLocation : string = 'Location User Labels';

export const urlUserLabelsItemXRef : string = '/UserLabels/AITCR';
export const nameUserLabelItemXRef : string = 'Item Cross Reference User Labels';

export const urlUserLabelsShipTo : string = '/UserLabels/ASU01';
export const nameUserLabelShipTo : string = 'Ship To User Labels';

export const urlUserLabelsTP : string = '/UserLabels/ATU01';
export const nameUserLabelTP : string = 'Trading Partner Global User Labels';

export const urlUserLabelsTPG : string = '/UserLabels/ATU01/!';
export const nameUserLabelTPG : string = 'Trading Partner Per Partner User Labels';

export const urlUserLabelsShipTP : string = '/UserLabels/AAU01/!';
export const nameUserLabelShipTP : string = 'Ship Orders Per Partner User Labels';

const iconList = 'fa fa-list';

const utilityMenu =  {   name: 'SendReceive', url: '/config', icon: 'fas fa-cog',
    children: [
        {  
            icon: iconList,
            name: nameUserLabelsItems,
            url: urlUserLabelsItems,
        },
        {
            icon: iconList,
            name: nameUserLabelsCarriers,
            url: urlUserLabelsCarriers,
        },            
        {
            icon: iconList,
            name: nameUserLabelsCarrierXref,
            url: urlUserLabelsCarrierXref,
        },
        {
            icon: iconList,
            name: nameUserLabelShipTo,
            url: urlUserLabelsShipTo
        },
        {
            icon: iconList,
            name: nameUserLabelLocation,
            url: urlUserLabelsLocation
        },
        {
            icon: iconList,
            name: nameUserLabelItemXRef,
            url: urlUserLabelsItemXRef
        },
        {
            icon: iconList,
            name: nameUserLabelTP,
            url: urlUserLabelsTP
        },
        {
            icon: iconList,
            name: nameUserLabelTPG,
            url: urlUserLabelsTPG
        },
        {
            icon: iconList,
            name: nameUserLabelShipTP,
            url: urlUserLabelsShipTP
        },
    ]
};

export default utilityMenu;