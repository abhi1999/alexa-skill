import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';

import {lsChartThemeKey} from "./../constants";


export const ChartOptions = {
    // type:'logarithmic',
    legend:{
      display:false,
      labels: {
        boxWidth: 10
      },
      position: 'right',
    },
    maintainAspectRatio: false,
    tooltips: {
        custom: CustomTooltips,
        enabled: false,
    },   
  }
  
 const ChartBackgroundColors = [
 // Blue
'#246aa9',

// purple 
'#814f9b',

// blue
// '#2c71af',
'#75a5eb',

// Green:
'#00aebb',
'#00c7cd',
'#8ee8ea',

// Red:
'#d63120',
'#de5646',
'#e26357',
'#f0c1c5',


// Orange:
'#f15e1f',

// Gold:
'#ef921f',


// Purple:

'#c63189',

// Grey:
'#2f3d40',

// Dark Blue:
'#001e46'
]
 const ChartBackgroundColors2 = ['#3366CC',
        '#DC3912',
        '#FF9900',
        '#109618',
        '#990099',
        '#3B3EAC',
        '#0099C6',
        '#DD4477',
        '#66AA00',
        '#B82E2E',
        '#316395',
        '#994499',
        '#22AA99',
        '#AAAA11',
        '#6633CC',
        '#E67300',
        '#8B0707',
        '#329262',
        '#5574A6',
        '#3B3EAC',
        ]
        const ChartBackgroundColors3 = [
          //  color 1
         '#0c4988',
         
         //  color 2
         '#3a75ae',
         
         // color 3
         '#5e93c5',
         
         // Color 4:
         '#85b3df',
         
         // color 5
          '#c4e2ff',

           // color 6
           '#e7f3ff',

         ]
const ChartBackgroundColors4 = [
  // Blue
 '#246aa9',
 
 // purple 
 '#49b848',
 
 // blue
 // '#2c71af',
 '#f36922',
 
 // Green:
 '#00aebb',
 '#f19d22',
 '#8ee8ea',
 
 // Red:
 '#d63120',
 '#de5646',
 '#e26357',
 '#f0c1c5',
 
 
 // Orange:
 '#f15e1f',
 
 // Gold:
 '#ef921f',
 
 
 // Purple:
 
 '#c63189',
 
 // Grey:
 '#2f3d40',
 
 // Dark Blue:
 '#001e46'
 ]
  
let moduleToExport = ChartBackgroundColors;
switch(localStorage.getItem(lsChartThemeKey)){
  case 'ChartBackgroundColors2':
    moduleToExport=ChartBackgroundColors2;
    break;
  case 'ChartBackgroundColors3':
    moduleToExport=ChartBackgroundColors3;
    break;
  case 'ChartBackgroundColors4':
    moduleToExport=ChartBackgroundColors4;
    break;
  default:
    moduleToExport=ChartBackgroundColors;
    break;
}

export {
  moduleToExport as ChartBackgroundColors
}