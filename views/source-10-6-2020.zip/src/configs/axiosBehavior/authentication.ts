import { axiosRoot } from '../axios';
import { axClientKey, axClientKeySep, axUsername, lsCompanyID, sessCompanyID, axAccessToken, axRefreshToken, cookieMultiSession, nameofClientKey, UpdateCookieWithClientKey } from '../../constants/index';
import { SERVICES, consoleColor } from '../../configs/index';
import { IWindow } from '../../constants/IWindow';
import { intl } from '../../utils/IntlGlobalProvider';
import { FixURIComponent } from "../axios";
import { Logout } from '../../utils/Logout'

let doingRetoken : boolean = false;

// Pause the Axios request processing until we have a username and company ID
let isLoginInProgress = false;
let isAuthenticated : boolean = false;

// let isGettingToken = false;   // Pause other requests while waiting for a new OAuth2 token
const promiseResolveArray:any[]=[];



export const ApplyAuthenticationBehavior =(axiosMain)=>{
    // Intercept all Request messages to see if we're still logged in
    axiosMain.interceptors.request.use(async (config)=> {
        console.info('%c' + config.method + ": " + config.url, consoleColor.colorAxiosMain);

        config.timeout = ((window as any).env as IWindow).API_TIMEOUT_MINUTES * 60 * 1000;
        config.baseURL = ((window as any).env as IWindow).VP4API_URL;

        // Apply OAuth2 token to the header
        const oauth = sessionStorage.getItem(axAccessToken);
        if (oauth === undefined){
            console.error('%cMissing OAuth token', consoleColor.consoleError);
            console.log("Logging Out Now")
            Logout();
            return;
        } else {
            // Apply the OAuth2 token
            config.headers.common['Authorization'] = 'Bearer ' + oauth;
            config.headers['Authorization'] = 'Bearer ' + oauth;
            config.withCredentials = true;
        }

        // These requests should flow directly to the API without a client key
        if (config.url.indexOf('/Login/Connect') > 0) { return config };  
        if (config.url.indexOf('/Setup/GetConfiguration/') > 0) { return config }; 
        if (config.url.indexOf('/Setup/ProcessInstallationCode') > 0) { return config }; 
        if (config.url.indexOf('/Setup/CreateEdiDB') > 0) { return config }; 
        if (config.url.indexOf('/Utility/UpdateSoftware') > 0) { return config }; 
        if (config.url.indexOf('/Utility/CheckSWUpdateProgress') > 0) { return config }; 
        if (config.url.indexOf('/Utility/CheckSWUpdateErrors') > 0) { return config };

        try {
            ((window as any).env as IWindow).LastURL = config.url;

            // See if we have a ClientKey already
            const cid = sessionStorage.getItem(sessCompanyID);
            let key : any = '';
            isAuthenticated = false;
            if (cid !== null) {
                key = sessionStorage.getItem(axClientKey + axClientKeySep + cid);
                if (cid !== null) {
                    isAuthenticated = true;
                }
            }

            if (!isAuthenticated) {
                const retVal = await launchLogin(config);  // Hang here until login and connect completes
                key = sessionStorage.getItem(axClientKey + axClientKeySep + cid);
            }

            // Apply our current client key to every request   
            config.headers.common[axClientKey] = key;
            config.headers[axClientKey] = key;
        } catch (error) {
            console.error('%caxiosMain interceptor fail, ' + error.message, consoleColor.consoleError)
        }
        return config;
    }, 
    (error) => {
        console.error('%cHTTP Status ' + error.request.Status, consoleColor.consoleError);
        return Promise.reject(error);
    });


    // Intecept all the Responses and deal with the ClientKey going out of scope due to IIS reset
    // or the OAuth2 token expiring
    axiosMain.interceptors.response.use( (response)=> {
        // Normal response
        return response;
    }, 
    async (error) =>{
        try {
            if (error.message === "Network Error") {
                // HTTP 404, 500 or others
                return Promise.reject(new Error(error.message + "; " + error.config.url));
            }

            // Some other sort of error, see if Bad Request and Not Authorized
            if (error.message.indexOf('timeout') >= 0) {
                // API call timed out and the error object has no useful info, sigh...
                // .LastURL may be the request that timed-out but not guarenteed if multiple requests were queued
                return Promise.reject(new Error(((window as any).env as IWindow).LastURL + '; ' + error.message)); 
            }
        } catch (error) {
            console.error('%caxiosMain response interceptor fail, ' + error.message, consoleColor.consoleError);
            return Promise.reject(error);
        }


        try {
            if (error.response.status === 401) {
                // OAuth token has expired
                if (doingRetoken)
                {
                    // Hang here while another request gets the new token
                    const newConfig = error.response.config;
                    console.log('%cWaiting for new Token ' + newConfig.url, consoleColor.consoleWarn);
                    await until(_ => !doingRetoken);
                    
                    console.log('%cHave new Token ' + newConfig.url, consoleColor.consoleWarn);
                    const oauth = sessionStorage.getItem(axAccessToken);
                    newConfig.headers['Authorization'] = 'Bearer ' + oauth;
                    newConfig.withCredentials = true;
                    return axiosRoot(newConfig);
                }

                doingRetoken = true;
                const newRetVal = await refreshToken()
                                    .then((r) => {
                                        doingRetoken = false;
                                        const newConfig = error.response.config;
                                        console.log('%cReissue after new Token ' + newConfig.url, consoleColor.consoleWarn);
                                        const oauth = sessionStorage.getItem(axAccessToken);
                                        newConfig.headers['Authorization'] = 'Bearer ' + oauth;
                                        newConfig.withCredentials = true;
                                        return axiosRoot(newConfig);
                                    })
                    return newRetVal;
            }
        } catch (error) {
            console.log('%cUnable to get new OAuth token', consoleColor.consoleError);
        }

        try {
            if (error.response.status === 400) {
                // Bad Request
                if (error.response.data.error.message.includes('ot authorized')) {
                    console.info('%cGetting new client key',consoleColor.consoleWarn);
                    // Get a new ClientKey and retry the initial request
                    const newRetVal = await retryRequest(error);
                    console.info('%cGot new client key', consoleColor.consoleInfo);
                    return Promise.resolve(newRetVal);
                }
            }
        }
        catch { 
            // Ignore this and check below
        } 
        
        try {
            if (error.response.status === 400) {
                // Bad Request
                if (error.response.data.ExceptionMessage.includes('ot authorized')) {
                    console.info('%cGetting new client key',consoleColor.consoleWarn);
                    // Get a new ClientKey and retry the initial request
                    const newRetVal = await retryRequest(error);
                    console.info('%cGot new client key', consoleColor.consoleInfo);
                    return Promise.resolve(newRetVal);
                }
            }
        }
        catch { 
            // Ignore this and check below
        }  

        try {
            if (error.response.status === 400) {
                if (error.response.data.Message.includes('ot authorized')) {
                    console.warn('%cGetting new client key', consoleColor.consoleWarn);
                    // Get a new ClientKey and retry the initial request
                    const newRetVal = await retryRequest(error);
                    console.info('%cGot new client key', consoleColor.consoleInfo);
                    return Promise.resolve(newRetVal);
                }

                if (error.response.data.ExceptionMessage !== undefined) {
                    return Promise.reject(new Error(error.response.data.ExceptionMessage + "; " + error.config.url));
                }
                
                if (error.response.data.Message !== undefined) {
                    return Promise.reject(new Error(error.response.data.Message + "; " + error.config.url));
                }
            }
        } catch {
            // Keep looking
        }

        try {
            if (error.response.status === 409) {   
                // Duplicate key errors (usually on Adds)   
                const err409 : any = new Error(error.message + " Conflict; " + error.config.url);    
                // See if any response data and if so append it to the Error object
                if (error.response.data !== undefined) {
                    err409.data = error.response.data;
                }
                return Promise.reject(err409);
            }
        } catch {
            // Keep Looking
        }

        try {
            if (error.response.status === 400) {
                if (error.response.data.ExceptionMessage !== '' && error.response.data.ExceptionMessage  !== undefined) {
                    return Promise.reject(new Error(error.response.data.ExceptionMessage + "; " + error.config.url));
                }
            }
        } catch {
            // Keep Looking
        }

        try {
            if (error.response.status === 400) {
                if (!(error.response.data.error.message === null || error.response.data.error.message === undefined)) {
                    return Promise.reject(new Error(error.response.data.error.message + "; " + error.config.url));
                }
            }
        } catch {
            // Keep Looking
        }

        try {
            if (!(error.response.data.error.innererror.internalexception.message === null || error.response.data.error.innererror.internalexception.message === undefined)) {
                return Promise.reject(new Error(error.response.data.error.innererror.internalexception.message + "; " + error.config.url));
            }
        } catch {
            // Keep Looking
        }

        try {
            if (error.response.status === 404) {
                return Promise.reject(new Error('API method not found, ' + error.response.config.url));
            }
        } catch {
            // Keep looking
        }

        try
        {
            if (error.response.data.error === undefined) {
                if (error.response.data.Message !== undefined) {
                    return Promise.reject(new Error(error.request.responseURL + "; " + error.response.data.Message));
                }
                else {
                    if (error.response.data.length !== 0) {
                    return Promise.reject(new Error(error.request.responseURL + "; " + error.response.data));
                    } else {
                        return Promise.reject(new Error(error.request.responseURL + "; " + error.response.statusText));
                    }
                }
            }
            else {
                try
                {
                    if (error.response.data.error.message.indexOf("MethodAccessException") >= 0) {
                        // API rejected the request based on role permissions
                        return Promise.reject(new Error(intl.formatMessage({ id: 'Validation.NotAllowed'})));
                    } else if (error.response.data.error.innererror.message !== undefined) {
                        return Promise.reject(new Error(error.request.responseURL + "; " + error.response.data.error.innererror.message));
                    } else {
                        return Promise.reject(new Error(error.request.responseURL + "; " + error.response.data.error.message));
                    }
                }
                catch {
                    return Promise.reject(error.request.responseURL + "; " + error);
                }
            }
        }
        catch {
            return Promise.reject(error);
        }
    });
}

// https://stackoverflow.com/questions/22125865/wait-until-flag-true
const until = (conditionFunction) => {

    const poll = (resolve) => {
      if(conditionFunction()) { resolve() }
      else { setTimeout(_ => poll(resolve), 400) };
    }
  
    return new Promise(poll);
  }

// Get a new ClientKey and retry the original request that was rejected
const retryRequest = async (error) => {
    return new Promise(r => {
            console.error("%cfailed: " + error.response.request.responseURL, consoleColor.consoleError);
            const url = SERVICES.endpoints.connectToApi + '/' 
                + FixURIComponent(sessionStorage.getItem(axUsername) as string) + '/' 
                + sessionStorage.getItem(sessCompanyID);
            axiosRoot.get(url)
            .then((resp) => {
                const cid = sessionStorage.getItem(sessCompanyID);
                sessionStorage.setItem(axClientKey + axClientKeySep + cid, resp.data);
                UpdateCookieWithClientKey();

                // Update the rejected request with the new ClientKey
                error.config.headers[axClientKey] = resp.data;

                // Reissue the rejected request
                axiosRoot(error.config)
                    .then(
                        (resp1) => {
                            console.info('%cResolving after re-issue ' + error.response.request.responseURL, consoleColor.consoleInfo);
                            r(resp1);
                        },
                        (newError) => {
                            console.error("%cfailed: " + newError.response.request.responseURL, consoleColor.consoleError);
                            r(newError);
                        }
                    )
            });
        })
}

// Get a new OAuth2 token

const refreshToken = async () => {
    return new Promise(r=>{
        try {
            console.log('%caxiosroot refreshToken: ' + SERVICES.endpoints.getLoginToken, consoleColor.consoleAxiosRoot); 

            const reftok : string = sessionStorage.getItem(axRefreshToken) as string; 
            const oauthRequest = "grant_type=refresh_token&client_id=VPEDI&refresh_token=" + reftok; 
            axiosRoot.post(SERVICES.endpoints.getLoginToken, oauthRequest)
                .then((resp) => {
                    console.log('%caxiosroot refreshToken complete', consoleColor.consoleAxiosRoot);
                    // Update our cached tokens
                    const token : string = resp.data.access_token;
                    console.log('New Token ' + token);
                    sessionStorage.setItem(axAccessToken, token);
                    sessionStorage.setItem(axRefreshToken, resp.data.refresh_token);
                    r(true);
                },
                (tkError) => {
                    console.log('%cUnable to get new token/clientkey ' + tkError.message, consoleColor.consoleError);

                    // Force re-login
                    sessionStorage.removeItem(axUsername);
                    sessionStorage.removeItem(axAccessToken);
                    sessionStorage.removeItem(axRefreshToken);
                    document.cookie = cookieMultiSession + '=; path=/;';
                    window.location.replace('/');
                })
        }
        catch (error) {
                console.log('%cUnable to get new token ' + error.message, consoleColor.consoleError);
                throw(error);
            }
        })
    }

const launchLogin = async (config)=>{
    if(isAuthenticated) {return Promise.resolve();}

    const retPromise = new Promise(r=>{
        console.log('pushing ' + config.url);
        promiseResolveArray.push({resolve:r, config})
    });
    
    if(!isLoginInProgress){
        isLoginInProgress=true;
        login(config);
    }
    console.log('queuing up promise', promiseResolveArray)
    return retPromise;
}

const login=async(config)=>{
    // if (sessionStorage.getItem(axUsername) === null) {
    //     // Simulate Login and Company screen responses
    //     sessionStorage.setItem(axUsername, 'Demo.User');
    //     let cid = sessionStorage.getItem(sessCompanyID);
    //     if (cid === null) {
    //         cid = ((window as any).env as IWindow).DEFAULT_TEST_COMPANY.toString();
    //         localStorage.setItem(lsCompanyID, cid);
    //         sessionStorage.setItem(sessCompanyID, cid);
    //     }
    //     sessionStorage.removeItem(axClientKey + axClientKeySep + cid.toString());
    // }

    return new Promise(r=>{
            // mar - 5/18/2020 use session storage first (session may have timed out)
            let cid = sessionStorage.getItem(sessCompanyID);
            if (cid == null ) {
                cid = localStorage.getItem(lsCompanyID);
            }
            if (cid === null) {
                localStorage.setItem(lsCompanyID, '1');
                sessionStorage.setItem(sessCompanyID, '1');
                cid = '1';
            }
            let user : string;
            if (sessionStorage.getItem(axUsername) === null || sessionStorage.getItem(axUsername) === '') {
                user = 'NotSignedIn';
            } else {
                user = sessionStorage.getItem(axUsername) as string;
            }
            const url = SERVICES.endpoints.connectToApi + '/' 
                + FixURIComponent(user) 
                + '/' + cid;
            axiosRoot.get(url)
            .then((resp) => {
                // Save the new ClientKey in sessionStorage for subsequent sessions
                sessionStorage.setItem(axClientKey + axClientKeySep + cid, resp.data);
                UpdateCookieWithClientKey();

                // Update the current Axios config with the new ClientKey value
                config.headers.common[axClientKey] = resp.data;
                const compUrl = SERVICES.endpoints.companySet + "?$select=YourCompany_DispName&$filter=Company_ID eq " + cid;
                axiosRoot.get(compUrl)
                .then((resp1) => {
                    ((window as any).env as IWindow).YourCompany_DispName = resp1.data.value[0].YourCompany_DispName;
                    document.title = 'Data Masons EDI - ' + ((window as any).env as IWindow).YourCompany_DispName;
                    // Complete login and resolve any outstanding requests
                    console.log('%clogin done- now resolving all promises', consoleColor.colorAxiosMain);
                    isLoginInProgress = false;
                    isAuthenticated= true;

                    while(promiseResolveArray.length > 0) {
                        const p = promiseResolveArray.shift();
                        console.log('%cresolving ' + p.config.url, consoleColor.colorAxiosMain)
                        p.resolve();
                    }  
                    r(true); // Resolve no problems
                });
        })
        .catch((err) => {
            r(false);
        })
    })
}

export default ApplyAuthenticationBehavior;