import axios from 'axios';
import buildQuery from "odata-query";
import ApplyAuthenticationBehavior from "./axiosBehavior/authentication";
import { IWindow } from '../constants/IWindow';
import { consoleColor, SERVICES } from '../configs/index';
import { axAccessToken, sessWSApiBaseUrl } from '../constants/index';
import { isNullOrUndefined } from 'util';
import { Logout } from '../utils/Logout'

// OData query parameters are only sometimes used, and should not be appended to every call
// This causes problems for other axios calls (post, put, delete) because it interferes with the second parameter being applied to the body
/*
axios.defaults.paramsSerializer = (params):string=>{ 
    const query = buildQuery(params).substring(1); // Strip question mark. Axios adds one already.
    return query;
}
*/

//
// encodeURIComponent doesn't escape asterisks and WebApi doesn't like single tick marks
//   stutter the single quote even through it's escaped
//
export function FixURIComponent(param : string) : string {
    return encodeURIComponent(param).replace(/\*/g,'%2a').replace(/'/g,'%27%27');
}


//
// encodeURIComponent doesn't escape asterisks but React accepts single tick marks
//
export function FixURIComponentReact(param : string) : string {
    return encodeURIComponent(param).replace('*','%2a');
}

// Adding the params serializer back for odata queries
axios.interceptors.request.use( async (config)=> {
    if(config && config.method === "get" && config.url && config.url.indexOf('odata')>-1){
        config.paramsSerializer = (params):string=>{ 
            const query = buildQuery(params).substring(1); // Strip question mark. Axios adds one already.
            return query;
        }
    }
    return config;
}, (error) =>{
    return Promise.reject(error);
});

// if(process.env.NODE_ENV !== 'production') {
    // mockBehavior(axios)
// }

// This Axios instance does not flow through the axios interceptors so only to be used by the axiosBehavior code
export const axiosRoot = axios.create({
    baseURL : ((window as any).env as IWindow).VP4API_URL,
    timeout : ((window as any).env as IWindow).API_TIMEOUT_MINUTES * 60 * 1000,
});

axiosRoot.interceptors.request.use(async (config)=> {
    const curl : string = config.url as string;
    const burl : string = config.baseURL as string;
    if (curl.indexOf(burl) === 0) {
        console.info('%c' + config.method + ": " + config.url, consoleColor.consoleAxiosRoot);
    } else {
        console.info('%c' + config.method + ": " + config.baseURL + config.url, consoleColor.consoleAxiosRoot);
    }
    const oauth = sessionStorage.getItem(axAccessToken);
    if (isNullOrUndefined(oauth)){
        if (config.url !== SERVICES.endpoints.getLoginToken && config.url && config.url.indexOf('Duo') ===-1) {
            console.error('%cMissing OAuth token', consoleColor.consoleError);
            console.log("Logging Out Now");
            Logout();

        }
    } else {
        config.headers.common['Authorization'] = 'Bearer ' + oauth;
        config.withCredentials = true;
    }
    return config;
    
}, 
(error) => {
    console.error('%cHTTP Status ' + error.request.Status, consoleColor.consoleError);
    
    return Promise.reject(error);
});

// This Axios instance points to the Scheduler API
export const axiosSched = axios.create({
    baseURL : ((window as any).env as IWindow).WSAPI_URL,
    // baseURL : ((window as any).env as IWindow).WSAPI_URL + ":" + sessionStorage.getItem(sessWSApiBaseUrl),
    timeout : ((window as any).env as IWindow).API_TIMEOUT_MINUTES * 60 * 1000
});

axiosSched.interceptors.request.use(async (config)=> {
    
    config.baseURL = config.baseURL + ":" + sessionStorage.getItem(sessWSApiBaseUrl);
    console.info('%c' + config.method + ": " + config.baseURL + config.url, consoleColor.consoleAxioSched);

    return config;
}, 
(error) => {
    console.error('%cHTTP Status ' + error.request.Status, consoleColor.consoleError);
    return Promise.reject(error);
});

// Intecept all the Responses and format the error response
axiosSched.interceptors.response.use( (response)=> {
    // Normal response
    return response;
}, 
(error) =>{
    if (error.message === "Network Error") {
        // HTTP 404, 500 or others
        return Promise.reject(new Error(error.config.url + "; " + error.message));
    } else {
        // Some other sort of error
        try
        {
            if (error.response.data.error === undefined) {
                if (error.response.data.Message !== undefined) {
                    return Promise.reject(new Error(error.config.url + "; " + error.response.data.Message));
                }
                else {
                    return Promise.reject(new Error(error.config.url + "; " + error.response.data));
                }
            }
            else {
                try
                {
                    if (error.response.data.error.innererror.message !== undefined) {
                        return Promise.reject(new Error(error.config.url + "; " + error.response.data.error.innererror.message));
                    } else {
                        return Promise.reject(new Error(error.config.url + "; " + error.response.data.error.message));
                    }
                }
                catch {
                    return Promise.reject(error);
                }
            }
        }
        catch {
            return Promise.reject(error);
        }
    }
});



// This Axios instance points to the TLE API
export const axiosTLE = axios.create({
    baseURL : ((window as any).env as IWindow).TLEAPI_URL,
    timeout : ((window as any).env as IWindow).API_TIMEOUT_MINUTES * 60 * 1000
});

axiosTLE.interceptors.request.use(async (config)=> {
    console.info('%c' + config.method + ": " + config.url, consoleColor.consoleAxiosTLE);
    return config;
}, 
(error) => {
    console.error('%cHTTP Status ' + error.request.Status, consoleColor.consoleError);
    return Promise.reject(error);
});

// Intecept all the Responses and format the error response
axiosTLE.interceptors.response.use( (response)=> {
    // Normal response
    return response;
}, 
(error) =>{
    if (error.message === "Network Error") {
        // HTTP 404, 500 or others
        return Promise.reject(new Error(error.config.url + "; " + error.message));
    } else {
        try
        {
            if (error.response.data.error === undefined) {
                if (error.response.data.Message !== undefined) {
                    return Promise.reject(new Error(error.config.url + "; " + error.response.data.Message));
                }
                else {
                    return Promise.reject(new Error(error.config.url + "; " + error.response.data));
                }
            }
            else {
                try
                {
                    if (error.response.data.error.innererror.message !== undefined) {
                        return Promise.reject(new Error(error.config.url + "; " + error.response.data.error.innererror.message));
                    } else {
                        return Promise.reject(new Error(error.config.url + "; " + error.response.data.error.message));
                    }
                }
                catch {
                    return Promise.reject(error);
                }
            }
        }
        catch {
            return Promise.reject(error);
        }
    }
});


ApplyAuthenticationBehavior(axios)

export default axios;