
 export const urlOsn : string = '/OsnListView';
 export const nameOsn : string = 'Menu.OutboundShipNotices';

const iconList = 'fa fa-list';

const sendReceiveMenu =  {   name: 'SendReceive', url: '/config', icon: 'fas fa-cog',
    children: [
        {  
            icon: iconList,
            name: nameOsn,
            
            url: '/documents',
        },
        {
            icon: iconList,
            name: 'Documents Sent',
            url: '/documentsSent',
        },            
        {
            icon: iconList,
            name: 'Documents Received',
            url: '/documentsReceived',
        },
        {
            icon: iconList,
            name: nameOsn,
            url: urlOsn
        },
    ]
};

export default sendReceiveMenu;