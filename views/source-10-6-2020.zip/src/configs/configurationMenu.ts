
 const urlItems : string = '/items';
 const nameItems : string = 'Items';

 const urlItemDetails : string = '/itemDetails';
 const nameItemDetails : string = 'Item Details';

 const urlItemCrossRef : string = '/itemsCrossReferences';
 const nameItemCrossRef : string = 'Item Cross References';

 const urlItemSacRef : string = '/itemSacReferences';
 const nameItemSacRef : string = 'Item SAC References';

 const urlVPNetworks : string = '/vpNetworks';
 const nameVPNetworks : string = 'Networks';

 const urlEdiStandards : string = '/EdiStandards';
 const nameEdiStandards : string = 'EDI Standards';

const iconList = 'fa fa-list';

const configurationMenu = { name : 'Configuration', url : '/config', icon : ' fas fa-cog', 
    children : [
        {
            icon: iconList,
            name: 'Default Transformation Objects',
            url: '/transObjects',
        },
        {
            icon: iconList,
            name: 'Transformation Definitions',
            url: '/tranDefs',
        },
    ]
};

export const systemMenu = {name : 'Values', url : '/config', icon : ' fas fa-cog', 
    children : [
        {
            icon: iconList,
            name: 'Company Settings',
            url: '/companysettings'
        },
    ]
};

export const valuesMenu = { name : 'Values', url : '/config', icon : ' fas fa-cog', 
    children : [
        {
            icon: iconList,
            name: 'Error Codes',
            url: '/errorCodes',
        },
        {
            icon: iconList,
            name: 'Last Numbers',
            url: '/LastNumbers'
        },
    ]
}

export const masterDataMenu =  {   name: 'MasterData',
url: '/config',
icon: 'fas fa-cog',
children: [
{  
    icon: iconList,
    name: 'Carriers',
    url: '/carriers',
},
{  
    icon: iconList,
    name: 'Freight Codes',
    url: '/freightCodes',
},
{  
    icon: iconList,
    name: 'Trading Partners',
    url: '/trades',
},
{
    icon: iconList,
    name: nameVPNetworks,
    url: urlVPNetworks,
},
{
    icon: iconList,
    name: 'Notification History',
    url: '/notifications',
},
{  
    icon: iconList,
    name: 'Ship To Locations',
    url: '/shipTos',
},
{  
    icon: iconList,
    name: 'Document Explorer',
    url: '/documents',
},
{
    icon: iconList,
    name: nameItems,
    url: urlItems
},
{
    icon: iconList,
    name: nameItemCrossRef,
    url: urlItemCrossRef
},
{
    icon: iconList,
    name: nameItemSacRef,
    url: urlItemSacRef
},
{
    icon: iconList,
    name: nameEdiStandards,
    url: urlEdiStandards
},
{
    icon: iconList,
    name: 'Maps',
    url: '/maps'
},
{
    icon: iconList,
    name: 'Error Log',
    url: '/errorLog',
},
{
    icon: iconList,
    name: 'Documents Sent',
    url: '/documentsSent',
},            
{
    icon: iconList,
    name: 'Documents Received',
    url: '/documentsReceived',
},
{
    icon: iconList,
    name: 'Document Load Configurations',
    url: '/docLoadConfig',
},
{
    icon: iconList,
    name: 'Request Routing',
    url: '/requestRouting',
},

// {
//     icon: iconList,
//     name: 'Locations',
//     url: '/locations'
// }
]
};

export default configurationMenu;