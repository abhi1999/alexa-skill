import moment from "moment";
import * as  React from 'react';
import { Badge, Card, CardBody, CardFooter, CardHeader, CardSubtitle, CardTitle, Col, Collapse, Fade, Row } from 'reactstrap';
import { INewsFeedItem } from "./../../domain/DataModel"
import { FormattedDate, FormattedTime } from 'react-intl';

interface INewsFeedItemProps{
    item:INewsFeedItem
    renderInDashboard?:boolean
}
interface INewsFeedItemState{
    collapse:boolean
    fadeIn:boolean
    timeout:number
}
class NewsFeedItem extends React.Component<INewsFeedItemProps, INewsFeedItemState>{
    private momentInstance:any;
    public constructor(props) {
        super(props);
        this.momentInstance = moment;
        this.toggle = this.toggle.bind(this);
        this.toggleFade = this.toggleFade.bind(this);
        this.state = {
          collapse: false,
          fadeIn: true,
          timeout: 300
        };
    }
    public render(){
        let crDate : Date = new Date();
        if(this.props.item && this.props.item.date){
            crDate = new Date(this.props.item.date);
        }
        const content=
              <Card className="news-feed-list-item">
                <CardTitle> 
                    {this.props.item.title}
                    <div className="card-header-actions">
                    <a className="card-header-action btn btn-minimize" data-target="#collapseExample" onClick={this.toggle}><i className={this.state.collapse?"icon-arrow-up":"icon-arrow-down"}/></a>
                    <a className="card-header-action btn btn-minimize" onClick={()=>{window.open(this.props.item.guid)}}><i className="icon-action-redo" title="View Post"/></a>
                  </div>
                </CardTitle>
                {/* <CardSubtitle> <small className="text-muted">{createdAt}</small></CardSubtitle> */}
                <CardSubtitle>
                  <small className="text-muted">
                      <FormattedDate value={crDate} day="numeric" month="short" year="numeric" />&nbsp;
                      <FormattedTime value={crDate}  />
                  </small></CardSubtitle>
                <Collapse isOpen={this.state.collapse} id="collapseExample">
                  <CardBody>
                    <div dangerouslySetInnerHTML={{ __html: this.props.item.contentEncoded }} />
                   </CardBody>
                  {/* <CardFooter>
                      <small className="text-muted">Categories: {this.props.item.categories.join(';')}</small>
                  </CardFooter> */}
                </Collapse>
              </Card>
       if(this.props.renderInDashboard){
         return content;
       }
       else{
        return <Fade timeout={this.state.timeout} in={this.state.fadeIn}>
                {content}
              </Fade> 
       }
       
    }
    private toggle() {
        this.setState({ collapse: !this.state.collapse });
    }
    
    private toggleFade() {
        this.setState( {fadeIn: !this.state.fadeIn });
    }
}

export default NewsFeedItem;
