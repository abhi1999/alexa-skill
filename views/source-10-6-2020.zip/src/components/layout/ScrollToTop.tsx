import * as React from 'react';
import {withRouter} from "react-router-dom";
import {  animateScroll as scroll } from 'react-scroll';

interface IScrollToTopProps{
    location:any
}
class ScrollToTop extends React.Component<IScrollToTopProps> {
    public componentDidUpdate(prevProps) {
      if (this.props.location !== prevProps.location) {
        scroll.scrollToTop();
        // window.scrollTo(0, 0)
      }
    }
  
    public render() {
      return this.props.children
    }
  }
  
  export default withRouter(ScrollToTop)
  