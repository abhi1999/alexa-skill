import { AppAside, AppBreadcrumb, AppFooter, AppHeader, AppSidebar, AppSidebarHeader, AppSidebarMinimizer, AppSidebarNav, } from '@coreui/react';
import { withRouter } from "react-router";
import uuid from 'uuid-v4';
import { cloneDeep } from 'lodash';
import classnames from "classnames"
import * as React from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import { Container, Input } from 'reactstrap';
import Header from "./Header";
import { injectIntl, intlShape } from 'react-intl';
import BusinessProcessFlowView from '../../views/scheduler/businessProcessFlow';
import * as MenuInfo from '../../reducers/businessFlowReducer';
import { menuConfigGetUserMenuGroupsFailure } from '../../actions/MenuConfigAction';
import appRoutes from './../../configs/appRoutes';
import { sessCompanyID } from '../../constants/index';

interface IDefaultLayoutProps {
  reload: () => void,
  dbUpdateNeeded: boolean,
  noCompanyTable: boolean,
  forceCompanyModal: boolean,
  navItems: any[]
  intl: intlShape.isRequired,
  settings: any
}
interface IDefaultLayoutState {
  asideMenuType?: string
  randomKey?: string
  navbarKey?: string
  navItemSearchText?: string
  navItems: any[],
  isSearchFocused: boolean,
  routes: any[],
  availableCompanies: any[],

}


// const setIntlName = (item, intl, textProp, intlId) => {
//   if (intl && intl.formatMessage && item[intlId]) {
//     item[textProp] = intl.formatMessage({ id: item[intlId] })

//     if (item.intlId === 'Menu.ExceptionReportName.PostingLog') {

//       item["attributes"] = {disabled:true} 

//     }
//   }
//   if (item.children && item.children.length > 0) {
//     item.children.forEach(c => setIntlName(c, intl, textProp, intlId))
//   }
// }

let searchMenuPlaceHolder: string;

class DefaultLayout extends React.Component<IDefaultLayoutProps, IDefaultLayoutState> {
  private privateAppSideBarNav: any;
  private onChangeTimeout: any
  public constructor(props) {
    super(props);
    this.state = {
      asideMenuType: '1', randomKey: uuid(), navItems: this.getNavItemsFromProps(this.props), navbarKey: 'navbarKey', navItemSearchText: '', isSearchFocused: false,
      routes: this.getRoutes(props), availableCompanies: []
    }

    this.isMenuDisabled = this.isMenuDisabled.bind(this);

    this.privateAppSideBarNav = AppSidebarNav;
    const ref = this.privateAppSideBarNav.prototype.handleClick;
    // Localize the search placeholder
    searchMenuPlaceHolder = props.intl.formatMessage({ id: 'Global.SearchMenu' });

    // Hooks in place to auto scroll if we expand the last node in the menu
    // this.privateAppSideBarNav.prototype.handleClick =(e)=>{ console.log('need to scroll to'); ref(e);}
  }
  /*  public componentDidMount(){
      if(!document.body.classList.contains("sidebar-minimized")){   
        document.body.classList.add("sidebar-minimized")
      };  
    }*/
  public componentWillReceiveProps(nextProps) {
    if (nextProps.settings !== undefined && this.props.settings !== undefined) {

      if (nextProps.settings.locale !== this.props.settings.locale || nextProps.settings.selectedCompany !== this.props.settings.selectedCompany) {
        this.setState({ randomKey: uuid(), navItems: this.getNavItemsFromProps(nextProps) })
      }
    }

    if (nextProps.navItems !== this.props.navItems) {
      this.setState({ navItems: this.getNavItemsFromProps(nextProps) })
    }

    // mar - 12/10/2019 need to get company list to determine whether or not to disable Post Log Report (Macola) menu option    
    if (nextProps.settings.availableCompanies !== this.state.availableCompanies) {
      this.setState({
        availableCompanies: nextProps.settings.availableCompanies,
      })
    }

    this.setState({ routes: this.getRoutes(nextProps) })
  }

  public componentDidUpdate(prevProps, prevState) {
    // mar - 12/10/2019 Post Log Report (Macola) is disabled if not using Macola ERP - which is based on availableCompanies list
    // list is initially empty until after login so need to redraw menus after if loads 
    if (prevState.availableCompanies !== this.state.availableCompanies) {
      this.setState({
        navItems: this.getNavItemsFromProps(prevProps)
      })
    }
  }

  public getRoutes = (props) => {
    const companyName = props.settings && props.settings.selectedCompany ? props.settings.selectedCompany : "Home";

    const formatIntlMessage = props.intl ? props.intl.formatMessage : (val) => val.id;

    const routes: any[] = cloneDeep(appRoutes);
    routes.push({ path: '/', exact: true, name: companyName })

    routes.forEach(r => {
      if (r.intlId) {
        r.name = formatIntlMessage({ id: r.intlId })
      }
    })
    return routes;
  }



  public render() {

    const { routes } = this.state;
    // See if database is out of date or we need to force the user to the Company screen
    let firstPage: JSX.Element = <Redirect from="/" to="/Dashboard" />
    if (this.props.dbUpdateNeeded || this.props.forceCompanyModal) {
      const nocomp: string = this.props.noCompanyTable ? 'true' : 'false';
      const fcm: string = this.props.forceCompanyModal ? 'true' : 'false';
      const dbUpd: string = this.props.dbUpdateNeeded ? 'true' : 'false';
      firstPage = <Redirect from="/" to={MenuInfo.urlCompany + '?dbup=' + dbUpd + '&nocomp=' + nocomp + '&fcm=' + fcm} />
    }

    return (
      <div className="app">
        <AppHeader fixed={true}>
          <Header asideMenuChange={this.setAsideMenuType} {...this.props} routes={routes} />
        </AppHeader>
        <div className="app-body">
          <AppSidebar fixed={true} display="lg">
            <div className={classnames("slideout-search-container", { "focus-within": this.state.isSearchFocused })}>
              <i className="fas fa-search" aria-hidden="true" />
              <Input autoComplete={"off"} onFocus={() => this.setState({ isSearchFocused: true })}
                onBlur={() => this.setState({ isSearchFocused: false })} type="search"
                className={classnames("slideout-search", { "has-content": this.state.navItemSearchText && this.state.navItemSearchText.length > 0 })}
                name="menuFilter" placeholder={searchMenuPlaceHolder}
                onChange={(e) => {
                  const navItemSearchText = e.target.value
                  if (this.onChangeTimeout) { clearTimeout(this.onChangeTimeout) }
                  this.onChangeTimeout = setTimeout(() => this.setState({ navItemSearchText }), 200);
                }}
                disabled={false} />
            </div>
            <this.privateAppSideBarNav key={this.state.navbarKey} navConfig={{ items: this.getNavItemsForMenu() }} location={window.location} />
            <AppSidebarMinimizer />
          </AppSidebar>
          <main className="main">
            <AppBreadcrumb key={this.state.randomKey} appRoutes={routes} />
            <Container fluid={true} className="content-panel">
              <Switch >
                {routes.map((route: any, idx) => {
                  return route.component ? (<Route key={idx} path={route.path} exact={route.exact} name={route.name} render={props => (
                    <route.component {...props} intl={this.props.intl} />
                  )} />)
                    : (null);
                },
                )}
                {/* <Route path='/JsonEdit' render={(props) => (
                  <JsonEditView />
                )} /> */}
                {firstPage}
              </Switch>
            </Container>
          </main>
          {/* <AppAside fixed={true} hidden={true}>
            {this.getAsideMenu()}
          </AppAside> */}
        </div>
      </div>
    );
  }

  private setIntlName = (item, intl, textProp, intlId) => {
    if (intl && intl.formatMessage && item[intlId]) {
      item[textProp] = intl.formatMessage({ id: item[intlId] })
      item["attributes"] = { disabled: this.isMenuDisabled(item.intlId) }
    }
    if (item.children && item.children.length > 0) {
      item.children.forEach(c => this.setIntlName(c, intl, textProp, intlId))
    }
  }

  private isMenuDisabled(name: string) {

    // check for state (possibly undefined during initial login)

    // default is menu enabled
    let menuDisabled:boolean = false;

    if (this.state) {

      switch (name) {

        case 'Menu.HTMLReportName.PostingLog':
          // disabled unless using Macola erp
          const { availableCompanies } = this.state;
          const company = sessionStorage.getItem(sessCompanyID);
          if (company) {
            const erp = availableCompanies.find(c => c.Company_ID === +company)

            if (erp) {
              switch (erp.AcctPackageID) {
                case 'MAC10':
                case 'MES40':
                case 'MSQL70':
                  menuDisabled = false;
                  break;
                default:
                  menuDisabled = true;
              }

            }
          }
      }
    }
      return menuDisabled;
  }
  
  private getNavItemsFromProps = (props) => {
    const { navItems } = props
    navItems.forEach(i => this.setIntlName(i, props.intl, "name", "intlId"));
    return navItems;
  }

  private getNavItemsForMenu = () => {
    const { navItems, navItemSearchText } = this.state;
    const regex = new RegExp(navItemSearchText ? navItemSearchText : "", 'i');

    const getNestedItem = (parent) => {
      return parent.children.filter(c =>
        (c.children === undefined && c.name.match(regex) !== null)
        || (c.children !== undefined && c.children.length > 0 && getNestedItem(c).length > 0)
      )
    }
    const itemsToReturn: any[] = []
    // return navItems.filter(i=> (i.children!== undefined && i.children.length> 0 && getNestedItem(i).length> 0) || i.name.match(regex) !== null)
    navItems.forEach(i => {
      if ((i.children === undefined && i.name.match(regex) !== null)) {
        itemsToReturn.push(i);
      }
      if ((i.children !== undefined && i.children.length > 0)) {
        const nestedItemMatch = getNestedItem(i);
        if (nestedItemMatch.length > 0) {
          const cloneItem = cloneDeep(i);
          cloneItem.children = nestedItemMatch;
          itemsToReturn.push(cloneItem);
        }
      }
    })

    return itemsToReturn;
  }
  private setAsideMenuType = (asideMenuType) => {
    this.setState({ asideMenuType })
  }
  // private getAsideMenu = () => {
  //   switch (this.state && this.state.asideMenuType ? this.state.asideMenuType : "1") {
  //     case "1":
  //       return <AsideMenu1 />
  //     case "2":
  //       return <AsideMenu2 />
  //     case "3":
  //       return <AsideMenu3 />
  //     case "4":
  //       return <AsideMenu4 />
  //     case "5":
  //       return <AsideMenu5 />
  //     default:
  //       return <AsideMenu1 />
  //   }
  // }
}

const DefaultLayoutWithIntl = injectIntl(DefaultLayout);
export default withRouter(DefaultLayoutWithIntl)

