import * as React from 'react';
import classNames from 'classnames';
import {Nav, NavLink, NavItem, TabContent, TabPane} from 'reactstrap';
import configurationMenu from "./../../configs/configurationMenu";
import { AppAsideToggler, AppHeaderDropdown, AppNavbarBrand, AppSidebarMinimizer, AppSidebarToggler } from '@coreui/react';
interface IAsideMenuState {
    activeTab:string
}

//
// Import
//
//

export default class AsideMenu extends React.Component<any, IAsideMenuState> {
    public constructor (props){
        super(props)
        this.state ={activeTab:'1'}
    }
    public render(){
        return <React.Fragment>
             <Nav tabs={true}>
                <NavItem>
                    <NavLink className={classNames({ active: this.state.activeTab === '1' })}
                            onClick={() => {
                            this.toggle('1');
                            }}>
                        <i className="icon-settings"/>
                    </NavLink>
                </NavItem>
                <NavItem>
                    <NavLink className={classNames({ active: this.state.activeTab === '2' })}
                            onClick={() => {
                            this.toggle('2');
                            }}>
                        <i className="icon-settings"/>
                    </NavLink>
                </NavItem>
                <NavItem>
                    <NavLink className={classNames({ active: this.state.activeTab === '3' })}
                            onClick={() => {
                            this.toggle('3');
                            }}>
                        <i className="icon-settings"/>
                    </NavLink>
                </NavItem>
                <NavItem>
                    <NavLink className={classNames({ active: this.state.activeTab === '4' })}
                            onClick={() => {
                            this.toggle('4');
                            }}>
                        <i className="icon-settings"/>
                    </NavLink>
                </NavItem>
                <NavItem>
                    <NavLink className={classNames({ active: this.state.activeTab === '5' })}
                            onClick={() => {
                            this.toggle('5');
                            }}>
                        <i className="icon-settings"/>
                    </NavLink>
                </NavItem>
            </Nav>
            <TabContent activeTab={this.state.activeTab}>
                <TabPane tabId="1">
                    <Nav vertical={true}>
                    {configurationMenu.children.map((path:any, idx) => {
                        return <NavLink key={idx} href={"#"+path.url} onClick={()=>document.body.classList.toggle('aside-menu-lg-show')}>{path.name}</NavLink>;
                    })}
                    </Nav>
                </TabPane>
                <TabPane tabId="2">Placeholder for second tab</TabPane>
                <TabPane tabId="3">Placeholder for third tab</TabPane>
                <TabPane tabId="4">Placeholder for fourth tab</TabPane>
                <TabPane tabId="5">Placeholder for fifth tab</TabPane>
            </TabContent>
        </React.Fragment>
    }

    
  private toggle=(tab)=> {
    if (this.state.activeTab !== tab) {
      this.setState({
        activeTab: tab,
      });
    }
  }
}