import AsideMenu1 from "./AsideMenu1";
import AsideMenu2 from "./AsideMenu2";
import AsideMenu3 from "./AsideMenu3";
import AsideMenu4 from "./AsideMenu4";
import AsideMenu5 from "./AsideMenu5";

export {AsideMenu1, AsideMenu2, AsideMenu3, AsideMenu4, AsideMenu5}