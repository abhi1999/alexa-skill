import * as React from 'react';
import {NavLink, Tooltip} from 'reactstrap';
import { FormattedMessage } from 'react-intl';

interface IToolTipNavLinkState{
    tooltipOpen:boolean,
    randomId:string
}

export default class ToolTipNavLink extends React.Component<any,IToolTipNavLinkState> {
    public constructor (props){
        super(props);
        this.state ={tooltipOpen:false,randomId:"someId-" + ((Math.random()*100).toString()) +'-tooltip'}
    }
    public render(){
        const { toolTipTarget,toolTip, children,  ...rest } = this.props;
        return <React.Fragment>
            <NavLink id={toolTip.replace(/[^a-zA-Z0-9 ]/g, "")} {...rest}>{children}</NavLink>
            <Tooltip placement="bottom" isOpen={this.state.tooltipOpen} target={toolTipTarget? toolTipTarget:toolTip.replace(/[^a-zA-Z0-9 ]/g, "")} toggle={this.toggle}>
                <FormattedMessage id={toolTip} />
            </Tooltip>
        </React.Fragment>
    }
    private toggle =() =>{
        this.setState({tooltipOpen:!this.state.tooltipOpen})
    }
}