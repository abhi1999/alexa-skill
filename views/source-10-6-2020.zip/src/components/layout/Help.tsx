import * as React from 'react';
import { connect } from 'react-redux'
import { axiosSched } from '../../configs/axios'
import { ShowHelp, ShowCustomerPortal } from '../../utils/index';
import { sessCompanyID } from '../../constants/index';
import ToolTipNavLink from "./ToolTipNavLink";
import { NotifyInfo, NotifyError, NotifySuccess, NotifyWarning } from "../../actions/Notification";
import * as MenuInfo from '../../reducers/businessFlowReducer';
import { forEach } from 'lodash';
import { FormattedMessage } from 'react-intl';
import { AppHeaderDropdown, AppNavbarBrand, AppSidebarToggler } from '@coreui/react';
import { Form, FormGroup, Label, Col, Input, Row, FormFeedback } from 'reactstrap';
import { Modal, ModalHeader, ModalBody, ModalFooter, DropdownToggle, DropdownMenu, Button, ListGroupItem, DropdownItem } from 'reactstrap';
import PageBtnContainer from './../widgets/PageBtnContainer';
import { IWindow } from '../../constants/IWindow';
import { IVersionInfo } from '../../constants/IVersionInfo'
import { AnySrvRecord } from 'dns';
import LoadingComponent from "../../components/widgets/LoadingComponent";
import { lsAlertsChartPresetKey, lsDashboardLayoutKey, lsChartThemeKey } from "./../../constants"
import * as busFlowReducer from "../../reducers/businessFlowReducer";

interface IMapHelp {
    route: string,
    url: string
}

const mapHelp: IMapHelp[] = [
    // settings

    { route: MenuInfo.urlItemDetailsEdit, url: 'Items.htm' },
    { route: MenuInfo.urlCarriers, url: 'Carriers.htm' },
    { route: MenuInfo.urlCarrierDetailsEdit, url: 'Carriers.htm' },
    { route: MenuInfo.urlCarrierDetailsAdd, url: 'Carriers.htm' },
    { route: MenuInfo.urlCarbonCopy, url: 'Carbon_Copy.htm' },
    { route: MenuInfo.urlCompany, url: 'Company.htm' },
    { route: MenuInfo.urlFreightCodes, url: 'Freight_Codes.htm' },
    { route: MenuInfo.urlFreightCodeDetailsAdd, url: 'Freight_Codes.htm' },
    { route: MenuInfo.urlFreightCodeDetailsEdit, url: 'Freight_Codes.htm' },
    { route: MenuInfo.urlItems, url: 'Items.htm' },
    { route: MenuInfo.urlItemCrossRefList, url: 'Item_Cross_References.htm' },
    { route: MenuInfo.urlItemCrossRefEdit, url: 'Item_Cross_References.htm' },
    { route: MenuInfo.urlRequestRouting, url: 'Request_Routing.htm' },
    { route: MenuInfo.urlRouteInstr, url: 'Routing_Instructions.htm' },
    { route: MenuInfo.urlShipTo, url: 'Ship_To_Locations.htm' },
    { route: MenuInfo.urlShipToAdd, url: 'Ship_To_Locations.htm' },
    { route: MenuInfo.urlShipToEdit, url: 'Ship_To_Locations.htm' },
    { route: MenuInfo.urlTrades, url: 'Trading_Partners.htm' },
    { route: MenuInfo.urlTradeEdit, url: 'Trading_Partners.htm' },
    { route: MenuInfo.urlTradeEditView, url: 'Trading_Partners.htm' },
    { route: MenuInfo.urlTradeClone, url: 'Trading_Partners.htm' },
    { route: MenuInfo.urlTradeEditView, url: 'Trading_Partners.htm' },

    { route: MenuInfo.urlVPNetworkDetailEdit, url: "Networks.htm" },
    { route: MenuInfo.urlVPNetworkDetailAdd, url: "Networks.htm" },
    { route: MenuInfo.urlVPNetworks, url: "Networks.htm" },
    { route: MenuInfo.urlTransObjects, url: "Default_Transformation_Objects.htm" },
    { route: MenuInfo.urlTransObjectEdit, url: "Default_Transformation_Objects.htm" },
    { route: MenuInfo.urlTranDefs, url: "Transformation_Definitions.htm" },
    { route: MenuInfo.urlTransDefAdd, url: "Transformation_Definitions.htm" },
    { route: MenuInfo.urlTransDefEdit, url: "Transformation_Definitions.htm" },
    { route: MenuInfo.urlDocLoadConfig, url: "Document_Load_Configurations.htm" },
    { route: MenuInfo.urlDocLoadConfigDetailsAdd, url: "Document_Load_Configurations.htm" },
    { route: MenuInfo.urlDocLoadConfigDetailsEdit, url: "Document_Load_Configurations.htm" },
    { route: MenuInfo.urlControlNum, url: 'Control_Numbers.htm' },
    { route: MenuInfo.urlTaxCode, url: 'Tax_Table.htm' },
    { route: MenuInfo.urlTaxCodeAdd, url: 'Tax_Table.htm' },
    { route: MenuInfo.urlTaxCodeEdit, url: 'Tax_Table.htm' },
    { route: MenuInfo.urlCumulativeQty, url: 'Cumulative_Quantities.htm' },
    { route: MenuInfo.urlCumulativeQtyAdd, url: 'Cumulative_Quantities.htm' },
    { route: MenuInfo.urlCumulativeQtyAddTPPartID, url: 'Cumulative_Quantities.htm' },
    { route: MenuInfo.urlCumulativeQtyDetail, url: 'Cumulative_Quantities.htm' },
    { route: MenuInfo.urlCumulativeQtyEdit, url: 'Cumulative_Quantities.htm' },
    { route: MenuInfo.urlProcessTrigger, url: 'Application_Triggers.htm' },
    { route: MenuInfo.urlEdiStandards, url: 'EDI_Standards.htm' },
    { route: MenuInfo.urlConfigRecords, url: 'Configuration_Records.htm' },
    { route: MenuInfo.urlEditConfigRecord, url: 'Configuration_Records.htm' },
    { route: MenuInfo.urlDataTransport, url: 'Data_Transport.htm' },
    { route: MenuInfo.urlErrorCodes, url: 'Error_Codes.htm' },
    { route: MenuInfo.urlItemCrossRefListMenu, url: 'Item_Cross_References.htm' },
    { route: MenuInfo.urlItemDetails, url: 'Items.htm' },
    { route: MenuInfo.urlItemDetailsAdd, url: 'Items.htm' },
    { route: MenuInfo.urlLastNumbers, url: 'Last_Numbers.htm' },
    { route: MenuInfo.urlLocation, url: 'Locations.htm' },
    { route: MenuInfo.urlItemSacRefList, url: 'SAC_Cross_References.htm' },
    { route: MenuInfo.urlItemSacRefListMenu, url: 'SAC_Cross_References.htm' },
    { route: MenuInfo.urlItemSacRefAdd, url: 'SAC_Cross_References.htm' },
    { route: MenuInfo.urlMaps, url: 'Documents_and_Maps.htm' },
    { route: MenuInfo.urlMapEdit, url: 'Documents_and_Maps.htm' },
    { route: MenuInfo.urlPackage, url: 'Packages.htm' },
    { route: MenuInfo.urlPackageDetailsAdd, url: 'Packages.htm' },
    { route: MenuInfo.urlPackageDetailsEdit, url: 'Packages.htm' },
    // KB: 07/02/2020 - Removed new Trade Maps feature for now per Debbie's request
    // { route: MenuInfo.urlTradeMaps, url: 'Documents_and_Maps.htm' },

    // send / receive

    { route: MenuInfo.urlAdvanced, url: 'Advanced_Transformations.htm' },
    { route: MenuInfo.urlDocExp, url: 'Document_Explorer.htm' },
    { route: MenuInfo.urlDocExpAlert, url: 'Document_Explorer.htm' },
    { route: MenuInfo.urlDocExpRejected, url: 'Document_Explorer.htm' },
    { route: MenuInfo.urlDocExpVPID, url: 'Document_Explorer.htm' },
    { route: MenuInfo.urlDocExpEdit, url: 'Document_Explorer.htm' },
    { route: MenuInfo.urlDocumentsReceived, url: 'Documents_Received.htm' },
    { route: MenuInfo.urlDocumentsSent, url: 'Documents_Sent.htm' },
    { route: MenuInfo.urlFromERP, url: 'Receive_from_ERP.htm' },
    { route: MenuInfo.urlToERP, url: 'Send_to_ERP.htm' },
    { route: MenuInfo.urlC303v850h, url: 'Inbound_Purchase_Orders.htm' },
    { route: MenuInfo.urlC303v850hEdit, url: 'Purchase_Order_Details.htm' },
    { route: MenuInfo.urlOsn, url: 'Outbound_Shipment_Notices.htm' },
    { route: MenuInfo.urlOsnById, url: 'Outbound_Shipment_Notices.htm' },
    { route: MenuInfo.urlOsnDetails, url: 'Outbound_Shipment_Notices.htm' },
    { route: MenuInfo.urlOsnDetailsOld, url: 'Outbound_Shipment_Notices.htm' },
    { route: MenuInfo.urlPlanningSched, url: 'Planning_Schedule.htm' },
    { route: MenuInfo.urlProdSequence, url: 'Production_Sequence_Processor.htm' },

    { route: MenuInfo.urlToTradingPartners, url: 'Send_to_Trading_Partners.htm' },

    // utilities

    { route: MenuInfo.urlConsolidateInvoice, url: 'Consolidate_Invoices.htm' },
    { route: MenuInfo.urlConsolidateOSR, url: 'Consolidate_Order_Status_Reports.htm' },
    { route: MenuInfo.urlCustomizeTerms, url: 'Customize_Terms.htm' },
    { route: MenuInfo.urlMenuConfig, url: 'Menu_Layout.htm' },
    { route: MenuInfo.urlBPFormTasks, url: 'Manage_Forms.htm' },
    { route: MenuInfo.urlTradeMaintenance, url: 'Trading_Partner_Maintenance.htm' },
    { route: MenuInfo.urlEditUserLabels, url: 'User_Field_Labels.htm' },
    { route: MenuInfo.urlCompanyCopy, url: 'Setup_New_Company.htm' },
    { route: MenuInfo.urlRoleAdmin, url: 'User_Role_Administration.htm' },

    // reports
    { route: MenuInfo.urlAuditViewer, url: 'Audit_Tracking.htm' },
    { route: MenuInfo.urlErrorLog, url: 'Error_Log.htm' },

    { route: MenuInfo.urlExceptionReportInboundAsn, url: 'Exception_Reports.htm' },
    { route: MenuInfo.urlExceptionReportFunctionAck, url: 'Exception_Reports.htm' },
    { route: MenuInfo.urlExceptionReportInboundInvoice, url: 'Exception_Reports.htm' },
    { route: MenuInfo.urlExceptionReportSalesOrder, url: 'Exception_Reports.htm' },
    { route: MenuInfo.urlExceptionReportDocHold, url: 'Exception_Reports.htm' },
    { route: MenuInfo.urlExceptionReportOutboundASN, url: 'Exception_Reports.htm' },
    { route: MenuInfo.urlExceptionReportOutboundInvoice, url: 'Exception_Reports.htm' },
    { route: MenuInfo.urlExceptionReportPurchaseOrder, url: 'Exception_Reports.htm' },
    { route: MenuInfo.urlExceptionReportPurchaseOrderAck, url: 'Exception_Reports.htm' },
    { route: MenuInfo.urlExceptionReportOutboundReturnMerchandiseAuthorization, url: 'Exception_Reports.htm' },
    { route: MenuInfo.urlExceptionReportWarehouseShippingOrder, url: 'Exception_Reports.htm' },
    { route: MenuInfo.urlExceptionReportOutboundLogisticsServiceRequest, url: 'Exception_Reports.htm' },
    { route: MenuInfo.urlExceptionReportInboundLogisticsServiceResponse, url: 'Exception_Reports.htm' },
    { route: MenuInfo.urlExceptionReportInboundCarrierShipmentStatus, url: 'Exception_Reports.htm' },

    { route: MenuInfo.urlHTMLReportCustomerPO, url: 'Customer_Purchase_Orders.htm' },
    { route: MenuInfo.urlHTMLReportISAControlLog, url: 'ISA_Control_Log.htm' },
    { route: MenuInfo.urlHTMLReportItemList, url: 'Item_List_Report.htm' },
    { route: MenuInfo.urlHTMLReportShipToList, url: 'Ship_to_List.htm' },
    { route: MenuInfo.urlHTMLReportTradingPartnerList, url: 'Trading_Partner_List.htm' },
    { route: MenuInfo.urlHTMLReportPartnerItemList, url: 'Partner_Item_List_Report.htm' },
    { route: MenuInfo.urlHTMLReportPOChangeLog, url: 'Purchase_Order_Change_Log.htm' },
    { route: MenuInfo.urlHTMLReportProductActivity, url: 'Product_Activity.htm' },
    { route: MenuInfo.urlHTMLReportShipments, url: 'Shipments.htm' },

    // import

    { route: MenuInfo.urlImport, url: 'Import.htm' },

    // scheduler

    { route: '/status', url: 'Status_Scheduler.htm' },
    { route: MenuInfo.urlWorkflows, url: 'Workflows.htm' },
    { route: MenuInfo.urlTasks, url: 'Tasks.htm' },
    { route: MenuInfo.urlSchedules, url: 'Schedules.htm' },
    { route: MenuInfo.urlNetworks, url: 'Networks_Scheduler.htm' },
    { route: MenuInfo.urlDatabases, url: 'Databases.htm' },
    { route: MenuInfo.urlFolders, url: 'Folders.htm' },
    { route: MenuInfo.urlVariables, url: 'Variables.htm' },

    // favorites
    { route: '/businessProcess/1001', url: 'Favorites.htm' },

    // quote to cash
    { route: '/businessProcess/1002', url: 'Quote_to_Cash.htm' },

    // procure to pay
    { route: '/businessProcess/1003', url: 'Procure_to_Pay.htm' },

    // logistics
    { route: '/businessProcess/1004', url: 'Logistics_Transportation.htm' },

    // automotive
    { route: '/businessProcess/1005', url: 'Automotive_Planning.htm' },

    // product management
    { route: '/businessProcess/1006', url: 'Product_Management.htm' },

    // pack & ship
    { route: MenuInfo.urlPackAndShipSelectOrders, url: 'Order_Selection.htm' },
    { route: MenuInfo.urlPackAndShip, url: 'Pack_Orders.htm' },
    { route: MenuInfo.urlPackAndShipShipmentList, url: 'Shipment_List.htm' },
    { route: MenuInfo.urlPackAndShipShipment, url: 'Ship_Orders.htm' },
    { route: MenuInfo.urlPackAndShipMultiLevel, url: 'Multi_Level_Packing.htm' }, // 'Multi_Level_Pack.htm' },
    { route: MenuInfo.urlPackAndShipEditOrder, url: 'View_And_Edit_Orders.htm' },

];

interface IHelpProps {
    routes: any[]
    location: any,
    showText?: boolean,
    settings: any,
    NotifyError: (any) => void,
}

interface IHelpState {
    modalState: boolean,
    versionInfo: any,
    fetchingVersionInfo: boolean
}
// export default class Help extends React.Component<IHelpProps, IHelpState> {
class Help extends React.Component<IHelpProps, IHelpState> {
    public constructor(props) {
        super(props);
        this.state = {
            modalState: false,
            versionInfo: '',
            fetchingVersionInfo: false
        };
    }

    public componentDidMount() {
        // MAR - Need to wait until setting session variable sessWSApiBaseUrl before making getVersionInfo call (sets the poper scheduler port)
        // this.getVersionInfo();
    }

    public render() {
        const { children, showText, ...rest } = this.props;

        if (this.state.fetchingVersionInfo) {
            return <LoadingComponent />
        }

        // const thisCompanyId = sessionStorage.getItem(sessCompanyID);
        // let dbVer = "";

        // // console.log("thisCompanyID", thisCompanyId);
        // if (thisCompanyId) {
        //   // Company_ID int
        //   const thisCompany = this.props.settings.availableCompanies.find(c => c.Company_ID === +thisCompanyId);
        //   if (thisCompany) {
        //     dbVer = thisCompany.dbver;
        //   }
        // }

        return (<React.Fragment>
            {showText ? this.renderForSmallView() : this.renderDropdown()}
            <Modal isOpen={this.state.modalState} autoFocus={false} toggle={this.toggleModal}>
                <ModalHeader toggle={this.toggleModal}><FormattedMessage id='Global.Action_About' /></ModalHeader>
                <ModalBody className="no-lp">

                    <Row noGutters={true}>
                        <Col lg={12} md={12} sm={12}>
                            <img src='../../assets/images/datamasons-logo.gif' width="155px" height="35px" alt="DMS Logo" /> <Label className="version-number">V.{((window as any).env as IWindow).VERSION}</Label>
                        </Col>
                    </Row>
                    <Form>
                        <Row noGutters={true}>
                            <Col lg={6} md={6} sm={6}>
                                <Label>swWorkflowService.exe</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).serviceExeVer}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>swTaskMsg.exe</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).taskmsgExeVer}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>vpConnect.exe</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).vpConnect}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>ax7Conn.exe</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).ax7conn}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>swToolkitC.dll</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).toolkitLibVer}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>swWorkflowLibraryC.dll</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).workflowLibVer}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>dms.Transformation_Library.dll</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).transformLibVer}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>DMS.WebApi.Client.dll</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).webApiClientLibVer}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>DMS.EDI.Domain.dll</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).ediDomainLibVer}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>DMS.EDI.Shared.dll</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).ediSharedLibVer}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>EdiDb.dll</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).ediDBLibVer}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>WorkflowScheduler_WebAPI.dll</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).apiLibVer}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>WorkflowScheduler_Data.dll</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).dataLibVer}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>TLEApi.dll</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).tleApi}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>TLEUI.dll</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).tleUI}</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>VP4C_Api.dll</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{(this.state.versionInfo as IVersionInfo).vp4cApi}</Label>
                            </Col>
                            {/* <Col lg={6} md={6} sm={6}>
                                <Label>Database</Label>
                            </Col>
                            <Col lg={6} md={6} sm={6}>
                                <Label>{dbVer}</Label>
                            </Col> */}
                        </Row>
                    </Form>
                </ModalBody>
                <PageBtnContainer className="no-border btn-center" onKeyDown={this.handleKeyDown}>
                    <Button id='ok' color="primary" onClick={this.modalClose}><FormattedMessage id='Global.Action_OK' /></Button>{' '}
                </PageBtnContainer>
                <ModalFooter>
                    All Rights Reserved {'\u00A9'}{new Date().getFullYear().toString()} Data Masons Software, LLC
                </ModalFooter>

            </Modal>
        </React.Fragment>)

    }
    private handleKeyDown(event) {
        if (event.key === 'Escape') { this.modalClose() };
    }
    private modalClose = () => {
        this.setState({ modalState: false })
    }
    private toggleModal = () => {
        // debugger;
        // MAR - Need to get version info after setting session variable sessWSApiBaseUrl 
        if (!this.state.modalState) {
            this.getVersionInfo();
        }
        this.setState({ modalState: !this.state.modalState })
    }
    private showCustomerPortal = () => {
        ShowCustomerPortal();
    }
    private renderForSmallView = () => {
        return <React.Fragment>
            <DropdownItem><div onClick={() => this.showHelp()}><FormattedMessage id='Global.Action_Help' /></div> </DropdownItem>
            <DropdownItem><div onClick={() => this.toggleModal()}><FormattedMessage id='Global.Action_About' /></div> </DropdownItem>
            <DropdownItem><div onClick={() => this.showCustomerPortal()}><FormattedMessage id='Global.Action_Customer_Portal' /></div> </DropdownItem>
            <DropdownItem onClick={() => this.resetDashboardLayout()}>
                <span><FormattedMessage id='Global.Action_Reset_Dashboard' /></span>
            </DropdownItem>
        </React.Fragment>
    }
    private renderDropdown = () => {
        return <AppHeaderDropdown direction="down">
            <DropdownToggle nav={true}>
                <i className="fas fa-question" />
            </DropdownToggle>
            <DropdownMenu >
                <DropdownItem onClick={() => this.showHelp()}>
                    <span><FormattedMessage id='Global.Action_Help' /></span>
                </DropdownItem>
                <DropdownItem onClick={() => this.toggleModal()}>
                    <span><FormattedMessage id='Global.Action_About' /></span>
                </DropdownItem>
                <DropdownItem onClick={() => this.showCustomerPortal()}>
                    <span><FormattedMessage id='Global.Action_Customer_Portal' /></span>
                </DropdownItem>
                <DropdownItem onClick={() => this.resetDashboardLayout()}>
                    <span><FormattedMessage id='Global.Action_Reset_Dashboard' /></span>
                </DropdownItem>

            </DropdownMenu>
        </AppHeaderDropdown>
    }
    /*
    public render1() {
        const { children, showText, ...rest } = this.props;
        return <React.Fragment>
            {showText ? <div onClick={() => this.toggle()}><FormattedMessage id='Global.Action_Help' /></div> :
                <ToolTipNavLink id="PopoverHelp" toolTipTarget="PopoverHelp" toolTip={"Global.Action_Help"}
                    href="javascript:void(0)" onClick={() => this.toggle()}><i className="fa fa-question" /></ToolTipNavLink>
            }
        </React.Fragment>
    }*/
    private showHelp = () => {
        // Find the URL to match the route start
        const savePath = this.props.location.pathname;
        let path: string = this.props.location.pathname;
        let helpurl: string = '';               

        const x = path.substring(1).split('/');
        path = '/' + x[0];
        if (x.length > 1) {
            path += '/' + x[1];
        }
        path = path.trim();

        forEach(mapHelp, (v) => {
            let route: string = v.route;
            if (route.endsWith('/')) {
                route = route.slice(0, -1);
            }

            console.log('Help route: ', v.route);

            // Testing
            if (route.startsWith(busFlowReducer.urlPackAndShipSelectOrders)) {
                const a = 0;
            }
            // -----------------------------------------------------------
            // KB: Added suport to match detail screen paths like this one
            // path = /itemEdit/0
            // route = /itemEdit/:itm
            // -----------------------------------------------------------
            const posColon = route.indexOf(":");
            if (posColon > -1) {
                // KB: 08/13/2020 - Handle special cases for Pack And Ship Routes
                /*
                    export const urlPackAndShipSelectOrders: string = '/packAndShip/Orders';
                    export const urlPackAndShipEditOrder: string = '/packAndShip/Orders/Edit/:orderId';
                    export const urlPackAndShip: string = '/packAndShip/Orders/:orderId';
                    export const urlPackAndShipMultiLevel: string = '/packAndShip/Orders/:orderId/multilevel';                
                */
                if (route.startsWith(busFlowReducer.urlPackAndShipSelectOrders)) {
                    if (savePath.endsWith('/multilevel') && !route.endsWith('/multilevel')) {
                        return;
                    }
                    else if (savePath.indexOf('/Edit') > -1 && route.indexOf("Edit/:orderId") === -1 ) {
                        return;
                    }
                }

                // I'll strip away the parameter(s) and try to match the base path

                // I'll match the route up to the first colon
                let subRoute = route.substring(0, posColon);
                // I'll match the path up to the same position
                let subPath = path.substring(0, posColon);

                // Trim the ending / off the subroute if needed
                if (subRoute.endsWith("/") && subRoute.length === subPath.length + 1) {
                    subRoute = subRoute.substring(0, subPath.length)
                }

                // Special cases
                if (route.startsWith('/packAndShip/Orders/Edit/') && savePath.startsWith('/packAndShip/Orders/Edit/')) {
                    // Handle special case
                    subPath = subRoute;
                }


                // So in our example we are matching /itemEdit/ for both route and path, thus they will be equal
                if (subRoute === subPath) {
                    helpurl = v.url;
                    return false; // break out of forEach loop
                }


            }

            if (route === savePath) { // path
                 helpurl = v.url;
                return false; // break out of forEach loop
            } else {
                return;
            }
        });
        ShowHelp(helpurl)
    }
    /*
    private showHelp = () => {
        // Find the URL to match the route start
        let path: string = this.props.location.pathname;
        const s: number = path.indexOf('/', 1);
        if (s > 0) {
            path = path.substring(0, s);
        }
        let helpurl: string = '';
        forEach(mapHelp, (v) => {
            const delim: number = v.route.substring(1).indexOf("/");
            const route: string = delim === -1 ? v.route : v.route.substring(0, delim + 1);
            if (path.startsWith(route)) {
                helpurl = v.url;
                return false;
            } else {
                return;
            }
        });
        ShowHelp(helpurl)
    }
    */
    private getVersionInfo() {
        if (this.state.fetchingVersionInfo) { return };  // Prevent multiple calls

        this.setState({ fetchingVersionInfo: true });
        axiosSched.get('/api/workflow/versionExtended/' + sessionStorage.getItem(sessCompanyID))
            .then((resp) => {
                this.setState({ versionInfo: resp.data, fetchingVersionInfo: false });
            })
            .catch((error) => {
                this.props.NotifyError({ message: <span><FormattedMessage id='Global.NoRecords' /><br />{error.message}</span> });
                this.setState({ fetchingVersionInfo: false });
            });
    }
    private resetDashboardLayout() {
        delete localStorage[lsAlertsChartPresetKey];
        delete localStorage[lsDashboardLayoutKey];
        delete localStorage[lsChartThemeKey];
        window.location.replace('/')
    }
}
const mapStateToProps = ({ config, settings }) => {
    return { config, settings }
};

const mapActionsToProps = {

    NotifyError,
    NotifySuccess,
    NotifyInfo,
    NotifyWarning
};

export default connect(mapStateToProps, mapActionsToProps)(Help);
