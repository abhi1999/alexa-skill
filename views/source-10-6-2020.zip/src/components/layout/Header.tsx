import { AppHeaderDropdown, AppNavbarBrand, AppSidebarToggler } from '@coreui/react';
import * as  React from 'react';
import { connect } from 'react-redux';
import { Nav, NavLink, NavItem, Dropdown, DropdownToggle, DropdownMenu, ListGroup, ListGroupItem } from 'reactstrap';
import { Modal, ModalHeader, ModalBody, DropdownItem } from 'reactstrap';
import { getVersionInfo, getErrorInfo } from './../../actions/SettingAction';
import { switchLanguage, switchCompany } from '../../actions/SettingAction';
import { languageGetAll } from '../../actions/LanguageAction';
import { FormattedMessage } from 'react-intl';
import LanguageItem from './../LanguageSwitcher/data';
import "flag-icon-css/css/flag-icon.min.css";
import Help from "./Help";
import { IAPICompanySet } from '../../constants/EDICompany';
import { IWindow } from '../../constants/IWindow';
import FlagIcon from "./FlagIcon";
import {
    axUsername, lsCompanyID, axInitials, cookieMultiSession, axRefreshToken, axAccessToken,
    lsChartThemeKey, sessCompanyID, nameofLicenseKey, forceLogout
} from 'src/constants';
import { injectIntl, intlShape } from 'react-intl';
import LoadingComponent from "../../components/widgets/LoadingComponent";
import { UserDefaultThemes } from '../../constants/UserDefaultThemes';
import axios, { FixURIComponent } from '../../configs/axios';
import { NotifyInfo, NotifyError } from "../../actions/Notification";
import { configSave } from 'src/actions';

const baseApiUrl = ((window as any).env as IWindow).VP4API_URL;

let ChartThemes: any[] = [];
let Themes: any[] = [];

const THEME_MAP = "vp5-theme-map";

interface IHeaderProps {
    location: any,
    routes: any[],
    errorInfo: any,
    versionInfo: any,
    className: string,
    availableCompanies: IAPICompanySet[],
    getVersionInfo: () => void
    getErrorInfo: () => void
    asideMenuChange: (type: string) => void
    switchLanguage: (string) => void
    languageGetAll: (string) => void
    switchCompany: (string) => void,
    NotifyError: (any) => void,
    NotifyInfo: (any) => void,
    settings: any,
    intl: intlShape.isRequired,
    history: any
}

interface IHeaderState {
    showingVersionInfo: boolean,
    showingErrorInfo: boolean,
    langSwitcher,
    asideType: string,
    theme: string,
    doLogout: boolean,
    smallScreenModal: boolean,
    smallScreenModalType?: string
}

class Header extends React.Component<IHeaderProps, IHeaderState>{

    constructor(props: any) {
        super(props);

        Themes = [
            { className: "vp5-default", displayName: props.intl.formatMessage({ id: 'Theme.Blue' }), isDefault: true },
            { className: "vp5-teal", displayName: props.intl.formatMessage({ id: 'Theme.Teal' }) },
            { className: "vp5-new-theme", displayName: props.intl.formatMessage({ id: 'Theme.D365' }) }
        ];
        ChartThemes = [
            { className: "ChartBackgroundColors", displayName: props.intl.formatMessage({ id: 'Theme.ChartDefault' }), isDefault: true },
            { className: "ChartBackgroundColors2", displayName: props.intl.formatMessage({ id: 'Theme.Chart1' }) },
            { className: "ChartBackgroundColors3", displayName: props.intl.formatMessage({ id: 'Theme.Chart2' }) },
            { className: "ChartBackgroundColors4", displayName: props.intl.formatMessage({ id: 'Theme.Chart3' }) }
        ];

        // let defaultTheme = Themes.find(t => t.isDefault === true);
        // if (defaultTheme === undefined) {
        //     defaultTheme = { className: "", displayName: "" };
        // }

        this.state = {
            showingVersionInfo: false,
            showingErrorInfo: false,
            langSwitcher: false,
            asideType: '',
            // theme: defaultTheme.className,
            theme: this.getDefaultTheme(),
            doLogout: false,
            smallScreenModal: false
        }
    }
    public componentDidMount() {
        // const parsedTHemeMap = this.getParsedThemeMap()
        // const selectedCompanyID = sessionStorage[sessCompanyID];
        // if (Themes.find(t => t.className === parsedTHemeMap[selectedCompanyID]) !== undefined) {
        //     this.themeChange(parsedTHemeMap[selectedCompanyID], false);
        // }

        // need to make api call to get theme
        this.loadThemes();

    }
    public toggleVersionInfo = () => {
        if (!this.state.showingVersionInfo === true) {
            this.props.getVersionInfo();
        }
        this.setState({
            showingVersionInfo: !this.state.showingVersionInfo
        });
    }

    public toggleErrorInfo = () => {
        if (!this.state.showingErrorInfo === true) {
            // Refresh the data
            this.props.getErrorInfo();
        }
        this.setState({
            showingErrorInfo: !this.state.showingErrorInfo
        });
    }

    public handleRequestClose = () => {
        this.setState({
            langSwitcher: false,
        });
    };

    public toggle = () => {
        this.setState(prevState => ({
            langSwitcher: !prevState.langSwitcher
        }));
    }

    public render() {
        if (this.state.doLogout) {
            window.location.replace('/');
            return <LoadingComponent />;
        }

        // Extract the user initials from the logged in userID
        let userInitials = sessionStorage.getItem(axInitials);;
        if (userInitials === null) { userInitials = 'DM'; }
        const { availableCompanies, settings, errorInfo, versionInfo } = this.props;
        const versionInfoList = versionInfo.map((item) =>
            <li key={item}>{item}</li>
        );
        const errorInfoList = errorInfo.map((item, index) =>
            <li key={index}>{item}</li>
        );
        const selectedLocale = settings && settings.locale && settings.locale ? settings.locale : { icon: 'us', locale: 'en' };

        const debugMode = ((window as any).env as IWindow).UIDEBUG;
        const initialsClassname = debugMode ? 'login-name login-name-debug' : 'login-name';
        return <React.Fragment>
            <Modal isOpen={this.state.showingVersionInfo} toggle={this.toggleVersionInfo} className={this.props.className}>
                <ModalHeader toggle={this.toggleVersionInfo}><FormattedMessage id='Header.VersionInfo' /></ModalHeader>
                <ModalBody>
                    <ul>{versionInfoList}</ul>
                </ModalBody>
            </Modal>

            <Modal isOpen={this.state.showingErrorInfo} toggle={this.toggleErrorInfo} size="lg" className={this.props.className}>
                <ModalHeader toggle={this.toggleErrorInfo}><FormattedMessage id='Header.RecentErrors' /></ModalHeader>
                <ModalBody>
                    <ul>{errorInfoList}</ul>
                </ModalBody>
            </Modal>
            <AppSidebarToggler className="d-lg-none" display="md" mobile={true}>
                <span className="fas fa-th" />
            </AppSidebarToggler>
            <AppSidebarToggler className="d-md-down-none" display="lg">
                <span className="fas fa-th" />
            </AppSidebarToggler>
            <AppNavbarBrand>
                <span>Data Masons EDI</span>
            </AppNavbarBrand>
            <Nav navbar={true} className="d-md-down-none">
                <AppHeaderDropdown direction="down">
                    <DropdownToggle nav={true} caret={true} className="selected-company">
                        {this.getSelectedCompany().YourCompany_DispName}
                    </DropdownToggle>
                    <DropdownMenu >
                        {availableCompanies.map((c, i) =>
                            <DropdownItem key={i} onClick={() => this.switchCompany(c)}>
                                {c.Company_ID.toString() + ' - ' + c.YourCompany_DispName} {Number(sessionStorage[sessCompanyID]) === c.Company_ID ?
                                    <i style={{ color: "black", "paddingLeft": "40px" }} className="fas fa-check" aria-hidden="true" /> : ""}
                            </DropdownItem>
                        )
                        }
                    </DropdownMenu>
                </AppHeaderDropdown>
                <AppHeaderDropdown direction="down">
                    <DropdownToggle nav={true}>
                        <i className="fas fa-palette" />
                    </DropdownToggle>
                    <DropdownMenu >
                        <DropdownItem header={true}>{this.props.intl.formatMessage({ id: 'Theme.Theme' })}</DropdownItem>
                        {Themes.map(t => <DropdownItem key={t.className} onClick={() => this.themeChange(t.className, true)}>{t.displayName} {this.renderCheckBox(t.className)}</DropdownItem>)}
                        <DropdownItem header={true}>{this.props.intl.formatMessage({ id: 'Theme.ChartTheme' })}</DropdownItem>
                        {
                            ChartThemes.map(t =>
                                <DropdownItem key={t.className} onClick={() => this.switchChartColorTheme(t.className, true)}>
                                    {t.displayName}
                                    {t.className === this.getSelectedChartTheme() ? <i style={{ color: "black", "paddingLeft": "40px" }} className="fas fa-check" aria-hidden="true" /> : ""}
                                </DropdownItem>)
                        }
                    </DropdownMenu>
                </AppHeaderDropdown>

                <Help {...this.props} />

                <AppHeaderDropdown direction="down">
                    <DropdownToggle nav={true}>
                        <i className="fas fa-globe-americas" /><span className="locale-label">{selectedLocale.locale}</span>
                    </DropdownToggle>
                    <DropdownMenu >
                        {LanguageItem.map(language =>
                            <DropdownItem key={language.name} onClick={() => this.switchLanguage(language)}>
                                <FlagIcon code={language.icon} />&nbsp; {language.name} {language.icon === selectedLocale.icon ? <i style={{ color: "black", "paddingLeft": "40px" }} className="fas fa-check" aria-hidden="true" /> : ""}
                            </DropdownItem>
                        )
                        }
                    </DropdownMenu>
                </AppHeaderDropdown>
                <AppHeaderDropdown direction="down">
                    <DropdownToggle nav={true}>
                        <span className={initialsClassname}>{userInitials}</span>
                    </DropdownToggle>
                    <DropdownMenu >
                        <DropdownItem key="logout" onClick={() => { this.logout() }}><FormattedMessage id='Login.Logout' /></DropdownItem>
                        {/* <DropdownItem key="Admin" onClick={()=>{this.goToRoleAdimin()}}><FormattedMessage id='Global.RoleAdministration' /></DropdownItem>  */}
                    </DropdownMenu>
                </AppHeaderDropdown>
            </Nav>

            <Nav className="d-lg-none" navbar={true}>
                <AppHeaderDropdown direction="down">
                    <DropdownToggle nav={true}>
                        <i className="fas fa-bars" aria-hidden="true" />
                    </DropdownToggle>
                    <DropdownMenu >
                        <Help {...this.props} showText={true} />
                        <DropdownItem onClick={() => { this.setState({ smallScreenModalType: "C" }); this.toggleSmallScreenModal() }}><FormattedMessage id='Menu.SmallCompany' /></DropdownItem>
                        <DropdownItem onClick={() => { this.setState({ smallScreenModalType: "T" }); this.toggleSmallScreenModal() }}><FormattedMessage id='Menu.SmallTheme' /></DropdownItem>
                        <DropdownItem onClick={() => { this.setState({ smallScreenModalType: "L" }); this.toggleSmallScreenModal() }}><FormattedMessage id='Menu.SmallLanguage' /></DropdownItem>
                        <DropdownItem key="logout" onClick={() => { this.logout() }}><FormattedMessage id='Login.Logout' /></DropdownItem>
                    </DropdownMenu>
                </AppHeaderDropdown>
            </Nav>


            <Modal isOpen={this.state.smallScreenModal} toggle={this.toggleSmallScreenModal} className={this.props.className}>
                <ModalHeader toggle={this.toggleSmallScreenModal}>{this.getSmallScreenModalTitle()}</ModalHeader>
                <ModalBody>
                    {this.getSmallScreenModalBody()}
                </ModalBody>
            </Modal>
            {/*
            <Nav className="d-md-down-none" navbar={true}>
                <NavItem className="">
                    <ToolTipNavLink toolTip="Settings" href="javascript:void()" onClick={()=>this.asideMenuClick('1')}><i className="fas fa-cog" /></ToolTipNavLink>
                </NavItem>
                <NavItem className="">
                    <ToolTipNavLink toolTip="Import" href="javascript:void()"  onClick={()=>this.asideMenuClick('2')}><i className="fas fa-download" /></ToolTipNavLink>
                </NavItem>
                <NavItem className="">
                    <ToolTipNavLink toolTip="Send/Receive" href="javascript:void()"  onClick={()=>this.asideMenuClick('3')}><i className="fas fa-exchange" /></ToolTipNavLink>
                </NavItem>
                <NavItem className="">
                    <ToolTipNavLink toolTip="Utilities" href="javascript:void()"  onClick={()=>this.asideMenuClick('4')}><i className="fas fa-wrench" /></ToolTipNavLink>
                </NavItem>
                <NavItem className="">
                    <ToolTipNavLink toolTip="Reports" href="javascript:void()"  onClick={()=>this.asideMenuClick('5')}><i className="fas fa-line-chart" /></ToolTipNavLink>
                </NavItem>
            </Nav>
            <Nav className="d-lg-none" navbar={true}>
                <AppHeaderDropdown direction="down">
                    <DropdownToggle nav={true}>
                        <i className="fas fa-bars" aria-hidden="true"/>
                    </DropdownToggle>
                    <DropdownMenu >
                        <DropdownItem onClick={()=>this.asideMenuClick('1')}><i className="fas fa-cog" /> Settings</DropdownItem>
                        <DropdownItem onClick={()=>this.asideMenuClick('2')}><i className="fas fa-download" /> Import</DropdownItem>
                        <DropdownItem onClick={()=>this.asideMenuClick('3')}><i className="fas fa-exchange" /> Send/Receive</DropdownItem>
                        <DropdownItem onClick={()=>this.asideMenuClick('4')}><i className="fas fa-wrench" /> Utilities</DropdownItem>
                        <DropdownItem onClick={()=>this.asideMenuClick('5')}><i className="fas fa-line-chart" /> Reports</DropdownItem>
                    </DropdownMenu>
                </AppHeaderDropdown>
            </Nav>
            */}
        </React.Fragment>
    }
    private getSelectedCompany = () => {
        const { availableCompanies } = this.props;
        const selectedCompanyId = Number(sessionStorage[sessCompanyID])
        const selected = availableCompanies.find(c => c.Company_ID === selectedCompanyId)
        return selected ? selected : { Company_ID: 1, YourCompany_DispName: "" }
    }
    private goToRoleAdimin = () => {
        this.props.history.push('/RoleAdmin')
    }

    // private getParsedThemeMap = () => {
    //     const currentThemeMap = localStorage.getItem(THEME_MAP)
    //     let parsedTHemeMap = {}
    //     if (currentThemeMap !== undefined && currentThemeMap !== null) {
    //         try { parsedTHemeMap = JSON.parse(currentThemeMap); }
    //         catch{
    //             console.log('cannot parse theme settings from localstorage')
    //         }
    //     }
    //     return parsedTHemeMap;
    // }

    private getDefaultTheme = () => {
        let defaultTheme = Themes.find(t => t.isDefault === true);
        if (defaultTheme === undefined) {
            defaultTheme = { className: "", displayName: "" };
        }
        return defaultTheme.className;
    }

    private themeChange = (className, userChanged: boolean) => {
        this.setState({ theme: className });

        // const parsedTHemeMap = this.getParsedThemeMap()
        // const selectedCompanyID = sessionStorage[sessCompanyID];
        // parsedTHemeMap[selectedCompanyID] = className;
        // localStorage.setItem(THEME_MAP, JSON.stringify(parsedTHemeMap));
        localStorage.setItem(THEME_MAP, className);

        // mar 6/2/2020 - post theme back to api if it was changed by user

        if (userChanged) {

            let chartTheme = localStorage.getItem(lsChartThemeKey)

            if (chartTheme === null || chartTheme === undefined) {
                chartTheme = ""
            }

            const userDefaultTheme: UserDefaultThemes = new UserDefaultThemes({ ColorTheme: className, ChartTheme: chartTheme });
            const user = FixURIComponent(sessionStorage.getItem(axUsername) as string);
            

            axios.post(baseApiUrl + "/api/Authorization/UpdateDefaultTheme/" + user, userDefaultTheme)

                .then(() => {
                    this.props.NotifyInfo({ message: <FormattedMessage id='Theme.Updated' /> })
                })
                .catch((error) => {
                    this.props.NotifyError({ message: error.message });
                })
        }

        Themes.forEach(t => document.body.classList.remove(t.className))
        document.body.classList.add(className);
    }

    private renderCheckBox = (className) => {
        return this.state.theme === className ? <i style={{ color: "black", "paddingLeft": "40px" }} className="fas fa-check" aria-hidden="true" /> : "";
    }
    private toggleSmallScreenModal = () => {
        this.setState({ smallScreenModal: !this.state.smallScreenModal })
    }
    private getSmallScreenModalTitle = () => {
        switch (this.state.smallScreenModalType) {
            case "C":
                return <FormattedMessage id='Menu.SmallCompany' />;
            case "T":
                return <FormattedMessage id='Menu.SmallTheme' />;
            case "L":
                return <FormattedMessage id='Menu.SmallLanguage' />;
            default:
                return <FormattedMessage id='Menu.SmallSelect' />;
        }
    }
    private getSmallScreenModalBody = () => {
        switch (this.state.smallScreenModalType) {
            case "C":
                const { availableCompanies } = this.props;
                return <ListGroup>
                    {availableCompanies.map((c, i) =>
                        <ListGroupItem key={i} onClick={() => { this.toggleSmallScreenModal(); this.switchCompany(c) }}>
                            {c.YourCompany_DispName} {Number(sessionStorage[sessCompanyID]) === c.Company_ID ?
                                <i style={{ color: "black", "paddingLeft": "40px" }} className="fas fa-check" aria-hidden="true" /> : ""}
                        </ListGroupItem>
                    )
                    }
                </ListGroup>
            case "T":
                return <ListGroup>
                    <ListGroupItem className="list-group-item-accent-secondary bg-light text-center font-weight-bold text-muted text-uppercase small">Theme</ListGroupItem>
                    {Themes.map(t => <ListGroupItem key={t.className} onClick={() => { this.toggleSmallScreenModal(); this.themeChange(t.className, false) }}>{t.displayName} {this.renderCheckBox(t.className)}</ListGroupItem>)}
                    <ListGroupItem className="list-group-item-accent-secondary bg-light text-center font-weight-bold text-muted text-uppercase small">Chart Theme</ListGroupItem>
                    {
                        ChartThemes.map(t =>
                            <ListGroupItem key={t.className} onClick={() => { this.toggleSmallScreenModal(); this.switchChartColorTheme(t.className, false) }}>
                                {t.displayName}
                                {t.className === this.getSelectedChartTheme() ? <i style={{ color: "black", "paddingLeft": "40px" }} className="fas fa-check" aria-hidden="true" /> : ""}
                            </ListGroupItem>)
                    }
                </ListGroup>
            case "L":
                const selectedLocale = this.props.settings && this.props.settings.locale && this.props.settings.locale ? this.props.settings.locale : { icon: 'us', locale: 'en' };
                return <ListGroup>
                    {LanguageItem.map(language =>
                        <ListGroupItem key={language.name} onClick={() => { this.toggleSmallScreenModal(); this.switchLanguage(language) }}>
                            <FlagIcon code={language.icon} />&nbsp; {language.name} {language.icon === selectedLocale.icon ? <i style={{ color: "black", "paddingLeft": "40px" }} className="fas fa-check" aria-hidden="true" /> : ""}
                        </ListGroupItem>
                    )
                    }
                </ListGroup>
            default:
                return <div>{this.state.smallScreenModalType} modal type</div>;
        }
    }
    private switchCompany(c: IAPICompanySet) {
        // Change the active company (see AxiosBehavior.ts)
        console.log("Switching Companies")
        const lsID = sessionStorage.getItem(sessCompanyID);
        if (lsID === c.Company_ID.toString()) {
            // Still the same company
            return;
        }
        // Update last company selected
        localStorage.setItem(lsCompanyID, c.Company_ID.toString());
        // Set the active company
        sessionStorage.setItem(sessCompanyID, c.Company_ID.toString())
        this.props.switchCompany(c.YourCompany_DispName);

        // Reload the entire browser screen to get updated data
        window.location.replace('/')
    }

    private async loadThemes() {

        const user = FixURIComponent(sessionStorage.getItem(axUsername) as string);

        await axios.get(baseApiUrl + "/api/Authorization/GetDefaultTheme/" + user)

            .then((result) => {
                if (result.data !== null) {
                    const userDefaultTheme: UserDefaultThemes = result.data
                    // this.switchChartColorTheme(userDefaultTheme.ChartTheme);
                    if (userDefaultTheme.ChartTheme !== undefined && userDefaultTheme.ChartTheme !== null) {
                        // localStorage.setItem(lsChartThemeKey, userDefaultTheme.ChartTheme);
                        this.switchChartColorTheme(userDefaultTheme.ChartTheme, false);
                    }
                    else {
                        this.switchChartColorTheme(this.getDefaultChart(), false);
                    }

                    if (userDefaultTheme.ColorTheme !== undefined && userDefaultTheme.ColorTheme !== null) {
                        this.themeChange(userDefaultTheme.ColorTheme, false);
                    }
                    else {
                        this.themeChange(this.getDefaultTheme(), false);
                    }
                }

            })
            .catch((error) => {
                this.props.NotifyError({ message: error.message });
            })

    }

    private getDefaultChart = () => {
        let defaultChart = ChartThemes.find(t => t.isDefault === true);
        if (defaultChart === undefined) {
            defaultChart = { className: "", displayName: "" };
        }
        return defaultChart.className;
    }

    private async switchChartColorTheme(chartTheme, userChanged: boolean) {
        // Change the active company (see AxiosBehavior.ts)
        const currentChartTheme = localStorage.getItem(lsChartThemeKey);
        if (currentChartTheme === chartTheme) {
            return;
        }

        localStorage.setItem(lsChartThemeKey, chartTheme);

        let className = localStorage.getItem(THEME_MAP);

        if (className === null || className === undefined) {
            className = ""
        }

        const userDefaultTheme: UserDefaultThemes = new UserDefaultThemes({ ColorTheme: className, ChartTheme: chartTheme });
        const user = FixURIComponent(sessionStorage.getItem(axUsername) as string)

        if (userChanged) {
            await axios.post(baseApiUrl + "/api/Authorization/UpdateDefaultTheme/" + user, userDefaultTheme)

                .then(() => {
                    this.props.NotifyInfo({ message: <FormattedMessage id='Theme.Updated' /> })
                })
                .catch((error) => {
                    this.props.NotifyError({ message: error.message });
                })
        }
        // Reload the entire browser screen to get updated data
        // window.location.reload();
        window.location.replace('/')
    }
    private getSelectedChartTheme() {
        const ChartThemeObject: any[] = [];
        if (ChartThemes.find(t => t.className === localStorage.getItem(lsChartThemeKey)) !== undefined) {

            ChartThemeObject.push(ChartThemes.find(t => t.className === localStorage.getItem(lsChartThemeKey)))
        }
        else {
            ChartThemeObject.push(ChartThemes.find(t => t.isDefault === true))
        }
        if (ChartThemeObject.length > 0) { return ChartThemeObject[0].className }
        return "";
    }


    // private asideMenuClick =(type)=>{
    //     this.props.asideMenuChange(type);
    //     if(this.state.asideType === type || this.state.asideType===""){
    //         document.body.classList.toggle('aside-menu-lg-show');
    //     }
    //     else{
    //         document.body.classList.remove('aside-menu-lg-show');
    //         setTimeout(()=>document.body.classList.add('aside-menu-lg-show'), 300);
    //     }
    //     this.setState({asideType:type})

    // }

    private switchLanguage = (locale) => {
        this.props.switchLanguage(locale);
        this.props.languageGetAll(locale);
    }

    private logout() {

        sessionStorage.removeItem(axUsername);
        sessionStorage.removeItem(axAccessToken);
        sessionStorage.removeItem(axRefreshToken);
        sessionStorage.removeItem(nameofLicenseKey());
        // user did not time out
        sessionStorage.setItem(forceLogout, 'none');
        document.cookie = cookieMultiSession + '=; path=/;';
        // mar 5/22/2020 - we use sessCompanyID when we log in (after timeout) - don't override with '1'
        // sessionStorage.setItem(sessCompanyID,'1');
        this.setState({ doLogout: true });
    }
}

const mapStateToProps = ({ settings, loginReducer }) => {
    const { versionInfo, errorInfo, availableCompanies } = settings;
    const { loggedInInitials } = loginReducer;
    return { versionInfo, errorInfo, availableCompanies, loggedInInitials }
};

const mapActionsToProps = {
    getVersionInfo,
    getErrorInfo,
    switchLanguage,
    languageGetAll,
    switchCompany,
    NotifyError,
    NotifyInfo
}

export default injectIntl(connect(mapStateToProps, mapActionsToProps)(Header));

/*
    <Nav className="d-md-down-none" navbar={true}>
        <NavItem className="px-3">
            <NavLink href="#"><i className="icon-settings" title="Settings"/></NavLink>
        </NavItem>
        <NavItem className="px-3">
            <NavLink href="#"><i className="icon-cloud-download" title="Download"/></NavLink>
        </NavItem>
        <NavItem className="px-3">
            <NavLink href="#"><i className="icon-cloud-upload" title="Update"/></NavLink>
        </NavItem>
        <NavItem className="px-3">
            <NavLink href="#"><i className="icon-notebook" title="Notes"/></NavLink>
        </NavItem>
    </Nav>
    <Nav className="ml-auto" navbar={true}>
        <NavItem className="d-md-down-none"> <Input type="search" name="search" id="exampleSearch" placeholder="Search..." />
        </NavItem>
        <NavItem className="d-md-down-none">
            <NavLink href="#"><i className="icon-globe"/><Badge pill={true} color="danger">5</Badge></NavLink>
        </NavItem>
        <NavItem className="d-md-down-none"><i className="icon-refresh" onClick={()=>{this.props.reload()}}/></NavItem>

    </Nav>
    <AppAsideToggler className="d-md-down-none" />
*/

//                         <i className={classnames("flag-icon ", "flag-icon-"+languageIcon)} />
//                                     <i className={classnames("flag-icon ", "flag-icon-"+language.icon)} /> {language.name}
