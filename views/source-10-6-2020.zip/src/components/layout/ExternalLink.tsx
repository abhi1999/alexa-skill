import * as  React from 'react';
import * as queryString from 'query-string'
import { setPageFilterState, setExternalLinkFilterState } from '../../actions/ViewStateAction';
import { connect } from "react-redux";


class ExternalLink extends React.Component<any, any>{
    constructor(props){
        super(props);
        console.log("ExternalLink");
    }
    public componentDidMount(){
        if(this.doHideMenu()){
            console.log('hide menu')
            this.hideMenu();
        }
        else if(this.doCollapseMenu()){
            console.log('collapse menu')
            this.collapseMenu();
        }
        const filterObj = this.getFilter();
        if(filterObj){
            console.log('found page filters')
            const filterState =filterObj.filter.split('|').filter(f=> f.split('~').length >= 3).map(f=>{
                const id = f.split('~')[0];
                const operator = f.split('~')[1];
                let value:any = decodeURIComponent(f.split('~')[2]);
                if(value.indexOf('__')>-1){
                    value=value.split('__').map(v=>{const i=1;return{value:v}})
                }
                if(f.split('~').length>3){
                    let toValue:any = decodeURIComponent(f.split('~')[3]);
                    if(toValue.indexOf('__')>-1){
                        toValue = toValue.split('__').map(v=>{const i=1;return{value:v}})
                    }
                    return {id, operator, value, toValue}
                }
                return {id, operator, value}
            })
            this.props.setExternalLinkFilterState({key: filterObj.filterKey, filterState})
            // this.props.setExternalLinkFilterState({key: filterObj.filterKey, filterState:JSON.parse(filterObj.filter)})

            setTimeout(()=>{this.props.setExternalLinkFilterState({key: filterObj.filterKey, filterState:[]})}, 10000)
        }
        console.log("This is the target", this.getTarget())
        this.props.history.push(this.getTarget());
    }
    public render(){
        return <div>Loading...</div>
    }
    private doHideMenu= ()=>{
        return this.props.noMenu? true:false
    }
    private doCollapseMenu= ()=>{
        return this.props.collapseMenu? true:false
    }
    private hideMenu= ()=>{
        if(!document.body.classList.contains("hide-sidebar")){   
            document.body.classList.add("hide-sidebar")
        };
        window.sessionStorage.setItem("HideMenu", 'true');
    }
    private collapseMenu =()=>{
        if(!document.body.classList.contains("sidebar-minimized")){   
            document.body.classList.add("sidebar-minimized")
        };
        window.sessionStorage.setItem("CollapseMenu", 'true');   
    }
    private getTarget = () => {
        // NOTE: This method converts the External Link request with a matching route
        console.log("getTarget() method called");

        const qsParams = queryString.parse(this.props.location.search);
        if(qsParams.filter !==undefined){delete qsParams.filter}
        if(qsParams.filterKey !==undefined){delete qsParams.filterKey}

        if(qsParams.target && qsParams.target.toString().length>0){
            if (Object.keys(qsParams).length === 1) {
                return '/'+qsParams.target;
            } 
            let url: string;
            url = '/' + qsParams.target + '?' + this.props.location.search.substring(7 + qsParams.target.length + 2);
            console.log("url", url);
            return url;
        }
        else {
            return '/';
        }
    }
    private getFilter=()=>{
        console.log("getFilter() method called");

        const qsParams = queryString.parse(this.props.location.search);
        if(qsParams.filter  !== undefined// && qsParams.filter.toString().length>0 
            && qsParams.filterKey && qsParams.filterKey.toString().length>0){
            return {filterKey:qsParams.filterKey, filter:qsParams.filter}
        }
        return null;
    }
}

// export default ExternalLink;
const mapStateToProps = (state, ownProps) => {
    return { ...ownProps}
};
  
const mapActionsToProps = {
    setExternalLinkFilterState,
};
  
export default connect(mapStateToProps, mapActionsToProps)(ExternalLink);

  
// http://localhost:9005/#/Link?target=PurchaseOrders/PurchaseOrderView/6610
