import * as React from 'react';
import { connect } from 'react-redux'
import Notifications from 'react-notification-system-redux';
import { Router, HashRouter, Link, Route, Switch } from "react-router-dom";
import DefaultLayout from "./layout/DefaultLayout";
import ScrollToTop from "./layout/ScrollToTop";
import { intlShape } from 'react-intl';
// import JsonEdit from '../views/document/JsonEdit';
import JsonEditView from '../views/document/JsonEditView';
import * as queryString from 'query-string';
import Loadable from 'react-loadable';
import LoadingComponent from "./../components/widgets/LoadingComponent";
import axiosRoot, { FixURIComponent } from "../configs/axios";
import history from "./../utils/History";
import { IntlProvider } from 'react-intl';
import { languageGetAll } from '../actions/LanguageAction';
import { NotifyInfo, NotifyError, NotifyWarning } from "../actions/Notification";
import { FormattedMessage } from 'react-intl';
import { getCompanyList, getCompanyListWithImpersonation } from '../actions/SettingAction';
import IntlGlobalProvider from '../utils/IntlGlobalProvider';
import { axUsername, axAccessToken, IMultiSession, cookieMultiSession, axInitials, lsCompanyID, axRefreshToken, nameofLicenseKey, sessCompanyID, kLicenseValid } from '../constants/index';
import { logoutWarning, logoutTimeout, forceLogout } from '../constants/index';
import { INewsFeed } from "./../domain/DataModel";
import { SetCursorBusy, SetCursorNotBusy } from '../utils/UIValidation';
import Login from '../views/Login/Login';
import * as VPCrypt from '../utils/VPEncryption';
import ExternalLink from "./layout/ExternalLink";
import { IWindow } from '../constants/IWindow';
import { ICompanySettingsReducer } from '../../src/reducers/CompanyReducer';
import DocumentListView from '../../src/views/document/DocumentListView';
import MultiFactorLogin from "./../views/Login/MultiFactorLogin";
import { permissionsNoCompany } from "../actions/RoleAdministrationAction";
import { Logout } from '../utils/Logout'
import LogRocket from 'logrocket';
import setupLogRocketReact from 'logrocket-react';

import './App.css';

const Loading = () => {
  return <LoadingComponent />;
}

// mar testing 11/1/2019
// const MAX_INACTIVITY_TIME: number = 0 // 60 * 1000;
const MAX_INACTIVITY_TIME: number = ((window as any).env as IWindow).LOGOUT_TIMEOUT_MINUTES === undefined ? 0 : ((window as any).env as IWindow).LOGOUT_TIMEOUT_MINUTES * 60 * 1000;


// const LOGOUT_WARNING: number = 0 // 45 * 1000;
// set LOGOUT_WARNING to 15 seconds before MAX_INACTIVITY_TIME
const LOGOUT_WARNING: number = MAX_INACTIVITY_TIME > 0 ? MAX_INACTIVITY_TIME - (15 * 1000) : 0;
// mar 

const DocListView = Loadable({ loader: () => import("../views/document/DocumentListView"), loading: Loading })
const TradeView = Loadable({ loader: () => import("../views/Trade/TradeView"), loading: Loading })
const ShipToView = Loadable({ loader: () => import("../views/ShipTo/ShipToView"), loading: Loading })
const ItemXRefList = Loadable({ loader: () => import("../views/Item/ItemXrefList"), loading: Loading })
const CumulativeQtyView = Loadable({ loader: () => import("../views/CumulativeQty/CumulativeQtyView"), loading: Loading })
const PlanningScheduleView = Loadable({ loader: () => import("../views/PlanningSchedule/PlanningScheduleListView"), loading: Loading })
const ProductionSequenceView = Loadable({ loader: () => import("../views/ProductionSequence/ProductionSequenceListView"), loading: Loading })

interface IAppProps {
  intl: intlShape.isRequired,
  alertGroupSet: any[],
  dashboardMenuItems: any[],
  notifications: any,
  navItems: any[],
  newsFeeds: INewsFeed,
  loadAllLookup: () => {},
  testNotification: (msg: string) => void,
  settings: any,
  languageGetAll: any,
  companySetting: any,
  getCompanyList: any,
  getCompanyListWithImpersonation: any,
  loggedInInitials: string,
  NotifyInfo: (any) => void
  NotifyError: (any) => void,
  NotifyWarning: (any) => void,
  location: any,
  permissionsNoCompany: any,
}

interface IAppState {
  isLoginSuccessful: boolean,
  dbUpdate: boolean,
  noCompany: boolean,
  forceCompanyModal: boolean,
  loginProps?: any,
  initiateMFA?: boolean,
  loading: boolean,


  // mar testing 11/1/2019
  // logoutWarning?: any,
  // logoutTimeout?: any,
  //
}

const defaultStyle = {
  NotificationItem: {
    DefaultStyle: {
      margin: "10px, 5px, 2px, 1px",
      wordWrap: 'break-word'
    }
  }
}

class App extends React.Component<IAppProps, IAppState> {
  public constructor(props) {
    super(props)
    const {UI_LOGGER_ENABLED, UI_LOGER_APP_ID} = ((window as any).env as IWindow);
    if(UI_LOGGER_ENABLED){
      LogRocket.init(UI_LOGER_APP_ID);
      setupLogRocketReact(LogRocket);
    }
    // See if we have any previously cached sessionStorage values to re-use for multitab/multiwindow support
    document.cookie.split('; ').forEach(c1 => {
      const cName: string[] = c1.split('=');
      if (cName[0] === cookieMultiSession && cName[1] !== '') {
        // Our cookie and it's not empty
        const mt: IMultiSession = JSON.parse(VPCrypt.XORDecrypt(VPCrypt.DefaultKey + VPCrypt.DefaultKey + VPCrypt.DefaultKey + VPCrypt.DefaultKey, cName[1]));
        if (typeof (mt.expires) === 'string') { mt.expires = new Date(mt.expires) };
        if (new Date() > mt.expires) {
          // Expired data so clear and continue
          document.cookie = cookieMultiSession + '=; path=/;';
        } else {
          sessionStorage.setItem(axAccessToken, mt.accessToken);
          sessionStorage.setItem(axUsername, mt.userName);
          sessionStorage.setItem(axRefreshToken, mt.refreshToken);
          sessionStorage.setItem(axInitials, mt.initials);
          let i: number;
          for (i = 0; i < mt.clientKey.length; i++) {
            sessionStorage.setItem(mt.clientKey[i], mt.clientValue[i]);
          }
          for (i = 0; i < mt.licenseKeys.length; i++) {
            sessionStorage.setItem(mt.licenseKeys[i], mt.licenseState[i] ? '1' : '0');
          }
          ((window as any).env as IWindow).YourCompany_DispName = mt.YourCompany_DispName;
        }
      }
    });

    // See if query parameter(s) are present.  e.g. "#/processTrigger?companyId=??"
    // Note: window.location.search is always empty because React used # in the URLs (http://singlepageapplication.com/react-app-url-schemes-part-1/)
    const q: number = window.location.hash.indexOf("?");
    if (q > 0) {
      const queryParms: any = queryString.parse(window.location.hash.substring(q));
      if (queryParms.companyId !== undefined) {
        // Set persistant ID for next login
        localStorage.setItem(lsCompanyID, queryParms.companyId);
        // Set current ID for this tab/window
        sessionStorage.setItem(sessCompanyID, queryParms.companyId);
      }
    } else {
      // mar - 5/18/2020 use session storage first (session may have timed out)
      let cid = sessionStorage.getItem(sessCompanyID);
      if (cid == null) {
        cid = localStorage.getItem(lsCompanyID);
      }
      if (cid === null) {
        localStorage.setItem(lsCompanyID, '1');
        sessionStorage.setItem(sessCompanyID, '1');
      } else {
        sessionStorage.setItem(sessCompanyID, cid);
      }
    }

    // See if we're already logged in with a valid license key or if we need to bring up the login view
    const licenseCheck = sessionStorage.getItem(nameofLicenseKey());
    let loggedIn: boolean = false;

    if (licenseCheck !== null) {
      loggedIn = licenseCheck === kLicenseValid;

      if (loggedIn) {
        // mar 11/22/2019 - need to determine if database is current
        SetCursorBusy();
        axiosRoot.get('/api/Utility/LatestDBVersion/true')
          .then((rsp) => {
            // DB is up to date
            SetCursorNotBusy();
          })
          .catch((err: Error) => {
            if (err.message.indexOf('409') > 0) {
              SetCursorNotBusy();
              // DB needs updating
              this.props.NotifyWarning({ message: <FormattedMessage id='Validation.CompanyNeedsUpdate' /> });
              // this.afterLoginCompleted(true, false, false);
              this.logoutUser(false);
              loggedIn = false;
            } else {
              SetCursorNotBusy();
              // Some other bad error
              loggedIn = false;
            }
          })
      }
      this.state = { isLoginSuccessful: loggedIn, dbUpdate: false, noCompany: false, forceCompanyModal: false, loading: true };
    } else {
      loggedIn = false;
      this.state = { isLoginSuccessful: false, dbUpdate: false, noCompany: false, forceCompanyModal: false, loading: false };
    }

    this.SetLoggedIn = this.SetLoggedIn.bind(this);

    if (loggedIn) { 
      const userName = sessionStorage.getItem('CachedUserName');
      LogRocket.identify(userName === null?"Unknown":userName)
      this.reloadData(); 
    }

    // mar testing 11/1/2019
    this.timeoutWarning = this.timeoutWarning.bind(this);
    this.logoutUser = this.logoutUser.bind(this);
    this.userTimedOut = this.userTimedOut.bind(this);
    this.resetTimeout = this.resetTimeout.bind(this);
    this.startTimer = this.startTimer.bind(this);
    this.stopTimer = this.stopTimer.bind(this);

    if (MAX_INACTIVITY_TIME > 0) {
      // window.addEventListener("load", this.resetTimeout, {passive:true});
      window.addEventListener("mousemove", this.resetTimeout, { passive: true });
      // window.addEventListener("mousedown", this.resetTimeout, {passive:true});
      // window.addEventListener("click", this.resetTimeout, {passive:true});
      // window.addEventListener("scroll", this.resetTimeout, {passive:true});
      window.addEventListener("keypress", this.resetTimeout, { passive: true });

      this.startTimer();
    }

    // log user out if they close the browser (happens on F5/refresh too)
    // window.addEventListener("beforeunload", this.logoutUser);
  }


  public componentDidMount() {
    this.setMenuStyleBasedOnSessionVariable();
  }

  public componentDidUpdate(prevProps, prevState) {
    // if (prevState.isLoginSuccessful && this.state.isLoginSuccessful === false) {
    //   console.log("Need to log you out!")
    // }

    if (!prevState.isLoginSuccessful && this.state.isLoginSuccessful) {
      // need to update the company list with only the ones the user has rights to (row level security)

      this.props.getCompanyListWithImpersonation()
    }
  }

  public componentWillReceiveProps(newProps) {
    this.setState({
        loading: newProps.settings.loading,

    });
}


  public render() {

    const { settings } = this.props;
    // const { loading } = this.state;

    // mar 2/11/2020 loading should be true if language is changed (during call to get reactLanguageTerms)
    // once call is complete, loading should be false
    // this allows time to update any override in default language terms
    // if (loading) {
    //   return <LoadingComponent />;
    // }

    // Update the browser tab title

    // http://w2k12s25:8080/browse/VP5-875  BuG the company name in title is incorrect.  Commenting out this code;
   /* if (((window as any).env as IWindow).YourCompany_DispName !== undefined) {
        document.title = 'Data Masons EDI - ' + ((window as any).env as IWindow).YourCompany_DispName;
      }
    */
    this.setCompanyInTitle();

    return (
      <div className="App">
        <IntlProvider locale={settings.locale.locale} messages={settings.messages}>
          <IntlGlobalProvider>
            {this.state.isLoginSuccessful ? this.renderApp() : this.renderLogin()
            }
            <Notifications notifications={this.props.notifications} style={defaultStyle} />
          </IntlGlobalProvider>
        </IntlProvider>
      </div>
    );
  }

  private setCompanyInTitle=()=>{
    const {settings} = this.props
    if(settings && settings.availableCompanies && settings.availableCompanies.length >0){
        document.title = 'Data Masons EDI - ' + this.getSelectedCompany(settings.availableCompanies).YourCompany_DispName;
    }
  }
  private getSelectedCompany=(availableCompanies)=>{
    const selectedCompanyId = Number(sessionStorage[sessCompanyID]) 
    const selected = availableCompanies.find(c=> c.Company_ID === selectedCompanyId)
    return selected ? selected :{Company_ID:1, YourCompany_DispName:""}
}

  // mar testing 11/1/2019
  private resetTimeout() {
    this.stopTimer();
    this.startTimer();
  }

  private stopTimer() {

    // const { logoutWarning, logoutTimeout } = this.state;


    const warning = sessionStorage.getItem(logoutWarning);
    const timeout = sessionStorage.getItem(logoutTimeout);

    if (warning !== null) {
      clearTimeout(parseInt(warning, 10));
    }

    if (timeout !== null) {
      clearTimeout(parseInt(timeout, 10));
    }

    // if (logoutWarning) {
    //   clearTimeout(_logoutWarning)
    // }

    // if (logoutTimeout) {
    //   clearTimeout(logoutTimeout);
    // }

  }

  private startTimer() {

    if (this.state.isLoginSuccessful) {
      const warning = setTimeout(this.timeoutWarning, LOGOUT_WARNING);
      // const timeout = setTimeout(this.logoutUser, MAX_INACTIVITY_TIME);
      const timeout = setTimeout(this.userTimedOut, MAX_INACTIVITY_TIME);

      sessionStorage.setItem(logoutWarning, warning.toString());
      sessionStorage.setItem(logoutTimeout, timeout.toString());

      // this.setState({ logoutWarning, logoutTimeout });
    }
  }

  private timeoutWarning() {
    this.props.NotifyInfo({ message: <FormattedMessage id='Global.InactiveLogout' />, autoDismiss: 15 });
    // console.log("timeoutwarning");
  }

  private userTimedOut() {
    this.logoutUser(true);
  }

  private logoutUser(timedOut: boolean) {
    this.stopTimer();
    // notify user they were logged out due to inactivity on the login screen

    if (timedOut) {
      sessionStorage.setItem(forceLogout, 'inactive');
    } else {
      sessionStorage.setItem(forceLogout, 'upgrade');
    }
    Logout();
  }

  private renderLogin = () => {
    if (this.state.initiateMFA) {
      return <MultiFactorLogin onSuccess={this.SetLoggedIn} loginProps={this.state.loginProps} />
    }
    return <Login onSuccess={this.afterLoginCompleted} />
  }

  private afterLoginCompleted = (dbUpdateNeeded: boolean, noCompanyTable: boolean, forceModal: boolean) => {
    const q: number = window.location.hash.indexOf("?");
    const queryParms: any = queryString.parse(window.location.hash.substring(q));
    if (q > 0 && ((queryParms.withMFA && queryParms.withMFA.toLowerCase() === 'y') || (queryParms.AutoEnroll && queryParms.AutoEnroll.toLowerCase() === 'y'))) {
      this.setState({
        initiateMFA: true,
        loginProps: { dbUpdateNeeded, noCompanyTable, forceModal }
      })
    } else {
      this.SetLoggedIn(dbUpdateNeeded, noCompanyTable, forceModal);
    }
  }
  // If dbUpdateNeeded is true the EDI database needs to have the vpEDI_Update.sql file applied
  // If noCompanyTable is true then we need to do a full initialization in the CompanySettingsView code
  private SetLoggedIn(dbUpdateNeeded: boolean, noCompanyTable: boolean, forceModal: boolean) {
    // Load the Dashboard if we have a Company table and are not forcing a modal Company form
    if (!noCompanyTable && !forceModal) {
      this.reloadData()
    }
    else {
      this.props.permissionsNoCompany();
    };

    // Tell DefaultLayout what to do next (see renderApp())
    this.setState({ isLoginSuccessful: true, dbUpdate: dbUpdateNeeded, noCompany: noCompanyTable, forceCompanyModal: forceModal });
  }

  private setMenuStyleBasedOnSessionVariable = () => {
    if (window.sessionStorage.getItem("HideMenu") === "true" && !document.body.classList.contains("hide-sidebar")) {
      document.body.classList.add("hide-sidebar")
    }
    else if (window.sessionStorage.getItem("CollapseMenu") === "true" && !document.body.classList.contains("sidebar-minimized")) {
      document.body.classList.add("sidebar-minimized");
    }
  }
  private renderApp() {
    if ((this.props.companySetting as ICompanySettingsReducer).reloadCompanyData) {
      this.reloadData();
      (this.props.companySetting as ICompanySettingsReducer).reloadCompanyData = false;  // Just do this once
    }


    const { loading } = this.state;

    // mar 2/11/2020 loading should be true if language is changed (during call to get reactLanguageTerms)
    // once call is complete, loading should be false
    // this allows time to update any override in default language terms
    if (loading) {
      return <LoadingComponent />;
    }


    return <Router history={history}>
      <ScrollToTop>
        <Switch>
          <Route path='/Link' exact={false} name='Redirecting' render={props => <ExternalLink collapseMenu={true} {...props} />} />
          <Route path='/Link2' exact={false} name='Redirecting' render={props => <ExternalLink noMenu={true} {...props} />} />
          <Route path='/route' exact={false} name='Redirecting' render={props => <ExternalLink {...props} />} />
          <Route path='/jsonEdit/:vpid' exact={true} name='EDI Editor' component={JsonEditView} />

          {<Route path='/DocExp' exact={true} name='' render={props => (
            <DocListView {...props} />
          )} />}

          {<Route path='/TradingPartner/:erpid' exact={true} name='' render={props => (
            <TradeView {...props} />
          )} />}

          {<Route path='/shipToErp/:erpid' exact={true} name='' render={props => (
            <ShipToView {...props} />
          )} />}

          {<Route path='/itemXRefErp/:erpid' exact={true} name='' render={props => (
            <ItemXRefList {...props} />
          )} />}

          {<Route path='/CumulativeQuantity/:erpid' exact={true} name='' render={props => (
            <CumulativeQtyView {...props} />
          )} />}

          {<Route path='/PlanningSchedule/:erpid' exact={true} name='' render={props => (
            <PlanningScheduleView {...props} />
          )} />}

          {<Route path='/ProductionSequence/:erpid' exact={true} name='' render={props => (
            <ProductionSequenceView {...props} />
          )} />}

          <Route path="/" name="Home" render={(props) => (
            <DefaultLayout {...this.props} reload={this.reloadData} dbUpdateNeeded={this.state.dbUpdate} noCompanyTable={this.state.noCompany} forceCompanyModal={this.state.forceCompanyModal} />
          )} />
        </Switch>
      </ScrollToTop>
    </Router>
  }

  private reloadData = () => {

    const { isLoginSuccessful } = this.state;

    this.props.loadAllLookup();
    this.props.languageGetAll(this.props.settings.locale);

    // Get the list of companies (with impersonation if isLoginSuccessful)

    if (isLoginSuccessful) {
      this.props.getCompanyListWithImpersonation()
    }
    // else {
    //   this.props.getCompanyList();
    // }
  }
}

const mapStateToProps = ({ settings, loginReducer, rolesAdmin }) => {
  const { loggedInInitials } = loginReducer;
  return { settings, loggedInInitials, rolesAdmin }
};

const mapActionsToProps = {
  languageGetAll,
  getCompanyList,
  getCompanyListWithImpersonation,
  NotifyInfo,
  NotifyError,
  NotifyWarning,
  permissionsNoCompany
};

export default connect(mapStateToProps, mapActionsToProps)(App);
