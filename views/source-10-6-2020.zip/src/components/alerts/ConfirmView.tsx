import * as React from "react";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import { FormattedMessage, } from 'react-intl';
import PageBtnContainer from "./../../components/widgets/PageBtnContainer";
import { IHasPermission, DefaultHasPermission } from '../../constants/RoleAdministration/IRoleAdministration';

export interface IConfirmViewProps {
    message: string,
    action: string,
    isOpen: boolean,
    dismiss: ()=> void,
    confirmed: ()=> void,
    hasPermission: IHasPermission
}

class ConfirmView extends React.Component<IConfirmViewProps, any> {

    public render() {
        const permissions: IHasPermission = this.props.hasPermission ? this.props.hasPermission : DefaultHasPermission();
        
        return (
            <Modal isOpen={this.props.isOpen} toggle={this.props.dismiss}>
                <ModalHeader toggle={this.props.dismiss}><FormattedMessage id="Scheduler.Confirm" /></ModalHeader>
                <ModalBody>
                    {this.props.message}
                </ModalBody>
                <ModalFooter>
                    <PageBtnContainer>
                        <Button disabled={!permissions.EDIT} onClick={() => { this.props.dismiss(); }} ><FormattedMessage id="Global.Action_Cancel" /></Button>
                        <Button disabled={!permissions.EDIT} onClick={() => { this.props.confirmed(); this.props.dismiss(); }}>{this.props.action}</Button>
                    </PageBtnContainer>
                </ModalFooter>
            </Modal>
        )
    };
}

export default ConfirmView;
