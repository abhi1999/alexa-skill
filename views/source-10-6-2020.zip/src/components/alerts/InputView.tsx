import * as React from "react";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import { FormattedMessage, } from 'react-intl';
import PageBtnContainer from "./../../components/widgets/PageBtnContainer";
import { Form, FormGroup, FormFeedback, Label, Col, Input, Row } from 'reactstrap';
import { IHasPermission, DefaultHasPermission } from '../../constants/RoleAdministration/IRoleAdministration';

export interface IInputViewProps {
    message: string,
    isOpen: boolean,
    dismiss: ()=> void,
    inputed: (configName:any)=> void,
    hasPermission: IHasPermission
}

class InputView extends React.Component<IInputViewProps, any> {

    constructor(props: IInputViewProps) {
        super(props);
    
        this.handleInputChange = this.handleInputChange.bind(this);

        this.handleSave = this.handleSave.bind(this);

        this.state = {ConfigName: ""};
      }

    public render() {
        const permissions: IHasPermission = this.props.hasPermission ? this.props.hasPermission : DefaultHasPermission();
        
        return (
            <Modal isOpen={this.props.isOpen} toggle={this.props.dismiss}>
                <ModalHeader toggle={this.props.dismiss}><FormattedMessage id="Scheduler.ConfigSave" /></ModalHeader>
                <ModalBody>
                    <Form>
                    <Row>
                        <Col lg={6} md={6} sm={9}>
                            <FormGroup>
                                <Label for="ConfigName"><FormattedMessage id="Scheduler.ConfigName" /></Label>
                                <Input
                                    id="ConfigName"
                                    value={this.state.ConfigName}
                                    onChange={this.handleInputChange} />
                            </FormGroup>
                        </Col>
                        </Row>
                        </Form>
                </ModalBody>
                <ModalFooter>
                    <PageBtnContainer>
                        <Button disabled={!permissions.EDIT} onClick={() => { this.props.dismiss(); }} ><FormattedMessage id="Global.Action_Cancel" /></Button>
                        <Button disabled={!permissions.EDIT} onClick={() => { this.handleSave(); }}><FormattedMessage id="Global.Action_Save" /></Button>
                    </PageBtnContainer>
                </ModalFooter>
            </Modal>
        )
    };
    
    private handleInputChange(event: any) {

        const target: any = event.target;
        const value: string = target.value;
        const name: string = target.id;

        this.setState({[name]: value});
    }

    private handleSave() {

        const configName = this.state.ConfigName;
        this.props.inputed(configName); 
    }
}

export default InputView;
