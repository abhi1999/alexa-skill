import * as  React from 'react';
import {Button, ButtonDropdown, ButtonGroup, DropdownItem, DropdownMenu, DropdownToggle, } from "reactstrap";
import GridActionMenu from "./../widgets/GridActionMenu";
import { intl } from '../../utils/IntlGlobalProvider';;

interface IAlertViewToggleState{
    isOpen: boolean
    rSelected:string
}
interface IAlertViewToggleProps{
    presets:string[],
    defaultSelection:string,
    onChange:(selected:string)=>void
    fullscreen?:boolean
}
class AlertViewToggle extends React.Component<IAlertViewToggleProps, IAlertViewToggleState>{
    public constructor(props) {
        super(props);
        this.state={isOpen:false, rSelected:this.props.defaultSelection}
        this.toggle = this.toggle.bind(this);
        this.onRadioBtnClick = this.onRadioBtnClick.bind(this);
    }
    public render(){
        return this.props.fullscreen? this.reunderButtonGroup():this.renderActionMenu();
    }

    private reunderButtonGroup(){
        return <ButtonGroup size="sm">
            {this.props.presets.map(p=>
            <Button key={p}  onClick={() => this.onRadioBtnClick(p)} active={this.state.rSelected === p}>
                {intl.formatMessage({ id:'Dashboard.' + p})}
            </Button>)}
      </ButtonGroup>
    }
    private renderActionMenu(){
        return <GridActionMenu className="alert-view-toggle" 
            items={this.props.presets.map(p => p = 'Dashboard.' + p)}
            onItemClick={(item)=>{this.onRadioBtnClick(item) }}/>
    }
    private renderDropdownToggle(){
        return <ButtonDropdown isOpen={this.state.isOpen} className="alert-view-toggle" toggle={this.toggle}>
            <DropdownToggle caret={true} size="sm">
                {this.state.rSelected}
            </DropdownToggle>
            <DropdownMenu>
                {
                    this.props.presets.map(p=>p === this.state.rSelected? "":<DropdownItem key={p} onClick={() => this.onRadioBtnClick(p)}>{p}</DropdownItem>)
                }
            </DropdownMenu>
        </ButtonDropdown>
    }
    private onRadioBtnClick(rSelected:string){
        this.setState({rSelected})
        this.props.onChange(rSelected)
    }
    private toggle(){
        this.setState({isOpen:!this.state.isOpen})
    }
}
export default AlertViewToggle;