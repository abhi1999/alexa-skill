import * as  React from 'react';
import { Table } from 'reactstrap';
import { GetFields } from "../../utils/"
import Chart from "../charts"
import AlertViewToggle from "./AlertViewToggle"

// const presets:string[] = ["Pie", "Doughnut", "Bar", "Table"];
const presets: string[] = ["Pie", "Doughnut", "Bar"];
const defaultSelected: string = "Bar";// "Doughnut";
interface IAlertViewState {
    selected: string
}
interface IAlertViewProps {
    alertId: string;
    data: any;
    setChartType: any;
    chartType: string;
    fullscreen?: boolean
}
class AlertView extends React.Component<IAlertViewProps, IAlertViewState>{
    public constructor(props) {
        super(props);
        // this.state={selected:defaultSelected}
        this.state = { selected: this.props.chartType }
        this.renderChart = this.renderChart.bind(this);
        this.changeChartType = this.changeChartType.bind(this);
    }
    public render() {
        return <React.Fragment>
            {this.renderChart()}
            {this.props.data && this.props.data.length > 0 ?
                // <AlertViewToggle defaultSelection={defaultSelected} presets={presets} onChange={(selected)=>{this.setState({selected})}} fullscreen={this.props.fullscreen}/>
                <AlertViewToggle defaultSelection={this.state.selected} presets={presets}  onChange={(selected) => { this.changeChartType(selected) }} fullscreen={this.props.fullscreen} />
                : ""
            }
        </React.Fragment>
    }
    private renderChart = () => {
        
        switch (this.state.selected) {
            case "Pie":
            case "Dashboard.Pie":
            case "Dashboard.Doughnut":
            case "Doughnut":
                return <Chart data={this.props.data} type={this.state.selected} chartOptions={{ segmentShowStroke: false }} fullscreen={this.props.fullscreen} />;
            case "Dashboard.Bar":
            case "Bar":
                return <Chart data={this.props.data} type={"HorizontalBar"} chartOptions={{ scales: { yAxes: [{ ticks: { display: false } }] } }} fullscreen={this.props.fullscreen} />;
            case "Dashboard.Table":
            case "Table":
                const headers = GetFields(this.props.data);
                return <Table>
                    <tbody>
                        {this.props.data.map((r, i) => <tr key={i}>{headers.map(h => <td key={h}>{r[h]}</td>)}</tr>)}
                    </tbody>
                </Table>
            default:
                return <div>ERROR in AlertView. Incompatible chart type - {this.state.selected}</div>
        }
    }

    private changeChartType(chartType) {
        this.props.setChartType(this.props.alertId, chartType)

        this.setState({
            selected: chartType
        })
    }
}
export default AlertView;