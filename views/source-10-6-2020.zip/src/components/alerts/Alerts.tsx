import { orderBy, cloneDeep } from "lodash";
import * as  React from 'react';
import { DashboardContainer, LoadingOrErrorComponent } from "./../widgets"
import AlertView from "./AlertView"
import { intl } from '../../utils/IntlGlobalProvider';

const defaultChartType: string = "Bar"

interface IAlertsProps {
    alertGroupSet: any[]
    alertGroupDetails: any[],
    alertGroupPresets: any[],

    error: boolean
    loadAlertPresets: () => {}
    setAlertPreset: (groupTile, chartType) => {}
    loading: boolean,
    alertGroupTile?:string
}


class Alerts extends React.Component<IAlertsProps, any>{
    public constructor(props) {
        super(props);
        this.props.loadAlertPresets();
        this.setChartType = this.setChartType.bind(this);
    }
    public render() {
        const { alertGroupDetails, alertGroupSet, alertGroupPresets, alertGroupTile } = this.props;

        // Localize the alert captions
        if (Array.isArray(alertGroupSet)) {
            alertGroupSet.map(ag => {
                switch(ag.Caption.trim()) {
                    case 'Critical alerts':
                    case 'Critical Alerts':
                        ag.Caption = intl.formatMessage({ id:'Dashboard.Alerts'});
                        break;
                    case 'Documents on hold Inbound':
                        ag.Caption = intl.formatMessage({ id:'Dashboard.HoldIn'});
                        break;
                    case 'Documents on hold Outbound':
                        ag.Caption = intl.formatMessage({ id:'Dashboard.HoldOut'});
                        break;
                    case 'Documents ready Inbound':
                        ag.Caption = intl.formatMessage({ id:'Dashboard.ReadyIn'});
                        break;
                    case 'Documents ready Outbound':
                        ag.Caption = intl.formatMessage({ id:'Dashboard.ReadyOut'});
                        break;
                    case 'Work required':
                        ag.Caption = intl.formatMessage({ id:'Dashboard.WorkReq'});  
                        break;
                }
            })
        }
        return <React.Fragment>
            {this.props.loading || this.props.error ? <DashboardContainer {...this.props} colSize={3} 
                headerTitle={''} ><LoadingOrErrorComponent {...this.props} /></DashboardContainer> :
                alertGroupSet.filter(a=> alertGroupTile===undefined || "alert-"+a.GroupTile === alertGroupTile).map(a => {
                    const key= "alert-"+a.GroupTile
                    return <DashboardContainer {...this.props} key={key} colSize={4} headerTitle={a.Caption} badgeText={a.quantity} 
                        fullScreenChildren={<AlertView alertId={a.GroupTile} fullscreen={true} chartType={this.getChartType(a.GroupTile, alertGroupPresets)} setChartType={this.setChartType} data={this.getChartData(a.GroupTile, alertGroupDetails)} {...this.props} />}
                    >
                        <AlertView alertId={a.GroupTile} chartType={this.getChartType(a.GroupTile, alertGroupPresets)} setChartType={this.setChartType} data={this.getChartData(a.GroupTile, alertGroupDetails)} {...this.props} />
                    </DashboardContainer>
                })
            }
        </React.Fragment>
    }
    private getChartData(GroupTile, details) {
        const item = details.find((d) => d.GroupTile === GroupTile)

        if (item && item.values) {
            const data = item.values.map(i => {
                const obj: any = { value: i.Quantity, label: i.Caption, id: i.AlertID }
                return obj;
            })
            return orderBy(data, ['value'], ['desc']);
        }
        return []
    }

    private getChartType(GroupTile, presets) {
        const chartType = presets.find(p => p.GroupTile === GroupTile)

        if (chartType) {
            return chartType.ChartType
        }
        else {
            return defaultChartType
        }
    }

    private setChartType(groupTile, chartType) {
        this.props.setAlertPreset(groupTile, chartType);
    }

}

export default Alerts;
