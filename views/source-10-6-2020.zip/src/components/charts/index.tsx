import * as  React from 'react';
import { Redirect } from "react-router-dom";
import { Bar, Doughnut, HorizontalBar, Line, Pie, Polar, Radar } from 'react-chartjs-2';
import { ChartBackgroundColors, ChartOptions } from "./../../configs/chartOptions"
import ChartViewToggle from "./ChartViewToggle";
import { FormattedMessage } from 'react-intl';
import * as MenuInfo from '../../reducers/businessFlowReducer';

enum views { Chart, Detail }

interface IChartProps {
    data?: any[],
    chartOptions?: any;
    chartSettings?: any,
    chartData?: any
    type?: string
    chartPresets?: string[],
    fullscreen?: boolean
}
interface IChartState {
    data: any,
    view: views,
    formID: string,
}

class Chart extends React.Component<IChartProps, IChartState>{
    private chartRef:any;
    constructor(props) {
        super(props);
        this.state = {
            data: this.getChartData(props),
            view: views.Chart,
            formID: "",
        }
    }
    public componentWillReceiveProps(nextProps) {
        this.setState({ data: this.getChartData(nextProps) })
    }
    public render() {

        const { view, formID } = this.state;

        switch (view) {

            case views.Detail:
                let url = ""
                if (formID !== undefined) {
                    if (formID.startsWith('A')) {
                        // format = {A}sn {direction} {Status} {DGID} - direction is always outbound and we can ignore DGID
                        const status = formID.substring(2, 3);
                        url = MenuInfo.urlAsnAlert.replace(':status', status);
                    }
                    else if (formID.startsWith('P')) {
                        // format = {P}urchase Order {direction} {Status} {DGID} - direction is always inbound and we can igore DGID
                        const status = formID.substring(2, 3);
                        url = MenuInfo.urlPOAlert.replace(':status', status);
                    }
                    else if (formID.startsWith('X')) {
                        // format = {X}mldoc {direction} {Status} {DGID}  example: 'XIHASN'
                        const direction = formID.substring(1, 2);
                        const status = formID.substring(2, 3);
                        const dgid = formID.substring(3, formID.length)
                        url = MenuInfo.urlDocExpAlert.replace(':direction', direction).replace(':dgid', dgid).replace(':status', status).replace(':resolved', 'false');
                    }
                    else if (formID.startsWith('C')) {
                        // format = {C} ({AckList}) {Status} DOC   example: 'C('4','M','R','W','X')YDOC'
                        const start = formID.indexOf('(')
                        const stop = formID.indexOf(')')

                        if (start >= 0 && stop >= 0) {
                            const ackList = formID.substr(start, stop)
                            url = MenuInfo.urlDocExpRejected.replace(':acklist', ackList);
                        }
                    }
                    else {
                        switch (formID) {

                            case 'E1_-4':
                                url = MenuInfo.urlDocumentErrors.replace(':dataKey', 'E1-4');
                                break;

                            case 'E2_4-48':
                                url = MenuInfo.urlDocumentErrors.replace(':dataKey', 'E2-48');
                                break;

                            case 'E3_48-400':
                                url = MenuInfo.urlDocumentErrors.replace(':dataKey', 'E3-400');
                                break;

                            case 'E4_400-':
                                url = MenuInfo.urlDocumentErrors.replace(':dataKey', 'E4-401');
                                break;

                            default:
                                url = "";
                        }
                    }
                }
                if (url !== "") {
                    return <Redirect to={url} push={true} />
                }
                else {
                    // missing redirect for AlertID
                    console.log("AlertID", formID)
                }

            default:

                return <React.Fragment>
                    {this.state.data ?
                        <div className="chart-wrapper">
                            {this.renderChart()}
                        </div>
                        : <FormattedMessage id='Dashboard.NoData' />
                    }
                </React.Fragment>
        }
    }
    private renderChart = () => {
        const type = this.props.type ? this.props.type : "";
        const fullScreenProps: any = {}
        if (this.props.fullscreen) {
            fullScreenProps.height = window.innerHeight > 600 ? 600 : window.innerHeight;
        }
        switch (type.toLowerCase()) {
            case "bar":
            case "dashboard.bar":
                return <Bar ref={(ref)=>this.chartRef=ref} data={this.state.data} getElementsAtEvent={(e) => this.onChartClick(e)} options={{ ...ChartOptions, ...this.props.chartOptions }} {...fullScreenProps} {...this.props.chartSettings} />;
            case "doughnut":
            case "dashboard.doughnut":
                return <Doughnut ref={(ref)=>this.chartRef=ref} data={this.state.data} getElementsAtEvent={(e) => this.onChartClick(e)} options={{ ...ChartOptions, ...this.props.chartOptions }} {...fullScreenProps}{...this.props.chartSettings} />;
            case "polar":
            case "dashboard.polar":
                return <Polar  ref={(ref)=>this.chartRef=ref} data={this.state.data} getElementsAtEvent={(e) => this.onChartClick(e)} options={{ ...ChartOptions, ...this.props.chartOptions }} {...fullScreenProps}{...this.props.chartSettings} />;
            case "radar":
            case "dashboard.radar":
                return <Radar ref={(ref)=>this.chartRef=ref} data={this.state.data} getElementsAtEvent={(e) => this.onChartClick(e)} options={{ ...ChartOptions, ...this.props.chartOptions }} {...fullScreenProps}{...this.props.chartSettings} />;
            case "line":
            case "dashboard.line":
                return <Line ref={(ref)=>this.chartRef=ref} data={this.state.data} getElementsAtEvent={(e) => this.onChartClick(e)} options={{ ...ChartOptions, ...this.props.chartOptions }}  {...fullScreenProps}{...this.props.chartSettings} />;
            case "horizontalbar":
            case "dashboard.horizontalbar":
                return <HorizontalBar ref={(ref)=>this.chartRef=ref} data={this.state.data} getElementsAtEvent={(e) => this.onChartClick(e)} options={{ ...ChartOptions, ...this.props.chartOptions }} {...fullScreenProps} {...this.props.chartSettings} />;
            case "pie":
            default:
                return <Pie ref={(ref)=>this.chartRef=ref} data={this.state.data} getElementsAtEvent={(e) => this.onChartClick(e)} options={{ ...ChartOptions, ...this.props.chartOptions }} {...fullScreenProps}{...this.props.chartSettings} />
        }
    }
    private renderChartViewToggle() {
        const type = this.props.type ? this.props.type : "pie";
        if (this.props.chartPresets && this.props.chartPresets.length > 0) {
            return <ChartViewToggle defaultSelection={type} presets={this.props.chartPresets} onChange={(selected) => { console.log({ selected }) }} />
        }
        return "";
    }
    private getChartData(props) {
        const { data, chartData } = props
        if (chartData !== undefined) {
            return chartData;
        }
        const singleSeriesData: any = { datasets: [{ backgroundColor: ChartBackgroundColors, data: [], hoverBackgroundColor: ChartBackgroundColors }], labels: [] }
        if (props.data && props.data.length > 0) {
            data.forEach((item: any) => { singleSeriesData.datasets[0].data.push(item.value); singleSeriesData.labels.push(item.label) })
            return singleSeriesData;
        }
        return undefined;
    }

    private onChartClick = (elements: any) => {

        if (elements !== undefined) {

            if (elements.length > 0) {
                const index = elements[0]._index;

                if (index !== undefined) {
                    const id = this.props.data === undefined ? "" : this.props.data[index].id;

                    if (id !== "") {
                        this.setState({
                            formID: id,
                            view: views.Detail
                        })
                    }
                }
            }
        }
    }
}

export default Chart;
