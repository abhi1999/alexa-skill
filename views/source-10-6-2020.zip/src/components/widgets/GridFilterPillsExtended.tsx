import * as React from 'react';
import { Button, Tooltip } from 'reactstrap';
import FilterDescriptorExtended from '../../constants/params/filterDescriptorExtended';
import { valueList, nullOrblankList, filterPillsList } from './GridFilterExtended'
import { FormattedMessage } from 'react-intl';
import SearchTerm from '../../languages/SearchTerm';
import { intl } from '../../utils/IntlGlobalProvider';

interface IGridFilterPillsExtendedProps {
    filters: FilterDescriptorExtended[],
    onFilterClear: (newFilter: FilterDescriptorExtended[]) => void
}
interface IGridFilterPillsExtendedState {
    tooltipOpen: string;
}
export default class GridFilterPillsExtended extends React.Component<IGridFilterPillsExtendedProps, IGridFilterPillsExtendedState> {
    public constructor(props) {
        super(props);
        this.state = {
            tooltipOpen: ""
        }
    }
    public render() {
        const { filters } = this.props;
        const filterList =
            filters.map((f) => ((f.value !== undefined && f.value !== '') ||
                valueList.find(operator => operator === f.operator) === undefined ?
                <React.Fragment key={f.id}>
                    <Button className="btn-filter-pill" id={f.id} onClick={() => { this.clearFilter(f.id) }}>
                        {f.displayLabel ? <FormattedMessage id={f.displayLabel} /> : f.id}<i className="fa far fa-times" aria-hidden="true" />
                    </Button>
                    <Tooltip isOpen={this.state.tooltipOpen === f.id} target={f.id} toggle={() => this.toggleToolTip(f.id)}>
                        {/* <SearchTerm term={filterPillsList.find(o => o.id === f.operator)!.value} /> { (f.displayValue === undefined ? f.value : f.displayValue) + (f.toValue !== undefined && f.toValue !== '' ? " and " + f.toValue : "")}  */}
                        {/* <SearchTerm term={filterPillsList.find(o => o.id === f.operator)!.value} /> 
                    <GridFilterToolTip filter={f} /> 
                    {(f.toValue !== undefined && f.toValue !== '' ? " and " + f.toValue : "")}  */}

                        <SearchTerm term={filterPillsList.find(o => o.id === f.operator)!.value} />
                        <React.Fragment>
                            {} {(f.displayValue === undefined ? (Array.isArray(f.value) ? f.value.map(v => v.label).join(',') : this.formatValue(f.value, f)) : this.formatValue(f.displayValue, f))}
                        </React.Fragment>
                        {(f.toValue !== undefined && f.toValue !== '' && f.operator === '..' ? " " + intl.formatMessage({ id: 'Operator.AndBetween' }) + " " + this.formatValue(f.toValue, f) : "")}
                    </Tooltip>
                </React.Fragment>
                : ''))

        return <span className="filter-pills">
            <FormattedMessage id={"Global.Action_Filter"} />:
                {filterList}
            {this.getFilterCount() > 1 ?
                <Button className="btn-filter-pill" onClick={() => { this.clearFilter() }}>
                    <FormattedMessage id='Global.Action_Clear_All' /> <i className="fa far fa-times" aria-hidden="true" />
                </Button>
                : ""}
        </span>
    }

    // Localize any date and boolean filters
    private formatValue(v: any, f: any) {
        if (f.valueType === "date") {
            const parts: string[] = (v as string).split("-");
            const d: Date = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
            return intl.formatDate(d);
        } else if (f.valueType === 'boolean') {
            return (v as string).toLowerCase() === 'true' ? intl.formatMessage({ id: 'Global.True' }) : intl.formatMessage({ id: 'Global.False' });
        } else {
            return v
        }
    }

    private toggleToolTip = (id) => {
        this.setState({ tooltipOpen: this.state.tooltipOpen === id ? "" : id })
    }

    private clearFilter = (id = "") => {
        const filterList: FilterDescriptorExtended[] = [];

        if (id === undefined || id.length === 0) {
            this.props.filters.map(f => {
                f.operator = nullOrblankList.indexOf(f.operator) === -1 ? f.operator : "eq";
                f.value = undefined;
                filterList.push(f);
            })
        }
        else {
            this.props.filters.map(f => f.id === id ? filterList.push(
                {
                    id: f.id, displayLabel: f.displayLabel, operator: nullOrblankList.indexOf(f.operator) === -1 ? f.operator : "eq", valueType: f.valueType, isList: f.isList,
                    value: undefined, toValue: undefined, options: f.options
                })
                : filterList.push(f))
        }
        this.props.onFilterClear(filterList);
    }

    private getFilterCount() {
        let count = 0

        this.props.filters.map((f) => ((f.value !== undefined && f.value !== '') ||
            valueList.find(operator => operator === f.operator) === undefined
            ? count++ : count))

        return count
    }
}