import * as React from 'react';
import {Tooltip} from 'reactstrap';


export default class Anchor extends React.Component<any, any> {
    public constructor (props){
        super(props);
        this.state = {tooltipOpen:false}
    }
    public render(){
        const { className, children, id, tooltipText,  ...rest } = this.props;

        return <React.Fragment>
            <a {...rest} id={id} className={className}>{children}</a>
            {tooltipText!== undefined && id !== undefined?
                <Tooltip placement="bottom" isOpen={this.state.tooltipOpen} target={id} toggle={this.toggleTooltip}>{tooltipText}</Tooltip>
                :""
            }
        </React.Fragment>
    }
    private toggleTooltip = ()=>{ this.setState({tooltipOpen:!this.state.tooltipOpen})}
}