import * as React from 'react';
import classNames from 'classnames';
import {  Collapse } from 'reactstrap';


export default class CollapsePanel extends React.Component<any, any> {
    public constructor (props){
        super(props);
        this.state ={collapse:this.props.initialState === undefined?false:this.props.initialState};
        
    }
    public render(){
        const {enableClickOnTitle, collapseActionAtStart,title,enableOptimizedMode,contentClassName, children, disabled} = this.props;
        const {collapse}= this.state;
        return <React.Fragment>
               <span onClick={()=> {if(enableClickOnTitle){this.toggle()}}} className={classNames({'cursor-pointer':enableClickOnTitle})}> 
                    {collapseActionAtStart?this.renderCollapseLink():""}
                    {title}
                </span>
                {this.renderHeaderButtons()}
                {!enableOptimizedMode || collapse?
                <Collapse in={collapse} timeout={1000} isOpen={collapse} id={"someId-"+title} className={contentClassName}>
                    {children}
                </Collapse>:""}
            </React.Fragment>
    }
    private toggle=()=> {
        if(this.props.disabled){return}
        const collapse = !this.state.collapse;
        if(this.props.onToggle){
            this.props.onToggle(collapse)
        }
        this.setState({ collapse });
    }
    private renderHeaderButtons =() =>{
        const {collapseActionAtStart, headerButtons} = this.props;
        if((collapseActionAtStart=== undefined || collapseActionAtStart ===false ) || headerButtons!== undefined){
            return <div className="card-header-actions">
                    {headerButtons}
                    {collapseActionAtStart=== undefined || collapseActionAtStart ===false ?this.renderCollapseLink():""}
                </div>
        }
        
        return "";
    }
    private renderCollapseLink =() =>{
        return <a className={classNames("collapse-panel-link", "card-header-action", "btn btn-minimize", {disabled:this.props.disabled})} data-target={"someId-"+this.props.title} onClick={this.toggle}><i className={this.state.collapse?"icon-arrow-down":"icon-arrow-right"}/></a>;
    }
}
