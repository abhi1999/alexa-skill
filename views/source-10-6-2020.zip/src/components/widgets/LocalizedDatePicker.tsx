import * as React from "react";
import { intl } from '../../utils/IntlGlobalProvider';
import { ILocaleInformation } from "../../components/LanguageSwitcher/data";
import  * as moment  from 'moment';
import DateTime  from 'react-datetime';
import classnames from 'classnames';
import "react-datetime/css/react-datetime.css";
import 'moment/locale/da';
import 'moment/locale/de';
import 'moment/locale/es';
import 'moment/locale/fi';
import 'moment/locale/fr';
import 'moment/locale/id';
import 'moment/locale/is';
import 'moment/locale/it';
import 'moment/locale/ms';
import 'moment/locale/nl';
import 'moment/locale/pt';
import 'moment/locale/sv';
import 'moment/locale/tl-ph';
import { lsLocale } from 'src/constants';

// Provide a localized Date-only picker

// Example: Date Only
// <LocalizedDatePicker value={companyRecord.SupExp} onChange={(e) => props.handleSupExpChange(e)} />

// Example: Date and Time
// <LocalizedDatePicker value={companyRecord.SupExp} onChange={(e) => props.handleSupExpChange(e)} timeFormat={true}/>

// export interface ILocalizedDatePickerProps {
//    value : Date|undefined| any,   // Date value for the initial display
//    onChange : any,
//    dateFormat : boolean,
//    timeFormat : boolean,
// }



export default class LocalizedDatePicker extends React.Component<any> {
    public constructor (props){
        super(props)
    }
    
    public render() {
        let lang : string | null = localStorage.getItem(lsLocale);
        let fixLang : string;
        if (lang === null) { lang = 'en-US' };

        if (lang === 'tl') {
            fixLang = 'tl-ph';
        } else {
            fixLang = lang;
        }
        moment.locale(fixLang);

        /*
                      value={this.props.value}
                onChange={(e) => this.props.onChange(e)}
                dateFormat={this.props.dateFormat}
                timeFormat={this.props.timeFormat}
  
        */
       const {invalid, inputProps} = this.props;
       
       const {className} = inputProps
        inputProps.className = classnames('form-control',{"is-invalid":invalid},{className:className!==undefined})
       const otherProps ={renderInput:this.renderInput }
        return (
            <DateTime
                locale={fixLang}
                closeOnSelect={true}
                {...this.props}
                {...otherProps}
                inputProps={inputProps}
                className={classnames({"is-invalid":invalid})}
            />);
    }
    private renderInput=( props, openCalendar, closeCalendar )=>{
        const clear=()=>{
            props.onChange({target: {value: ''}});
        }
        const componentProps= this.props
        return (
            <div>
                <input {...props} />
                {props.value !== "" && (componentProps.enableClear === undefined ||  componentProps.enableClear=== true) ? <i className=" datetime-clear fa fa-times" onClick={clear}/>:""}
            </div>
        );
    }
}