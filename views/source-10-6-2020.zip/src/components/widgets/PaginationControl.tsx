import * as React from 'react';
import { Input} from 'reactstrap';
import Paging from "rc-pagination";
import localeInfo from 'rc-pagination/lib/locale/en_US';
import 'rc-pagination/assets/index.css';
import './PaginationControl.css';


export default class PaginationControl extends React.Component<any, any> {
  public constructor(props){
    super(props);
    this.pageSizeChanged = this.pageSizeChanged.bind(this);
  }
  public render(){
    let {pageSize} = this.props
    const {current, total, onChange} = this.props
    if(isNaN(pageSize)){
      pageSize =10;
    }
    let numberOfPages = Math.ceil(total/pageSize);
    if(isNaN(numberOfPages)) {
      numberOfPages=0
    };
    const pageSizeNumber:number = parseInt(pageSize,10)
    return <div className="paging-control">
              {total>0?
                <React.Fragment>
                  <Paging showSizeChanger={false} current={current} pageSize={pageSizeNumber} onChange={onChange} total={total} locale={localeInfo} />
                  <Input type="select" name="select" id="" onChange={this.pageSizeChanged} disabled={numberOfPages===0 || total < 10} value={pageSize}>
                    {this.getPageSizeOptions().map(i=><option key={i} value={i} >{i} / Page</option>)}     
                  </Input>
                </React.Fragment>:""}
            </div>
  }
  private pageSizeChanged(e){
    this.props.onShowSizeChange(1, e.target.value);
  }
  private getPageSizeOptions= ()=>{
    const pageSize = this.props.pageSizeOptions? this.props.pageSizeOptions: [10, 50, 100, 250, 500, 1000, 5000];
    const newPageSize = pageSize.filter((size)=> size <= this.props.total);
    return newPageSize.length=== 0? [pageSize[0]]: this.subarray(pageSize, 0, newPageSize.length +1) 
  }
  private subarray=(array, start,end)=>{
    if(!end){ end=-1;} 
    return array.slice(start, end);
  }
  
}