import * as  React from 'react';
import {Input, Label, Tooltip} from "reactstrap";

export default class ExtendedSwitchToggle extends React.Component<any, any>{
  public constructor (props){
    super(props);
    this.state = {tooltipOpen:false}
    // this.toggleTooltip = this.toggleTooltip.bind(this);
  }
  public render(){
      const {tooltipText, id, placement,...rest} = this.props;
      return <React.Fragment>
        <div className="custom-control custom-switch" id={"div-"+id}>
          <Input type="checkbox" className="custom-control-input" id={id}  {...rest}/>
          <Label className="custom-control-label" for={id} id={'label-'+id} />
        </div>
        {tooltipText!== undefined && tooltipText.length>0 && id !== undefined?
          <Tooltip placement={placement?placement:"right"} fade={true} isOpen={this.state.tooltipOpen} target={"div-"+id} toggle={this.toggleTooltip}>{tooltipText}</Tooltip>
              :""
        }
      </React.Fragment> 
  }
  private toggleTooltip = ()=>{ this.setState({tooltipOpen:!this.state.tooltipOpen})}
}