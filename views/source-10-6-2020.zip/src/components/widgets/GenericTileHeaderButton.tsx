import * as React from 'react';
import {Button,  Modal, ModalHeader, ModalBody, ModalFooter} from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import PageBtnContainer from "./PageBtnContainer";
import classNames from 'classnames';

const TYPES_THAT_REQUIRES_CONFIRMATION =["delete", "trash", "purge"]
const doesRequireModal = (type, text)=>  TYPES_THAT_REQUIRES_CONFIRMATION.indexOf(type)>-1 || (text && text.length>0)

interface IGenericTileHeaderButtonProps{
    onClick:(type?:string)=>void,
    type:string,
    iconClass?:string,
    confirmationText?:string
    className?:string
    disabled?:boolean
}
export default class GenericTileHeaderButton extends React.Component<IGenericTileHeaderButtonProps, any> {
    public constructor (props){
        super(props);
        this.state = {tooltipOpen:false}
    }
    public render(){
        const { children, className, disabled } = this.props;
        const isDisabled = disabled===undefined?false:disabled;
        return <React.Fragment>
                <a  className={classNames("card-header-action  btn",className, {"disabled":isDisabled})} onClick={this.onClick}><i className={classNames(this.getIconClassName())} />{children}</a>
                {this.renderModal()}
            </React.Fragment>
    }
    private getIconClassName = ()=>{
        const { type, iconClass } = this.props;
        let className = '';
        switch(type){
            case "add":
                className="fa fa-plus";
                break;
            case "edit":
                className="fa fa-edit";
                break;
            case "clone":
                className="far fa-clone";
                break;
            case "trash":
            case "delete":
                className="fa fa-trash";
                break;
            case "custom":
                className = iconClass?iconClass:"";
                break;
            case "non-active":
                className="rar fa-circle";
                break
            case "active-off":
                className="far fa-circle";
                break;
            case "active-on":
                className="far fa-check-circle";
                break;
            case "play":
                className="far fa-play-circle";
                break;
            case "pause":
                className="far fa-pause-circle";
                break;
            case "stop":
                className="far fa-stop-circle";
                break;
            default:
                className = "fa fa-bug";
                console.log('Invalid type:', type);
        }
        return className;
    }
    private renderModal=()=>{
        if(doesRequireModal(this.props.type, this.props.confirmationText)){
            return <Modal isOpen={this.state.modalState} toggle={this.toggleModal} autoFocus={false}>
                <ModalHeader toggle={this.toggleModal}><FormattedMessage id='Global.Title_Confirm'/></ModalHeader>
                <ModalBody>
                    {this.state.modelBodyText}
                </ModalBody>
                <ModalFooter>
                    <PageBtnContainer className="no-border">
                        <Button color="primary" onClick={this.proceedWithDelete}><FormattedMessage id='Global.Action_OK'/></Button>{' '}
                        <Button color="secondary" onClick={this.toggleModal}><FormattedMessage id='Global.Action_Cancel'/></Button>
                    </PageBtnContainer>
                </ModalFooter>
            </Modal>
        }
        return "";
    }
    private onClick= ()=>{
        const {type, onClick, confirmationText} = this.props;
        const setConfirmationText=(btnType, text)=>{
            if(text && text.length > 0){
                this.setState({modelBodyText:text})
            }else{
                this.setState({modelBodyText:btnType==='delete'?<FormattedMessage id='Global.Query_Delete'/>:<FormattedMessage id='Global.Query_Purge'/>})
            } 
        }
        if(doesRequireModal(type, confirmationText)){
            setConfirmationText(type, confirmationText)
            this.toggleModal();
        }
        else {
            onClick(type);
        }
    }
    private toggleModal = ()=>{
        this.setState({modalState:!this.state.modalState})
    }
    private proceedWithDelete =()=>{
        this.toggleModal();
        this.props.onClick(this.props.type);
    }

}