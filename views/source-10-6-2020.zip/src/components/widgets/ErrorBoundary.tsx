import * as  React from 'react';

class ErrorBoundary extends React.Component<any, any> {
    public static getDerivedStateFromError(error) {
        // Update state so the next render will show the fallback UI.
        return { hasError: true };
        console.log(error)
      }
  
    public constructor(props) {
      super(props);
      this.state = { hasError: false };
    }
  
  
    public componentDidCatch(error, info) { 
      // You can also log the error to an error reporting service
      // logErrorToMyService(error, info);
      console.log('error',error,info)
    }
  
    public render() {
      if (this.state.hasError) {
        // You can render any custom fallback UI
        return <small>...</small>;
      }
  
      return this.props.children; 
    }
  }

  export default ErrorBoundary;