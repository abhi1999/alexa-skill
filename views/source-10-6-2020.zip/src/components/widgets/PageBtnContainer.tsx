import * as React from 'react';
import classNames from 'classnames';
import { isNullOrUndefined } from 'util';

export default class PageBtnContainer extends React.Component<any> {
    public constructor (props){
        super(props)

        this.localOnKeyDown = this.localOnKeyDown.bind(this);
    }
    public render(){
        const { children, className, ...rest } = this.props;
        return <div className={classNames("btn-container", className)} {...rest} onKeyDown={this.localOnKeyDown}>{children}</div>
    }

    // Grab the Enter and Escape keystrokes and bounce back to caller
    private localOnKeyDown(event) {
        // if (this.props.onKeyDown !== null) { this.props.onKeyDown(event) };
        if (!isNullOrUndefined(this.props.onKeyDown)) { this.props.onKeyDown(event) };
    }
}



// Sample on how to use this in form
// <PageBtnContainer><Button.....></PageBtnContainer>
