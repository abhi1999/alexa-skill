import * as React from 'react';
import {Button, ButtonDropdown, DropdownItem, DropdownMenu, DropdownToggle, Popover, PopoverBody, Modal, ModalHeader, ModalBody, ModalFooter} from 'reactstrap';
import IconButton from "./IconButton";
import uuid from 'uuid-v4';
import PageBtnContainer from "./PageBtnContainer";
import classnames from "classnames"
import { FormattedMessage } from 'react-intl';
import {CopyToClipboard} from 'react-copy-to-clipboard';
import { connect } from "react-redux";
import { NotifyError, NotifyInfo } from "../../actions/Notification";


interface IGridCellWithCopyToClipboardProps{
    cellText:string
    className?:string
    iconClassName?:string
    NotifyInfo:(any)=>void
}

class GridCellWithCopyToClipboard extends React.Component<IGridCellWithCopyToClipboardProps,{}> {
    private iconButtonRef:any;
    public constructor (props){
        super(props)
        this.state = {
        }
        this.iconButtonRef = uuid();
    }
/*<CopyToClipboard text={cellText}}>
                    <IconButton id={"menu-"+this.iconButtonRef} mode="flat" className={classnames("fa  btn-toggle grid-icon",{"fa-clipboard":this.props.iconClassName===undefined},this.props.iconClassName,className)} onClick={()=>{this.copyToClipBoard(cellText)}}/> &nbsp;
                    </CopyToClipboard>
*/
    public render(){
        const {cellText, children, className}= this.props;
        return <React.Fragment>
                {cellText && cellText.length>0?
                <CopyToClipboard text={cellText} onCopy={()=>{this.props.NotifyInfo({message:'Data Copied to Clipboard'})}}>
                   <span title="Copy to Clipboard" className="fa fa-clipboard grid-icon"/>
                </CopyToClipboard>
                :""}
                <span>{cellText}</span>
                {children}
            </React.Fragment>
    }

}

const mapStateToProps = () => {
    return {  }
};

const mapActionsToProps = {
    NotifyInfo
};

export default connect(mapStateToProps, mapActionsToProps)(GridCellWithCopyToClipboard);
