import * as  React from 'react';
import { FadeLoader, RingLoader,PacmanLoader, ScaleLoader,GridLoader, CircleLoader, PropagateLoader, PulseLoader, BounceLoader, MoonLoader} from 'react-spinners';
import { FormattedMessage } from 'react-intl';
/*
<CircleLoader size={100} />
          <FadeLoader height={10} width={2} radius={1} margin="2px" color={'#123abc'}/>
          <GridLoader size={25} />
          <ScaleLoader height={80} width={20} radius={10} margin="2px" color={'#123abc'}/>
          <PacmanLoader size={25} margin="2px"/>
          
          <PropagateLoader size={25} />
          <PulseLoader size={25} margin="2px"/>
          <BounceLoader size={100} color={'#ccc'}/>
<MoonLoader size={100} color={'#ccc'}/>
          <BounceLoader size={100} color={'#2a70ac'}/>
*/

export default class LoadingComponent extends React.Component<any, any>{
  // MOD: KB: 2/11/2020 - Added message prop support
  public constructor(props) {
    super(props);
    this.state = { message: this.props.message === undefined ? '' : this.props.message };    
  }

  public render() {
    const message = this.renderMessage(); 

    return (
      <div>
        <div className='dashboard-component-loading' >
          <FadeLoader height={10} width={2} radius={1} margin="2px" color={'#123abc'} />      
        </div>        
        {message}
      </div>
    )

  }

  protected renderMessage() {
    const message = this.state.message;

    if (message && message.length > 0) {
      return <div style={{ textAlign: 'left' }}><FormattedMessage id={message} /></div>
    } else {
      return null;
    }
  }
}
