import * as React from 'react';
import {ButtonDropdown, DropdownItem, DropdownMenu, DropdownToggle, Tooltip} from 'reactstrap';
import KeyValueLabel from "./../../constants/params/keyValueLabel";
import { FormattedMessage } from 'react-intl';
import { intl } from '../../utils/IntlGlobalProvider';

interface IFormActionGroupProps {
    items?: string[]
    permissions?: boolean[]
    keyValueLabel?: KeyValueLabel[]
    direction?: string
    title?: string
    tooltip?: string
    onItemClick: (item: string) => void
}
interface IFormActionGroupState{
    menuState:boolean
    toolTipIsOpen:boolean
}

export const RecordsSelectedTooltip = (count : number) => {
    return count === 0
    ? ''
    : ( count === 1
        ? intl.formatMessage({ id:'Global.ActionTooltip1'})
        : intl.formatMessage({ id:'Global.ActionTooltip'}).replace('0', count.toString())
    );
}

// Sample on how to use this
// <FormActionGroup items={["Help", "Settings"]} onItemClick={(item)=>console.log(item)}/>
export default class FormActionGroup extends React.Component<IFormActionGroupProps,IFormActionGroupState> {
    public constructor (props){
        super(props)
        this.state = {
            menuState:false,
            toolTipIsOpen:false
        }
        this.tooltipToggle = this.tooltipToggle.bind(this);
    }
    
    public render(){
        const { keyValueLabel, items, children, onItemClick, direction, permissions } = this.props;
        const isEnabled= (index)=>{
            return permissions === undefined || 
            (permissions.length>index && permissions[index])
        }        
        let { title } = this.props;
        if (title === undefined) { title = 'Global.Action_Actions'};
        return <ButtonDropdown className="form-action-group" direction={direction?direction:"left"}
                    isOpen={this.state.menuState} toggle={()=>{this.setState({menuState:!this.state.menuState})}}
                    id='btnFormActionGroup'
                >
                    <Tooltip placement='top' target='btnFormActionGroup' isOpen={this.state.toolTipIsOpen} toggle={this.tooltipToggle}>{this.props.tooltip}</Tooltip>
                    <DropdownToggle caret={false} className="fa fa-bars btn-toggle"><span><FormattedMessage id={title} /></span></DropdownToggle>
                    <DropdownMenu>
                        { items ===undefined?"":
                            items.map((i:string, index)=>{
                                return <DropdownItem key={i} disabled={!isEnabled(index)} onClick={() => {this.setState({menuState:!this.state.menuState}); onItemClick(i)}}><FormattedMessage id={i} /></DropdownItem>
                              
                                    })
                        }
                        { keyValueLabel ===undefined?"":
                            keyValueLabel.map((i:KeyValueLabel, index)=>{
                                return <DropdownItem key={i.key} disabled={!isEnabled(index)} onClick={() => {this.setState({menuState:!this.state.menuState}); onItemClick(i.value)}}>{i.label}</DropdownItem>
                            })
                        }
                        { children }
                    </DropdownMenu>
                </ButtonDropdown>
    }

    private tooltipToggle() {
        this.setState({ toolTipIsOpen : !this.state.toolTipIsOpen && (this.props.tooltip !== undefined && this.props.tooltip !== '') })
    }
}