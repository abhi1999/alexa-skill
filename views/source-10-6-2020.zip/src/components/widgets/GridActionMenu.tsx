import * as React from 'react';
import {Button, ListGroup, ListGroupItem, Popover, PopoverBody, Modal, ModalHeader, ModalBody, ModalFooter} from 'reactstrap';
import IconButton from "./IconButton";
import uuid from 'uuid-v4';
import PageBtnContainer from "./PageBtnContainer";
import classnames from "classnames"
import { FormattedMessage } from 'react-intl';

interface IGridActionMenuProps{
    items: Array<{key:string,confirmationText?:string}| string | {type:string, category:string}> ,
    permissions?:boolean[],
    className?:string
    onItemClick:(item:string)=>void
    mode?:string
    iconClassName?:string
}

interface IGridActionMenuState{
    actionMenuState:boolean
    modalState:boolean
    itemClicked:string
    modelBodyText?:any
}

export default class GridActionMenu extends React.Component<IGridActionMenuProps,IGridActionMenuState> {
    private iconButtonRef:any;
    public constructor (props){
        super(props)
        this.state = {
            actionMenuState:false,
            modalState:false,
            itemClicked:''
        }
        this.iconButtonRef = uuid();
        this.handleKeyDown = this.handleKeyDown.bind(this);
    }
    public componentDidUpdate() {
        const btnDelete : any = document.getElementById('btnDelete');
        if (btnDelete !== null) { btnDelete.focus() };
    }
    public render(){
        const {items, children, className, permissions}= this.props;
        return <React.Fragment>
                    <IconButton id={"menu-"+this.iconButtonRef} mode={this.props.mode} 
                        className={classnames("fa  btn-toggle",{"fa-bars":this.props.iconClassName===undefined},this.props.iconClassName,className)} 
                        onClick={()=>{this.setState({actionMenuState:!this.state.actionMenuState})}}
                        disabled={items === undefined || items === null || items.length === 0}/>
                    <Popover className={classnames("action-menu" )} placement="auto" isOpen={this.state.actionMenuState} target={"menu-"+this.iconButtonRef} toggle={()=>{this.setState({actionMenuState:!this.state.actionMenuState})}}>
                        <PopoverBody>
                        {
                            this.renderButtons(items,permissions)
                        }
                        {children}
                        </PopoverBody>
                    </Popover>
                    <Modal isOpen={this.state.modalState} autoFocus={false}>
                        <ModalHeader><FormattedMessage id='Global.Title_Confirm'/></ModalHeader>
                        <ModalBody>
                            {this.state.modelBodyText}
                        </ModalBody>
                        <ModalFooter>
                            <PageBtnContainer className="no-border"  onKeyDown={this.handleKeyDown}>
                                <Button id='btnDelete' color="primary" onClick={this.proceedWithDelete}><FormattedMessage id='Global.Action_OK'/></Button>{' '}
                                <Button color="secondary" onClick={this.modalClose}><FormattedMessage id='Global.Action_Cancel'/></Button>
                            </PageBtnContainer>
                        </ModalFooter>
                    </Modal>
            </React.Fragment>
    }
    private renderButtons=(items, permissions)=>{
        const isEnabled= (index)=>{
            return permissions === undefined || 
            (permissions.length>index && permissions[index])
        }
        const renderItems :any[] =[];
        const categoryButtons :any[]= [];
        (items as any[]).forEach((i:any, index)=>{
            if(typeof i ==="string"){
                renderItems.push(<Button disabled={!isEnabled(index)} block={true} key={index} onClick={()=>this.menuButtonClick(i)}><FormattedMessage id={i} /></Button>)
            }
            else if(i.category !== undefined && i.type !== undefined){
                const btn =<Button disabled={!isEnabled(index)} block={true} key={index} onClick={()=>this.menuButtonClick(i.type)}><FormattedMessage id={i.type} /></Button>
                const categoryFromArray = categoryButtons.find(c=> c.category  === i.category);
                if(categoryFromArray){
                    categoryFromArray.items.push(btn)
                }
                else{
                    const newCategory = {category:i.category , items:[btn]};
                    categoryButtons.push(newCategory)
                    renderItems.push({category:i.category})
                }
            }
            else if (i.key!== undefined){ 
                renderItems.push(<Button disabled={!isEnabled(index)} block={true} key={index} onClick={()=>this.menuButtonClick(i)}>{i.key}</Button>)
            }
        });
        return renderItems.map((i, index)=>{
            if(i && i.category){
                const categoryItems=categoryButtons.find(c=> c.category === i.category)
                return <div key={'category-'+index} className="grid-action-menu-category"> <span className="category-title">{i.category}</span>{categoryItems.items}</div>
            }
            return i
        })
    }
    private handleKeyDown(event) {
        if (event.key === 'Escape') { this.modalClose() };
    }

    private menuButtonClick=(item)=>{
        this.setState({itemClicked:item, actionMenuState:!this.state.actionMenuState})
        if( (typeof item === "string" && item === "Global.Action_Delete") || (item.confirmationText && item.confirmationText.length>0)) {
            const modelBodyText = (item.confirmationText && item.confirmationText.length>0)
                ?item.confirmationText:<FormattedMessage id='Global.Query_Delete'/>;
            this.setState({modelBodyText})
            this.toggleModal();
        } else if ((typeof item === "string" && item === "Global.Action_Purge") || (item.confirmationText && item.confirmationText.length>0)) {
            const modelBodyText = (item.confirmationText && item.confirmationText.length>0)
                ?item.confirmationText:<FormattedMessage id='Global.Query_Purge'/>;
            this.setState({modelBodyText})
            this.toggleModal();
        }
        else{
            this.props.onItemClick(item);
        }
    }
    private modalClose = ()=>{
        this.setState({modalState:false})
    }
    private toggleModal = ()=>{
        this.setState({modalState:!this.state.modalState})
    }
    private proceedWithDelete =()=>{
        this.modalClose();
        this.props.onItemClick(this.state.itemClicked);
    }
}