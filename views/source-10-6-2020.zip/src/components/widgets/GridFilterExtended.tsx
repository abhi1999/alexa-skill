import * as React from 'react';
import { Badge, Button, Input, Popover, PopoverHeader, PopoverBody } from 'reactstrap';
import FilterDescriptorExtended from '../../constants/params/filterDescriptorExtended';
import { remove, cloneDeep } from 'lodash';
import IconButton from "./IconButton";
import PageBtnContainer from "./PageBtnContainer";
import KeyValueLabel from '../../constants/params/keyValueLabel';
import { kAll, kTrue, kFalse } from '../../utils/Comparison';
import { NumericOnly } from '../../utils/UIValidation';
import  moment from 'moment';
import { NotifyError, NotifyInfo } from "../../actions/Notification";
import { connect } from "react-redux";
import { StringChecker} from '../../utils/Conversion';
import Anchor from "./../../components/widgets/AnchorWIthToolTip";

import DateTime from './LocalizedDatePicker';
import "react-datetime/css/react-datetime.css";
import { FormattedMessage } from 'react-intl';
import { intlShape, injectIntl } from 'react-intl';
import { intl } from '../../utils/IntlGlobalProvider';

// sample {type:'text', label:'ID' name:'xxx', placeholder:'', returnType:'number'}
import GridFilterItemContainer from "./GridFilterItemContainer";
import Select from 'react-select';

const stringOperatorList = [
    { id: "eq", value: "Operator.Equals" },
    { id: "ne", value: "Operator.Not_Equals" },
    { id: "contains", value: "Operator.Contains" },
    { id: "in", value: "Operator.In" },
    { id: "starts", value: "Operator.Starts_With" },
    { id: "ends", value: "Operator.Ends_With" },
    { id: "null", value: "Operator.Null" },
    { id: "!null", value: "Operator.Not_Null" },
    { id: "empty", value: "Operator.Empty" },
    { id: "!empty", value: "Operator.Not_Empty" },
    { id: "blank", value: "Operator.Blank" },
    { id: "!blank", value: "Operator.Not_Blank" },
]

const numberOperatorList = [
    { id: "eq", value: "Operator.Equals" },
    { id: "ne", value: "Operator.Not_Equals" },
    { id: "in", value: "Operator.In" },
    { id: "gt", value: "Operator.Greater_Than" },
    { id: "ge", value: "Operator.Greater_Than_Equal" },
    { id: "lt", value: "Operator.Less_Than" },
    { id: "le", value: "Operator.Less_Than_Equal" },
    { id: "..", value: "Operator.Between" },
    { id: "null", value: "Operator.Null" },
    { id: "!null", value: "Operator.Not_Null" },
]

const operatorList = [
    { id: "eq", value: "Operator.Equals" },
    { id: "ne", value: "Operator.Not_Equals" },
    { id: "gt", value: "Operator.Greater_Than" },
    { id: "ge", value: "Operator.Greater_Than_Equal" },
    { id: "lt", value: "Operator.Less_Than" },
    { id: "le", value: "Operator.Less_Than_Equal" },
    { id: "..", value: "Operator.Between" },
    { id: "null", value: "Operator.Null" },
    { id: "!null", value: "Operator.Not_Null" },
]

const singleOperatorList = [
    { id: "single", value: "Operator.Equals" },
]

const multiSelectOperatorList = [
    { id: "in", value: "Operator.In" },
    { id: "not in", value: "Operator.NotIn" },
]

const ynErrorOperatorList = [
    { id: "eq", value: "Operator.Equals" }
]

export const filterPillsList = [
    { id: "eq", value: "Operator.Equals" },
    { id: "single", value: "Operator.Equals" },
    { id: "ne", value: "Operator.Not_Equals" },
    { id: "contains", value: "Operator.Contains" },
    { id: "in", value: "Operator.In" },
    { id: "not in", value: "Operator.NotIn" },
    { id: "starts", value: "Operator.Starts_With" },
    { id: "ends", value: "Operator.Ends_With" },
    { id: "gt", value: "Operator.Greater_Than" },
    { id: "ge", value: "Operator.Greater_Than_Equal" },
    { id: "lt", value: "Operator.Less_Than" },
    { id: "le", value: "Operator.Less_Than_Equal" },
    { id: "..", value: "Operator.Between" },
    { id: "null", value: "Operator.Null" },
    { id: "!null", value: "Operator.Not_Null" },
    { id: "empty", value: "Operator.Empty" },
    { id: "!empty", value: "Operator.Not_Empty" },
    { id: "blank", value: "Operator.Blank" },
    { id: "!blank", value: "Operator.Not_Blank" },
]

export const valueList = ["eq", "single", "ne", "contains", "in", "not in", "starts", "ends", "gt", "ge", "lt", "le", ".."]
export const nullOrblankList = ["null", "!null", "empty", "!empty", "blank", "!blank"]

/*
  example of multi select
    { id:XDatabase.Field_VersionId, displayLabel:XDatabase.Label_VersionId, operator:"contains", valueType:"miltiselect", isList:false, value:undefined, toValue:undefined,
      options:[{ value: 'value1', label: 'display 1' },
      { value: 'value2', label: 'display 2' },
      { value: 'value3', label: 'display 3' }]
    }, 
 */
// For Boolean dropdown filters
export const booleanTypes: KeyValueLabel[] = [
    new KeyValueLabel({ key: "", value: '', label: intl.formatMessage({ id: 'Global.All'}) }),
    new KeyValueLabel({ key: kTrue, value: true, label: intl.formatMessage({ id: 'Global.True'}) }),
    new KeyValueLabel({ key: kFalse, value: false, label: intl.formatMessage({ id: 'Global.False'}) })
];

export const yesNoTypes : KeyValueLabel[] = [
    new KeyValueLabel({ key: "", value: '', label: intl.formatMessage({ id: 'Global.All'}) }),
    new KeyValueLabel({ key: 'Y', value: 'Y', label: 'Y' }),
    new KeyValueLabel({ key: 'N', value: 'N', label: 'N' }) 
];

export const ynErrorTypes = [
    new KeyValueLabel({ key: "", value: '', label: intl.formatMessage({ id: 'Global.All'}) }),
    new KeyValueLabel({ key: 'N', value: intl.formatMessage({ id: 'Global.NoError'}), label: intl.formatMessage({ id: 'Global.NoError'}) }),
    new KeyValueLabel({ key: 'Y', value: intl.formatMessage({ id: 'Global.HasError'}), label: intl.formatMessage({ id: 'Global.HasError'}) }) 
]



interface IGridFilterExtendedProps {
    filters: FilterDescriptorExtended[],
    onApply: (newFilter: FilterDescriptorExtended[]) => void
    onDirtyFilterChange?: (newFilter: FilterDescriptorExtended[]) => void
    onCancel?:()=>void
    filterKey?:string,
    targetRoute?:string,
    intl: intlShape.isRequired,
    NotifyInfo:(notifyObj:any)=>void
}
interface IGridFilterExtendedState {
    isOpen: boolean
    filtersDirtyState: FilterDescriptorExtended[]
}

class GridFilterExtended extends React.Component<IGridFilterExtendedProps, IGridFilterExtendedState> {

    public constructor(props) {
        super(props)
        this.state = {
            isOpen: false,
            filtersDirtyState: props.filters,
        }
    }

    public componentWillReceiveProps(props) {
        this.setState({ filtersDirtyState: cloneDeep(props.filters) })
    }

    public render() {
        const { filters } = this.props;
        const { isOpen, filtersDirtyState } = this.state;
        const count = this.getFilterCount(filters)

        return <React.Fragment>
            <IconButton id="filterBtn" className="fa fa-filter" active={this.isFilterSelected()}
                onClick={() => {
                    if (!isOpen) {
                        this.setState({ filtersDirtyState: cloneDeep(filters) })
                    }
                    this.setState({ isOpen: !isOpen })
                }} iconText={'Global.Action_Filter'} />
            {count > 0 ? <Badge className="filter-pills-badge" color="secondary">{count}</Badge> : ""}
            {this.renderPopover()}
        </React.Fragment>
    }
    private renderCopyRouteToClipboard = () =>{
        // return "";
        const {filterKey, targetRoute} = this.props;
        if(StringChecker(filterKey)!==""&& StringChecker(targetRoute) !== "" && navigator && navigator.clipboard && navigator.clipboard.writeText){
            return  <div className ="header-btn">
                <IconButton id="filterCopy" className="fa fa-clipboard" iconText="Copy Route" active={false} onClick={()=>{
                    this.copyFilterStateToClipboard()
                }}/>
             </div>
        }
        return null
    }
    private renderCopyRouteToClipboardAccordian = () =>{
        const {filterKey, targetRoute} = this.props;
        if(StringChecker(filterKey)!==""&& StringChecker(targetRoute) !== "" && navigator && navigator.clipboard && navigator.clipboard.writeText){
            return  <GridFilterItemContainer initialOpenState={false} 
                    key={'filterAccordian'} label={"Copy Route"} value={""} toValue={""} f={{}}>
                        <div className="header-btn copy-route"><IconButton id="filterCopy" className="" iconText="Copy Route" active={false} onClick={()=>{
                            this.copyFilterStateToClipboard()
                        }}/></div>
            </GridFilterItemContainer>  
        }
        return null
    }
    private renderCopyRouteToClipboardLink = () =>{
        const {filterKey, targetRoute} = this.props;
        if(StringChecker(filterKey)!==""&& StringChecker(targetRoute) !== "" && navigator && navigator.clipboard && navigator.clipboard.writeText){
            return  <Anchor href="#" id="filterCopyLink" className="filter-copy-route-link" 
                        onClick={(e)=>{
                            this.copyFilterStateToClipboard()
                            e.preventDefault()
                        }}>
                    Copy Route
                </Anchor>
        }
        return null
    }
    private copyFilterStateToClipboard = ()=>{
        const { filtersDirtyState } = this.state;
        const {filterKey, targetRoute} = this.props;
        const filter = filtersDirtyState.filter(f=> f.value!== undefined  && f.value !== '').map(f=>({id:f.id, value:f.value, operator:f.operator, toValue:f.toValue}));
        console.log('copying filter string to clipboard', filter);
        const filterString = filter.map(f=> {
            const val = Array.isArray(f.value)? f.value.map(v=>v.value).join('__'):f.value
            const toValue = f.toValue? (Array.isArray(f.toValue)? f.toValue.map(v=>v.value).join('__'):f.toValue):undefined
            let retString= f.id+'~'+f.operator+'~'+encodeURIComponent(val);
            if(toValue !== undefined){retString =retString + '~' +encodeURIComponent(toValue)}
            return retString;
        }).join('|')
        const isSideBarMinimized = document.body.classList.contains('sidebar-minimized');
        let baseRoute = window.location.origin+"/#/route?target="
        if(isSideBarMinimized){
            baseRoute =window.location.origin+"/#/Link?target="
        }
        const route =baseRoute+targetRoute + "&filterKey="+ filterKey + "&filter="+filterString;
        // const route =window.location.origin+"/#/route?target="+targetRoute + "&filterKey="+ filterKey + "&filter="+encodeURIComponent(JSON.stringify(filter));
        (navigator as any).clipboard.writeText(route);
        this.props.NotifyInfo({message:"Route copied to the clipboard."})
    }
    private renderFilterTypeDropDown = (f) => {
        const filterTypeDropDownOptions = this.filterTypeDropDownOptions(f)
        return <Input type="select"
            disabled={f.valueType === 'boolean' || f.operator === 'single' ? true : false}
            value={f.operator}
            onChange={(e) => this.handleFieldChange(f.id, "operator", e.target.value)}
        >
            { 
                filterTypeDropDownOptions.map((option) => <option key={option.id} value={option.id}>{this.props.intl.formatMessage({ id: option.value })}</option>) 
            }
        </Input>
    }
    private filterTypeDropDownOptions = (f) =>{
        if (f.operator === 'single'){
            return singleOperatorList;
        }

        switch(f.valueType){
            case "string":
            case "guid":
                return stringOperatorList;
            case "number":
                return numberOperatorList;
            case "multiselect":
                return multiSelectOperatorList;
            default:
                return operatorList;
        }
        /*
        (f.valueType === 'string' || f.valueType === 'guid' ?
                stringOperatorList.map((option) => <option key={option.id} value={option.id}>{this.props.intl.formatMessage({ id: option.value })}</option>)
                :
                 (f.valueType === 'number' ? 
                    numberOperatorList.map((option) => <option key={option.id} value={option.id}>{this.props.intl.formatMessage({ id: option.value })}</option>)
                    :
                    ( f.valueType === 'ynstring' ?
                        ynErrorOperatorList.map((option) => <option key={option.id} value={option.id}>{this.props.intl.formatMessage({ id: option.value })}</option>)
                        : 
                        (                    
                            operatorList.map((option) => <option key={option.id} value={option.id}>{this.props.intl.formatMessage({ id: option.value })}</option>)
                        )
                    )
                 )
        */           
    }
    private renderListForEqualToOrNonEqual = (f) => {
        if (f.isList) {
            if (f.operator === 'eq' || f.operator ==='single' || f.operator === 'ne') {
                return <Input type="select"
                    value={f.value}
                    onChange={(e) => this.handleFieldChange(f.id, "value", e.target.value)}
                >
                    {/* { (f.isList === 1 ? f.options : f.options.map((option) => <option key={option.key} value={option.value}>{option.label}</option>))} */}
                    {f.options}
                </Input>;
            }
            else {
                return this.renderTextFilter(f);
            }
        }
        return "";
    }
    private renderTextFilter = (f, prop = "value") => {
        return <Input autoComplete="off" disabled={(valueList.find(operator => operator === f.operator) === undefined ? true : false)}
            id={f.id} value={f[prop] === undefined ? "" : f[prop]} onChange={(e) => this.handleFieldChange(f.id, prop, e.target.value)} 
                onKeyPress={this.handleKeyPress}/>
    }
    private renderMultiSelectValue=(f, prop = "value") => {
        // let v;
        // if (Array.isArray(f.value)) {
        //     f.value.map(fv => {
        //         if (fv.value === '') { v = "" } // Selecting All clears the existing entries
        //         }
        //     );  
        // }
        
        return <div className="grid-filter-with-padding">
                <Select
                    // value={v}
                    className="react-select"
                    placeholder={intl.formatMessage({ id: 'Global.SelectPlaceholder'})}
                    isMulti={true}
                    closeMenuOnSelect={false}
                    defaultValue={f.value}
                    onChange={(selectedOptions)=>this.handleMultiSelectChange(selectedOptions, f)}
                    options={f.options}
                />
            </div>
    }

    private handleMultiSelectChange=(selectedOptions, filter)=>{
        this.handleFieldChange(filter.id, "value", selectedOptions.length === 0 ? '': selectedOptions)
    }

    private renderDateTypeFilter = (f, prop = "value", dateFormat: boolean | string = "MM/DD/YYYY", timeFormat: boolean | string = false, filterDataFormat: string = "YYYY-MM-DD") => {
        const dateTimeOptions = {
            dateFormat, // 'MM/DD/YYYY',
            timeFormat, // false,// 'HH:mm A',
            input: true,
            utc: false,
            closeOnSelect: true,
            closeOnTab: true,
            inputProps: { readOnly: true }
        }
        if (f.valueType === "dateonly" || f.valueType === "date" || f.valueType === "datetime" || f.valueType === "time") {
            return <DateTime
                value={moment(f[prop], filterDataFormat)}
                onChange={(date: moment.Moment) => {
                    if (date === undefined || date.isValid === undefined || !date.isValid()) { return; }
                    const val = date.format(filterDataFormat); this.handleFieldChange(f.id, prop, val)
                }}
                {...dateTimeOptions}
            />
        }
        return "";
    }
    private renderFirstFilterControl = (f) => {
        if(f.valueType === "multiselect"){
            return this.renderMultiSelectValue(f);
        }
        else if (f.isList) {
            return this.renderListForEqualToOrNonEqual(f);
        }
        else {
            switch (f.valueType) {
                case "date":
                    return this.renderDateTypeFilter(f);
                case "dateonly":
                    return this.renderDateTypeFilter(f);
                case "time":
                    return this.renderDateTypeFilter(f, "value", false, 'hh:mm A', 'hh:mm A');
                case "datetime":
                    return this.renderDateTypeFilter(f, "value", "MM/DD/YYYY", 'hh:mm A', "MM/DD/YYYY hh:mm A");
                default:
                    return this.renderTextFilter(f);
            }
        }
    }
    private renderSecondFilterControl = (f) => {
        if (f.operator === "..") {
            switch (f.valueType) {
                case "date":
                    return this.renderDateTypeFilter(f, "toValue");
                case "dateonly":
                    return this.renderDateTypeFilter(f, "toValue");
                case "time":
                    return this.renderDateTypeFilter(f, "toValue", false, 'hh:mm A', 'hh:mm A');
                case "datetime":
                    return this.renderDateTypeFilter(f, "toValue", "MM/DD/YYYY", 'hh:mm A', "MM/DD/YYYY hh:mm A");
                case "multiselect":
                    return <div/>
                default:
                    return this.renderTextFilter(f, "toValue");
            }
        }
        return "";
    }
    private renderPopover = () => {
        const { filters } = this.props;
        const { isOpen, filtersDirtyState } = this.state;
        const count = this.getFilterCount(filtersDirtyState)
        
        return (
            <Popover placement="left-end" isOpen={isOpen} target="filterBtn" toggle={() => this.setState({ isOpen: !isOpen })} className="filter-popover filter-popover-extended2">
                <PopoverHeader className="filter-popover">
                        <FormattedMessage id='Global.Action_Filter' />
                        {/*this.renderCopyRouteToClipboard()*/}
                </PopoverHeader>
                <PopoverBody>
                    {filtersDirtyState.map((f, i) => {
                        return <GridFilterItemContainer initialOpenState={filtersDirtyState.length < 2 ? true : false} 
                            key={i} label={f.displayLabel} value={f.value} toValue={f.operator === ".." ? f.toValue : ''} f={f}>
                            {this.renderFilterTypeDropDown(f)}
                            {this.renderFirstFilterControl(f)}
                            {f.operator === ".." ? "To" : ''}
                            {this.renderSecondFilterControl(f)}
                        </GridFilterItemContainer>
                    })}
                    {/*this.renderCopyRouteToClipboardAccordian()*/}
                    <PageBtnContainer>
                        <Button color="primary" onClick={this.handleFilterApply}><FormattedMessage id='Global.Action_Apply' /></Button>
                        <Button color="secondary" onClick={this.handleFilterCancel}><FormattedMessage id='Global.Action_Cancel' /></Button>
                        {this.renderCopyRouteToClipboardLink()}
                    </PageBtnContainer>
                </PopoverBody>
            </Popover>
        )
    }

    private handleKeyPress = (e) => {
        if (e.charCode === 13) {
            this.handleFilterApply();
        }
    }

    private isFilterSelected = (): boolean => {
        return this.props.filters && this.props.filters.filter(f => f.value !== undefined && f.value !== '').length > 0
    }
    private handleFieldChange(id, field, value) {
        const filter = this.state.filtersDirtyState.find(item => item.id === id);
        // get display value for lists
        if (field === "value") {
            if (filter!.isList) {
                const index = filter!.options.findIndex((i) => i.key === value);
                if (index >= 0) {
                    if (Array.isArray(filter!.options[index].props.children)) {
                        filter!.displayValue = filter!.options[index].props.children[0];
                    }
                    else {
                        filter!.displayValue = filter!.options[index].props.children;
                    }
                }
            }
        }

        let newValue = value;

        if (filter !== undefined) {

            // verify numeric fields are entered correctly - exception is 'in' operator (comma separated list)
            if (field === "value" || field === "toValue") {
                if (filter.valueType === "number" && filter.operator !== 'in') {
                    newValue = NumericOnly(value);
                }
            }

            filter[field] = newValue;

            // set value to '' for null or blank filters
            if (field === 'operator') {
                if (nullOrblankList.find(operator => operator === value) !== undefined) {
                    filter.value = ''
                }
            }

            this.setState({
                filtersDirtyState: this.state.filtersDirtyState.map((f) =>
                    f.id === id ? filter : f)
            },()=>{ 
                if(this.props.onDirtyFilterChange) {
                    this.props.onDirtyFilterChange(this.state.filtersDirtyState)
                }
            }
            )
           
        }
    }

    private getFilterCount(filters: FilterDescriptorExtended[]) {
        let count = 0

        filters.map((f) => ((f.value !== undefined && f.value !== '') ||
            valueList.find(operator => operator === f.operator) === undefined
            ? count++ : count))

        return count
    }

    private getValueForFilter = (id) => {
        const item = this.state.filtersDirtyState.find(f => f.id === id);
        return item ? item.value : undefined;
    }
    // private handleFilterDirtyChange = (id, operator, valueType, value, toValue?, displayValue?, displayLabel?) => {
    //     const filtersDirtyState = this.state.filtersDirtyState;
    //     let item = filtersDirtyState.find(f => f.id === id)
    //     if (item !== undefined) {
    //         item.value = value;
    //     } else {
    //         item = { id, operator, value, valueType, toValue, displayValue, displayLabel }
    //         filtersDirtyState.push(item);
    //     }
    //     if (displayValue) {
    //         item.displayValue = displayValue;
    //     }
    //     remove(filtersDirtyState, (f) => f.value === undefined || f.value.length === 0)
    //     this.setState({ filtersDirtyState });
    // }
    private handleFilterApply = () => {
        const filtersDirtyState: FilterDescriptorExtended[] = this.state.filtersDirtyState;
        // filtersDirtyState.forEach(f => {
        //     const filterItem = this.props.filterItems.find((fi: any) => fi.name === f.id);
        //     if (filterItem && filterItem.returnType === "number") {
        //         f.value = parseInt(f.value, 10);
        //     }
        //     else if (filterItem && filterItem.returnType === "boolean") {
        //         if (Boolean(f.value.toLowerCase())) {
        //             f.value = (f.value.toLowerCase() === "true")
        //         }
        //         else {
        //             f.value = undefined;
        //         }
        //     }
        // });
        // filtersDirtyState.filter(f=> f.defaultValue !== undefined).forEach(f=> f.value = f.defaultValue)
        remove(filtersDirtyState, (f) => f.value === undefined)

        this.setState({ isOpen: false }, () => {
            this.props.onApply(filtersDirtyState);
        })
    }
    private handleFilterCancel = () => {
        this.setState({ isOpen: false })
        if(this.props.onCancel){this.props.onCancel()}
    }
}

// export default injectIntl(GridFilterExtended);


const mapStateToProps = (state, ownProps) => {
    return { ...ownProps}
};
  
const mapActionsToProps = {
    NotifyError, NotifyInfo
};
  
export default connect(mapStateToProps, mapActionsToProps)(injectIntl(GridFilterExtended));

  // export default connect(mapStateToProps, mapActionsToProps)(TaskListView);