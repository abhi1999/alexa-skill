import * as React from 'react';
import classNames from 'classnames';
import { Badge, Card, CardBody, CardFooter, CardHeader, CardSubtitle, CardTitle, Col, Collapse, Fade, Row } from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import SearchTerm from '../../languages/SearchTerm'
import { valueList, filterPillsList } from './GridFilterExtended'


interface IGridFilterItemContainerProps{
    label?:string
    className?:string
    value?:any
    toValue?:any,
    f:any,
    initialOpenState?:boolean
}
interface IGridFilterItemContainerState{
    collapse:boolean
    timeout:number
    fadeIn:boolean
}
export default class GridFilterItemContainer extends React.Component<IGridFilterItemContainerProps,IGridFilterItemContainerState> {
    public constructor (props){
        super(props);
        this.state={collapse:this.props.initialOpenState ?this.props.initialOpenState:false,timeout:300,fadeIn: true,}
    }
    
    public render(){
    
        const { children, className, label, value, toValue, f } = this.props;
        const displayValue = (f.displayValue === undefined ? (Array.isArray(f.value)?f.value.map(v=>v.label).join(','):f.value) : f.displayValue)
    
        return <Fade timeout={this.state.timeout} in={this.state.fadeIn}>
        <Card className="filter-item">
          <CardTitle  onClick={this.toggle}> 
            <i className={this.state.collapse?"icon-arrow-down":"icon-arrow-right"}/>
            <span className="filter-name"><FormattedMessage  id={label} /></span>
            <span className="filter-value">{
                (f.value !== undefined && f.value !== '') ||
                valueList.find(operator => operator === f.operator) === undefined ?
                    <React.Fragment>
                        <SearchTerm term={f.operator===undefined? undefined: filterPillsList.find(o => o.id === f.operator)!.value} /> { }
                            { displayValue }
                            {/* {(f.toValue !== undefined && f.toValue !== ''  && f.operator === '..' ? " and " + f.toValue : "")}  */}
                            {(toValue !== undefined && toValue !== '' ? " and " + toValue : "")} 
                    </React.Fragment>
                    :''
                }
           </span>
          </CardTitle>
          <Collapse isOpen={this.state.collapse} id={"#collapseExample-"+label}>
            <CardBody>
            {children}
             </CardBody>
          </Collapse>
        </Card>
      </Fade>
    }
    private toggle=()=> {
        this.setState({ collapse: !this.state.collapse });
    }
    private getValue=()=>{
        let retVal = this.props.value!== undefined ? this.props.value.toString():'';
        if(this.props.toValue!== undefined && this.props.toValue !== ""){
            retVal+= ' to '+this.props.toValue 
        }
        return retVal
    }
    
}