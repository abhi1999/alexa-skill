import classnames from "classnames";
import * as  React from 'react';
import scrollToComponent from 'react-scroll-to-component';
import { Badge, Card, CardBody, CardFooter, CardHeader, Col, Collapse, Fade, Row, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

interface IDashboardContainerProps {
    colSize: number
    maxColSize?: number
    children?: any;
    fullScreenChildren?: any
    enableMaximize?: boolean
    headerTitle?: any
    badgeText?: string
    onMaximize?: (isMaximized: boolean) => {}
    onFullScreen?: (isFullScreen: boolean) => void
    renderInDashboard?:boolean
}
interface IDashboardContainerState {
    colSize: number
    isModalOpen: boolean
}
class DashboardContainer extends React.Component<IDashboardContainerProps, IDashboardContainerState>{
    private containerRef: any;
    public constructor(props) {
        super(props);
        this.state = {
            colSize: this.props.colSize ? this.props.colSize : 3,
            isModalOpen: false
        };
        this.containerRef = React.createRef()
    }
    public componentDidLoad() {
        this.setState({ colSize: this.props.colSize })
    }
    public componentWillReceiveProps(nextProps) {
        this.setState({ colSize: nextProps.colSize })
    }

    public render() {
        const innerContent =
            <Card>
                <CardHeader>
                    {this.renderHeader()}
                    <div className="card-header-actions" ref={this.containerRef}>
                        <a className="card-header-action btn" onClick={this.toggleModal}><i className={classnames({ "icon-size-fullscreen": !this.state.isModalOpen }, { "icon-size-actual": this.state.isModalOpen })} /></a>
                    </div>
                </CardHeader>
                <CardBody>
                    {this.props.children}
                </CardBody>
                <Modal size="lg" centered={true} isOpen={this.state.isModalOpen} toggle={this.toggleModal} >
                    <ModalHeader toggle={this.toggleModal}>
                        {this.renderHeader()}
                    </ModalHeader>
                    <ModalBody>
                        {this.props.fullScreenChildren ? this.props.fullScreenChildren : this.props.children}
                    </ModalBody>
                </Modal>
            </Card>
        
        if(this.props.renderInDashboard){
            return <div className="dashboard-container-widget no-col" >
                    {innerContent}
                </div>            
        }
        return <Col md={this.state.colSize} className="dashboard-container-widget" >
                {innerContent}
            </Col>
    }
    private renderHeader = () => {
        return <React.Fragment>
            {this.props.headerTitle} {this.props.badgeText !== undefined ? <Badge pill={true} color="info">{this.props.badgeText}</Badge> : ""}
        </React.Fragment>
    }
    private toggleModal = () => {
        this.setState({ isModalOpen: !this.state.isModalOpen },
            () => { if (this.props.onFullScreen) { this.props.onFullScreen(this.state.isModalOpen) } })

    }
    private toggleColSize = () => {
        let isMaximized = false;
        let colSize;
        if (this.state.colSize === this.props.colSize) {
            isMaximized = true;
            colSize = this.getMaxColSize();
        }
        else {
            isMaximized = false;
            colSize = this.props.colSize
        }

        this.setState({ colSize }, () => {
            setTimeout(() => { scrollToComponent(this.containerRef.current, { offset: -200, align: 'top', duration: 150, ease: 'inCirc' }) }, 500)
        })
        if (this.props.onMaximize) {
            this.props.onMaximize(isMaximized)
        }
    }
    private getMaxColSize = () => {
        return this.props.maxColSize ? this.props.maxColSize : 12;
    }

}

export default DashboardContainer;
