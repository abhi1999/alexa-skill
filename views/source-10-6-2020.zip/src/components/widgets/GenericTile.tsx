import * as React from 'react';
import classnames from 'classnames';
import {Card, CardBody, CardSubtitle, CardTitle, Tooltip} from "reactstrap";
import uuid from 'uuid-v4';
import ErrorBoundary from './ErrorBoundary';

interface IGenericTileProps{
    title?:any
    headerButtons?:any[]
    type?:string
    className?:string
}
export default class GenericTile extends React.Component<IGenericTileProps,any> {
    public constructor (props){
        super(props)
        this.state = {tooltipOpen:false, id:'tooltip-'+performance.now(),fullView:false};
    }
    public render(){
        const { children, className,title,type,headerButtons } = this.props;
        const {tooltipOpen,fullView}=this.state;;
        let id = title && typeof title ==="string"? 'tooltip-'+title.toString().replace(/ /g,"_"):undefined;
        if(id !== undefined){
            id = id.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g,'_');
        }
        const useDefaultClass = className === undefined || className.length === 0;
        return (<ErrorBoundary>
                <Card outline={false} className={classnames({"business-process-seq-no-0":useDefaultClass}, className)} >
                    <CardBody>
                        {type===undefined?"":<span className="card-type">{type}</span>  }
                        {title === undefined? "":<CardSubtitle id={id}>
                                {title}
                               {title!==undefined && id!==undefined && typeof title ==="string"?<ErrorBoundary><Tooltip isOpen={tooltipOpen} target={id} toggle={this.toggleTooltip}>{title}</Tooltip></ErrorBoundary>:""}
                            </CardSubtitle>
                        }
                        <small className={classnames({"full-view":fullView})}>
                        <i className={classnames("fa", {"fa-angle-up":fullView},{"fa-angle-down":!fullView} )} onClick={()=>{this.setState({fullView:!this.state.fullView})}}/>
                            {children}
                        </small>
                    </CardBody>
                    <CardTitle>
                        <span className="card-header-actions">
                            {headerButtons}
                        </span>    
                    </CardTitle>
                </Card>
                
                </ErrorBoundary>
        )
        
    }
    private handleClick = () =>{
        return false
    }
    private toggleTooltip = ()=>{ this.setState({tooltipOpen:!this.state.tooltipOpen})}

}