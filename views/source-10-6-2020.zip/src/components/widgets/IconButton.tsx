import * as React from 'react';
import {Badge, Button, Input, Popover, PopoverHeader, PopoverBody,Tooltip} from 'reactstrap';
import classNames from 'classnames';
import { FormattedMessage } from 'react-intl';

// export default class IconButton extends React.Component<any, any> {
//     public constructor (props){
//         super(props)
//     }
//     public render(){
//         const { className, children, iconText, ...rest } = this.props;
//         return <Button className={classNames("btn-icon", className)} {...rest}>{children}
//             {iconText && iconText.length> 0? <span>{iconText}</span>:''}
//         </Button>
//     }
// }

export default class IconButton extends React.Component<any, any> {
    public constructor (props){
        super(props);
        this.state = {tooltipOpen:false}

        
    }
    public render(){
        const { className, children, iconText, id, tooltipText, mode,faType,  ...rest } = this.props;

        return <React.Fragment>
            {mode && mode.toLowerCase()==="flat"?
                <i className={classNames(faType?faType:"fas", className)} id={id} {...rest}>{children}
                {iconText && iconText.length> 0? <span><FormattedMessage id={iconText} /></span>:''}</i>
                :    
                <Button className={classNames("btn-icon", className)} {...rest} id={id}>{children}
                {iconText && iconText.length> 0? <span><FormattedMessage id={iconText} /></span>:''}
                </Button>
            }
        
        {tooltipText!== undefined && id !== undefined?
            <Tooltip placement="bottom" isOpen={this.state.tooltipOpen} target={id} toggle={this.toggleTooltip}>{tooltipText}</Tooltip>
                :""
        }
        </React.Fragment>
    }
    private toggleTooltip = ()=>{ this.setState({tooltipOpen:!this.state.tooltipOpen})}
}