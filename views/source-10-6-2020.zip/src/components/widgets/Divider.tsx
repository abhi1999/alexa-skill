import classnames from "classnames";
import * as  React from 'react';
import IconButton from './IconButton';
interface IDividerProps{
    orientation?:any;
    title?:string
    btnToAdd?:any[]
    className?:string,
    simpleView?:boolean
}
class Divider extends React.Component<IDividerProps, any>{
    public constructor(props) {
        super(props);
        this.state = {
        };
    }
    public render(){
        const {btnToAdd, className, simpleView}= this.props;
        /*
        const btnToAdd =[
            <IconButton key="btn1" className="fa fa-plus" iconText="Global.Add"/>,
            <IconButton key="btn2" className="fa fa-plus" iconText="Global.Add"/>
        ]
        */
        return <div className={classnames("divider divider-body header-icons",className, {"simple-view":simpleView})}><span className="divider-title">{this.props.children}</span><div className="header-btn">{btnToAdd}</div></div>
    } 
}

export default Divider;
