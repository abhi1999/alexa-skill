import * as React from "react";
import { connect } from "react-redux";
import {
  IPermission,
  IUserMenuPermission,
  IHasPermission
} from "../../constants/RoleAdministration/IRoleAdministration";
import { Alert } from "reactstrap";

/* 
    --------------------------------------------------------------------------------------
    PURPOSE: This component is a higher order component to create reusability for applying 
             a users role permissions to a form
    --------------------------------------------------------------------------------------
*/

// -- Private Methods
function getDisplayName(WrappedComponent) {
  return WrappedComponent.displayName || WrappedComponent.name || "Component";
}

const DOMAIN_ADMIN_PERMISSION = "Permission.DomainAdmin";
const ADMIN_PERMISSION = "Permission.Admin";
const CREATE_PERMISSION = "Permission.Create";
const EDIT_PERMISSION = "Permission.Update";
const DELETE_PERMISSION = "Permission.Delete";
const READ_PERMISSION = "Permission.Read";

const getPermissionsForPage = (pageKey: string, permissions: IPermission[], menuPermission: IUserMenuPermission[]) => {
  const effectivePermissions: IPermission[] = [];
  const userPermission = menuPermission.find(m => m.Menu === pageKey);

  if (userPermission !== undefined) {
    userPermission.Permissions.forEach(up => {
      // mar 4/25/2020 changed Id to id
      // const per = permissions.find(p => p.Id === up);
      const per = permissions.find(p => p.id === up);
      if (per !== undefined) {
        effectivePermissions.push(per);
      }
    });
  }
  return effectivePermissions;
};

// -- Our HOC Component
export const withRolePermissions = (WrappedComponent, pageKey: string) => {
  interface IProps {
    // redux
    myPermissions: IUserMenuPermission[];
    permissions: IPermission[];
    pageKey: string;
    isRolesLoading: boolean;
  }

  class HOC extends React.Component<IProps> {
    private permissions: IPermission[] = [];
    private myPermissions: IUserMenuPermission[] = [];
    private effectivePermissions: IPermission[] = [];
    private hasPermission?: IHasPermission;

    constructor(props: IProps) {
      super(props);

      // console.log("DisplayName of Wrapped Component:", getDisplayName(WrappedComponent));
      // console.log(this.props);

      this.isEnabled = this.isEnabled.bind(this);
      this.hasREAD = this.hasREAD.bind(this);
      this.hasCREATE = this.hasCREATE.bind(this);
      this.hasEDIT = this.hasEDIT.bind(this);
      this.hasDELETE = this.hasDELETE.bind(this);
      this.hasADMIN = this.hasADMIN.bind(this);
    }

    public isEnabled = (type: string): boolean => {
      let retValue = false;
      if (this.permissions && this.effectivePermissions) {
        if (
          this.permissions.find(p => p.Permission === type) === undefined ||
          this.effectivePermissions.find(p => p.Permission === type)
        ) {
          retValue = true;
        }
      }
      return retValue;
    };

    public hasREAD = (): boolean => {
      return this.isEnabled(READ_PERMISSION);
    };
    public hasCREATE = (): boolean => {
      return this.isEnabled(CREATE_PERMISSION);
    };
    public hasEDIT = (): boolean => {
      return this.isEnabled(EDIT_PERMISSION);
    };
    public hasDELETE = (): boolean => {
      return this.isEnabled(DELETE_PERMISSION);
    };
    public hasADMIN = (): boolean => {
      return this.isEnabled(ADMIN_PERMISSION);
    };
    public hasDOMAINADMIN = (): boolean => {
      return this.isEnabled(DOMAIN_ADMIN_PERMISSION);
    };

    public checkPermissions() {
      // NOTE: Had to move this logic in here to make it work properly when the Browser refresh is hit...
      this.permissions = this.props.permissions;
      this.myPermissions = this.props.myPermissions;

      this.effectivePermissions = getPermissionsForPage(pageKey, this.permissions, this.myPermissions);

      this.hasPermission = {
        DOMAIN_ADMIN: this.hasDOMAINADMIN(),
        ADMIN: this.hasADMIN(),
        CREATE: this.hasCREATE(),
        DELETE: this.hasDELETE(),
        EDIT: this.hasEDIT(),
        READ: this.hasREAD()
      };
    }

    public render() {
      // If the role permissions haven't finished loading yet, then we wait
      if (this.props.isRolesLoading) {
        // This use case occurs when a user hits refresh and the form is shown before the permissions
        // are updated in the store, so we wait for the props and React to re-render...
        return <div>One moment while loading user permissions...</div>;
      }

      // Check the users permissions
      this.checkPermissions();

      // If NOT ADMIN and NOT READ PERMISSION assigned, then show this alert message
      // This is our alternative to disabling the menu option though I would prefer to
      // see the menu option in a lighter color to designate it is not permitted
      // if (!this.isEnabled(READ_PERMISSION)) {
      if (this.hasPermission && !this.hasPermission.READ && !this.hasPermission.ADMIN) {
        return (
          <div>
            <Alert color="danger">
              You do not have permission to access this page. Please contact your system administrator.
            </Alert>
          </div>
        );
      } else {
        return (
          <WrappedComponent
            {...this.props}
            // NOTE: Just sending a single IHasPermisson object that has all the CRUD permission boolean values in it
            hasPermission={this.hasPermission}
          />
        );
      }
    }
  }

  const mapStateToProps = ({ rolesAdmin: { myPermissions, permissions, loading } }) => {
    return { myPermissions, permissions, pageKey, isRolesLoading: loading };
  };

  return connect(mapStateToProps)(HOC);
};

export default withRolePermissions;
