import * as React from "react";
import { connect } from "react-redux";
import {
  IPermission,
  IUserMenuPermission,
  IHasPermission,
  IMenuPermission,
  AuthorizationVersion
} from "../../constants/RoleAdministration/IRoleAdministration";
import { Alert } from "reactstrap";
import appRoutes from "./../../configs/appRoutes";
import { matchPath } from "react-router";
import { consoleColor } from '../../configs/index';
import { FormattedMessage } from 'react-intl';
import { sessCompanyID } from '../../constants/index';


/* 
    --------------------------------------------------------------------------------------
    PURPOSE: This component is a higher order component to create reusability for applying 
             a users role permissions to a form
    --------------------------------------------------------------------------------------
*/
/*
Scenarios to handle
1) There are no permissions for the selected route
2) Only partial Permissions can be set for a route  - For e.g. Read & Delete only
*/
const DOMAIN_ADMIN_PERMISSION = "Permission.DomainAdmin";
const ADMIN_PERMISSION = "Permission.Admin";
const CREATE_PERMISSION = "Permission.Create";
const EDIT_PERMISSION = "Permission.Update";
const DELETE_PERMISSION = "Permission.Delete";
const READ_PERMISSION = "Permission.Read";

// KB: Added Internationalization to UI messages
const intlOneMomentWhileLoadingPermissions = 'RoleAdmin.OneMomentWhileLoadingPermissions';
const intlNoPermissionAccess = 'RoleAdmin.NoPermissionAccess';

export const withRolePermissions = WrappedComponent => {
  interface IProps {
    myPermissions: IUserMenuPermission[];
    permissions: IPermission[];
    menuPermissions: IMenuPermission[];
    pageKey: string;
    arePermissionsLoading: boolean;
    match: any;
    loginReducer: any;
    settings: any;
    location: any;
    alertsReducer: any;
  }
  interface IState {
    hasDomainAdmin: boolean;
    hasAdmin: boolean;
    hasCreate: boolean;
    hasRead: boolean;
    hasEdit: boolean;
    hasDelete: boolean;
    arePermissionsLoading: boolean;
    allPermissionSet: string[];
    noPermissionsFound: boolean;
    dbVer: number;
  }
  class HOC extends React.Component<IProps, IState> {
    constructor(props: IProps) {
      super(props);
      this.state = this.getStateForHOC(
        this.getPageKey(props),
        props.permissions,
        props.myPermissions,
        props.menuPermissions,
        props.arePermissionsLoading,
        props.settings
      );
    }


    public componentWillReceiveProps(newProps: IProps) {
      // console.log("%ccomponentWillReceiveProps() function", consoleColor.consoleInfo);
      // console.log(newProps);
      this.setHOCState(newProps);
    }
    public render() {
      // const { arePermissionsLoading, hasRead, hasCreate, hasEdit, hasDelete, hasAdmin, allPermissionSet, noPermissionsFound = true, dbVer } = this.state;
      const { arePermissionsLoading, hasRead, hasCreate, hasEdit, hasDelete, hasDomainAdmin, hasAdmin, allPermissionSet, noPermissionsFound, dbVer } = this.state;

      // *****************************************
      // **** Comment this out for production ****
      // *****************************************
      // if (this.props.location && this.props.location.search === "?987654321") {
      //   console.log('skipping checks');
      //   return <WrappedComponent {...this.props} />
      // }

      if (arePermissionsLoading) {
        // return <Alert color="info">One moment while loading user permissions...</Alert>;
        return <Alert color="info">
          <FormattedMessage id={intlOneMomentWhileLoadingPermissions} />
        </Alert>;

      }

      // ADMIN or READ permission can get you access to the screen
      // const hasNoAccess = !noPermissionsFound && (!hasRead && !hasAdmin);
      // MOD: KB: 11/13/2019 - Changed to now allow any permission to grant access to the screen
      const hasNoAccess = !noPermissionsFound && (!hasRead && !hasDomainAdmin && !hasAdmin && !hasCreate && !hasDelete && !hasEdit);
      // const hasNoAccess = (!hasRead && !hasAdmin && !hasCreate && !hasDelete && !hasEdit);

      if (dbVer < AuthorizationVersion || this.props.match.path.includes('dashboard')) {
        // Prior version has no permission tables and users have all righto to the dashboard 
        const hasPermission: IHasPermission = {
          DOMAIN_ADMIN: false,
          ADMIN: true,
          CREATE: true,
          DELETE: true,
          EDIT: true,
          READ: true
        };

        return (
          <WrappedComponent
            {...this.props}
            hasPermission={hasPermission} // NOTE: Just sending a single IHasPermisson object that has all the CRUD permission boolean values in it
          // allPermissionSet={allPermissionSet} // catch all for any special permission.  We maynot need this
          />
        );
      } else if (hasNoAccess) {
        return (
          <Alert color="danger">
            {" "}
            {/* You do not have permission to access this page. Please contact your system administrator. */}
            <FormattedMessage id={intlNoPermissionAccess} />
            {" "}
          </Alert>
        );
      } else if (noPermissionsFound) {
        // console.log("%cWarning, this form is unprotected due to no permissions found", consoleColor.consoleWarn);
        const hasPermission: IHasPermission = {
          DOMAIN_ADMIN: false,
          ADMIN: true,
          CREATE: true,
          DELETE: true,
          EDIT: true,
          READ: true
        };

        // While testing, output the permissions that are set 
        // if (!arePermissionsLoading) {
        //   console.log(hasPermission);
        // }

        return (
          <WrappedComponent
            {...this.props}
            hasPermission={hasPermission} // NOTE: Just sending a single IHasPermisson object that has all the CRUD permission boolean values in it
          // allPermissionSet={allPermissionSet} // catch all for any special permission.  We maynot need this
          />
        );

      } else {

        // Default behavior

        const hasPermission: IHasPermission = {
          DOMAIN_ADMIN: hasDomainAdmin,
          ADMIN: hasAdmin,
          CREATE: hasCreate,
          DELETE: hasDelete,
          EDIT: hasEdit,
          READ: hasRead
        };

        // While testing, output the permissions that are set based on the db values loaded
        if (!arePermissionsLoading) {
          console.log(hasPermission);
        }

        return (
          <WrappedComponent
            {...this.props}
            hasPermission={hasPermission} // NOTE: Just sending a single IHasPermisson object that has all the CRUD permission boolean values in it
            allPermissionSet={allPermissionSet} // catch all for any special permission.  We maynot need this
          />
        );
      }
    }

    private setHOCState = (props: IProps) => {
      // console.log("%csetHOCState() function", consoleColor.consoleInfo);
      // console.log("%cAre permissions loading: (" + props.arePermissionsLoading + ")", consoleColor.consoleInfo);
      if (!props.arePermissionsLoading) {
        // console.log("TEST");
        const newState = this.getStateForHOC(
          this.getPageKey(props),
          props.permissions,
          props.myPermissions,
          props.menuPermissions,
          props.arePermissionsLoading,
          props.settings
        );
        this.setState({ ...newState });
      }
    };

    private getStateForHOC = (
      menuKey: string,
      permissions: IPermission[],
      userMenuPermission: IUserMenuPermission[],
      menuPermissions: IMenuPermission[],
      arePermissionsLoading: boolean,
      settings: any

    ): IState => {
      const stateValue: IState = {
        hasDomainAdmin: false,
        hasAdmin: false,
        hasCreate: false,
        hasRead: false,
        hasEdit: false,
        hasDelete: false,
        arePermissionsLoading: true,
        allPermissionSet: [],
        noPermissionsFound: false,
        dbVer: 0
      };
      // if (!arePermissionsLoading) {
      //   console.log("getStateForHOC: menuKey:", menuKey);
      // }
      // console.log("%cgetStateForHOC() function", consoleColor.consoleInfo);

      const permissionForSelectedMenu = menuPermissions.find(m => m.Menu === menuKey);
      const userPermissionForSelectedMenu = userMenuPermission.find(m => m.Menu === menuKey);
      const allPermissionSet: string[] = [];

      // Display additional info while testing
      if (!arePermissionsLoading && permissionForSelectedMenu === undefined && menuKey != null) {
        console.log("%cThe menu (" + menuKey + ") is not set for any permission", consoleColor.consoleWarn);
        // Set the noPermissonsFound state

        if (stateValue.dbVer < AuthorizationVersion) {
          // console.log("setting state noPermissions found = true")
          // this.setState({ noPermissionsFound: true });
          stateValue.noPermissionsFound = true;
        }
      }

      permissions.forEach(p => {
        if (
          // permissionForSelectedMenu === undefined || /// i.e. the menu is not set for any permission
          permissionForSelectedMenu !== undefined && /// i.e. the menu is not set for any permission
          // MOD: KB: 10/29/2019 - If Permission is not set for menu, then I want it to be FALSE, not TRUE
          // permissionForSelectedMenu.Permissions.find(menuPermission => menuPermission === p.Id) === undefined || // Permission is not set for the menu
          // mar 4/25/2020 change p.Id to p.id to match table field name
          (userPermissionForSelectedMenu !== undefined &&
            userPermissionForSelectedMenu.Permissions.find(menuPermission => menuPermission === p.id) !== undefined) // User has access to that permission
        ) {
          allPermissionSet.push(p.Permission);
          switch (p.Permission) {
            case DOMAIN_ADMIN_PERMISSION:
              stateValue.hasDomainAdmin = true;
              stateValue.hasRead = true;
              break;
            case ADMIN_PERMISSION:
              // Setup New Company and/or Delete Company requires domain admin privileges
              if (menuKey === 'Menu.CopyCompany' || menuKey === 'Menu.DeleteCompany') {
                stateValue.hasAdmin = false;
                stateValue.hasRead = false;
              }
              else {
                stateValue.hasAdmin = true;
                stateValue.hasRead = true;
              }
              break;
            case CREATE_PERMISSION:
              stateValue.hasCreate = true;
              stateValue.hasRead = true;
              break;
            case READ_PERMISSION:
              stateValue.hasRead = true;
              break;
            case EDIT_PERMISSION:
              stateValue.hasEdit = true;
              stateValue.hasRead = true;
              break;
            case DELETE_PERMISSION:
              stateValue.hasDelete = true;
              stateValue.hasRead = true;
              break;
            default:
          }
        } // else user doesn't have permission for that menu
      });
      stateValue.arePermissionsLoading = arePermissionsLoading;
      stateValue.allPermissionSet = allPermissionSet;
      // IMPORTANT: Checking if the API returned any userMenuPermissions, older version's would return an 
      // empty permissions array by design, we let the API call determine that based on the business logic.
      // We don't want to apply any permission control in that case
      // The render will NOT include the hasPermission prop and the form will
      // end up calling DefaultHasPermission which has all permissions set to true
      // NOTE: No longer using this approach, using the actual dbVer to determine if permissions tables should be
      //       present or not
      // stateValue.noPermissionsFound = userMenuPermission.length === 0;

      // Grab the App version from the store and put in state, only performs this once
      // TODO: This should live in sessionStorage or the store without me having to hunt for it
      if (stateValue.dbVer === 0 && settings && settings.availableCompanies) {
        // console.log("Found company settings", settings.availableCompanies);

        // Pull company ID from session storage
        const thisCompanyId = sessionStorage.getItem(sessCompanyID);
        // console.log("thisCompanyID", thisCompanyId);
        if (thisCompanyId) {
          // Company_ID int
          const thisCompany = settings.availableCompanies.find(c => c.Company_ID === +thisCompanyId);
          if (thisCompany) {
            stateValue.dbVer = thisCompany.dbver;
            console.log("dbVer:", stateValue.dbVer);
          }
        }
      }

      return stateValue;
    };
    private getPageKey = (props: IProps) => {
      // console.log("%cgetPageKey() function", consoleColor.consoleInfo);
      if (props.match && props.match.url && this.getRoute(props)) {
        return this.getRoute(props);
      }
      // console.log("%cgetPageKey() failed", consoleColor.consoleWarn);
      // console.log("Are permissions loading:", props.arePermissionsLoading);
      return "";
    };

    private getRoute = (props: IProps) => {
      // console.log("%curl = (" + props.match.url + ")", consoleColor.consoleInfo);

      const aroute: any = appRoutes.find(route => matchPath(props.match.url, { path: route.path, exact: route.exact }));
      // console.log('aroute = ', aroute);

      // ** ************************************************************************* **
      // ** Handle special case routes where the core permissions per view won't work **
      // ** ************************************************************************* **
      //#region Handle Special Case Routes
      if (aroute && !props.arePermissionsLoading) {

        if (aroute.parentId) {
          console.log("%cSPECIAL CASE: Using parentId (" + aroute.parentId + ")", consoleColor.consoleInfo);
          // KB: Testing using new parentId parameter on our appRoute to designate a parent menu to be used for role permissions
          //     This is needed since only we have one entry in the Permissions db for the top level route and we can access the 
          //     child / sub components directly which bypasses the parent, thus breaking the chain of our solution where
          //     the parent is hit first and passes the permission prop to the child.
          return aroute.parentId;
        } else if (aroute.path === "/businessProcess/:MenuID") {
          console.log("%cSPECIAL CASE: Business Process", consoleColor.consoleInfo);
          // Special case for businessProcess menu items where the menuId is passed as a parameter
          // Example: QuoteToCash, url = /businessProcess/1002 where 1002 is the MenuId for Menu.QuoteToCash
          // console.log(props.match.params.MenuID);
          // console.log(props);
          // console.log("props.menuPermissions = ", props.menuPermissions);
          const matchPermission: any = props.menuPermissions.find(item => item.MenuID === +props.match.params.MenuID);

          if (matchPermission) {
            console.log("%cSuccess, User Menu Permission match found (" + matchPermission.MenuID + " - " + matchPermission.Menu + ")", consoleColor.consoleSuccess);
            return matchPermission.Menu;
          } else {
            console.log("%cUnable to find a matching Menu Permission for id (" + props.match.params.MenuID + ")", consoleColor.consoleError);
            return null;
          }
        } else if (aroute.path === '/HTMLReports/:ReportName') {
          // console.log(props);
          // Special Case - HTML Reports
          // We are passed a report name parameter
          // However, the ReportName doesn't provide us a MenuId which we need, so we have to look it up
          console.log("%cSPECIAL CASE: HTML Report", consoleColor.consoleInfo);
          // console.log("props", props);
          // console.log("ReportName =", props.match.params.ReportName);
          const matchMenuName = "Menu.HTMLReportName." + props.match.params.ReportName;
          // console.log("props.menuPermissions = ", props.menuPermissions);
          const matchPermission: any = props.menuPermissions.find(item => item.Menu === matchMenuName);
          if (matchPermission) {
            console.log("%cSuccess, User Menu Permission match found (" + matchPermission.MenuID + " - " + matchPermission.Menu + ")", consoleColor.consoleSuccess);
            return matchPermission.Menu;
          } else {
            console.log("%cUnable to find a matching Menu Permission for name (" + matchMenuName + ")", consoleColor.consoleError);
            // if (props.menuPermissions.length === 0) {
            //   console.log("%cThe props.menuPermissions are empty", consoleColor.consoleWarn);
            // }
            return null;
          }
          // console.log("window.location.hash = ", window.location.hash);
        } else if (aroute.path.includes("/ExceptionReports/")) {
          console.log("%cSPECIAL CASE: Exception Report", consoleColor.consoleInfo);
          // console.log(props);
          // Need to XRef in BPMenus, Menu.ExceptionReportName.InboundASN can be found in BPMenus
          // sample path: /ExceptionReports/InboundASN
          const path = props.match.path;
          const menuId = path.substring(path.lastIndexOf("/") + 1);
          const matchMenuName = "Menu.ExceptionReportName." + menuId;
          // console.log("matchMenuName = ", matchMenuName);

          const matchPermission: any = props.menuPermissions.find(item => item.Menu === matchMenuName);
          if (matchPermission) {
            console.log("%cSuccess, User Menu Permission match found (" + matchPermission.MenuID + " - " + matchPermission.Menu + ")", consoleColor.consoleSuccess);
            return matchPermission.Menu;
          } else {
            console.log("%cUnable to find a matching Menu Permission for name (" + matchMenuName + ")", consoleColor.consoleError);
            // if (props.menuPermissions.length === 0) {
            // console.log("%cThe props.menuPermissions are empty", consoleColor.consoleWarn);
            // }
            return null;
          }
        }
      }
      //#endregion Handle Special Cases

      // Log out additional info while testing
      if (!aroute) {
        console.log("%cUnable to find a matching route for url", consoleColor.consoleWarn);
      } else {
        let menuId = "?";
        // Lookup the menu id by the name so I can display it
        if (aroute.intlId) {
          const matchPermission: any = props.menuPermissions.find(item => item.Menu === aroute.intlId);
          if (matchPermission) {
            menuId = matchPermission.MenuID;
          }
        }
        // console.log("%cDEFAULT: (" + menuId + " - " + (aroute.intlId ? aroute.intlId : "null") + ")", consoleColor.consoleInfo);
      }

      // Default return value if a special case is not handled above
      return aroute && aroute.intlId ? aroute.intlId : null;

    };
  }
  const mapStateToProps = ({ rolesAdmin: { myPermissions, permissions, loadingBasePermissions, menuPermissions }, loginReducer, settings }) => {
    return { myPermissions, permissions, arePermissionsLoading: loadingBasePermissions, menuPermissions, loginReducer, settings };
  };

  return connect(mapStateToProps)(HOC);
};

export default withRolePermissions;
