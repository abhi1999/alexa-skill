import * as React from 'react';

import LanguageItem from './LanguageItem';
import languageData from './data';

const LanguageSwitcher = ({
        switchLanguage,
        handleRequestClose
    }) => {
        return ( <ul className = "list-unstyled" > {
                    languageData.map((language, index) => < LanguageItem key = {
                            index
                        }
                        language = {
                            language
                        }
                        handleRequestClose = {
                            handleRequestClose
                        }
                        switchLanguage = {
                            switchLanguage
                        }
                        />)} </ul>
                    )
                };

export default LanguageSwitcher;