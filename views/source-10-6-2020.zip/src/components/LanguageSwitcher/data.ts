export interface ILocaleInformation {
    languageId : string,
    locale : string,
    name : string,
    icon : string,
    decimalSep : string,
    dateFormatString : string
}

const languageData : ILocaleInformation[] = [
    {
        languageId: 'danish',
        locale: 'da',
        name: 'Dansk',
        icon: 'dk',
        decimalSep : Intl.NumberFormat('da').format(1.1).substring(1,2),
        dateFormatString : 'DD/MM/YYYY'
    },
    {
        languageId: 'german',
        locale: 'de',
        name: 'Deutsche',
        icon: 'de',
        decimalSep : Intl.NumberFormat('de').format(1.1).substring(1,2),
        dateFormatString : 'DD.MM.YYYY'
    },
    {
        languageId: 'english',
        locale: 'en',
        name: 'English',
        icon: 'us',
        decimalSep : Intl.NumberFormat('en').format(1.1).substring(1,2),
        dateFormatString : 'MM/DD/YYYY'
    },
    {
        languageId: 'spanish',
        locale: 'es',
        name: 'Español',
        icon: 'es',
        decimalSep : Intl.NumberFormat('es').format(1.1).substring(1,2),
        dateFormatString : 'DD/MM/YYYY'
    },
    {
        languageId: 'finnish',
        locale: 'fi',
        name: 'Suomalainen',
        icon: 'fi',
        decimalSep : Intl.NumberFormat('fi').format(1.1).substring(1,2),
        dateFormatString : 'DD.MM.YYYY'
    },
    {
        languageId: 'french',
        locale: 'fr',
        name: 'Français',
        icon: 'fr',
        decimalSep : Intl.NumberFormat('fr').format(1.1).substring(1,2),
        dateFormatString : 'DD/MM/YYYY'
    },
    {
        languageId: 'Indonesian',
        locale: 'id',
        name: 'Indonesian',
        icon: 'id',
        decimalSep : Intl.NumberFormat('id').format(1.1).substring(1,2),
        dateFormatString : 'DD/MM/YYYY'
    },
    {
        languageId: 'icelandic',
        locale: 'is',
        name: 'Icelandic',
        icon: 'is',
        decimalSep : Intl.NumberFormat('is').format(1.1).substring(1,2),
        dateFormatString : 'YYYY-MM-DD'
    },
    {
        languageId: 'italian',
        locale: 'it',
        name: 'Italiano',
        icon: 'it',
        decimalSep : Intl.NumberFormat('it').format(1.1).substring(1,2),
        dateFormatString : 'DD/MM/YYYY'
    },
    {
        languageId: 'malay',
        locale: 'ms',
        name: 'Malay',
        icon: 'my',
        decimalSep : Intl.NumberFormat('ms').format(1.1).substring(1,2),
        dateFormatString : 'DD/MM/YYYY'
    },
    {
        languageId: 'dutch',
        locale: 'nl',
        name: 'Nederlands',
        icon: 'nl',
        decimalSep : Intl.NumberFormat('nl').format(1.1).substring(1,2),
        dateFormatString : 'DD-MM-YYYY'
    },
    {
        languageId: 'portugese',
        locale: 'pt',
        name: 'Português',
        icon: 'pt',
        decimalSep : Intl.NumberFormat('pt').format(1.1).substring(1,2),
        dateFormatString : 'DD/MM/YYYY'
    },
    {
        languageId: 'swedish',
        locale: 'sv',
        name: 'Svenska',
        icon: 'se',
        decimalSep : Intl.NumberFormat('sv').format(1.1).substring(1,2),
        dateFormatString : 'YYYY-MM-DD'
    },
    {
        languageId: 'filipino',
        locale: 'tl',
        name: 'Filipino',
        icon: 'ph',
        decimalSep : Intl.NumberFormat('tl').format(1.1).substring(1,2),
        dateFormatString : 'MM/DD/YYYY'
    }
];
export default languageData;
