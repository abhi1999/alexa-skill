import * as React from 'react';

export interface IModalProps {
    show: boolean;
}

// export interface IModalState {
    
// }

export default class Modal extends React.Component<IModalProps, any> {

    constructor(props) {
        super(props);        
    }
    
    public render() {
        if (!this.props.show) {
            return null;
        }

        return (
            <div>{this.props.children}</div>
        );
    }
}