import * as  React from 'react';
import Charts from "./../charts";
import {DashboardContainer, LoadingOrErrorComponent} from "./../widgets";
import { FormattedMessage } from 'react-intl';

interface ITopErrorsProps{
    topErrors:any[],
    loading:boolean,
    error:boolean
}
class TopErrors extends React.Component<ITopErrorsProps, any>{
    public constructor(props) {
        super(props);

    }
    public render(){
        const {topErrors} = this.props;
        const chartOptions = {scales:{
                        xAxes:[{ticks:{display:false}}],
                        yAxes:[{ticks:{display:false}}]
                    }}
        return <React.Fragment>
            <DashboardContainer colSize={4} headerTitle={<FormattedMessage id='Dashboard.Exceptions' />} {...this.props} 
                fullScreenChildren={<Charts chartOptions={chartOptions} data={this.getData(topErrors)} type="HorizontalBar" fullscreen={true}/>}>
            <LoadingOrErrorComponent {...this.props}/>
            {
                (this.props.loading || this.props.error)? "": <Charts chartOptions={chartOptions} data={this.getData(topErrors)} type="HorizontalBar" chartPresets={["Pie", "Bar","HorizontalBar" ]}/>
            }
            </DashboardContainer>
        </React.Fragment>
    }
    private getData(topErrors){
        return topErrors.map(e=>({label:e.LogProcess, value:e.Count}));
    }
}

export default TopErrors;
