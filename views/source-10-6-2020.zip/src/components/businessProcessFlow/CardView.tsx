import { orderBy, groupBy } from "lodash";
import * as  React from 'react';
import { Badge, Card, CardBody, CardFooter, CardHeader, Col, Collapse, Fade, Row, Table } from 'reactstrap';

import ProcessStepCard from "./ProcessStepCard";
import { StringChecker, StripAtSign, StripScheduler } from '../../utils/Conversion';
import { IHasPermission } from '../../constants/RoleAdministration/IRoleAdministration';


interface ICardViewProps{
    data:any
    service:any
    workflow:any
    taskCommand:(ID:string, command:string)=>void
    setFavorite: (ControlID: string, isFav: boolean) => void
    hasPermission: IHasPermission
}
class CardView extends React.Component<ICardViewProps>{
    constructor(props) {
        super(props);
    }
    public render(){
        const {data} = this.props;
        const sortedData = orderBy(orderBy(data, "GroupOrder","asc"), "ControlOrder", "asc")
        const groupedData = groupBy(sortedData, "GroupName");
        return <div className="business-flow-card-container">
                { this.getGroupRows(groupedData)}
            </div>
    }
    private getGroupRows = (groupedData) => {
        const rows:any[] =[]
        let counter =0;
        for(const key in groupedData){
            if(groupedData.hasOwnProperty(key)){
                rows.push(<React.Fragment key={"fragment-"+key}>
                        <h2 key={"header"+key}>{groupedData[key][0].GroupName}</h2>
                        <Row key={key}> 
                            {groupedData[key].map((d, index)=> 
                                <Col xl={4} lg={4} md={4} sm={6} xs={12} key={index} className={"business-process-seq-no-"+ counter+ " "+key.toLocaleLowerCase().replace(/ /gi,"-")} >
                                    <ProcessStepCard item={d} taskData={this.getTaskForTile(d)} {...this.props}/>
                                </Col>)}
                        </Row>
                    </React.Fragment>
                )
                counter++;
            }
        }
        return rows;
    }
    private getTaskForTile=(d:any)=>{
        return this.props.service.taskStatusList.find(l=>StripAtSign(l.Name) ===d.Title);// || l.Name === mapping.Name)
    }
}
export default CardView;
