import * as  React from 'react';
import CardView from "./CardView";
import { IHasPermission } from '../../constants/RoleAdministration/IRoleAdministration';

interface IBusinessProcessFlowViewProps{
    dashboardMenuItemDetails:any[]
    dashboardMenuItems:any[]
    error:boolean,
    loading:boolean
    match:any
    service:any
    workflow:any
    taskStatusListGetAllDispatch:()=>void
    serviceGetState:()=>void
    taskCommand:(ID:string, command:string)=>void
    setFavorite: (ControlID: string, isFav: boolean) => void
    hasPermission: IHasPermission
}

class BusinessProcessFlowView extends React.Component<IBusinessProcessFlowViewProps, any>{
    public constructor(props) {
        super(props);
        this.props.taskStatusListGetAllDispatch();
        this.props.serviceGetState();// to refresh status for all task
    }
 
    public render(){
        return <div className="process-flow"> 
              <CardView data={this.getData()} {...this.props}/>  
        </div>
    }

    private getData = () =>{
        const {dashboardMenuItemDetails, match} = this.props;
        const data = dashboardMenuItemDetails.find(i=> i.ShortCutID.toString() === match.params.ShortCutID)
        return data && data.values ? data.values : [];
    }
}
export default BusinessProcessFlowView;
