import classnames from 'classnames';
import * as  React from 'react';
import { Badge, Card, CardBody, CardFooter, CardHeader,CardSubtitle, CardText, CardTitle,  Col, Collapse, Fade, Row, Table} from 'reactstrap';
import { COMMAND_START, COMMAND_PAUSE, COMMAND_CONTINUE, COMMAND_TERMINATE } from '../../constants/ServiceParameters';
import { TYPE_TASK, TYPE_WORKFLOW, STATE_BUSY, STATE_IDLE, STATE_PAUSED, STATE_TERMINATED } from '../../constants/ServiceParameters';
import { StringChecker, StripAtSign, StripScheduler } from '../../utils/Conversion';
import TaskWorkflowActionButtons from "./../../views/scheduler/TaskWorkflowActionButtons";
import TaskWorkflowDetailsView from "./../../views/scheduler/TaskWorkflowDetailsView";
import { IHasPermission, DefaultHasPermission } from '../../constants/RoleAdministration/IRoleAdministration';

interface IProcessStepCardProps{
    item:any
    taskData:any
    taskCommand:(ID:string, command:string)=>void
    setFavorite: (ControlID: string, isFav: boolean) => void
    hasPermission: IHasPermission
}
interface IProcessStepCardState{
    favSelected:boolean,
}

class ProcessStepCardAlt extends React.Component<IProcessStepCardProps, IProcessStepCardState>{
    public constructor(props) {
        super(props);
        this.state ={
            favSelected:false,
        }
    }
    public render() {
        const permissions: IHasPermission = this.props.hasPermission ? this.props.hasPermission : DefaultHasPermission();
        
        const { item, taskData } = this.props;
        return <Card key={item.ControlID} outline={false} >
            <CardBody>
                {(taskData ? taskData.Status.toLowerCase() : "") === STATE_BUSY ? <div className="loading-bar" /> : ""}
                <span className="card-type">{this.getTileType(taskData, item.GroupName)}</span>
                <CardSubtitle>{item.Title}</CardSubtitle>
                <CardTitle>
                    <span className="card-header-actions">
                        <TaskWorkflowActionButtons
                            status={taskData ? taskData.Status.toLowerCase() : ""}
                            start={() => this.executeTaskCommand(COMMAND_START)}
                            pause={() => this.executeTaskCommand(COMMAND_PAUSE)}
                            continue={() => this.executeTaskCommand(COMMAND_CONTINUE)}
                            terminate={() => this.executeTaskCommand(COMMAND_TERMINATE)}
                            hasPermission={this.props.hasPermission}
                        />
                        <a className="card-header-action btn" onClick={() => this.favClicked()}>
                            <i className={classnames("",
                                { "far fa-star": !this.state.favSelected },
                                { "fas fa-star": this.state.favSelected })}
                            />
                        </a>
                    </span>
                </CardTitle>
                {this.taskDetails(taskData)}
            </CardBody>
        </Card>
    }
    private getTileType(taskData, groupName){
        let retVal = '';// groupName && groupName.length>2? groupName.substring(0,2):""
        if(taskData !== undefined){
            switch(taskData.Type){
                case TYPE_TASK:
                    retVal= "T";
                    break;
                case TYPE_WORKFLOW:
                    retVal= "W";
                    break;
                default:       
            }
        }
        return retVal;
    }
    private taskDetails=(taskData)=>{
        if(taskData !== undefined){
            return <TaskWorkflowDetailsView Status={taskData.Status}LastRun={taskData.LastRun} Duration={taskData.Duration} 
                    RunCount={taskData.RunCount} Event={taskData.Event}/>
        }
        return "";
    }
   private favClicked=()=>{
        this.setState({favSelected:!this.state.favSelected})
        this.props.setFavorite(this.props.item.ControlID, !this.state.favSelected)
   }
   private executeTaskCommand=(command)=>{
       if(this.props.taskData && this.props.taskData.Id !== undefined){
            this.props.taskCommand(this.props.taskData.Id, command);
       }
    }
}
export default ProcessStepCardAlt;
