import { 
    SHIPTO_GET_ALL, 
    SHIPTO_GET_ALL_SUCCESS, 
    SHIPTO_GET_ALL_FAILURE, 
    SHIPTO_GET_ONE, 
    SHIPTO_GET_ONE_SUCCESS, 
    SHIPTO_GET_ONE_FAILURE, 
    SHIPTO_ADD,
    SHIPTO_ADD_SUCCESS,
    SHIPTO_ADD_FAILURE,
    SHIPTO_DELETE, 
    SHIPTO_DELETE_SUCCESS, 
    SHIPTO_DELETE_FAILURE 
} from './../constants/ActionTypes';

import { IApiShipToView } from '../constants/edidb'
import ODataParams from '../constants/params/oDataParams';

export const shipToGetAll = ( params:ODataParams ) => {
    return {
        type: SHIPTO_GET_ALL,
        payload: params
    };
};

export const shipToGetAllSuccess = (shipToList:IApiShipToView[]) => {
    return {
        type: SHIPTO_GET_ALL_SUCCESS,
        payload: shipToList
    }
};

export const shipToGetAllFailure = (error) => {
    return {
        type: SHIPTO_GET_ALL_FAILURE,
        payload: error
    }
};

export const shipToGetOne = ( params ) => {
    return {
        type: SHIPTO_GET_ONE,
        payload: params
    };
};

export const shipToGetOneSuccess = (shipToList:IApiShipToView[]) => {
    return {
        type: SHIPTO_GET_ONE_SUCCESS,
        payload: shipToList
    }
};

export const shipToGetOneFailure = (error) => {
    return {
        type: SHIPTO_GET_ONE_FAILURE,
        payload: error
    }
};

export const shipToAdd = (shipTo:IApiShipToView) => {
    return {
        type: SHIPTO_ADD,
        payload: shipTo
    };
};

export const shipToAddSuccess = (shipTo:IApiShipToView) => {
    return {
        type: SHIPTO_ADD_SUCCESS,
        payload: shipTo
    }
};

export const shipToAddFailure = (error) => {
    return {
        type: SHIPTO_ADD_FAILURE,
        payload: error
    }
};

export const shipToDelete = (shipTo:IApiShipToView) => {
    return {
        type: SHIPTO_DELETE,
        payload: shipTo
    };
};

export const shipToDeleteSuccess = (shipTo:IApiShipToView) => {
    return {
        type: SHIPTO_DELETE_SUCCESS,
        payload: shipTo
    }
};

export const shipToDeleteFailure = (error) => {
    return {
        type: SHIPTO_DELETE_FAILURE,
        payload: error
    }
};

