import { 
    PACKAGE_LABEL_GET_ALL, 
    PACKAGE_LABEL_GET_ALL_SUCCESS, 
    PACKAGE_LABEL_GET_ALL_FAILURE,
    PACKAGE_LABEL_ADD, 
    PACKAGE_LABEL_ADD_SUCCESS, 
    PACKAGE_LABEL_ADD_FAILURE,
    PACKAGE_LABEL_UPDATE, 
    PACKAGE_LABEL_UPDATE_SUCCESS, 
    PACKAGE_LABEL_UPDATE_FAILURE,
    PACKAGE_LABEL_DELETE, 
    PACKAGE_LABEL_DELETE_SUCCESS, 
    PACKAGE_LABEL_DELETE_FAILURE

} from './../constants/ActionTypes';

import { IPackageLabel } from '../constants/edidb'
import ODataParams from '../constants/params/oDataParams';

export const packageLabelGetAll = (params:ODataParams) => {
    return {
        type: PACKAGE_LABEL_GET_ALL,
        payload: params
    };
};

export const packageLabelGetAllSuccess = (packageLabelList:IPackageLabel[]) => {
    return {
        type: PACKAGE_LABEL_GET_ALL_SUCCESS,
        payload:packageLabelList
    }
};

export const packageLabelGetAllFailure = (error) => {
    return {
        type: PACKAGE_LABEL_GET_ALL_FAILURE,
        payload: error
    }
};

export const packageLabelAdd = (packageLabel:IPackageLabel) => {
    return {
        type: PACKAGE_LABEL_ADD,
        payload: packageLabel
    };
};

export const packageLabelAddSuccess = (packageLabel:IPackageLabel) => {
    return {
        type: PACKAGE_LABEL_ADD_SUCCESS,
        payload: packageLabel
    }
};

export const packageLabelAddFailure = (error) => {
    return {
        type: PACKAGE_LABEL_ADD_FAILURE,
        payload: error
    }
};

export const packageLabelUpdate = (packageLabel:IPackageLabel) => {
    return {
        type: PACKAGE_LABEL_UPDATE,
        payload: packageLabel
    };
};

export const packageLabelUpdateSuccess = (packageLabel:IPackageLabel) => {
    return {
        type: PACKAGE_LABEL_UPDATE_SUCCESS,
        payload: packageLabel
    }
};

export const packageLabelUpdateFailure = (error) => {
    return {
        type: PACKAGE_LABEL_UPDATE_FAILURE,
        payload: error
    }
};

export const packageLabelDelete = (packageLabel:IPackageLabel) => {
    return {
        type: PACKAGE_LABEL_DELETE,
        payload: packageLabel
    };
};

export const packageLabelDeleteSuccess = (packageLabel:IPackageLabel) => {
    return {
        type: PACKAGE_LABEL_DELETE_SUCCESS,
        payload: packageLabel
    }
};

export const packageLabelDeleteFailure = (error) => {
    return {
        type: PACKAGE_LABEL_DELETE_FAILURE,
        payload: error
    }
};