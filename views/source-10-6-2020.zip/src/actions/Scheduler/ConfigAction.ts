import { 
    CONFIG_GET_ALL, 
    CONFIG_GET_ALL_SUCCESS, 
    CONFIG_GET_ALL_FAILURE, 
    CONFIG_SAVE, 
    CONFIG_SAVE_SUCCESS, 
    CONFIG_SAVE_FAILURE, 
    CONFIG_LOAD, 
    CONFIG_LOAD_SUCCESS, 
    CONFIG_LOAD_FAILURE
} from '../../constants/ActionTypes';

export const configGetAll = () => {
    return {
        type: CONFIG_GET_ALL
    };
};

export const configGetAllSuccess = (configList) => {
    return {
        type: CONFIG_GET_ALL_SUCCESS,
        payload: configList
    }
};

export const configGetAllFailure = (error) => {
    return {
        type: CONFIG_GET_ALL_FAILURE,
        payload: error
    }
};

export const configSave = (configName: string) => {
    return {
        type: CONFIG_SAVE,
        payload: configName
    };
};

export const configSaveSuccess = (config) => {
    return {
        type: CONFIG_SAVE_SUCCESS,
        payload: config
    }
};

export const configSaveFailure = (error) => {
    return {
        type: CONFIG_SAVE_FAILURE,
        payload: error
    }
};

export const configLoad = (configName: string) => {
    return {
        type: CONFIG_LOAD,
        payload: configName
    };
};

export const configLoadSuccess = (config) => {
    return {
        type: CONFIG_LOAD_SUCCESS,
        payload: config
    }
};

export const configLoadFailure = (error) => {
    return {
        type: CONFIG_LOAD_FAILURE,
        payload: error
    }
};