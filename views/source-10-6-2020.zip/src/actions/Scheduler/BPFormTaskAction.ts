import {
    BPFORMTASK_GET_ALL,
    BPFORMTASK_GET_ALL_SUCCESS,
    BPFORMTASK_GET_ALL_FAILURE,
    BPFORMTASK_ADD,
    BPFORMTASK_ADD_SUCCESS,
    BPFORMTASK_ADD_FAILURE,
    BPFORMTASK_UPDATE,
    BPFORMTASK_UPDATE_SUCCESS,
    BPFORMTASK_UPDATE_FAILURE,
    BPFORMTASK_DELETE,
    BPFORMTASK_DELETE_SUCCESS,
    BPFORMTASK_DELETE_FAILURE,

} from '../../constants/ActionTypes';

import ODataParams from '../../constants/params/oDataParams';

export const bpFormTaskGetAll = (params:ODataParams) => {
    return {
        type: BPFORMTASK_GET_ALL,
        payload: params
    };
};

export const bpFormTaskGetAllSuccess = (taskList) => {
    return {
        type: BPFORMTASK_GET_ALL_SUCCESS,
        payload: taskList
    }
};

export const bpFormTaskGetAllFailure = (error) => {
    return {
        type: BPFORMTASK_GET_ALL_FAILURE,
        payload: error
    }
};

export const bpFormTaskAdd = (task) => {
    return {
        type: BPFORMTASK_ADD,
        payload: task
    };
};

export const bpFormTaskAddSuccess = (task) => {
    return {
        type: BPFORMTASK_ADD_SUCCESS,
        payload: task
    }
};

export const bpFormTaskAddFailure = (error) => {
    return {
        type: BPFORMTASK_ADD_FAILURE,
        payload: error
    }
};

export const bpFormTaskUpdate = (task) => {
    return {
        type: BPFORMTASK_UPDATE,
        payload: task
    };
};

export const bpFormTaskUpdateSuccess = (task) => {
    return {
        type: BPFORMTASK_UPDATE_SUCCESS,
        payload: task
    }
};

export const bpFormTaskUpdateFailure = (error) => {
    return {
        type: BPFORMTASK_UPDATE_FAILURE,
        payload: error
    }
};

export const bpFormTaskDelete = (task) => {
    return {
        type: BPFORMTASK_DELETE,
        payload: task
    };
};

export const bpFormTaskDeleteSuccess = (task) => {
    return {
        type: BPFORMTASK_DELETE_SUCCESS,
        payload: task
    }
};

export const bpFormTaskDeleteFailure = (error) => {
    return {
        type: BPFORMTASK_DELETE_FAILURE,
        payload: error
    }
};

