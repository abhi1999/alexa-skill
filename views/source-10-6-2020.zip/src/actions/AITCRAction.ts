import { AITCR_GET_ALL, AITCR_GET_ALL_FAILURE, AITCR_GET_ALL_SUCCESS, 
        AITCR_UPDATE, AITCR_UPDATE_FAILURE, AITCR_UPDATE_SUCCESS,
        AITCR_GETGLOBAL_ALL, AITCR_GETGLOBAL_ALL_FAILURE,AITCR_GETGLOBAL_ALL_SUCCESS
} from '../constants/ActionTypes';
import { IUserLabel } from '../constants/IUserLabel';
import { IAITCRUpdate, IAITCRGetAll, IAITCRGetGlobalAll } from '../reducers/AITCRReducer';

export const aitcrGetAll = (dgid : string, tppartid: string, count : number) => {
    const pld : IAITCRGetAll = {dgid, count, tppartid };
    return {
        type: AITCR_GET_ALL,
        payload : pld
    };
};

export const aitcrGetAllSuccess = (odataResp : any) => {
    return {
        type: AITCR_GET_ALL_SUCCESS,
        payload: odataResp
    }
};

export const aitcrGetAllFailure = (error) => {
    return {
        type: AITCR_GET_ALL_FAILURE,
        payload: error
    }
};

export const aitcrGetGlobalAll = (dgid : string, count : number) => {
    const pld : IAITCRGetGlobalAll = {dgid, count, tppartid: '' };
    return {
        type: AITCR_GETGLOBAL_ALL,
        payload : pld
    };
};

export const aitcrGetGlobalAllSuccess = (odataResp : any) => {
    return {
        type: AITCR_GETGLOBAL_ALL_SUCCESS,
        payload: odataResp
    }
};

export const aitcrGetGlobalAllFailure = (error) => {
    return {
        type: AITCR_GETGLOBAL_ALL_FAILURE,
        payload: error
    }
};

export const aitcrUpdate = (dgid : string, tppartid : string, aitcrList:IUserLabel[]) => {
    const pld : IAITCRUpdate = { dgid, tppartid, aitcrList };
    return {
        type: AITCR_UPDATE,
        payload: pld
    };
};

export const aitcrUpdateSuccess = (aitcr:IUserLabel) => {
    return {
        type: AITCR_UPDATE_SUCCESS,
        payload: aitcr
    }
};

export const aitcrUpdateFailure = (error) => {
    return {
        type: AITCR_UPDATE_FAILURE,
        payload: error
    }
};

