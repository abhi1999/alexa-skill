import {
    THEME_GET,
    THEME_GET_ERROR, 
    THEME_GET_SUCCESS,
    THEME_UPDATE,
    THEME_UPDATE_ERROR,
    THEME_UPDATE_SUCCESS
} from '../constants/ActionTypes';

export const themeGetRequest = () => {
    return {
        type: THEME_GET,
    };
};

export const themeGetSuccess = ( chartTheme: string, siteTheme: string ) => {
    return {
        type: THEME_GET_SUCCESS,
        payload: {chartTheme, siteTheme}
    }
};

export const themeGetError = (error) => {
    return {
        type: THEME_GET_ERROR,
        payload: error
    }
};


export const themeUpdateRequest = (chartTheme: string, siteTheme: string) => {
    return {
        type: THEME_UPDATE,
        payload:{chartTheme, siteTheme}
    };
};

export const themeUpdateSuccess = ( ) => {
    return {
        type: THEME_UPDATE_SUCCESS,
    }
};

export const themeUpdateError = (error) => {
    return {
        type: THEME_UPDATE_ERROR,
        payload: error
    }
};