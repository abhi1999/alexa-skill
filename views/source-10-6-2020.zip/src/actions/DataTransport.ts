import { 
    DATATRANSPORT_GET_LOOKUPS, 
    DATATRANSPORT_GET_LOOKUPS_SUCCESS, 
    DATATRANSPORT_GET_LOOKUPS_FAILURE, 
    DATATRANSPORT_GET_ALL, 
    DATATRANSPORT_GET_ALL_SUCCESS, 
    DATATRANSPORT_GET_ALL_FAILURE, 
    DATATRANSPORT_GET_ONE, 
    DATATRANSPORT_GET_ONE_SUCCESS, 
    DATATRANSPORT_GET_ONE_FAILURE, 
    DATATRANSPORT_ADD, 
    DATATRANSPORT_ADD_SUCCESS, 
    DATATRANSPORT_ADD_FAILURE, 
    DATATRANSPORT_UPDATE, 
    DATATRANSPORT_UPDATE_SUCCESS, 
    DATATRANSPORT_UPDATE_FAILURE,
    DATATRANSPORT_DELETE, 
    DATATRANSPORT_DELETE_SUCCESS, 
    DATATRANSPORT_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IDataTransport } from '../constants/edidb';

export const dataTransportGetLookups = (params: ODataParams) => {
    return {
        type: DATATRANSPORT_GET_LOOKUPS,
        payload: params
    };
};

export const dataTransportGetLookupsSuccess = ( tradeList: any, transObjectList: any ) => {
    return {
        type: DATATRANSPORT_GET_LOOKUPS_SUCCESS,
        payload: { tradeList, transObjectList }
    }
};

export const dataTransportGetLookupsFailure = (error) => {
    return {
        type: DATATRANSPORT_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const dataTransportGetAll = (params: ODataParams) => {
    return {
        type: DATATRANSPORT_GET_ALL,
        payload: params
    };
};

export const dataTransportGetAllSuccess = (dataTransportList: any) => {
    return {
        type: DATATRANSPORT_GET_ALL_SUCCESS,
        payload: dataTransportList
    }
};

export const dataTransportGetAllFailure = (error) => {
    return {
        type: DATATRANSPORT_GET_ALL_FAILURE,
        payload: error
    }
};

export const dataTransportGetOne = (params: ODataParams) => {
    return {
        type: DATATRANSPORT_GET_ONE,
        payload: params
    };
};

export const dataTransportGetOneSuccess = (dataTransportList: any) => {
    return {
        type: DATATRANSPORT_GET_ONE_SUCCESS,
        payload: dataTransportList
    }
};

export const dataTransportGetOneFailure = (error) => {
    return {
        type: DATATRANSPORT_GET_ONE_FAILURE,
        payload: error
    }
};

export const dataTransportAdd = (dataTransport: IDataTransport) => {
    return {
        type: DATATRANSPORT_ADD,
        payload: dataTransport
    };
};

export const dataTransportAddSuccess = (dataTransport: IDataTransport) => {
    return {
        type: DATATRANSPORT_ADD_SUCCESS,
        payload: dataTransport
    }
};

export const dataTransportAddFailure = (error) => {
    return {
        type: DATATRANSPORT_ADD_FAILURE,
        payload: error
    }
};

export const dataTransportUpdate = (dataTransport: IDataTransport) => {
    return {
        type: DATATRANSPORT_UPDATE,
        payload: dataTransport
    };
};

export const dataTransportUpdateSuccess = (dataTransport: IDataTransport) => {
    return {
        type: DATATRANSPORT_UPDATE_SUCCESS,
        payload: dataTransport
    }
};

export const dataTransportUpdateFailure = (error) => {
    return {
        type: DATATRANSPORT_UPDATE_FAILURE,
        payload: error
    }
};

export const dataTransportDelete = (dataTransport: IDataTransport) => {
    return {
        type: DATATRANSPORT_DELETE,
        payload: dataTransport
    };
};

export const dataTransportDeleteSuccess = (dataTransport: IDataTransport) => {
    return {
        type: DATATRANSPORT_DELETE_SUCCESS,
        payload: dataTransport
    }
};

export const dataTransportDeleteFailure = (error) => {
    return {
        type: DATATRANSPORT_DELETE_FAILURE,
        payload: error
    }
};
