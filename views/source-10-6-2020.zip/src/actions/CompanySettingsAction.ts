import {
  COMPANYSETTINGS_GET_ALL,
  COMPANYSETTINGS_GET_ALL_SUCCESS,
  COMPANYSETTINGS_GET_ALL_FAILURE,
  COMPANYSETTINGS_ADD,
  COMPANYSETTINGS_ADD_SUCCESS,
  COMPANYSETTINGS_ADD_FAILURE,
  COMPANYSETTINGS_UPDATE,
  COMPANYSETTINGS_UPDATE_SUCCESS,
  COMPANYSETTINGS_UPDATE_FAILURE,
  COMPANYSETTINGS_DELETE,
  COMPANYSETTINGS_DELETE_SUCCESS,
  COMPANYSETTINGS_DELETE_FAILURE,
  COMPANYSETTINGS_TESTERPCONNECTION,COMPANYSETTINGS_TESTERPCONNECTION_SUCCESS,COMPANYSETTINGS_TESTERPCONNECTION_FAILURE,
  COMPANYSETTINGS_TESTWSCONNECTION,COMPANYSETTINGS_TESTWSCONNECTION_SUCCESS,COMPANYSETTINGS_TESTWSCONNECTION_FAILURE,
} from "../constants/ActionTypes";
import CompanySettingsModel from "../constants/implementations/CompanySettingsModel";
import { ICompany } from '../constants/EDICompany';

export const companysettingsGetAll = (companyID: string) => {
  return {
    type: COMPANYSETTINGS_GET_ALL,
    payload: companyID
  };
};

export const companysettingsGetAllSuccess = (
  compSettings: any
) => {
  return {
    type: COMPANYSETTINGS_GET_ALL_SUCCESS,
    payload: compSettings
  };
};

export const companysettingsGetAllFailure = error => {
  return {
    type: COMPANYSETTINGS_GET_ALL_FAILURE,
    payload: error
  };
};

export const companysettingsAdd = (compSettings: CompanySettingsModel) => {
  return {
    type: COMPANYSETTINGS_ADD,
    payload: compSettings
  };
};

export const companysettingsAddSuccess = (
  compSettings: CompanySettingsModel
) => {
  return {
    type: COMPANYSETTINGS_ADD_SUCCESS,
    payload: compSettings
  };
};

export const companysettingsAddFailure = error => {
  return {
    type: COMPANYSETTINGS_ADD_FAILURE,
    payload: error
  };
};

export const companysettingsUpdate = (compSettings: CompanySettingsModel) => {
  return {
    type: COMPANYSETTINGS_UPDATE,
    payload: compSettings
  };
};

export const companysettingsUpdateSuccess = (
  compSettings: CompanySettingsModel
) => {
  return {
    type: COMPANYSETTINGS_UPDATE_SUCCESS,
    payload: compSettings
  };
};

export const companysettingsUpdateFailure = error => {
  return {
    type: COMPANYSETTINGS_UPDATE_FAILURE,
    payload: error
  };
};

export const companysettingsDelete = (compSettings: CompanySettingsModel) => {
  return {
    type: COMPANYSETTINGS_DELETE,
    payload: compSettings
  };
};

export const companysettingsDeleteSuccess = (
  compSettings: CompanySettingsModel
) => {
  return {
    type: COMPANYSETTINGS_DELETE_SUCCESS,
    payload: compSettings
  };
};

export const companysettingsDeleteFailure = error => {
  return {
    type: COMPANYSETTINGS_DELETE_FAILURE,
    payload: error
  };
};

export const companySettingsTestErpConnection = (params : ICompany) => {
  return {
      type: COMPANYSETTINGS_TESTERPCONNECTION,
      payload: params
 };
};

export const companySettingsTestErpConnectionSuccess = (apiResp : any) => {
  return {
      type: COMPANYSETTINGS_TESTERPCONNECTION_SUCCESS,
      payload: apiResp
 };
};

export const companySettingsTestErpConnectionFailure = (error : Error) => {
  return {
      type: COMPANYSETTINGS_TESTERPCONNECTION_FAILURE,
      payload: error
 };
};

export const companysettingsTestWsConnection = (params : ICompany) => {
  return {
      type: COMPANYSETTINGS_TESTWSCONNECTION,
      payload: params
 };
};

export const companysettingsTestWsConnectionSuccess = (apiResp : any) => {
  return {
      type: COMPANYSETTINGS_TESTWSCONNECTION_SUCCESS,
      payload: apiResp
 };
};

export const companysettingsTestWsConnectionFailure = (error : Error) => {
  return {
      type: COMPANYSETTINGS_TESTWSCONNECTION_FAILURE,
      payload: error
 };
};