
import { 
    AUDITDETAILXMLDOC_GET_ALL,
    AUDITDETAILXMLDOC_GET_ALL_SUCCESS, 
    AUDITDETAILXMLDOC_GET_ALL_FAILURE, 
    AUDITDETAILXMLDOC_GET_ONE,
    AUDITDETAILXMLDOC_GET_ONE_FAILURE,
    AUDITDETAILXMLDOC_GET_ONE_SUCCESS,
} from '../constants/ActionTypes';
import ODataParams from '../constants/params/oDataParams';

// **************************************************************
// ******** AUDIT DETAIL XML DOC ********************************
// **************************************************************

export const auditDetailXmlDocGetAll = (params:ODataParams) => {
    return {
        type: AUDITDETAILXMLDOC_GET_ALL,
        payload: params
    };
};

export const auditDetailXmlDocGetAllSuccess = (odataResp : any) => {
    return {
        type: AUDITDETAILXMLDOC_GET_ALL_SUCCESS,
        payload: odataResp
    }
};

export const auditDetailXmlDocGetAllFailure = (error) => {
    return {
        type: AUDITDETAILXMLDOC_GET_ALL_FAILURE,
        payload: error
    }
};


export const AauditDetailXmlDocGetOne = (params:ODataParams) => {
    return {
        type: AUDITDETAILXMLDOC_GET_ONE,
        payload: params
    };
};

export const auditDetailXmlDocGetOneSuccess = (odataResp : any) => {
    return {
        type: AUDITDETAILXMLDOC_GET_ONE_SUCCESS,
        payload: odataResp
    }
};

export const auditDetailXmlDocGetOneFailure = (error) => {
    return {
        type: AUDITDETAILXMLDOC_GET_ONE_FAILURE,
        payload: error
    }
};

