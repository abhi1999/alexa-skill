import { 
    TRADE_MAPS_GET_ALL,
    TRADE_MAPS_GET_ALL_SUCCESS, 
    TRADE_MAPS_GET_ALL_FAILURE,
    TRADE_MAPS_UPDATE_MAP,
    TRADE_MAPS_UPDATE_MAP_SUCCESS, 
    TRADE_MAPS_UPDATE_MAP_FAILURE,
} from './../constants/ActionTypes';

import { ITradeMapView } from '../constants/edidb';
import ODataParams from '../constants/params/oDataParams';

export const tradeMapsGetAll = (params: ODataParams) => {
    return {
        type: TRADE_MAPS_GET_ALL,
        payload: params
    };
};

export const tradeMapsGetAllSuccess = (odataResp : any) => {
    return {
        type: TRADE_MAPS_GET_ALL_SUCCESS,
        payload: odataResp
    }
};

export const tradeMapsGetAllFailure = (error) => {
    return {
        type: TRADE_MAPS_GET_ALL_FAILURE,
        payload: error
    }
};

export const tradeMapsUpdate = (tradeMapObject: ITradeMapView) => {
    return {
        type: TRADE_MAPS_UPDATE_MAP,
        payload: tradeMapObject
    };
};

export const tradeMapsUpdateSuccess = (tradeMapObject: ITradeMapView) => {
    return {
        type: TRADE_MAPS_UPDATE_MAP_SUCCESS,
        payload: tradeMapObject
    }
};

export const tradeMapsUpdateFailure = (error) => {
    return {
        type: TRADE_MAPS_UPDATE_MAP_FAILURE,
        payload: error
    }
};
