import { 
    C303V850S_GET_LOOKUPS, 
    C303V850S_GET_LOOKUPS_SUCCESS, 
    C303V850S_GET_LOOKUPS_FAILURE, 
    C303V850S_GET_ALL, 
    C303V850S_GET_ALL_SUCCESS, 
    C303V850S_GET_ALL_FAILURE, 
    C303V850S_GET_ONE, 
    C303V850S_GET_ONE_SUCCESS, 
    C303V850S_GET_ONE_FAILURE, 
    C303V850S_ADD, 
    C303V850S_ADD_SUCCESS, 
    C303V850S_ADD_FAILURE, 
    C303V850S_UPDATE, 
    C303V850S_UPDATE_SUCCESS, 
    C303V850S_UPDATE_FAILURE,
    C303V850S_DELETE, 
    C303V850S_DELETE_SUCCESS, 
    C303V850S_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IC303v850s } from '../constants/edidb';

export const c303v850sGetLookups = (params: ODataParams) => {
    return {
        type: C303V850S_GET_LOOKUPS,
        payload: params
    };
};

export const c303v850sGetLookupsSuccess = ( /* tableNameList: any, ... */ ) => {
    return {
        type: C303V850S_GET_LOOKUPS_SUCCESS,
        payload: { /* tableNameList, ... */ }
    }
};

export const c303v850sGetLookupsFailure = (error) => {
    return {
        type: C303V850S_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const c303v850sGetAll = (params: ODataParams) => {
    return {
        type: C303V850S_GET_ALL,
        payload: params
    };
};

export const c303v850sGetAllSuccess = (c303v850sList: any) => {
    return {
        type: C303V850S_GET_ALL_SUCCESS,
        payload: c303v850sList
    }
};

export const c303v850sGetAllFailure = (error) => {
    return {
        type: C303V850S_GET_ALL_FAILURE,
        payload: error
    }
};

export const c303v850sGetOne = (params: ODataParams) => {
    return {
        type: C303V850S_GET_ONE,
        payload: params
    };
};

export const c303v850sGetOneSuccess = (c303v850sList: any) => {
    return {
        type: C303V850S_GET_ONE_SUCCESS,
        payload: c303v850sList
    }
};

export const c303v850sGetOneFailure = (error) => {
    return {
        type: C303V850S_GET_ONE_FAILURE,
        payload: error
    }
};

export const c303v850sAdd = (c303v850s: IC303v850s) => {
    return {
        type: C303V850S_ADD,
        payload: c303v850s
    };
};

export const c303v850sAddSuccess = (c303v850s: IC303v850s) => {
    return {
        type: C303V850S_ADD_SUCCESS,
        payload: c303v850s
    }
};

export const c303v850sAddFailure = (error) => {
    return {
        type: C303V850S_ADD_FAILURE,
        payload: error
    }
};

export const c303v850sUpdate = (c303v850s: IC303v850s) => {
    return {
        type: C303V850S_UPDATE,
        payload: c303v850s
    };
};

export const c303v850sUpdateSuccess = (c303v850s: IC303v850s) => {
    return {
        type: C303V850S_UPDATE_SUCCESS,
        payload: c303v850s
    }
};

export const c303v850sUpdateFailure = (error) => {
    return {
        type: C303V850S_UPDATE_FAILURE,
        payload: error
    }
};

export const c303v850sDelete = (c303v850s: IC303v850s) => {
    return {
        type: C303V850S_DELETE,
        payload: c303v850s
    };
};

export const c303v850sDeleteSuccess = (c303v850s: IC303v850s) => {
    return {
        type: C303V850S_DELETE_SUCCESS,
        payload: c303v850s
    }
};

export const c303v850sDeleteFailure = (error) => {
    return {
        type: C303V850S_DELETE_FAILURE,
        payload: error
    }
};
