import { 
    DOC_RECEIVE_GET_ALL, 
    DOC_RECEIVE_GET_ALL_SUCCESS, 
    DOC_RECEIVE_GET_ALL_FAILURE, 
    DOC_RECEIVE_UPDATE, 
    DOC_RECEIVE_UPDATE_SUCCESS, 
    DOC_RECEIVE_UPDATE_FAILURE,
    DOC_RECEIVE_DELETE, 
    DOC_RECEIVE_DELETE_SUCCESS, 
    DOC_RECEIVE_DELETE_FAILURE,
    DOC_RECEIVE_GET_DOCUMENT,
    DOC_RECEIVE_GET_DOCUMENT_SUCCESS,
    DOC_RECEIVE_GET_DOCUMENT_FAILURE,
    DOC_RECEIVE_GET_ORIGINAL_DOCUMENT_ID,
    DOC_RECEIVE_GET_ORIGINAL_DOCUMENT_ID_SUCCESS,
    DOC_RECEIVE_GET_ORIGINAL_DOCUMENT_ID_FAILURE,
    DOC_RECEIVE_CLEAR_ORIGINAL_DOCUMENT_ID,

} from './../constants/ActionTypes';

export const docReceiveGetAll = (params) => {
    return {
        type: DOC_RECEIVE_GET_ALL,
        payload: params
    };
};

export const docReceiveGetAllSuccess = (docReceiveList: any) => {
    return {
        type: DOC_RECEIVE_GET_ALL_SUCCESS,
        payload: docReceiveList
    }
};

export const docReceiveGetAllFailure = (error) => {
    return {
        type: DOC_RECEIVE_GET_ALL_FAILURE,
        payload: error
    }
};

export const docReceiveUpdate = (docReceiveList) => {
    return {
        type: DOC_RECEIVE_UPDATE,
        payload: docReceiveList,
    };
};

export const docReceiveUpdateSuccess = (docReceive) => {
    return {
        type: DOC_RECEIVE_UPDATE_SUCCESS,
        payload: docReceive
    }
};

export const docReceiveUpdateFailure = (error) => {
    return {
        type: DOC_RECEIVE_UPDATE_FAILURE,
        payload: error
    }
};

export const docReceiveDelete = (docReceiveList) => {
    return {
        type: DOC_RECEIVE_DELETE,
        payload: docReceiveList
    };
};

export const docReceiveDeleteSuccess = (docReceive) => {
    return {
        type: DOC_RECEIVE_DELETE_SUCCESS,
        payload: docReceive
    }
};

export const docReceiveDeleteFailure = (error) => {
    return {
        type: DOC_RECEIVE_DELETE_FAILURE,
        payload: error
    }
};

export const docReceiveGetDocument= (miscID) => {
    return {
        type: DOC_RECEIVE_GET_DOCUMENT,
        payload: miscID
    };
};

export const docReceiveGetDocumentSuccess = (document) => {
    return {
        type: DOC_RECEIVE_GET_DOCUMENT_SUCCESS,
        payload: document
    }
};

export const docReceiveGetDocumentFailure = (error) => {
    return {
        type: DOC_RECEIVE_GET_DOCUMENT_FAILURE,
        payload: error
    }
};

export const docReceiveGetOriginalDocumentID= (docReceive) => {
    return {
        type: DOC_RECEIVE_GET_ORIGINAL_DOCUMENT_ID,
        payload: docReceive
    };
};

export const docReceiveGetOriginalDocumentIDSuccess = (docReceive) => {
    return {
        type: DOC_RECEIVE_GET_ORIGINAL_DOCUMENT_ID_SUCCESS,
        payload: docReceive
    }
};

export const docReceiveGetOriginalDocumentIDFailure = (error) => {
    return {
        type: DOC_RECEIVE_GET_ORIGINAL_DOCUMENT_ID_FAILURE,
        payload: error
    }
};


export const docReceiveClearOriginalDocumentID = () => {
    return {
        type: DOC_RECEIVE_CLEAR_ORIGINAL_DOCUMENT_ID
    }
};