import { 
    ROUTEINSTR_GET_ALL, 
    ROUTEINSTR_GET_ALL_SUCCESS, 
    ROUTEINSTR_GET_ALL_FAILURE, 
    ROUTEINSTR_CREATE_ASN,
    ROUTEINSTR_CREATE_ASN_SUCCESS,
    ROUTEINSTR_CREATE_ASN_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IRouteInstr } from '../constants/edidb';

export const routeInstrGetAll = (params: ODataParams) => {
    return {
        type: ROUTEINSTR_GET_ALL,
        payload: params
    };
};

export const routeInstrGetAllSuccess = (routeInstrList: any) => {
    return {
        type: ROUTEINSTR_GET_ALL_SUCCESS,
        payload: routeInstrList
    }
};

export const routeInstrGetAllFailure = (error) => {
    return {
        type: ROUTEINSTR_GET_ALL_FAILURE,
        payload: error
    }
};

export const routeInstrCreateASN = (params: any) => {
    return {
        type: ROUTEINSTR_CREATE_ASN,
        payload: params
    };
};

export const routeInstrCreateASNSuccess = (routeInstrList: any) => {
    return {
        type: ROUTEINSTR_CREATE_ASN_SUCCESS,
        payload: routeInstrList
    }
};

export const routeInstrCreateASNFailure = (error) => {
    return {
        type: ROUTEINSTR_CREATE_ASN_FAILURE,
        payload: error
    }
};

