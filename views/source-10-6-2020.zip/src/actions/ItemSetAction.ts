
import { 
    ITEM_GET_ALL, 
    ITEM_GET_ALL_SUCCESS,
    ITEM_GET_ALL_FAILURE, 
    ITEM_GET_ONE,
    ITEM_GET_ONE_FAILURE,
    ITEM_GET_ONE_SUCCESS,
    ITEM_ADD, 
    ITEM_ADD_SUCCESS, 
    ITEM_ADD_FAILURE, 
    ITEM_UPDATE, 
    ITEM_UPDATE_SUCCESS, 
    ITEM_UPDATE_FAILURE,
    ITEM_DELETE, 
    ITEM_DELETE_SUCCESS, 
    ITEM_DELETE_FAILURE,
    ITEM_FRT_GET_ALL,
    ITEM_FRT_GET_FAILURE,
    ITEM_FRT_GET_SUCCESS,
    ITEM_IMPORT_ITEMS,
    ITEM_IMPORT_ITEMS_FAILURE,
    ITEM_IMPORT_ITEMS_SUCCESS,
    ITEM_IMPORT_GET_STATUS,
    ITEM_IMPORT_GET_STATUS_FAILURE,
    ITEM_IMPORT_GET_STATUS_SUCCESS
} from '../constants/ActionTypes';
import { IItem, IFreightCode } from "../constants/edidb";
import ODataParams from '../constants/params/oDataParams';

export interface IUpdateItemAction {
    Original_Int_Item_No : string,
    NewItem : IItem
}

export const itemGetAll = (params:ODataParams) => {
    return {
        type: ITEM_GET_ALL,
        payload: params
    };
};

export const itemGetAllSuccess = (odataResp:any) => {
    return {
        type: ITEM_GET_ALL_SUCCESS,
        payload: odataResp
    }
};

export const itemGetAllFailure = (error) => {
    return {
        type: ITEM_GET_ALL_FAILURE,
        payload: error
    }
};


export const itemGetOne = (params:string) => {
    return {
        type: ITEM_GET_ONE,
        payload: params
    };
};

export const itemGetOneSuccess = (odataResp:any) => {
    return {
        type: ITEM_GET_ONE_SUCCESS,
        payload: odataResp
    }
};

export const itemGetOneFailure = (error) => {
    return {
        type: ITEM_GET_ALL_FAILURE,
        payload: error
    }
};



export const itemFrtGetAll = () => {
    return {
        type: ITEM_FRT_GET_ALL,
    };
};

export const itemFrtGetAllSuccess = (itemList:IFreightCode[]) => {
    return {
        type: ITEM_FRT_GET_SUCCESS,
        payload: itemList
    }
};

export const itemFrtGetAllFailure = (error) => {
    return {
        type: ITEM_FRT_GET_FAILURE,
        payload: error
    }
};

export const itemAdd = (item:IItem) => {
    return {
        type: ITEM_ADD,
        payload: item
    };
};

export const itemAddSuccess = (item:IItem) => {
    return {
        type: ITEM_ADD_SUCCESS,
    }
};

export const itemAddFailure = (error) => {
    return {
        type: ITEM_ADD_FAILURE,
        payload: error
    }
};

export const itemUpdate = (itemNo : string, item:IItem) => {
    const pld : IUpdateItemAction = { Original_Int_Item_No : itemNo, NewItem : item }
    return {
        type: ITEM_UPDATE,
        payload:pld
    };
};

export const itemUpdateSuccess = (item:IItem) => {
    return {
        type: ITEM_UPDATE_SUCCESS,
        payload: item
    }
};

export const itemUpdateFailure = (error) => {
    return {
        type: ITEM_UPDATE_FAILURE,
        payload: error
    }
};

export const itemDelete = (item:IItem, odp : ODataParams) => {
    return {
        type: ITEM_DELETE,
        payload: { item, odp }
    };
};

export const itemDeleteSuccess = (odataResp : any) => {
    return {
        type: ITEM_DELETE_SUCCESS,
        payload: odataResp
    }
};

export const itemDeleteFailure = (error) => {
    return {
        type: ITEM_DELETE_FAILURE,
        payload: error
    }
};

export const itemImport = (params:ODataParams) => {
    return {
        type: ITEM_IMPORT_ITEMS,
        payload: params
    };
};

export const itemImportSuccess = (odataResp:any) => {
    return {
        type: ITEM_IMPORT_ITEMS_SUCCESS,
        payload: odataResp
    }
};

export const itemImportFailure = (error) => {
    return {
        type: ITEM_IMPORT_ITEMS_FAILURE,
        payload: error
    }
};


export const itemGetImportStatus = (pid : string, importStart : string) => {
    return {
        type: ITEM_IMPORT_GET_STATUS,
        payload : { pid, importStart }
    };
};

export const itemGetImportStatusSuccess = (apiResp:any) => {
    return {
        type: ITEM_IMPORT_GET_STATUS_SUCCESS,
        payload: apiResp
    }
};

export const itemGetImportStatusFailure = (error) => {
    return {
        type: ITEM_IMPORT_GET_STATUS_FAILURE,
        payload: error
    }
};