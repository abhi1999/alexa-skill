import { 
    PACKAGE_GET_ALL, 
    PACKAGE_GET_ALL_SUCCESS, 
    PACKAGE_GET_ALL_FAILURE,
    PACKAGE_GET_ONE,
    PACKAGE_GET_ONE_SUCCESS,
    PACKAGE_GET_ONE_FAILURE,
    PACKAGE_ADD,
    PACKAGE_ADD_SUCCESS,
    PACKAGE_ADD_FAILURE,
    PACKAGE_UPDATE,
    PACKAGE_UPDATE_SUCCESS,
    PACKAGE_UPDATE_FAILURE,
    PACKAGE_DELETE,
    PACKAGE_DELETE_SUCCESS,
    PACKAGE_DELETE_FAILURE,

} from './../constants/ActionTypes';

import { IPackage } from '../constants/edidb'
import ODataParams from '../constants/params/oDataParams';

export const packageGetAll = (params:ODataParams) => {
    return {
        type: PACKAGE_GET_ALL,
        payload: params
    };
};

export const packageGetAllSuccess = (packageList:IPackage[]) => {
    return {
        type: PACKAGE_GET_ALL_SUCCESS,
        payload:packageList
    }
};

export const packageGetAllFailure = (error) => {
    return {
        type: PACKAGE_GET_ALL_FAILURE,
        payload: error
    }
};

export const packageGetOne = (code:any) => {
    return {
        type: PACKAGE_GET_ONE,
        payload: code
    };
};

export const packageGetOneSuccess = (odataResp : any) => {
    return {
        type: PACKAGE_GET_ONE_SUCCESS,
        payload: odataResp
    }
};

export const packageGetOneFailure = (error) => {
    return {
        type: PACKAGE_GET_ONE_FAILURE,
        payload: error
    }
};

export const packageAdd = (packRecord:IPackage) => {
    return {
        type: PACKAGE_ADD,
        payload: packRecord
    };
};

export const packageAddSuccess = (packRecord:IPackage) => {
    return {
        type: PACKAGE_ADD_SUCCESS,
        payload: packRecord
    }
};

export const packageAddFailure = (error) => {
    return {
        type: PACKAGE_ADD_FAILURE,
        payload: error
    }
};

export const packageUpdate = (packRecord:IPackage) => {
    return {
        type: PACKAGE_UPDATE,
        payload: packRecord
    };
};

export const packageUpdateSuccess = (packRecord:IPackage) => {
    return {
        type: PACKAGE_UPDATE_SUCCESS,
        payload: packRecord
    }
};

export const packageUpdateFailure = (error) => {
    return {
        type: PACKAGE_UPDATE_FAILURE,
        payload: error
    }
};

export const packageDelete = (packRecord:IPackage) => {
    return {
        type: PACKAGE_DELETE,
        payload: packRecord
    };
};

export const packageDeleteSuccess = (packRecord:IPackage) => {
    return {
        type: PACKAGE_DELETE_SUCCESS,
        payload: packRecord
    }
};

export const packageDeleteFailure = (error) => {
    return {
        type: PACKAGE_DELETE_FAILURE,
        payload: error
    }
};


