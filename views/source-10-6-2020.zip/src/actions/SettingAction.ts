import {
    SWITCH_LANGUAGE,
    TOGGLE_COLLAPSED_NAV,
    WINDOW_WIDTH,
    GET_LAST_MODIFIED,
    GET_VERSION_INFO,
    GET_VERSION_INFO_SUCCESS,
    GET_VERSION_INFO_FAILURE,
    GET_ERROR_INFO,
    GET_ERROR_INFO_SUCCESS,
    GET_ERROR_INFO_FAILURE,
    SWITCH_COMPANY,
    GET_COMPANYLIST,
    GET_COMPANYLIST_FAILURE,
    GET_COMPANYLIST_SUCCESS,
    GET_COMPANYLIST_WITH_IMPERSONATION,
    // GET_COMPANYLIST_FAILURE_WITH_IMPERSONATION,
    // GET_COMPANYLIST_SUCCESS_WITH_IMPERSONATION,
    COMPANY_COPY,
    COMPANY_COPY_SUCCESS,
    COMPANY_COPY_FAILURE,
    GET_SERVER_CERTIFICATES,
    GET_SERVER_CERTIFICATES_SUCCESS,
    GET_SERVER_CERTIFICATES_FAILURE,
}
    from './../constants/ActionTypes';
import { lsLocale } from '../constants/index';
import { ILocaleInformation } from 'src/components/LanguageSwitcher/data';
import { ICompanyData } from "../constants/EDICompany/ICompanyData";
import { IServerCertificates} from "../constants/IServerCertificates"

export function toggleCollapsedNav(isNavCollapsed) {
    return { type: TOGGLE_COLLAPSED_NAV, isNavCollapsed };
}

export function updateWindowWidth(width) {
    return { type: WINDOW_WIDTH, width };
}

export function switchLanguage(locale: ILocaleInformation) {
    if (locale.locale !== undefined) {
        // Should always be not undefined except when testing
        localStorage.setItem(lsLocale, locale.locale);  // Keep for next time
    }
    return {
        type: SWITCH_LANGUAGE,
        payload: locale
    };
}

export const getVersionInfo = () => {
    return {
        type: GET_VERSION_INFO
    };
};

export const getVersionInfoSuccess = (versionInfo) => {
    return {
        type: GET_VERSION_INFO_SUCCESS,
        payload: versionInfo
    }
};

export const getVersionInfoFailure = (error) => {
    return {
        type: GET_VERSION_INFO_FAILURE,
        payload: error
    }
};

export const getErrorInfo = () => {
    return {
        type: GET_ERROR_INFO
    };
};

export const getErrorInfoSuccess = (errorInfo) => {
    return {
        type: GET_ERROR_INFO_SUCCESS,
        payload: errorInfo
    }
};

export const getErrorInfoFailure = (error) => {
    return {
        type: GET_ERROR_INFO_FAILURE,
        payload: error
    }
};

export const getCompanyList = () => {
    return {
        type: GET_COMPANYLIST
    };
};

export const getCompanyListSuccess = (errorInfo) => {
    return {
        type: GET_COMPANYLIST_SUCCESS,
        payload: errorInfo
    }
};

export const getCompanyListFailure = (error) => {
    return {
        type: GET_COMPANYLIST_FAILURE,
        payload: error
    }
};

export const getCompanyListWithImpersonation = () => {
    return {
        type: GET_COMPANYLIST_WITH_IMPERSONATION
    };
};

// export const getCompanyListSuccessWithImpersonation = (errorInfo) => {
//     return {
//         type: GET_COMPANYLIST_SUCCESS_WITH_IMPERSONATION,
//         payload: errorInfo
//     }
// };

// export const getCompanyListFailureWithImpersonation = (error) => {
//     return {
//         type: GET_COMPANYLIST_FAILURE_WITH_IMPERSONATION,
//         payload: error
//     }
// };


export const switchCompany = (company) => {
    return {
        type: SWITCH_COMPANY,
        payload: company
    }
};

export const companyCopy = (companyData: ICompanyData) => {
    return {
        type: COMPANY_COPY,
        payload: companyData
    };
};

export const companyCopySuccess = (companyData: ICompanyData) => {
    return {
        type: COMPANY_COPY_SUCCESS,
        payload: companyData
    }
};

export const companyCopyFailure = (error) => {
    return {
        type: COMPANY_COPY_FAILURE,
        payload: error
    }
};

export const getServerCertificates = () => {
    return {
        type: GET_SERVER_CERTIFICATES,
    };
};

export const getServerCertificatesSuccess = (serverCertificates: IServerCertificates) => {
    return {
        type: GET_SERVER_CERTIFICATES_SUCCESS,
        payload: serverCertificates
    }
};

export const getServerCertificatesFailure = (error) => {
    return {
        type: GET_SERVER_CERTIFICATES_FAILURE,
        payload: error
    }
};