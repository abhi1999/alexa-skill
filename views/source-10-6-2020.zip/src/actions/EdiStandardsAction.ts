import { 
    EDISTANDARDS_GET_KNOWNSTANDARDS,
    EDISTANDARDS_GET_KNOWNSTANDARDS_FAILURE,
    EDISTANDARDS_GET_KNOWNSTANDARDS_SUCCESS,
    EDISTANDARDS_DOWNLOAD,
    EDISTANDARDS_DOWNLOAD_FAILURE,
    EDISTANDARDS_DOWNLOAD_SUCCESS,
    EDISTANDARDS_INSTALL,
    EDISTANDARDS_INSTALL_FAILURE,
    EDISTANDARDS_INSTALL_SUCCESS,
    EDISTANDARDS_PURGE,
    EDISTANDARDS_PURGE_FAILURE,
    EDISTANDARDS_PURGE_SUCCESS,
    EDISTANDARDS_GET_DISTINCT_DOCS,
    EDISTANDARDS_GET_DISTINCT_DOCS_SUCCESS,
    EDISTANDARDS_GET_DISTINCT_DOCS_FAILURE,
    EDISTANDARDS_PROCESSSTATUS,
    EDISTANDARDS_PROCESSSTATUS_FAILURE,
    EDISTANDARDS_PROCESSSTATUS_SUCCESS,
    EDISTANDARDS_PROCESSLOG,
    EDISTANDARDS_PROCESSLOG_FAILURE,
    EDISTANDARDS_PROCESSLOG_SUCCESS

} from '../constants/ActionTypes';
import { IDmsEdiStdList } from '../constants/DMSDatamasons';
import { IKnownStandardsStatusReturn } from 'src/constants/DMS.EDI.Shared.Interfaces';

export const ediStandardsGetKnownStandards = (params:any) => {
    return {
        type: EDISTANDARDS_GET_KNOWNSTANDARDS,
        payload: params
    };
};

export const ediStandardsGetKnownStandardsSuccess = (apiResp : any) => {
    return {
        type: EDISTANDARDS_GET_KNOWNSTANDARDS_SUCCESS,
        payload: apiResp
    }
};

export const ediStandardsGetKnownStandardsFailure = (error) => {
    return {
        type: EDISTANDARDS_GET_KNOWNSTANDARDS_FAILURE,
        payload: error
    }
};


export const ediStandardsDownload = (list:IDmsEdiStdList[]) => {
    return {
        type: EDISTANDARDS_DOWNLOAD,
        payload: list
    };
};

export const ediStandardsDownloadSuccess = (apiResp : any) => {
    return {
        type: EDISTANDARDS_DOWNLOAD_SUCCESS,
        payload: apiResp
    }
};

export const ediStandardsDownloadFailure = (error) => {
    return {
        type: EDISTANDARDS_DOWNLOAD_FAILURE,
        payload: error
    }
};


export const ediStandardsInstall = (list:IDmsEdiStdList[]) => {
    return {
        type: EDISTANDARDS_INSTALL,
        payload: list
    };
};

export const ediStandardsInstallSuccess = (apiResp : any) => {
    return {
        type: EDISTANDARDS_INSTALL_SUCCESS,
        payload: apiResp
    }
};

export const ediStandardsInstallFailure = (error) => {
    return {
        type: EDISTANDARDS_INSTALL_FAILURE,
        payload: error
    }
};


export const ediStandardsPurge = (params:any) => {
    return {
        type: EDISTANDARDS_PURGE,
        payload: params
    };
};

export const ediStandardsPurgeSuccess = (action : any) => {
    return {
        type: EDISTANDARDS_PURGE_SUCCESS,
        payload : action
    }
};

export const ediStandardsPurgeFailure = (error) => {
    return {
        type: EDISTANDARDS_PURGE_FAILURE,
        payload: error
    }
};

export const ediStandardsGetDistinctDocs = (params:any) => {
    return {
        type: EDISTANDARDS_GET_DISTINCT_DOCS,
        payload: params
    };
};

export const ediStandardsGetDistinctDocsSuccess = (apiResp : any) => {
    return {
        type: EDISTANDARDS_GET_DISTINCT_DOCS_SUCCESS,
        payload: apiResp
    }
};

export const ediStandardsGetDistinctDocsFailure = (error) => {
    return {
        type: EDISTANDARDS_GET_DISTINCT_DOCS_FAILURE,
        payload: error
    }
};

export const ediStandardsProcessStatus = (params:IKnownStandardsStatusReturn) => {
    return {
        type: EDISTANDARDS_PROCESSSTATUS,
        payload: params
    };
};

export const ediStandardsProcessStatusSuccess = (apiResp : any) => {
    return {
        type: EDISTANDARDS_PROCESSSTATUS_SUCCESS,
        payload: apiResp
    }
};

export const ediStandardsProcessStatusFailure = (error) => {
    return {
        type: EDISTANDARDS_PROCESSSTATUS_FAILURE,
        payload: error
    }
};

export const ediStandardsProcessLog = (params:IKnownStandardsStatusReturn) => {
    return {
        type: EDISTANDARDS_PROCESSLOG,
        payload: params
    };
};

export const ediStandardsProcessLogSuccess = (apiResp : any) => {
    return {
        type: EDISTANDARDS_PROCESSLOG_SUCCESS,
        payload: apiResp
    }
};

export const ediStandardsProcessLogFailure = (error) => {
    return {
        type: EDISTANDARDS_PROCESSLOG_FAILURE,
        payload: error
    }
};