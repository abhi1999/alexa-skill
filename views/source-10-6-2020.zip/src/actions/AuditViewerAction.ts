
import { 
    AUDITVIEWER_GET_ALL, 
    AUDITVIEWER_GET_ALL_SUCCESS, 
    AUDITVIEWER_GET_ALL_FAILURE, 
    AUDITVIEWER_GET_ONE,
    AUDITVIEWER_GET_ONE_FAILURE,
    AUDITVIEWER_GET_ONE_SUCCESS,
    AUDITVIEWER_UPDATE, 
    AUDITVIEWER_UPDATE_SUCCESS, 
    AUDITVIEWER_UPDATE_FAILURE,
    AUDITVIEWER_DELETE, 
    AUDITVIEWER_DELETE_SUCCESS, 
    AUDITVIEWER_DELETE_FAILURE,
} from '../constants/ActionTypes';
import ODataParams from '../constants/params/oDataParams';
import { IAuditViewer } from 'src/constants/edidb';

export const auditViewerGetAll = (params:ODataParams) => {
    return {
        type: AUDITVIEWER_GET_ALL,
        payload: params
    };
};

export const auditViewerGetAllSuccess = (odataResp : any) => {
    return {
        type: AUDITVIEWER_GET_ALL_SUCCESS,
        payload: odataResp
    }
};

export const auditViewerGetAllFailure = (error) => {
    return {
        type: AUDITVIEWER_GET_ALL_FAILURE,
        payload: error
    }
};


export const auditViewerGetOne = (params:ODataParams) => {
    return {
        type: AUDITVIEWER_GET_ONE,
        payload: params
    };
};

export const auditViewerGetOneSuccess = (odataResp : any) => {
    return {
        type: AUDITVIEWER_GET_ONE_SUCCESS,
        payload: odataResp
    }
};

export const auditViewerGetOneFailure = (error) => {
    return {
        type: AUDITVIEWER_GET_ONE_FAILURE,
        payload: error
    }
};

export const auditViewerUpdate = (AUDITVIEWER:IAuditViewer, Approve: boolean) => {
    return {
        type: AUDITVIEWER_UPDATE,
        payload: AUDITVIEWER,
        approve: Approve
    };
};

export const auditViewerUpdateSuccess = (AUDITVIEWER:IAuditViewer) => {
    return {
        type: AUDITVIEWER_UPDATE_SUCCESS,
        payload: AUDITVIEWER
    }
};

export const auditViewerUpdateFailure = (error) => {
    return {
        type: AUDITVIEWER_UPDATE_FAILURE,
        payload: error
    }
};

export const auditViewerDelete = (AUDITVIEWER:IAuditViewer) => {
    return {
        type: AUDITVIEWER_DELETE,
        payload: AUDITVIEWER
    };
};

export const auditViewerDeleteSuccess = (AUDITVIEWER:IAuditViewer) => {
    return {
        type: AUDITVIEWER_DELETE_SUCCESS,
        payload: AUDITVIEWER
    }
};

export const auditViewerDeleteFailure = (error) => {
    return {
        type: AUDITVIEWER_DELETE_FAILURE,
        payload: error
    }
};

