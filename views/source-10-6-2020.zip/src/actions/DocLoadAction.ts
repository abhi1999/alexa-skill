import { 
    DOCLOAD_GET_ALL, 
    DOCLOAD_GET_ALL_SUCCESS, 
    DOCLOAD_GET_ALL_FAILURE,
    DOCLOAD_GET_ONE,
    DOCLOAD_GET_ONE_SUCCESS,
    DOCLOAD_GET_ONE_FAILURE,
    DOCLOAD_ADD, 
    DOCLOAD_ADD_SUCCESS, 
    DOCLOAD_ADD_FAILURE,
    DOCLOAD_UPDATE, 
    DOCLOAD_UPDATE_SUCCESS, 
    DOCLOAD_UPDATE_FAILURE,
    DOCLOAD_DELETE, 
    DOCLOAD_DELETE_SUCCESS, 
    DOCLOAD_DELETE_FAILURE,
    DOCLOAD_GET_LOOKUPTABLES,
    DOCLOAD_GET_LOOKUPTABLES_SUCCESS,
    DOCLOAD_GET_LOOKUPTABLES_FAILURE

} from './../constants/ActionTypes';

import { IApiDocLoadConfig} from '../constants/edidb'
import ODataParams from '../constants/params/oDataParams';

export const docLoadGetAll = (params:ODataParams) => {
    return {
        type: DOCLOAD_GET_ALL,
        payload: params
    };
};

export const docLoadGetAllSuccess = (docLoadList:IApiDocLoadConfig[]) => {
    return {
        type: DOCLOAD_GET_ALL_SUCCESS,
        payload:docLoadList
    }
};

export const docLoadGetAllFailure = (error) => {
    return {
        type: DOCLOAD_GET_ALL_FAILURE,
        payload: error
    }
};
export const docLoadGetOne = (params:any) => {
    return {
        type: DOCLOAD_GET_ONE,
        payload: params
    };
};

export const docLoadGetOneSuccess = (odataResp:any) => {
    return {
        type: DOCLOAD_GET_ONE_SUCCESS,
        payload:odataResp
    }
};

export const docLoadGetOneFailure = (error) => {
    return {
        type: DOCLOAD_GET_ONE_FAILURE,
        payload: error
    }
};

export const docLoadAdd = (docLoad:IApiDocLoadConfig) => {
    return {
        type: DOCLOAD_ADD,
        payload: docLoad
    };
};

export const docLoadAddSuccess = (docLoad:IApiDocLoadConfig) => {
    return {
        type: DOCLOAD_ADD_SUCCESS,
        payload: docLoad
    }
};

export const docLoadAddFailure = (error) => {
    return {
        type: DOCLOAD_ADD_FAILURE,
        payload: error
    }
};

export const docLoadUpdate = (docLoad:IApiDocLoadConfig) => {
    return {
        type: DOCLOAD_UPDATE,
        payload: docLoad
    };
};

export const docLoadUpdateSuccess = (docLoad:IApiDocLoadConfig) => {
    return {
        type: DOCLOAD_UPDATE_SUCCESS,
        payload: docLoad
    }
};

export const docLoadUpdateFailure = (error) => {
    return {
        type: DOCLOAD_UPDATE_FAILURE,
        payload: error
    }
};

export const docLoadDelete = (docLoad:IApiDocLoadConfig) => {
    return {
        type: DOCLOAD_DELETE,
        payload: docLoad
    };
};

export const docLoadDeleteSuccess = (docLoad:IApiDocLoadConfig) => {
    return {
        type: DOCLOAD_DELETE_SUCCESS,
        payload: docLoad
    }
};

export const docLoadDeleteFailure = (error) => {
    return {
        type: DOCLOAD_DELETE_FAILURE,
        payload: error
    }
};

export const docLoadGetLookupTables = () => {
    return {
        type: DOCLOAD_GET_LOOKUPTABLES,
    };
};

export const docLoadGetLookupTablesSuccess = () => {
    return {
        type: DOCLOAD_GET_LOOKUPTABLES_SUCCESS,
    }
};

export const docLoadGetLookupTablesFailure = (error) => {
    return {
        type: DOCLOAD_GET_LOOKUPTABLES_FAILURE,
        payload: error
    }
};