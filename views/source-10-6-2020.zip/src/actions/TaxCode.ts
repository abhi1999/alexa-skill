import { 
    TAXCODE_GET_LOOKUPS, 
    TAXCODE_GET_LOOKUPS_SUCCESS, 
    TAXCODE_GET_LOOKUPS_FAILURE, 
    TAXCODE_GET_ALL, 
    TAXCODE_GET_ALL_SUCCESS, 
    TAXCODE_GET_ALL_FAILURE, 
    TAXCODE_GET_ONE, 
    TAXCODE_GET_ONE_SUCCESS, 
    TAXCODE_GET_ONE_FAILURE, 
    TAXCODE_ADD, 
    TAXCODE_ADD_SUCCESS, 
    TAXCODE_ADD_FAILURE, 
    TAXCODE_UPDATE, 
    TAXCODE_UPDATE_SUCCESS, 
    TAXCODE_UPDATE_FAILURE,
    TAXCODE_DELETE, 
    TAXCODE_DELETE_SUCCESS, 
    TAXCODE_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { ITaxCode } from '../constants/edidb';

export const taxCodeGetLookups = (params: ODataParams) => {
    return {
        type: TAXCODE_GET_LOOKUPS,
        payload: params
    };
};

export const taxCodeGetLookupsSuccess = ( tradeList: any, ) => {
    return {
        type: TAXCODE_GET_LOOKUPS_SUCCESS,
        payload: { tradeList, }
    }
};

export const taxCodeGetLookupsFailure = (error) => {
    return {
        type: TAXCODE_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const taxCodeGetAll = (params: ODataParams) => {
    return {
        type: TAXCODE_GET_ALL,
        payload: params
    };
};

export const taxCodeGetAllSuccess = (taxCodeList: any) => {
    return {
        type: TAXCODE_GET_ALL_SUCCESS,
        payload: taxCodeList
    }
};

export const taxCodeGetAllFailure = (error) => {
    return {
        type: TAXCODE_GET_ALL_FAILURE,
        payload: error
    }
};

export const taxCodeGetOne = (params: ODataParams) => {
    return {
        type: TAXCODE_GET_ONE,
        payload: params
    };
};

export const taxCodeGetOneSuccess = (taxCodeList: any) => {
    return {
        type: TAXCODE_GET_ONE_SUCCESS,
        payload: taxCodeList
    }
};

export const taxCodeGetOneFailure = (error) => {
    return {
        type: TAXCODE_GET_ONE_FAILURE,
        payload: error
    }
};

export const taxCodeAdd = (taxCode: ITaxCode) => {
    return {
        type: TAXCODE_ADD,
        payload: taxCode
    };
};

export const taxCodeAddSuccess = (taxCode: ITaxCode) => {
    return {
        type: TAXCODE_ADD_SUCCESS,
        payload: taxCode
    }
};

export const taxCodeAddFailure = (error) => {
    return {
        type: TAXCODE_ADD_FAILURE,
        payload: error
    }
};

export const taxCodeUpdate = (taxCode: ITaxCode) => {
    return {
        type: TAXCODE_UPDATE,
        payload: taxCode
    };
};

export const taxCodeUpdateSuccess = (taxCode: ITaxCode) => {
    return {
        type: TAXCODE_UPDATE_SUCCESS,
        payload: taxCode
    }
};

export const taxCodeUpdateFailure = (error) => {
    return {
        type: TAXCODE_UPDATE_FAILURE,
        payload: error
    }
};

export const taxCodeDelete = (taxCode: ITaxCode) => {
    return {
        type: TAXCODE_DELETE,
        payload: taxCode
    };
};

export const taxCodeDeleteSuccess = (taxCode: ITaxCode) => {
    return {
        type: TAXCODE_DELETE_SUCCESS,
        payload: taxCode
    }
};

export const taxCodeDeleteFailure = (error) => {
    return {
        type: TAXCODE_DELETE_FAILURE,
        payload: error
    }
};
