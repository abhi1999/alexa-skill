import ODataParams from '../constants/params/oDataParams';
import {
OSN_GENERAL,OSN_GENERAL_SUCCESS,OSN_GENERAL_FAILURE,
OSN_NOTES,OSN_NOTES_SUCCESS,OSN_NOTES_FAILURE,
OSN_DETAILSDATES,OSN_DETAILSDATES_SUCCESS,OSN_DETAILSDATES_FAILURE,
OSN_DESTINATION,OSN_DESTINATION_SUCCESS,OSN_DESTINATION_FAILURE,
OSN_DEPARTURE,OSN_DEPARTURE_SUCCESS,OSN_DEPARTURE_FAILURE,
OSN_SETNEXT,OSN_SETNEXT_SUCCESS,OSN_SETNEXT_FAILURE,
OSN_ORDERS,OSN_ORDERS_SUCCESS,OSN_ORDERS_FAILURE,
OSN_CONTAINERLABEL,OSN_CONTAINERLABEL_SUCCESS,OSN_CONTAINERLABEL_FAILURE,
OSN_OSNLIST,OSN_OSNLIST_SUCCESS,OSN_OSNLIST_FAILURE,
OSN_PACKDETAILS,OSN_PACKDETAILS_SUCCESS,OSN_PACKDETAILS_FAILURE,
} from '../constants/ActionTypes';

// OSN_DESTINATION calls
export interface IOSNDestinationParameters {
    custpo : string,
    tppartid : string,
    xref : string,
    asnid : string
}
    
export const osnGeneral = (params : ODataParams) => {
    return {
        type: OSN_GENERAL,
        payload: params
    };
};

export const osnGeneralSuccess = (apiResp : any) => {
    return {
        type: OSN_GENERAL_SUCCESS,
        payload: apiResp
    };
};

export const osnGeneralFailure = (error : Error) => {
    return {
        type: OSN_GENERAL_FAILURE,
        payload: error
    };
};

export const osnNotes = (params : ODataParams) => {
    return {
        type: OSN_NOTES,
        payload: params
    };
};

export const osnNotesSuccess = (apiResp : any) => {
    return {
        type: OSN_NOTES_SUCCESS,
        payload: apiResp
    };
};

export const osnNotesFailure = (error : Error) => {
    return {
        type: OSN_NOTES_FAILURE,
        payload: error
    };
};

export const osnDetailsdates = (params : ODataParams) => {
    return {
        type: OSN_DETAILSDATES,
        payload: params
    };
};

export const osnDetailsdatesSuccess = (apiResp : any) => {
    return {
        type: OSN_DETAILSDATES_SUCCESS,
        payload: apiResp
    };
};

export const osnDetailsdatesFailure = (error : Error) => {
    return {
        type: OSN_DETAILSDATES_FAILURE,
        payload: error
    };
};

export const osnDestination = (params : IOSNDestinationParameters) => {
    return {
        type: OSN_DESTINATION,
        payload: params
    };
};

export const osnDestinationSuccess = (apiResp : any) => {
    return {
        type: OSN_DESTINATION_SUCCESS,
        payload: apiResp
    };
};

export const osnDestinationFailure = (error : Error) => {
    return {
        type: OSN_DESTINATION_FAILURE,
        payload: error
    };
};


export const osnDeparture = (params : ODataParams) => {
    return {
        type: OSN_DEPARTURE,
        payload: params
    };
};

export const osnDepartureSuccess = (apiResp : any) => {
    return {
        type: OSN_DEPARTURE_SUCCESS,
        payload: apiResp
    };
};

export const osnDepartureFailure = (error : Error) => {
    return {
        type: OSN_DEPARTURE_FAILURE,
        payload: error
    };
};

export const osnSetnext = (params : ODataParams) => {
    return {
        type: OSN_SETNEXT,
        payload: params
    };
};

export const osnSetnextSuccess = (apiResp : any) => {
    return {
        type: OSN_SETNEXT_SUCCESS,
        payload: apiResp
    };
};

export const osnSetnextFailure = (error : Error) => {
    return {
        type: OSN_SETNEXT_FAILURE,
        payload: error
    };
};

export const osnOrders = (params : ODataParams) => {
    return {
        type: OSN_ORDERS,
        payload: params
    };
};

export const osnOrdersSuccess = (apiResp : any) => {
    return {
        type: OSN_ORDERS_SUCCESS,
        payload: apiResp
    };
};

export const osnOrdersFailure = (error : Error) => {
    return {
        type: OSN_ORDERS_FAILURE,
        payload: error
    };
};

export const osnContainerlabel = (params : ODataParams) => {
    return {
        type: OSN_CONTAINERLABEL,
        payload: params
    };
};

export const osnContainerlabelSuccess = (apiResp : any) => {
    return {
        type: OSN_CONTAINERLABEL_SUCCESS,
        payload: apiResp
    };
};

export const osnContainerlabelFailure = (error : Error) => {
    return {
        type: OSN_CONTAINERLABEL_FAILURE,
        payload: error
    };
};

export const osnOsnlist = (params : ODataParams) => {
    return {
        type: OSN_OSNLIST,
        payload: params
    };
};

export const osnOsnlistSuccess = (apiResp : any) => {
    return {
        type: OSN_OSNLIST_SUCCESS,
        payload: apiResp
    };
};

export const osnOsnlistFailure = (error : Error) => {
    return {
        type: OSN_OSNLIST_FAILURE,
        payload: error
    };
};

export const osnPackdetails = (params : any) => {
    return {
        type: OSN_PACKDETAILS,
        payload: params
   };
};

export const osnPackdetailsSuccess = (apiResp : any) => {
    return {
        type: OSN_PACKDETAILS_SUCCESS,
        payload: apiResp
   };
};

export const osnPackdetailsFailure = (error : Error) => {
    return {
        type: OSN_PACKDETAILS_FAILURE,
        payload: error
   };
};