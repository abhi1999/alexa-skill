import { 
    EDI_DOC_GROUP_GET_ALL, 
    EDI_DOC_GROUP_GET_ALL_SUCCESS, 
    EDI_DOC_GROUP_GET_ALL_FAILURE
} from './../constants/ActionTypes';

import { IEDIDocGroup} from '../constants/edidb'

export const ediDocGroupGetAll = () => {
    return {
        type: EDI_DOC_GROUP_GET_ALL,
    };
};

export const ediDocGroupGetAllSuccess = (ediDocGroupList:any) => {
    return {
        type: EDI_DOC_GROUP_GET_ALL_SUCCESS,
        payload:ediDocGroupList
    }
};

export const ediDocGroupGetAllFailure = (error) => {
    return {
        type: EDI_DOC_GROUP_GET_ALL_FAILURE,
        payload: error
    }
};

