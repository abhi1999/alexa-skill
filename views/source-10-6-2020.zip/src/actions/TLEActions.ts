
import {    
    TLE_WORKFLOW_DETAILS_LOAD_START,
    TLE_WORKFLOW_DETAILS_LOAD_SUCCESS,
    TLE_WORKFLOW_DETAILS_LOAD_ERROR,
    TLE_WORKFLOW_RETRY_START,
    TLE_WORKFLOW_RETRY_SUCCESS,
    TLE_WORKFLOW_RETRY_ERROR,
    TLE_WORKFLOW_RAW_DATA_LOAD_START,
    TLE_WORKFLOW_RAW_DATA_LOAD_SUCCESS, 
    TLE_WORKFLOW_RAW_DATA_LOAD_ERROR,
    TLE_WORKFLOW_REPORT_DATA_LOAD_START,
    TLE_WORKFLOW_REPORT_DATA_LOAD_SUCCESS,
    TLE_WORKFLOW_REPORT_DATA_LOAD_ERROR,
    TLE_WORKFLOW_ERROR_DATA_LOAD_START,
    TLE_WORKFLOW_ERROR_DATA_LOAD_SUCCESS, 
    TLE_WORKFLOW_ERROR_DATA_LOAD_ERROR,    
    TLE_WORKFLOW_ERROR_CODE_DATA_LOAD_START,
    TLE_WORKFLOW_ERROR_CODE_DATA_LOAD_SUCCESS,
    TLE_WORKFLOW_ERROR_CODE_DATA_LOAD_ERROR,
    TLE_WORKFLOW_STATUS_DETAILS_DATA_LOAD_START,
    TLE_WORKFLOW_STATUS_DETAILS_DATA_LOAD_SUCCESS,
    TLE_WORKFLOW_STATUS_DETAILS_DATA_LOAD_ERROR,
    TLE_WORKFLOW_LOOKUP_START,
    TLE_WORKFLOW_LOOKUP_SUCCESS,
    TLE_WORKFLOW_LOOKUP_ERROR
    } from './../constants/ActionTypes';

export const tleWorkflowDetailsLoad = (params: any) => {
    return {
        type: TLE_WORKFLOW_DETAILS_LOAD_START,
        payload: params
    };
};

export const tleWorkflowDetailsLoadSuccess = ( tleWorkflowDetails: any ) => {
    return {
        type: TLE_WORKFLOW_DETAILS_LOAD_SUCCESS,
        payload: tleWorkflowDetails
    }
};

export const tleWorkflowDetailsLoadFailure = (error) => {
    return {
        type: TLE_WORKFLOW_DETAILS_LOAD_ERROR,
        payload: error
    }
};
    

export const tleRetryWorkflow = (params: any) => {
    return {
        type: TLE_WORKFLOW_RETRY_START,
        payload: params
    };
};
export const tleRetryWorkflowSuccess = (params:any) => {
    return {
        type: TLE_WORKFLOW_RETRY_SUCCESS,
        payload: params
    };
};
export const tleRetryWorkflowFailure = (error: any) => {
    return {
        type: TLE_WORKFLOW_RETRY_ERROR,
        payload: error
    };
};


export const tleWorkflowRawDataLoad = (params: any) => {
    return {
        type: TLE_WORKFLOW_RAW_DATA_LOAD_START,
        payload: params
    };
};

export const tleWorkflowRawDataSuccess = ( tleWorkflowRawDataDetails: any ) => {
    return {
        type: TLE_WORKFLOW_RAW_DATA_LOAD_SUCCESS,
        payload: tleWorkflowRawDataDetails
    }
};

export const tleWorkflowRawDataFailure = (error) => {
    return {
        type: TLE_WORKFLOW_RAW_DATA_LOAD_ERROR,
        payload: error
    }
};
    

export const tleWorkflowReportDataLoad = (params: any) => {
    return {
        type: TLE_WORKFLOW_REPORT_DATA_LOAD_START,
        payload: params
    };
};

export const tleWorkflowReportDataSuccess = ( tleWorkflowReportDetails: any ) => {
    return {
        type: TLE_WORKFLOW_REPORT_DATA_LOAD_SUCCESS,
        payload: tleWorkflowReportDetails
    }
};

export const tleWorkflowReportDataFailure = (error) => {
    return {
        type: TLE_WORKFLOW_REPORT_DATA_LOAD_ERROR,
        payload: error
    }
};



export const tleWorkflowErrorDataLoad = (params: any) => {
    return {
        type: TLE_WORKFLOW_ERROR_DATA_LOAD_START,
        payload: params
    };
};

export const tleWorkflowErrorDataSuccess = ( tleWorkflowErrorData: any[] ) => {
    return {
        type: TLE_WORKFLOW_ERROR_DATA_LOAD_SUCCESS,
        payload: tleWorkflowErrorData
    }
};

export const tleWorkflowErrorDataFailure = (error) => {
    return {
        type: TLE_WORKFLOW_ERROR_DATA_LOAD_ERROR,
        payload: error
    }
};


export const tleWorkflowErrorCodeDataLoad = (params: any) => {
    return {
        type: TLE_WORKFLOW_ERROR_CODE_DATA_LOAD_START,
        payload: params
    };
};

export const tleWorkflowErrorCodeDataSuccess = ( tleWorkflowErrorCodeData: any[] ) => {
    return {
        type: TLE_WORKFLOW_ERROR_CODE_DATA_LOAD_SUCCESS,
        payload: tleWorkflowErrorCodeData
    }
};

export const tleWorkflowErrorCodeDataFailure = (error) => {
    return {
        type: TLE_WORKFLOW_ERROR_CODE_DATA_LOAD_ERROR,
        payload: error
    }
};


export const tleWorkflowStatusDetailsDataLoad = (params: any) => {
    return {
    type: TLE_WORKFLOW_STATUS_DETAILS_DATA_LOAD_START,
        payload: params
    };
};

export const tleWorkflowStatusDetailsDataSuccess = ( tleStatusDetails: any[] ) => {
    return {
        type: TLE_WORKFLOW_STATUS_DETAILS_DATA_LOAD_SUCCESS,
        payload: tleStatusDetails
    }
};

export const tleWorkflowStatusDetailsDataFailure = (error) => {
    return {
        type: TLE_WORKFLOW_STATUS_DETAILS_DATA_LOAD_ERROR,
        payload: error
    }
};

    
export const tleWorkflowLookup = (params:string) => {
    return {
        type: TLE_WORKFLOW_LOOKUP_START,
        payload: params
    }
};

export const tleWorkflowLookupSuccess = (data) => {
    return {
        type: TLE_WORKFLOW_LOOKUP_SUCCESS,
        payload: data
    }
};


export const tleWorkflowLookupFailure = (error) => {
    return {
        type: TLE_WORKFLOW_LOOKUP_ERROR,
        payload: error
    }
};  