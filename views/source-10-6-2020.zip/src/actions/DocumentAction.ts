import { 
    DOCUMENT_GET_ALL, 
    DOCUMENT_GET_ALL_SUCCESS, 
    DOCUMENT_GET_ALL_FAILURE, 
    DOCUMENT_GET_LOOKUPTABLES, 
    DOCUMENT_GET_LOOKUPTABLES_SUCCESS, 
    DOCUMENT_GET_LOOKUPTABLES_FAILURE, 
    DOCUMENT_ADD, 
    DOCUMENT_ADD_SUCCESS, 
    DOCUMENT_ADD_FAILURE, 
    DOCUMENT_UPDATE, 
    DOCUMENT_UPDATE_SUCCESS, 
    DOCUMENT_UPDATE_FAILURE,
    DOCUMENT_UPDATE_STATUS, 
    DOCUMENT_UPDATE_STATUS_SUCCESS, 
    DOCUMENT_UPDATE_STATUS_FAILURE,
    DOCUMENT_DELETE, 
    DOCUMENT_DELETE_SUCCESS, 
    DOCUMENT_DELETE_FAILURE,
    DOCUMENT_GET_TERMS, 
    DOCUMENT_GET_TERMS_SUCCESS, 
    DOCUMENT_GET_TERMS_FAILURE, 
    DOCUMENT_GET_XML, 
    DOCUMENT_GET_XML_SUCCESS, 
    DOCUMENT_GET_XML_FAILURE, 
    DOCUMENT_GET_TLEURL, 
    DOCUMENT_GET_TLEURL_SUCCESS, 
    DOCUMENT_GET_TLEURL_FAILURE, 
    DOCUMENT_UPDATE_XML, 
    DOCUMENT_UPDATE_XML_SUCCESS, 
    DOCUMENT_UPDATE_XML_FAILURE, 
    DOCUMENT_MARK_RESOLVED,
    DOCUMENT_MARK_RESOLVED_SUCCESS,
    DOCUMENT_MARK_RESOLVED_FAILURE,

} from '../constants/ActionTypes';
import { IXMLDoc } from '../constants/edidb'
import ODataParams from '../constants/params/oDataParams';
import KeyValuePair from '../constants/params/keyValuePair';

export const documentGetAll = (params:ODataParams) => {
    return {
        type: DOCUMENT_GET_ALL,
        payload: params
    };
};

export const documentGetAllSuccess = (documentList:IXMLDoc[]) => {
    return {
        type: DOCUMENT_GET_ALL_SUCCESS,
        payload: documentList
    }
};

export const documentGetAllFailure = (error) => {
    return {
        type: DOCUMENT_GET_ALL_FAILURE,
        payload: error
    }
};

export const documentGetLookupTables = (params:any) => {
    return {
        type: DOCUMENT_GET_LOOKUPTABLES,
        payload: params
    };
};

export const documentGetLookupTablesSuccess = () => {
    return {
        type: DOCUMENT_GET_LOOKUPTABLES_SUCCESS,
    }
};

export const documentGetLookupTablesFailure = (error) => {
    return {
        type: DOCUMENT_GET_LOOKUPTABLES_FAILURE,
        payload: error
    }
};

export const documentAdd = (document:IXMLDoc) => {
    return {
        type: DOCUMENT_ADD,
        payload: document
    };
};

export const documentAddSuccess = (document:IXMLDoc) => {
    return {
        type: DOCUMENT_ADD_SUCCESS,
        payload: document
    }
};

export const documentAddFailure = (error) => {
    return {
        type: DOCUMENT_ADD_FAILURE,
        payload: error
    }
};

export const documentUpdate = (document:IXMLDoc) => {
    return {
        type: DOCUMENT_UPDATE,
        payload: document
    };
};

export const documentUpdateSuccess = (document:IXMLDoc) => {
    return {
        type: DOCUMENT_UPDATE_SUCCESS,
        payload: document
    }
};

export const documentUpdateFailure = (error) => {
    return {
        type: DOCUMENT_UPDATE_FAILURE,
        payload: error
    }
};

export const documentUpdateStatus = (vpidArray:number[], status:string) => {
    return {
        type: DOCUMENT_UPDATE_STATUS,
        payload: vpidArray,
        status
    };
};

export const documentUpdateStatusSuccess = (vpidArray:number[], status:string) => {
    return {
        type: DOCUMENT_UPDATE_STATUS_SUCCESS,
        payload: vpidArray,
        status
    }
};

export const documentUpdateStatusFailure = (error) => {
    return {
        type: DOCUMENT_UPDATE_STATUS_FAILURE,
        payload: error
    }
};

export const documentDelete = (document:any) => {
    return {
        type: DOCUMENT_DELETE,
        payload: document
    };
};

export const documentDeleteSuccess = (document:any) => {
    return {
        type: DOCUMENT_DELETE_SUCCESS,
        payload: document
    }
};

export const documentDeleteFailure = (error) => {
    return {
        type: DOCUMENT_DELETE_FAILURE,
        payload: error
    }
};

export const documentGetTerms = () => {
    return {
        type: DOCUMENT_GET_TERMS
    };
};

export const documentGetTermsSuccess = (termList:KeyValuePair[]) => {
    return {
        type: DOCUMENT_GET_TERMS_SUCCESS,
        payload: termList
    }
};

export const documentGetTermsFailure = (error) => {
    return {
        type: DOCUMENT_GET_TERMS_FAILURE,
        payload: error
    }
};

export const documentGetXml = (id:string) => {
    return {
        type: DOCUMENT_GET_XML,
        payload: id
    };
};

export const documentGetXmlSuccess = (result:any) => {
    return {
        type: DOCUMENT_GET_XML_SUCCESS,
        payload: result
    }
};

export const documentGetXmlFailure = (error) => {
    return {
        type: DOCUMENT_GET_XML_FAILURE,
        payload: error
    }
};

export const documentGetTLEUrl = () => {
    return {
        type: DOCUMENT_GET_TLEURL,
    };
};

export const documentGetTLEUrlSuccess = (result:any) => {
    return {
        type: DOCUMENT_GET_TLEURL_SUCCESS,
        payload: result
    }
};

export const documentGetTLEUrlFailure = (error) => {
    return {
        type: DOCUMENT_GET_TLEURL_FAILURE,
        payload: error
    }
};

export const documentUpdateXml = (VPID:string, xml:string) => {
    return {
        type: DOCUMENT_UPDATE_XML,
        VPID,
        payload: xml,
    };
};

export const documentUpdateXmlSuccess = (VPID:string, xml:string) => {
    return {
        type: DOCUMENT_UPDATE_XML_SUCCESS,
        VPID,
        payload: xml,
    }
};

export const documentUpdateXmlFailure = (error) => {
    return {
        type: DOCUMENT_UPDATE_XML_FAILURE,
        payload: error
    }
};

export const documentMarkResolved = (params:any) => {
    return {
        type: DOCUMENT_MARK_RESOLVED,
        payload: params,
    };
};

export const documentMarkResolvedSuccess = (params:any) => {
    return {
        type: DOCUMENT_MARK_RESOLVED_SUCCESS,
        payload: params,
    }
};

export const documentMarkResolvedFailure = (error) => {
    return {
        type: DOCUMENT_MARK_RESOLVED_FAILURE,
        payload: error
    }
};