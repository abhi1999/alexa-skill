import { 
    PROCESSTRIGGER_GET_LOOKUPS, 
    PROCESSTRIGGER_GET_LOOKUPS_SUCCESS, 
    PROCESSTRIGGER_GET_LOOKUPS_FAILURE, 
    PROCESSTRIGGER_GET_ALL, 
    PROCESSTRIGGER_GET_ALL_SUCCESS, 
    PROCESSTRIGGER_GET_ALL_FAILURE, 
    PROCESSTRIGGER_GET_ONE, 
    PROCESSTRIGGER_GET_ONE_SUCCESS, 
    PROCESSTRIGGER_GET_ONE_FAILURE, 
    PROCESSTRIGGER_ADD, 
    PROCESSTRIGGER_ADD_SUCCESS, 
    PROCESSTRIGGER_ADD_FAILURE, 
    PROCESSTRIGGER_UPDATE, 
    PROCESSTRIGGER_UPDATE_SUCCESS, 
    PROCESSTRIGGER_UPDATE_FAILURE,
    PROCESSTRIGGER_DELETE, 
    PROCESSTRIGGER_DELETE_SUCCESS, 
    PROCESSTRIGGER_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IProcessTrigger } from '../constants/edidb';

export const processTriggerGetLookups = (params: ODataParams) => {
    return {
        type: PROCESSTRIGGER_GET_LOOKUPS,
        payload: params
    };
};

export const processTriggerGetLookupsSuccess = ( processList, processSubList, /* tableNameList: any, ... */ ) => {
    return {
        type: PROCESSTRIGGER_GET_LOOKUPS_SUCCESS,
        payload: { processList, processSubList /* tableNameList, ... */ }
    }
};

export const processTriggerGetLookupsFailure = (error) => {
    return {
        type: PROCESSTRIGGER_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const processTriggerGetAll = (params: ODataParams) => {
    return {
        type: PROCESSTRIGGER_GET_ALL,
        payload: params
    };
};

export const processTriggerGetAllSuccess = (processTriggerList: any) => {
    return {
        type: PROCESSTRIGGER_GET_ALL_SUCCESS,
        payload: processTriggerList
    }
};

export const processTriggerGetAllFailure = (error) => {
    return {
        type: PROCESSTRIGGER_GET_ALL_FAILURE,
        payload: error
    }
};

export const processTriggerGetOne = (params: ODataParams) => {
    return {
        type: PROCESSTRIGGER_GET_ONE,
        payload: params
    };
};

export const processTriggerGetOneSuccess = (processTriggerList: any) => {
    return {
        type: PROCESSTRIGGER_GET_ONE_SUCCESS,
        payload: processTriggerList
    }
};

export const processTriggerGetOneFailure = (error) => {
    return {
        type: PROCESSTRIGGER_GET_ONE_FAILURE,
        payload: error
    }
};

export const processTriggerAdd = (processTrigger: IProcessTrigger) => {
    return {
        type: PROCESSTRIGGER_ADD,
        payload: processTrigger
    };
};

export const processTriggerAddSuccess = (processTrigger: IProcessTrigger) => {
    return {
        type: PROCESSTRIGGER_ADD_SUCCESS,
        payload: processTrigger
    }
};

export const processTriggerAddFailure = (error) => {
    return {
        type: PROCESSTRIGGER_ADD_FAILURE,
        payload: error
    }
};

export const processTriggerUpdate = (processTrigger: IProcessTrigger) => {
    return {
        type: PROCESSTRIGGER_UPDATE,
        payload: processTrigger
    };
};

export const processTriggerUpdateSuccess = (processTrigger: IProcessTrigger) => {
    return {
        type: PROCESSTRIGGER_UPDATE_SUCCESS,
        payload: processTrigger
    }
};

export const processTriggerUpdateFailure = (error) => {
    return {
        type: PROCESSTRIGGER_UPDATE_FAILURE,
        payload: error
    }
};

export const processTriggerDelete = (processTrigger: IProcessTrigger) => {
    return {
        type: PROCESSTRIGGER_DELETE,
        payload: processTrigger
    };
};

export const processTriggerDeleteSuccess = (processTrigger: IProcessTrigger) => {
    return {
        type: PROCESSTRIGGER_DELETE_SUCCESS,
        payload: processTrigger
    }
};

export const processTriggerDeleteFailure = (error) => {
    return {
        type: PROCESSTRIGGER_DELETE_FAILURE,
        payload: error
    }
};
