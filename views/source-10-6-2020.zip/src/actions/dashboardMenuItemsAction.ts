import Notifications from 'react-notification-system-redux';
import { SERVICES } from "./../configs/";
import axios from "./../configs/axios";
import {  
    ErrorNotificationOptions,
    LOAD_DASHBOARD_MENU_ITEM_DETAILS,
    LOAD_DASHBOARD_MENU_LIST,
} from './../constants';
import {loadDataError, loadDataState} from "./mainAction"
import { axUsername } from '../constants/index';


// export const loadDashboardMenuList = () => (dispatch, getState)=> {
//     dispatch(loadDataState(LOAD_DASHBOARD_MENU_LIST));
//     const orderBy = ["ShortcutOrder"]    
//     const url = SERVICES.endpoints.shortcutMenuItems;
//     return axios.get(url, {params:{orderBy}})
//                 .then((response:any)=>{
//                     dispatch(loadDashboardMenuItemListSuccess(response.data.value));
//                     if(response.data.value){
//                         response.data.value.forEach((element:any) => {
//                             dispatch(loadDashboardMenuItemDetails(element.ShortCutID))
//                         });
//                     }
//                 })
//                 .catch((error)=>{
//                     dispatch(loadDataError(error, LOAD_DASHBOARD_MENU_LIST));
//                     dispatch(Notifications.error({
//                         ...ErrorNotificationOptions,
//                         message:  error.message
//                     }));
//                 })
    
// };


// MAR - TESTING
export const loadDashboardMenuList = () => (dispatch, getState)=> {
    dispatch(loadDataState(LOAD_DASHBOARD_MENU_LIST));
    // const orderBy = ["MenuOrdinal"]    
    let user = (sessionStorage.getItem(axUsername) === null ? "demo.user" : sessionStorage.getItem(axUsername)!.toLowerCase())
    
    if( user.indexOf('\\') !== -1){
        user = user.substring(user.indexOf('\\') + 1, user.length)
    }
    const url = SERVICES.endpoints.businessProcessMenuItems.replace('{0}', user);
    // return axios.get(url, {params:{orderBy}})
    return axios.get(url)
                .then((response:any)=>{
                    dispatch(loadDashboardMenuItemListSuccess(response.data));
                    // if(response.data.value){
                    //     response.data.value.forEach((element:any) => {
                    //         dispatch(loadDashboardMenuItemDetails(element.ShortCutID))
                    //     });
                    // }
                })
                .catch((error)=>{
                    dispatch(loadDataError(error, LOAD_DASHBOARD_MENU_LIST));
                    dispatch(Notifications.error({
                        ...ErrorNotificationOptions,
                        message:  error.message
                    }));
                })
    
};
// MAR - TESTING

export const loadDashboardMenuItemDetails = (ShortCutID) => (dispatch, getState)=> {
    dispatch(loadDataState(LOAD_DASHBOARD_MENU_ITEM_DETAILS));
    const filter = [{ShortCutID}]
    const url = SERVICES.endpoints.shortcutMenuItemDetails;
    // return axios.get(url,{params:{filter}})
    return axios.get(url)
                .then((response:any)=>{
                    dispatch(loadDashboardMenuItemDetailsSuccess(response.data.value, ShortCutID));
                })
                .catch((error)=>{
                    dispatch(loadDataError(error,LOAD_DASHBOARD_MENU_ITEM_DETAILS));
                    dispatch(Notifications.error({
                        ...ErrorNotificationOptions,
                        message: error.message
                    }));
                })
    
};

const loadDashboardMenuItemListSuccess = (data:any) => {
    return {
        data, 
        type: LOAD_DASHBOARD_MENU_LIST
    };
};
const loadDashboardMenuItemDetailsSuccess = (data:any, ShortCutID) => {
    return {
        ShortCutID,
        data, 
        type: LOAD_DASHBOARD_MENU_ITEM_DETAILS
    };
};