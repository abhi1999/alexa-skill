import { 
    C303V850H_GET_LOOKUPS, 
    C303V850H_GET_LOOKUPS_SUCCESS, 
    C303V850H_GET_LOOKUPS_FAILURE, 
    C303V850H_GET_ALL, 
    C303V850H_GET_ALL_SUCCESS, 
    C303V850H_GET_ALL_FAILURE, 
    C303V850H_GET_ONE, 
    C303V850H_GET_ONE_SUCCESS, 
    C303V850H_GET_ONE_FAILURE, 
    C303V850H_ADD, 
    C303V850H_ADD_SUCCESS, 
    C303V850H_ADD_FAILURE, 
    C303V850H_UPDATE, 
    C303V850H_UPDATE_SUCCESS, 
    C303V850H_UPDATE_FAILURE,
    C303V850H_DELETE, 
    C303V850H_DELETE_SUCCESS, 
    C303V850H_DELETE_FAILURE,
    C303V850H_GET_DETAILS,
    C303V850H_GET_DETAILS_SUCCESS,
    C303V850H_GET_DETAILS_FAILURE,
    C303V850H_DELETE_ITEM,
    C303V850H_DELETE_ITEM_SUCCESS,
    C303V850H_DELETE_ITEM_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IC303v850h } from '../constants/edidb';
import { IApiPurchaseOrderDetail } from '../constants/edidb';

export const c303v850hGetLookups = (params: ODataParams) => {
    return {
        type: C303V850H_GET_LOOKUPS,
        payload: params
    };
};

export const c303v850hGetLookupsSuccess = ( tradeList: any, ) => {
    return {
        type: C303V850H_GET_LOOKUPS_SUCCESS,
        payload: { tradeList }
    }
};

export const c303v850hGetLookupsFailure = (error) => {
    return {
        type: C303V850H_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const c303v850hGetAll = (params: ODataParams) => {
    return {
        type: C303V850H_GET_ALL,
        payload: params
    };
};

export const c303v850hGetAllSuccess = (c303v850hList: any) => {
    return {
        type: C303V850H_GET_ALL_SUCCESS,
        payload: c303v850hList
    }
};

export const c303v850hGetAllFailure = (error) => {
    return {
        type: C303V850H_GET_ALL_FAILURE,
        payload: error
    }
};

export const c303v850hGetOne = (params: ODataParams) => {
    return {
        type: C303V850H_GET_ONE,
        payload: params
    };
};

export const c303v850hGetOneSuccess = (c303v850hList: any, itemDetailList: any, shipToList: any, referencesList: any, datesList: any, allowancesList: any, commentsList: any ) => {
    return {
        type: C303V850H_GET_ONE_SUCCESS,
        payload: { c303v850hList, itemDetailList, shipToList, referencesList, datesList, allowancesList, commentsList }
    }
};

export const c303v850hGetOneFailure = (error) => {
    return {
        type: C303V850H_GET_ONE_FAILURE,
        payload: error
    }
};

export const c303v850hAdd = (c303v850h: IApiPurchaseOrderDetail) => {
    return {
        type: C303V850H_ADD,
        payload: c303v850h
    };
};

export const c303v850hAddSuccess = (c303v850h: IApiPurchaseOrderDetail) => {
    return {
        type: C303V850H_ADD_SUCCESS,
        payload: c303v850h
    }
};

export const c303v850hAddFailure = (error) => {
    return {
        type: C303V850H_ADD_FAILURE,
        payload: error
    }
};

export const c303v850hUpdate = (c303v850h: IApiPurchaseOrderDetail) => {
    return {
        type: C303V850H_UPDATE,
        payload: c303v850h
    };
};

export const c303v850hUpdateSuccess = (c303v850h: IApiPurchaseOrderDetail) => {
    return {
        type: C303V850H_UPDATE_SUCCESS,
        payload: c303v850h
    }
};

export const c303v850hUpdateFailure = (error) => {
    return {
        type: C303V850H_UPDATE_FAILURE,
        payload: error
    }
};

export const c303v850hDelete = (c303v850h: IApiPurchaseOrderDetail) => {
    return {
        type: C303V850H_DELETE,
        payload: c303v850h
    };
};

export const c303v850hDeleteSuccess = (c303v850h: IApiPurchaseOrderDetail) => {
    return {
        type: C303V850H_DELETE_SUCCESS,
        payload: c303v850h
    }
};

export const c303v850hDeleteFailure = (error) => {
    return {
        type: C303V850H_DELETE_FAILURE,
        payload: error
    }
};

export const c303v850hDeleteItem = ( params ) => {
    return {
        type: C303V850H_DELETE_ITEM,
        payload: params
    };
};

export const c303v850hDeleteItemSuccess = ( params ) => {
    return {
        type: C303V850H_DELETE_ITEM_SUCCESS,
        payload: params
    }
};

export const c303v850hDeleteItemFailure = (error) => {
    return {
        type: C303V850H_DELETE_ITEM_FAILURE,
        payload: error
    }
};

export const c303v850hGetDetails = ( params ) => {
    return {
        type: C303V850H_GET_DETAILS,
        payload: params
    };
};

export const c303v850hGetDetailsSuccess = ( qualifiersList: any, SDQList: any ) => {
    return {
        type: C303V850H_GET_DETAILS_SUCCESS,
        payload: { qualifiersList, SDQList }
    }
};

export const c303v850hGetDetailsFailure = (error) => {
    return {
        type: C303V850H_GET_DETAILS_FAILURE,
        payload: error
    }
};
