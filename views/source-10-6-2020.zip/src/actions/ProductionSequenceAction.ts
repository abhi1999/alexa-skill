import ODataParams from '../constants/params/oDataParams';
import {
PRODUCTIONSEQUENCE_PURGEPS,PRODUCTIONSEQUENCE_PURGEPS_SUCCESS,PRODUCTIONSEQUENCE_PURGEPS_FAILURE,
PRODUCTIONSEQUENCE_GETPSALL,PRODUCTIONSEQUENCE_GETPSALL_SUCCESS,PRODUCTIONSEQUENCE_GETPSALL_FAILURE,
PRODUCTIONSEQUENCE_GETITEMALL,PRODUCTIONSEQUENCE_GETITEMALL_SUCCESS,PRODUCTIONSEQUENCE_GETITEMALL_FAILURE,
PRODUCTIONSEQUENCE_ADDITEM,PRODUCTIONSEQUENCE_ADDITEM_SUCCESS,PRODUCTIONSEQUENCE_ADDITEM_FAILURE,
PRODUCTIONSEQUENCE_CHANGEITEMPROCESSTYPE,PRODUCTIONSEQUENCE_CHANGEITEMPROCESSTYPE_SUCCESS,PRODUCTIONSEQUENCE_CHANGEITEMPROCESSTYPE_FAILURE,
PRODUCTIONSEQUENCE_CHANGEITEMSTATUS,PRODUCTIONSEQUENCE_CHANGEITEMSTATUS_SUCCESS,PRODUCTIONSEQUENCE_CHANGEITEMSTATUS_FAILURE,
PRODUCTIONSEQUENCE_UPDATEITEM,PRODUCTIONSEQUENCE_UPDATEITEM_SUCCESS,PRODUCTIONSEQUENCE_UPDATEITEM_FAILURE,
PRODUCTIONSEQUENCE_PURGEITEM,PRODUCTIONSEQUENCE_PURGEITEM_SUCCESS,PRODUCTIONSEQUENCE_PURGEITEM_FAILURE,
PRODUCTIONSEQUENCE_GETORIGINALMISCID,PRODUCTIONSEQUENCE_GETORIGINALMISCID_SUCCESS,PRODUCTIONSEQUENCE_GETORIGINALMISCID_FAILURE,
} from '../constants/ActionTypes';

export const productionSequencePurgeps = (params : ODataParams) => {
    return {
        type: PRODUCTIONSEQUENCE_PURGEPS,
        payload: params
   };
};

export const productionSequencePurgepsSuccess = (apiResp : any) => {
    return {
        type: PRODUCTIONSEQUENCE_PURGEPS_SUCCESS,
        payload: apiResp
   };
};

export const productionSequencePurgepsFailure = (error : Error) => {
    return {
        type: PRODUCTIONSEQUENCE_PURGEPS_FAILURE,
        payload: error
   };
};

export const productionSequenceGetPSAll = (params : ODataParams) => {
    return {
        type: PRODUCTIONSEQUENCE_GETPSALL,
        payload: params
   };
};

export const productionSequenceGetPSAllSuccess = (apiResp : any) => {
    return {
        type: PRODUCTIONSEQUENCE_GETPSALL_SUCCESS,
        payload: apiResp
   };
};

export const productionSequenceGetPSAllFailure = (error : Error) => {
    return {
        type: PRODUCTIONSEQUENCE_GETPSALL_FAILURE,
        payload: error
   };
};

export const productionSequenceGetitemall = (params : ODataParams) => {
    return {
        type: PRODUCTIONSEQUENCE_GETITEMALL,
        payload: params
   };
};

export const productionSequenceGetitemallSuccess = (apiResp : any) => {
    return {
        type: PRODUCTIONSEQUENCE_GETITEMALL_SUCCESS,
        payload: apiResp
   };
};

export const productionSequenceGetitemallFailure = (error : Error) => {
    return {
        type: PRODUCTIONSEQUENCE_GETITEMALL_FAILURE,
        payload: error
   };
};

export const productionSequenceAdditem = (params : ODataParams) => {
    return {
        type: PRODUCTIONSEQUENCE_ADDITEM,
        payload: params
   };
};

export const productionSequenceAdditemSuccess = (apiResp : any) => {
    return {
        type: PRODUCTIONSEQUENCE_ADDITEM_SUCCESS,
        payload: apiResp
   };
};

export const productionSequenceAdditemFailure = (error : Error) => {
    return {
        type: PRODUCTIONSEQUENCE_ADDITEM_FAILURE,
        payload: error
   };
};

export const productionSequenceChangeitemprocesstype = (params : ODataParams) => {
    return {
        type: PRODUCTIONSEQUENCE_CHANGEITEMPROCESSTYPE,
        payload: params
   };
};

export const productionSequenceChangeitemprocesstypeSuccess = (apiResp : any) => {
    return {
        type: PRODUCTIONSEQUENCE_CHANGEITEMPROCESSTYPE_SUCCESS,
        payload: apiResp
   };
};

export const productionSequenceChangeitemprocesstypeFailure = (error : Error) => {
    return {
        type: PRODUCTIONSEQUENCE_CHANGEITEMPROCESSTYPE_FAILURE,
        payload: error
   };
};

export const productionSequenceChangeitemstatus = (params : ODataParams) => {
    return {
        type: PRODUCTIONSEQUENCE_CHANGEITEMSTATUS,
        payload: params
   };
};

export const productionSequenceChangeitemstatusSuccess = (apiResp : any) => {
    return {
        type: PRODUCTIONSEQUENCE_CHANGEITEMSTATUS_SUCCESS,
        payload: apiResp
   };
};

export const productionSequenceChangeitemstatusFailure = (error : Error) => {
    return {
        type: PRODUCTIONSEQUENCE_CHANGEITEMSTATUS_FAILURE,
        payload: error
   };
};

export const productionSequenceUpdateitem = (params : ODataParams) => {
    return {
        type: PRODUCTIONSEQUENCE_UPDATEITEM,
        payload: params
   };
};

export const productionSequenceUpdateitemSuccess = (apiResp : any) => {
    return {
        type: PRODUCTIONSEQUENCE_UPDATEITEM_SUCCESS,
        payload: apiResp
   };
};

export const productionSequenceUpdateitemFailure = (error : Error) => {
    return {
        type: PRODUCTIONSEQUENCE_UPDATEITEM_FAILURE,
        payload: error
   };
};

export const productionSequencePurgeitem = (params : ODataParams) => {
    return {
        type: PRODUCTIONSEQUENCE_PURGEITEM,
        payload: params
   };
};

export const productionSequencePurgeitemSuccess = (apiResp : any) => {
    return {
        type: PRODUCTIONSEQUENCE_PURGEITEM_SUCCESS,
        payload: apiResp
   };
};

export const productionSequencePurgeitemFailure = (error : Error) => {
    return {
        type: PRODUCTIONSEQUENCE_PURGEITEM_FAILURE,
        payload: error
   };
};

export const productionSequenceGetoriginalmiscid = (params : ODataParams) => {
    return {
        type: PRODUCTIONSEQUENCE_GETORIGINALMISCID,
        payload: params
   };
};

export const productionSequenceGetoriginalmiscidSuccess = (apiResp : any) => {
    return {
        type: PRODUCTIONSEQUENCE_GETORIGINALMISCID_SUCCESS,
        payload: apiResp
   };
};

export const productionSequenceGetoriginalmiscidFailure = (error : Error) => {
    return {
        type: PRODUCTIONSEQUENCE_GETORIGINALMISCID_FAILURE,
        payload: error
   };
};
