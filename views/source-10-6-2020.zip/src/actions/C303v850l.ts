import { 
    C303V850L_GET_LOOKUPS, 
    C303V850L_GET_LOOKUPS_SUCCESS, 
    C303V850L_GET_LOOKUPS_FAILURE, 
    C303V850L_GET_ALL, 
    C303V850L_GET_ALL_SUCCESS, 
    C303V850L_GET_ALL_FAILURE, 
    C303V850L_GET_ONE, 
    C303V850L_GET_ONE_SUCCESS, 
    C303V850L_GET_ONE_FAILURE, 
    C303V850L_ADD, 
    C303V850L_ADD_SUCCESS, 
    C303V850L_ADD_FAILURE, 
    C303V850L_UPDATE, 
    C303V850L_UPDATE_SUCCESS, 
    C303V850L_UPDATE_FAILURE,
    C303V850L_DELETE, 
    C303V850L_DELETE_SUCCESS, 
    C303V850L_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IC303v850l } from '../constants/edidb';

export const c303v850lGetLookups = (params: ODataParams) => {
    return {
        type: C303V850L_GET_LOOKUPS,
        payload: params
    };
};

export const c303v850lGetLookupsSuccess = ( /* tableNameList: any, ... */ ) => {
    return {
        type: C303V850L_GET_LOOKUPS_SUCCESS,
        payload: { /* tableNameList, ... */ }
    }
};

export const c303v850lGetLookupsFailure = (error) => {
    return {
        type: C303V850L_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const c303v850lGetAll = (params: ODataParams) => {
    return {
        type: C303V850L_GET_ALL,
        payload: params
    };
};

export const c303v850lGetAllSuccess = (c303v850lList: any) => {
    return {
        type: C303V850L_GET_ALL_SUCCESS,
        payload: c303v850lList
    }
};

export const c303v850lGetAllFailure = (error) => {
    return {
        type: C303V850L_GET_ALL_FAILURE,
        payload: error
    }
};

export const c303v850lGetOne = (params: ODataParams) => {
    return {
        type: C303V850L_GET_ONE,
        payload: params
    };
};

export const c303v850lGetOneSuccess = (c303v850lList: any) => {
    return {
        type: C303V850L_GET_ONE_SUCCESS,
        payload: c303v850lList
    }
};

export const c303v850lGetOneFailure = (error) => {
    return {
        type: C303V850L_GET_ONE_FAILURE,
        payload: error
    }
};

export const c303v850lAdd = (c303v850l: IC303v850l) => {
    return {
        type: C303V850L_ADD,
        payload: c303v850l
    };
};

export const c303v850lAddSuccess = (c303v850l: IC303v850l) => {
    return {
        type: C303V850L_ADD_SUCCESS,
        payload: c303v850l
    }
};

export const c303v850lAddFailure = (error) => {
    return {
        type: C303V850L_ADD_FAILURE,
        payload: error
    }
};

export const c303v850lUpdate = (c303v850l: IC303v850l) => {
    return {
        type: C303V850L_UPDATE,
        payload: c303v850l
    };
};

export const c303v850lUpdateSuccess = (c303v850l: IC303v850l) => {
    return {
        type: C303V850L_UPDATE_SUCCESS,
        payload: c303v850l
    }
};

export const c303v850lUpdateFailure = (error) => {
    return {
        type: C303V850L_UPDATE_FAILURE,
        payload: error
    }
};

export const c303v850lDelete = (c303v850l: IC303v850l) => {
    return {
        type: C303V850L_DELETE,
        payload: c303v850l
    };
};

export const c303v850lDeleteSuccess = (c303v850l: IC303v850l) => {
    return {
        type: C303V850L_DELETE_SUCCESS,
        payload: c303v850l
    }
};

export const c303v850lDeleteFailure = (error) => {
    return {
        type: C303V850L_DELETE_FAILURE,
        payload: error
    }
};
