
import {
    ROLES_GET_ALL,
    ROLES_GET_ALL_FAILURE,
    ROLES_GET_ALL_SUCCESS,
    USERS_GET_ALL,
    USERS_GET_ALL_FAILURE,
    USERS_GET_ALL_SUCCESS,
    USER_ADD, 
    USER_ADD_FAILURE, 
    USER_ADD_SUCCESS,
    USER_UPDATE,
    USER_UPDATE_FAILURE,
    USER_UPDATE_SUCCESS,
    USER_DELETE,
    USER_DELETE_FAILURE,
    USER_DELETE_SUCCESS,
    USER_UPDATE_PERMISSION,
    USER_UPDATE_PERMISSION_FAILURE,
    USER_UPDATE_PERMISSION_SUCCESS,
    ROLE_ADD,
    ROLE_ADD_FAILURE,
    ROLE_ADD_SUCCESS,
    ROLE_UPDATE,
    ROLE_UPDATE_FAILURE,
    ROLE_UPDATE_SUCCESS,
    ROLE_DELETE,
    ROLE_DELETE_FAILURE,
    ROLE_DELETE_SUCCESS,
    ROLES_GET_ALL_PERMISSION,
    ROLES_GET_ALL_PERMISSION_SUCCESS,
    ROLES_GET_ALL_PERMISSION_FAILURE,
    ROLE_UPDATE_PERMISSION,
    ROLE_UPDATE_PERMISSION_FAILURE,
    ROLE_UPDATE_PERMISSION_SUCCESS,
    PERMISSIONS_GET_ALL,
    PERMISSIONS_GET_ALL_FAILURE,
    PERMISSIONS_GET_ALL_SUCCESS,
    MY_PERMISSIONS_GET,
    MY_PERMISSIONS_GET_FAILURE,
    MY_PERMISSIONS_GET_SUCCESS,
    USER_PERMISSIONS_GET,
    USER_PERMISSIONS_GET_SUCCESS,
    USER_PERMISSIONS_GET_FAILURE,
    ADD_ADMIN_USER,
    ADD_ADMIN_USER_SUCCESS,
    ADD_ADMIN_USER_FAILURE,
    PERMISSIONS_NO_COMPANY,
} from "../constants/ActionTypes";

import {IRole,IRolePermission, IPermission,IMenuPermission, IUserRole,IUserMenuPermission} from "./../constants/RoleAdministration/IRoleAdministration"

export const loadMenuPermissionForUser=(user:IUserRole)=>{
    return {
        type: USER_PERMISSIONS_GET,
        payload: user
    };
}
export const loadMenuPermissionForUserSuccess=(userPermissions:IUserMenuPermission)=>{
    return {
        type: USER_PERMISSIONS_GET_SUCCESS,
        payload: userPermissions
    };
}
export const loadMenuPermissionForUserFailure=(error)=>{
    return {
        type: USER_PERMISSIONS_GET_FAILURE,
        payload: error
    };
}
export const loadLoggedInUserPermission=()=>{
    return {
        type: MY_PERMISSIONS_GET,
        payload: {}
    };
}
export const loadLoggedInUserPermissionSuccess=(userPermissions:IUserMenuPermission)=>{
    return {
        type: MY_PERMISSIONS_GET_SUCCESS,
        payload: userPermissions
    };
}
export const loadLoggedInUserPermissionFailure=(error)=>{
    return {
        type: MY_PERMISSIONS_GET_FAILURE,
        payload: error
    };
}

export const permissionsGetAll =() =>{
    return {
        type: PERMISSIONS_GET_ALL,
        payload: {}
    };
}

export const permissionsGetAllSuccess =(permissions:IPermission[], menuPermissions:IMenuPermission[]) =>{
    return {
        type: PERMISSIONS_GET_ALL_SUCCESS,
        payload: {permissions, menuPermissions}
    };
}
export const permissionsGetAllFailure =(error) =>{
    return {
        type: PERMISSIONS_GET_ALL_FAILURE,
        payload: error
    };
}
export const rolesGetAll = () => {
    return {
        type: ROLES_GET_ALL,
        payload: {}
    };
};

export const rolesGetAllSuccess = (data : IRole[]) => {
    return {
        type: ROLES_GET_ALL_SUCCESS,
        payload: data
    }
};

export const rolesGetAllFailure = (error) => {
    return {
        type: ROLES_GET_ALL_FAILURE,
        payload: error
    }
};

export const rolesGetAllPermission = () => {
    return {
        type: ROLES_GET_ALL_PERMISSION,
        payload: {}
    };
};

export const rolesGetAllPermissionSuccess = (data : IRolePermission[]) => {
    return {
        type: ROLES_GET_ALL_PERMISSION_SUCCESS,
        payload: data
    }
};

export const rolesGetAllPermissionFailure = (error) => {
    return {
        type: ROLES_GET_ALL_PERMISSION_FAILURE,
        payload: error
    }
};


export const roleAdd = (role:IRole) => {
    return {
        type: ROLE_ADD,
        payload: role
    };
};

export const roleAddSuccess = (data:IRole[]) => {
    return {
        type: ROLE_ADD_SUCCESS,
        payload: data
    }
};

export const roleAddFailure = (error) => {
    return {
        type: ROLE_ADD_FAILURE,
        payload: error
    }
};


export const roleUpdate = (role:IRole) => {
    return {
        type: ROLE_UPDATE,
        payload: role
    };
};

export const roleUpdateSuccess = (data:IRole[]) => {
    return {
        type: ROLE_UPDATE_SUCCESS,
        payload: data
    };
};
export const roleUpdateFailure = (error) => {
    return {
        type: ROLE_UPDATE_FAILURE,
        payload: error
    }
};


export const roleDelete = (role:IRole) => {
    return {
        type: ROLE_DELETE,
        payload: role
    };
};

export const roleDeleteSuccess = (data:IRole[]) => {
    return {
        type: ROLE_DELETE_SUCCESS,
        payload: data
    };
};
export const roleDeleteFailure = (error) => {
    return {
        type: ROLE_DELETE_FAILURE,
        payload: error
    }
};


export const roleUpdatePermission = (permission:IRolePermission) => {
    return {
        type: ROLE_UPDATE_PERMISSION,
        payload: permission
    };
};

export const roleUpdatePermissionSuccess = (data :IRolePermission[]) => {
    return {
        type: ROLE_UPDATE_PERMISSION_SUCCESS,
        payload: data
    }
};

export const roleUpdatePermissionFailure = (error) => {
    return {
        type: ROLE_UPDATE_PERMISSION_FAILURE,
        payload: error
    }
};



export const usersGetAll = () => {
    return {
        type: USERS_GET_ALL,
        payload: {}
    };
};

export const usersGetAllSuccess = (data : IUserRole[]) => {
    return {
        type: USERS_GET_ALL_SUCCESS,
        payload: data
    }
};

export const usersGetAllFailure = (error) => {
    return {
        type: USERS_GET_ALL_FAILURE,
        payload: error
    }
};

export const userAdd = (user:IUserRole) => {
    return {
        type: USER_ADD,
        payload: user
    };
};

export const userAddSuccess = (data:IUserRole[]) => {
    return {
        type: USER_ADD_SUCCESS,
        payload: data
    }
};

export const userAddFailure = (error) => {
    return {
        type: USER_ADD_FAILURE,
        payload: error
    }
};


export const userUpdate = (user:IUserRole) => {
    return {
        type: USER_UPDATE,
        payload: user
    };
};

export const userUpdateSuccess = (data:IUserRole[]) => {
    return {
        type: USER_UPDATE_SUCCESS,
        payload: data
    };
};
export const userUpdateFailure = (error) => {
    return {
        type: USER_UPDATE_FAILURE,
        payload: error
    }
};


export const userDelete = (user:IUserRole) => {
    return {
        type: USER_DELETE,
        payload: user
    };
};

export const userDeleteSuccess = (data:IUserRole[]) => {
    return {
        type: USER_DELETE_SUCCESS,
        payload: data
    };
};
export const userDeleteFailure = (error) => {
    return {
        type: USER_DELETE_FAILURE,
        payload: error
    }
};

export const addAdminUser = (user) => {
    return {
        type: ADD_ADMIN_USER,
        payload: user
    };
};

export const addAdminUserSuccess = (data: any) => {
    return {
        type: ADD_ADMIN_USER_SUCCESS,
        payload: data
    };
};

export const addAdminUserSuccessFailure = (error) => {
    return {
        type: ADD_ADMIN_USER_FAILURE,
        payload: error
    }
};

// Check if this is needed

export const usersUpdatePermission = (permissions) => {
    return {
        type: USER_UPDATE_PERMISSION,
        payload: permissions
    };
};

export const usersUpdatePermissionSuccess = (data : any) => {
    return {
        type: USER_UPDATE_PERMISSION_SUCCESS,
        payload: data
    }
};

export const usersUpdatePermissionFailure = (error) => {
    return {
        type: USER_UPDATE_PERMISSION_FAILURE,
        payload: error
    }
};

export const permissionsNoCompany = () => {
    return {
        type: PERMISSIONS_NO_COMPANY,
        
    }
};

