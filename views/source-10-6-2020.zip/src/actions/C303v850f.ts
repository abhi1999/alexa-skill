import { 
    C303V850F_GET_LOOKUPS, 
    C303V850F_GET_LOOKUPS_SUCCESS, 
    C303V850F_GET_LOOKUPS_FAILURE, 
    C303V850F_GET_ALL, 
    C303V850F_GET_ALL_SUCCESS, 
    C303V850F_GET_ALL_FAILURE, 
    C303V850F_GET_ONE, 
    C303V850F_GET_ONE_SUCCESS, 
    C303V850F_GET_ONE_FAILURE, 
    C303V850F_ADD, 
    C303V850F_ADD_SUCCESS, 
    C303V850F_ADD_FAILURE, 
    C303V850F_UPDATE, 
    C303V850F_UPDATE_SUCCESS, 
    C303V850F_UPDATE_FAILURE,
    C303V850F_DELETE, 
    C303V850F_DELETE_SUCCESS, 
    C303V850F_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IC303v850f } from '../constants/edidb';

export const c303v850fGetLookups = (params: ODataParams) => {
    return {
        type: C303V850F_GET_LOOKUPS,
        payload: params
    };
};

export const c303v850fGetLookupsSuccess = ( /* tableNameList: any, ... */ ) => {
    return {
        type: C303V850F_GET_LOOKUPS_SUCCESS,
        payload: { /* tableNameList, ... */ }
    }
};

export const c303v850fGetLookupsFailure = (error) => {
    return {
        type: C303V850F_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const c303v850fGetAll = (params: ODataParams) => {
    return {
        type: C303V850F_GET_ALL,
        payload: params
    };
};

export const c303v850fGetAllSuccess = (c303v850fList: any) => {
    return {
        type: C303V850F_GET_ALL_SUCCESS,
        payload: c303v850fList
    }
};

export const c303v850fGetAllFailure = (error) => {
    return {
        type: C303V850F_GET_ALL_FAILURE,
        payload: error
    }
};

export const c303v850fGetOne = (params: ODataParams) => {
    return {
        type: C303V850F_GET_ONE,
        payload: params
    };
};

export const c303v850fGetOneSuccess = (c303v850fList: any) => {
    return {
        type: C303V850F_GET_ONE_SUCCESS,
        payload: c303v850fList
    }
};

export const c303v850fGetOneFailure = (error) => {
    return {
        type: C303V850F_GET_ONE_FAILURE,
        payload: error
    }
};

export const c303v850fAdd = (c303v850f: IC303v850f) => {
    return {
        type: C303V850F_ADD,
        payload: c303v850f
    };
};

export const c303v850fAddSuccess = (c303v850f: IC303v850f) => {
    return {
        type: C303V850F_ADD_SUCCESS,
        payload: c303v850f
    }
};

export const c303v850fAddFailure = (error) => {
    return {
        type: C303V850F_ADD_FAILURE,
        payload: error
    }
};

export const c303v850fUpdate = (c303v850f: IC303v850f) => {
    return {
        type: C303V850F_UPDATE,
        payload: c303v850f
    };
};

export const c303v850fUpdateSuccess = (c303v850f: IC303v850f) => {
    return {
        type: C303V850F_UPDATE_SUCCESS,
        payload: c303v850f
    }
};

export const c303v850fUpdateFailure = (error) => {
    return {
        type: C303V850F_UPDATE_FAILURE,
        payload: error
    }
};

export const c303v850fDelete = (c303v850f: IC303v850f) => {
    return {
        type: C303V850F_DELETE,
        payload: c303v850f
    };
};

export const c303v850fDeleteSuccess = (c303v850f: IC303v850f) => {
    return {
        type: C303V850F_DELETE_SUCCESS,
        payload: c303v850f
    }
};

export const c303v850fDeleteFailure = (error) => {
    return {
        type: C303V850F_DELETE_FAILURE,
        payload: error
    }
};
