import { show, success, error, warning, info, hide, removeAll } from 'react-notification-system-redux';
import {  
    ErrorNotificationOptions,SuccessNotificationOptions,WarningNotificationOptions,InfoNotificationOptions
} from './../constants';

export const NotifyError = (notificationOptions:any) => (dispatch, getState)=>{
    dispatch(error({...ErrorNotificationOptions, ...notificationOptions}));
}

export const NotifyWarning = (notificationOptions:any) => (dispatch, getState)=>{
    dispatch(warning({...WarningNotificationOptions, ...notificationOptions}));
}

export const NotifyInfo = (notificationOptions:any) => (dispatch, getState)=>{
    dispatch(info({...InfoNotificationOptions, ...notificationOptions}));
}

export const NotifySuccess = (notificationOptions:any) => (dispatch, getState)=>{
    dispatch(success({...SuccessNotificationOptions, ...notificationOptions}));
}

// mar testing 11/1/2019

export const NotifyClearAll = () => (dispatch, getState)=>{
    dispatch(removeAll());
}
//