
import {
LOGIN_VALIDATELOGIN,LOGIN_VALIDATELOGIN_SUCCESS,LOGIN_VALIDATELOGIN_FAILURE,
    LOGIN_MFA_GENERATE_TRANSACTION,LOGIN_MFA_GENERATE_TRANSACTION_ERROR, LOGIN_MFA_GENERATE_TRANSACTION_SUCCESS,
    LOGIN_MFA_POLL_TRANSACTION,LOGIN_MFA_POLL_TRANSACTION_SUCCESS,LOGIN_MFA_POLL_TRANSACTION_ERROR,
    LOGIN_MFA_GET_PRE_AUTH, LOGIN_MFA_GET_PRE_AUTH_ERROR, LOGIN_MFA_GET_PRE_AUTH_SUCCESS,
    LOGIN_INITIATE_PUSH_NOTIFICATION,LOGIN_MFA_RETRY_PRE_AUTH
} from '../constants/ActionTypes';
import { ILoginRequest } from '../sagas/LoginSaga';

export const loginRetryMFA = () => {
     return {
        type: LOGIN_MFA_RETRY_PRE_AUTH,
        payload: {}
   };
};


// MFA Actions Start
export const loginGetMFAPreAuth = (params : ILoginRequest, loginAPIResp : any) => {
    return {
        type: LOGIN_MFA_GET_PRE_AUTH,
        payload: {params, loginAPIResp:loginAPIResp.data}
   };
};

export const loginGetMFAPreAuthError = (error : Error) => {
    console.log('Preauth error:  what happened here')
     return {
        type: LOGIN_MFA_GET_PRE_AUTH_ERROR,
        payload: {error}
   };
};
export const loginGetMFAPreAuthSuccess = (data) => {
    return {
        type: LOGIN_MFA_GET_PRE_AUTH_SUCCESS,
        payload: data
   };
};

export const loginInitiatePushNotification = () => {
    return {
        type: LOGIN_INITIATE_PUSH_NOTIFICATION,
        payload: {}
   };
};


export const loginGenerateMFATransaction = () => {
    return {
        type: LOGIN_MFA_GENERATE_TRANSACTION,
        payload: {}
   };
};
/*
export const loginGenerateMFATransaction = (params : ILoginRequest, loginAPIResp : any) => {
    return {
        type: LOGIN_MFA_GENERATE_TRANSACTION,
        payload: {params, loginAPIResp:loginAPIResp.data}
   };
};
*/
export const loginGenerateMFATransactionSuccess = (txnId) => {
    return {
        type: LOGIN_MFA_GENERATE_TRANSACTION_SUCCESS,
        payload: {txnId}
   };
};
export const loginGenerateMFATransactionError = (error : Error) => {
    console.log('what happened here')
    return {
        type: LOGIN_MFA_GENERATE_TRANSACTION_ERROR,
        payload: {error}
   };
};


export const loginStartMFATransactionPoll = (iteration) => {
    return {
        type: LOGIN_MFA_POLL_TRANSACTION,
        payload: {iteration}
   };
};
export const loginStartMFATransactionPollSuccess = () => {
    return {
        type: LOGIN_MFA_POLL_TRANSACTION_SUCCESS,
        payload: {}
   };
};
export const loginStartMFATransactionPollError = (error) => {
    return {
        type: LOGIN_MFA_POLL_TRANSACTION_ERROR,
        payload: error
   };
};



export const loginValidatelogin = (params : ILoginRequest) => {
    return {
        type: LOGIN_VALIDATELOGIN,
        payload: params
   };
};

export const loginValidateloginSuccess = (apiResp : any) => {
    return {
        type: LOGIN_VALIDATELOGIN_SUCCESS,
        payload: apiResp
   };
};

export const loginValidateloginFailure = (error : Error) => {
    return {
        type: LOGIN_VALIDATELOGIN_FAILURE,
        payload: error
   };
};