import { 
    LASTNUMS_GET_ALL, 
    LASTNUMS_GET_ALL_SUCCESS, 
    LASTNUMS_GET_ALL_FAILURE, 
    LASTNUMS_UPDATE, 
    LASTNUMS_UPDATE_SUCCESS, 
    LASTNUMS_UPDATE_FAILURE,
} from './../constants/ActionTypes';

export const lastNumsGetAll = (params) => {
    return {
        type: LASTNUMS_GET_ALL,
        payload: params
    };
};

export const lastNumsGetAllSuccess = (lastNumsList) => {
    return {
        type: LASTNUMS_GET_ALL_SUCCESS,
        payload: lastNumsList
    }
};

export const lastNumsGetAllFailure = (error) => {
    return {
        type: LASTNUMS_GET_ALL_FAILURE,
        payload: error
    }
};

export const lastNumsUpdate = (lastNums) => {
    return {
        type: LASTNUMS_UPDATE,
        payload: lastNums
    };
};

export const lastNumsUpdateSuccess = (lastNums) => {
    return {
        type: LASTNUMS_UPDATE_SUCCESS,
        payload: lastNums
    }
};

export const lastNumsUpdateFailure = (error) => {
    return {
        type: LASTNUMS_UPDATE_FAILURE,
        payload: error
    }
};
