import { 
    C303V850N_GET_LOOKUPS, 
    C303V850N_GET_LOOKUPS_SUCCESS, 
    C303V850N_GET_LOOKUPS_FAILURE, 
    C303V850N_GET_ALL, 
    C303V850N_GET_ALL_SUCCESS, 
    C303V850N_GET_ALL_FAILURE, 
    C303V850N_GET_ONE, 
    C303V850N_GET_ONE_SUCCESS, 
    C303V850N_GET_ONE_FAILURE, 
    C303V850N_ADD, 
    C303V850N_ADD_SUCCESS, 
    C303V850N_ADD_FAILURE, 
    C303V850N_UPDATE, 
    C303V850N_UPDATE_SUCCESS, 
    C303V850N_UPDATE_FAILURE,
    C303V850N_DELETE, 
    C303V850N_DELETE_SUCCESS, 
    C303V850N_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IC303v850n } from '../constants/edidb';

export const c303v850nGetLookups = (params: ODataParams) => {
    return {
        type: C303V850N_GET_LOOKUPS,
        payload: params
    };
};

export const c303v850nGetLookupsSuccess = ( /* tableNameList: any, ... */ ) => {
    return {
        type: C303V850N_GET_LOOKUPS_SUCCESS,
        payload: { /* tableNameList, ... */ }
    }
};

export const c303v850nGetLookupsFailure = (error) => {
    return {
        type: C303V850N_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const c303v850nGetAll = (params: ODataParams) => {
    return {
        type: C303V850N_GET_ALL,
        payload: params
    };
};

export const c303v850nGetAllSuccess = (c303v850nList: any) => {
    return {
        type: C303V850N_GET_ALL_SUCCESS,
        payload: c303v850nList
    }
};

export const c303v850nGetAllFailure = (error) => {
    return {
        type: C303V850N_GET_ALL_FAILURE,
        payload: error
    }
};

export const c303v850nGetOne = (params: ODataParams) => {
    return {
        type: C303V850N_GET_ONE,
        payload: params
    };
};

export const c303v850nGetOneSuccess = (c303v850nList: any) => {
    return {
        type: C303V850N_GET_ONE_SUCCESS,
        payload: c303v850nList
    }
};

export const c303v850nGetOneFailure = (error) => {
    return {
        type: C303V850N_GET_ONE_FAILURE,
        payload: error
    }
};

export const c303v850nAdd = (c303v850n: IC303v850n) => {
    return {
        type: C303V850N_ADD,
        payload: c303v850n
    };
};

export const c303v850nAddSuccess = (c303v850n: IC303v850n) => {
    return {
        type: C303V850N_ADD_SUCCESS,
        payload: c303v850n
    }
};

export const c303v850nAddFailure = (error) => {
    return {
        type: C303V850N_ADD_FAILURE,
        payload: error
    }
};

export const c303v850nUpdate = (c303v850n: IC303v850n) => {
    return {
        type: C303V850N_UPDATE,
        payload: c303v850n
    };
};

export const c303v850nUpdateSuccess = (c303v850n: IC303v850n) => {
    return {
        type: C303V850N_UPDATE_SUCCESS,
        payload: c303v850n
    }
};

export const c303v850nUpdateFailure = (error) => {
    return {
        type: C303V850N_UPDATE_FAILURE,
        payload: error
    }
};

export const c303v850nDelete = (c303v850n: IC303v850n) => {
    return {
        type: C303V850N_DELETE,
        payload: c303v850n
    };
};

export const c303v850nDeleteSuccess = (c303v850n: IC303v850n) => {
    return {
        type: C303V850N_DELETE_SUCCESS,
        payload: c303v850n
    }
};

export const c303v850nDeleteFailure = (error) => {
    return {
        type: C303V850N_DELETE_FAILURE,
        payload: error
    }
};
