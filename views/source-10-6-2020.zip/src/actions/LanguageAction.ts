import {
    LANGUAGE_GET_ALL,
    LANGUAGE_GET_ALL_SUCCESS,
    LANGUAGE_GET_ALL_FAILURE,
    LANGUAGE_UPDATE_TERM,
} from '../constants/ActionTypes';

import { IReactLanguageTerms } from '../constants/edidb'

export const languageGetAll = (locale) => {
    return {
        type: LANGUAGE_GET_ALL,
        payload: locale,
    };
};

export const languageGetAllSuccess = (languageList: IReactLanguageTerms[]) => {
    return {
        type: LANGUAGE_GET_ALL_SUCCESS,
        payload: languageList
    }
};

export const languageGetAllFailure = (error) => {
    return {
        type: LANGUAGE_GET_ALL_FAILURE,
        payload: error
    }
};

export const languageUpdateTerm = (term) => {
    return {
        type: LANGUAGE_UPDATE_TERM,
        payload: term
    }
};