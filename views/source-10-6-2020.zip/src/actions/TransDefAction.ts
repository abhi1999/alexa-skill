import { 
    TRANSDEF_GET_ALL, 
    TRANSDEF_GET_ALL_SUCCESS, 
    TRANSDEF_GET_ALL_FAILURE,
    TRANSDEF_GET_ONE,
    TRANSDEF_GET_ONE_SUCCESS,
    TRANSDEF_GET_ONE_FAILURE,
    TRANSDEF_ADD, 
    TRANSDEF_ADD_SUCCESS, 
    TRANSDEF_ADD_FAILURE,
    TRANSDEF_UPDATE, 
    TRANSDEF_UPDATE_SUCCESS, 
    TRANSDEF_UPDATE_FAILURE,
    TRANSDEF_DELETE, 
    TRANSDEF_DELETE_SUCCESS, 
    TRANSDEF_DELETE_FAILURE

} from './../constants/ActionTypes';

import { ITransDef} from '../constants/edidb'
import ODataParams from '../constants/params/oDataParams';

export const transDefGetAll = (params:ODataParams) => {
    return {
        type: TRANSDEF_GET_ALL,
        payload: params
    };
};

export const transDefGetAllSuccess = (transDefList:ITransDef[]) => {
    return {
        type: TRANSDEF_GET_ALL_SUCCESS,
        payload:transDefList
    }
};

export const transDefGetAllFailure = (error) => {
    return {
        type: TRANSDEF_GET_ALL_FAILURE,
        payload: error
    }
};

export const transDefGetOne = (params:any) => {
    return {
        type: TRANSDEF_GET_ONE,
        payload: params
    };
};

export const transDefGetOneSuccess = (transDef:ITransDef) => {
    return {
        type: TRANSDEF_GET_ONE_SUCCESS,
        payload:transDef
    }
};

export const transDefGetOneFailure = (error) => {
    return {
        type: TRANSDEF_GET_ALL_FAILURE,
        payload: error
    }
};

export const transDefAdd = (transDef:ITransDef) => {
    return {
        type: TRANSDEF_ADD,
        payload: transDef
    };
};

export const transDefAddSuccess = (transDef:ITransDef) => {
    return {
        type: TRANSDEF_ADD_SUCCESS,
        payload: transDef
    }
};

export const transDefAddFailure = (error) => {
    return {
        type: TRANSDEF_ADD_FAILURE,
        payload: error
    }
};

export const transDefUpdate = (transDef:ITransDef) => {
    return {
        type: TRANSDEF_UPDATE,
        payload: transDef
    };
};

export const transDefUpdateSuccess = (transDef:ITransDef) => {
    return {
        type: TRANSDEF_UPDATE_SUCCESS,
        payload: transDef
    }
};

export const transDefUpdateFailure = (error) => {
    return {
        type: TRANSDEF_UPDATE_FAILURE,
        payload: error
    }
};

export const transDefDelete = (transDef:ITransDef) => {
    return {
        type: TRANSDEF_DELETE,
        payload: transDef
    };
};

export const transDefDeleteSuccess = (transDef:ITransDef) => {
    return {
        type: TRANSDEF_DELETE_SUCCESS,
        payload: transDef
    }
};

export const transDefDeleteFailure = (error) => {
    return {
        type: TRANSDEF_DELETE_FAILURE,
        payload: error
    }
};