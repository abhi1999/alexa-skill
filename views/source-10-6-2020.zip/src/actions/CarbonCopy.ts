import { 
    CARBONCOPY_GET_LOOKUPS, 
    CARBONCOPY_GET_LOOKUPS_SUCCESS, 
    CARBONCOPY_GET_LOOKUPS_FAILURE, 
    CARBONCOPY_GET_ALL, 
    CARBONCOPY_GET_ALL_SUCCESS, 
    CARBONCOPY_GET_ALL_FAILURE, 
    CARBONCOPY_GET_ONE, 
    CARBONCOPY_GET_ONE_SUCCESS, 
    CARBONCOPY_GET_ONE_FAILURE,
    CARBONCOPY_ADD, 
    CARBONCOPY_ADD_SUCCESS, 
    CARBONCOPY_ADD_FAILURE, 
    CARBONCOPY_UPDATE, 
    CARBONCOPY_UPDATE_SUCCESS, 
    CARBONCOPY_UPDATE_FAILURE,
    CARBONCOPY_DELETE, 
    CARBONCOPY_DELETE_SUCCESS, 
    CARBONCOPY_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { ICarbonCopy } from '../constants/edidb';

export const carbonCopyGetLookups = (params: ODataParams) => {
    return {
        type: CARBONCOPY_GET_LOOKUPS,
        payload: params
    };
};

export const carbonCopyGetLookupsSuccess = (tradeList: any, docGroupList: any, networkList: any) => {
    return {
        type: CARBONCOPY_GET_LOOKUPS_SUCCESS,
        payload: { tradeList, docGroupList, networkList }
    }
};

export const carbonCopyGetLookupsFailure = (error) => {
    return {
        type: CARBONCOPY_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const carbonCopyGetAll = (params: ODataParams) => {
    return {
        type: CARBONCOPY_GET_ALL,
        payload: params
    };
};

export const carbonCopyGetAllSuccess = (carbonCopy: any) => {
    return {
        type: CARBONCOPY_GET_ALL_SUCCESS,
        payload: { carbonCopy }
    }
};

export const carbonCopyGetAllFailure = (error) => {
    return {
        type: CARBONCOPY_GET_ALL_FAILURE,
        payload: error
    }
};

export const carbonCopyGetOne = (params) => {
    return {
        type: CARBONCOPY_GET_ONE,
        payload: params
    };
};

export const carbonCopyGetOneSuccess = (carbonCopy: any) => {
    return {
        type: CARBONCOPY_GET_ONE_SUCCESS,
        payload: { carbonCopy }
    }
};

export const carbonCopyGetOneFailure = (error) => {
    return {
        type: CARBONCOPY_GET_ONE_FAILURE,
        payload: error
    }
};

export const carbonCopyAdd = (carbonCopy: ICarbonCopy) => {
    return {
        type: CARBONCOPY_ADD,
        payload: carbonCopy
    };
};

export const carbonCopyAddSuccess = (carbonCopy: ICarbonCopy) => {
    return {
        type: CARBONCOPY_ADD_SUCCESS,
        payload: carbonCopy
    }
};

export const carbonCopyAddFailure = (error) => {
    return {
        type: CARBONCOPY_ADD_FAILURE,
        payload: error
    }
};

export const carbonCopyUpdate = (carbonCopy: ICarbonCopy) => {
    return {
        type: CARBONCOPY_UPDATE,
        payload: carbonCopy
    };
};

export const carbonCopyUpdateSuccess = (carbonCopy: ICarbonCopy) => {
    return {
        type: CARBONCOPY_UPDATE_SUCCESS,
        payload: carbonCopy
    }
};

export const carbonCopyUpdateFailure = (error) => {
    return {
        type: CARBONCOPY_UPDATE_FAILURE,
        payload: error
    }
};

export const carbonCopyDelete = (carbonCopy: ICarbonCopy) => {
    return {
        type: CARBONCOPY_DELETE,
        payload: carbonCopy
    };
};

export const carbonCopyDeleteSuccess = (carbonCopy: ICarbonCopy) => {
    return {
        type: CARBONCOPY_DELETE_SUCCESS,
        payload: carbonCopy
    }
};

export const carbonCopyDeleteFailure = (error) => {
    return {
        type: CARBONCOPY_DELETE_FAILURE,
        payload: error
    }
};
