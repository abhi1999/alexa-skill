import { 
    ROUTING_REQUEST_GET_ALL, 
    ROUTING_REQUEST_GET_ALL_SUCCESS, 
    ROUTING_REQUEST_GET_ALL_FAILURE, 
    ROUTING_REQUEST_ROUTE,
    ROUTING_REQUEST_ROUTE_SUCCESS,
    ROUTING_REQUEST_ROUTE_FAILURE,
    ROUTING_REQUEST_UPDATE_EXPFLAG,
    ROUTING_REQUEST_UPDATE_EXPFLAG_SUCCESS,
    ROUTING_REQUEST_UPDATE_EXPFLAG_FAILURE,
    ROUTING_REQUEST_REMOVE_REQUEST,
    ROUTING_REQUEST_REMOVE_REQUEST_SUCCESS,
    ROUTING_REQUEST_REMOVE_REQUEST_FAILURE
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IApiRequestRoute } from '../constants/edidb';

export const routingRequestGetAll = (params:ODataParams) => {
    return {
        type: ROUTING_REQUEST_GET_ALL,
        payload: params
    };
};

export const routingRequestGetAllSuccess = (odataResp : any) => {
    return {
        type: ROUTING_REQUEST_GET_ALL_SUCCESS,
        payload: odataResp
    }
};

export const routingRequestGetAllFailure = (error) => {
    return {
        type: ROUTING_REQUEST_GET_ALL_FAILURE,
        payload: error
    }
};

export const routingRequestRoute = (params:any) => {
    return {
        type: ROUTING_REQUEST_ROUTE,
        payload: params
    };
};

export const routingRequestRouteSuccess = (response : any) => {
    return {
        type: ROUTING_REQUEST_ROUTE_SUCCESS,
        payload: response
    }
};

export const routingRequestRouteFailure = (error) => {
    return {
        type: ROUTING_REQUEST_ROUTE_FAILURE,
        payload: error
    }
};

export const routingRequestUpdateExpFlag = (params:any) => {
    return {
        type: ROUTING_REQUEST_UPDATE_EXPFLAG,
        payload: params
    };
};

export const routingRequestUpdateExpFlagSuccess = (response : any) => {
    return {
        type: ROUTING_REQUEST_UPDATE_EXPFLAG_SUCCESS,
        payload: response
    }
};

export const routingRequestUpdateExpFlagFailure = (error) => {
    return {
        type: ROUTING_REQUEST_UPDATE_EXPFLAG_FAILURE,
        payload: error
    }
};

export const routingRequestRemoveRequest= (params:any) => {
    return {
        type: ROUTING_REQUEST_REMOVE_REQUEST,
        payload: params
    };
};

export const routingRequestRemoveRequestSuccess = (response : any) => {
    return {
        type: ROUTING_REQUEST_REMOVE_REQUEST_SUCCESS,
        payload: response
    }
};

export const routingRequestRemoveRequestFailure = (error) => {
    return {
        type: ROUTING_REQUEST_REMOVE_REQUEST_FAILURE,
        payload: error
    }
};