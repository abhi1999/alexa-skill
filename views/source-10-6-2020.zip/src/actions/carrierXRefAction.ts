import ODataParams from '../constants/params/oDataParams';
import {
CARRIERXREF_GETALL,CARRIERXREF_GETALL_SUCCESS,CARRIERXREF_GETALL_FAILURE,
} from '../constants/ActionTypes';

export const carrierXRefGetall = (params : ODataParams) => {
    return {
        type: CARRIERXREF_GETALL,
        payload: params
   };
};

export const carrierXRefGetallSuccess = (apiResp : any) => {
    return {
        type: CARRIERXREF_GETALL_SUCCESS,
        payload: apiResp
   };
};

export const carrierXRefGetallFailure = (error : Error) => {
    return {
        type: CARRIERXREF_GETALL_FAILURE,
        payload: error
   };
};