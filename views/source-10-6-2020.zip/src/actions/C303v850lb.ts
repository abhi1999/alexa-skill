import { 
    C303V850LB_GET_LOOKUPS, 
    C303V850LB_GET_LOOKUPS_SUCCESS, 
    C303V850LB_GET_LOOKUPS_FAILURE, 
    C303V850LB_GET_ALL, 
    C303V850LB_GET_ALL_SUCCESS, 
    C303V850LB_GET_ALL_FAILURE, 
    C303V850LB_GET_ONE, 
    C303V850LB_GET_ONE_SUCCESS, 
    C303V850LB_GET_ONE_FAILURE, 
    C303V850LB_ADD, 
    C303V850LB_ADD_SUCCESS, 
    C303V850LB_ADD_FAILURE, 
    C303V850LB_UPDATE, 
    C303V850LB_UPDATE_SUCCESS, 
    C303V850LB_UPDATE_FAILURE,
    C303V850LB_DELETE, 
    C303V850LB_DELETE_SUCCESS, 
    C303V850LB_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IC303v850lb } from '../constants/edidb';

export const c303v850lbGetLookups = (params: ODataParams) => {
    return {
        type: C303V850LB_GET_LOOKUPS,
        payload: params
    };
};

export const c303v850lbGetLookupsSuccess = ( /* tableNameList: any, ... */ ) => {
    return {
        type: C303V850LB_GET_LOOKUPS_SUCCESS,
        payload: { /* tableNameList, ... */ }
    }
};

export const c303v850lbGetLookupsFailure = (error) => {
    return {
        type: C303V850LB_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const c303v850lbGetAll = (params: ODataParams) => {
    return {
        type: C303V850LB_GET_ALL,
        payload: params
    };
};

export const c303v850lbGetAllSuccess = (c303v850lbList: any) => {
    return {
        type: C303V850LB_GET_ALL_SUCCESS,
        payload: c303v850lbList
    }
};

export const c303v850lbGetAllFailure = (error) => {
    return {
        type: C303V850LB_GET_ALL_FAILURE,
        payload: error
    }
};

export const c303v850lbGetOne = (params: ODataParams) => {
    return {
        type: C303V850LB_GET_ONE,
        payload: params
    };
};

export const c303v850lbGetOneSuccess = (c303v850lbList: any) => {
    return {
        type: C303V850LB_GET_ONE_SUCCESS,
        payload: c303v850lbList
    }
};

export const c303v850lbGetOneFailure = (error) => {
    return {
        type: C303V850LB_GET_ONE_FAILURE,
        payload: error
    }
};

export const c303v850lbAdd = (c303v850lb: IC303v850lb) => {
    return {
        type: C303V850LB_ADD,
        payload: c303v850lb
    };
};

export const c303v850lbAddSuccess = (c303v850lb: IC303v850lb) => {
    return {
        type: C303V850LB_ADD_SUCCESS,
        payload: c303v850lb
    }
};

export const c303v850lbAddFailure = (error) => {
    return {
        type: C303V850LB_ADD_FAILURE,
        payload: error
    }
};

export const c303v850lbUpdate = (c303v850lb: IC303v850lb) => {
    return {
        type: C303V850LB_UPDATE,
        payload: c303v850lb
    };
};

export const c303v850lbUpdateSuccess = (c303v850lb: IC303v850lb) => {
    return {
        type: C303V850LB_UPDATE_SUCCESS,
        payload: c303v850lb
    }
};

export const c303v850lbUpdateFailure = (error) => {
    return {
        type: C303V850LB_UPDATE_FAILURE,
        payload: error
    }
};

export const c303v850lbDelete = (c303v850lb: IC303v850lb) => {
    return {
        type: C303V850LB_DELETE,
        payload: c303v850lb
    };
};

export const c303v850lbDeleteSuccess = (c303v850lb: IC303v850lb) => {
    return {
        type: C303V850LB_DELETE_SUCCESS,
        payload: c303v850lb
    }
};

export const c303v850lbDeleteFailure = (error) => {
    return {
        type: C303V850LB_DELETE_FAILURE,
        payload: error
    }
};
