
import { 
    CARRIER_GET_ALL, 
    CARRIER_GET_ALL_SUCCESS, 
    CARRIER_GET_ALL_FAILURE, 
    CARRIER_GET_COMPLETE_LIST,
    CARRIER_GET_COMPLETE_LIST_SUCCESS,
    CARRIER_GET_COMPLETE_LIST_FAILURE,
    CARRIER_GET_ONE,
    CARRIER_GET_ONE_FAILURE,
    CARRIER_GET_ONE_SUCCESS,
    CARRIER_ADD, 
    CARRIER_ADD_SUCCESS, 
    CARRIER_ADD_FAILURE, 
    CARRIER_UPDATE, 
    CARRIER_UPDATE_SUCCESS, 
    CARRIER_UPDATE_FAILURE,
    CARRIER_DELETE, 
    CARRIER_DELETE_SUCCESS, 
    CARRIER_DELETE_FAILURE,
    CARRIER_IMPORT,
    CARRIER_IMPORT_FAILURE,
    CARRIER_IMPORT_SUCCESS,
    CARRIER_IMPORT_GET_STATUS,
    CARRIER_IMPORT_GET_STATUS_FAILURE,
    CARRIER_IMPORT_GET_STATUS_SUCCESS,
    CARRIER_ACK_ERROR
} from '../constants/ActionTypes';
import ODataParams from '../constants/params/oDataParams';
import { IShipVia } from 'src/constants/edidb';

export const carrierAckError = () => {
    return {
        type: CARRIER_ACK_ERROR,
        payload: {}
    };
};

export const carrierGetAll = (params:ODataParams) => {
    return {
        type: CARRIER_GET_ALL,
        payload: params
    };
};

export const carrierGetAllSuccess = (odataResp : any) => {
    return {
        type: CARRIER_GET_ALL_SUCCESS,
        payload: odataResp
    }
};

export const carrierGetAllFailure = (error) => {
    return {
        type: CARRIER_GET_ALL_FAILURE,
        payload: error
    }
};

export const carrierGetCompleteList = () => {
    return {
        type: CARRIER_GET_COMPLETE_LIST
    };
};

export const carrierGetCompleteListSuccess = (list: any) => {
    return {
        type: CARRIER_GET_COMPLETE_LIST_SUCCESS,
        payload: list
    }
};

export const carrierGetCompleteListFailure = (error) => {
    return {
        type: CARRIER_GET_COMPLETE_LIST_FAILURE,
        payload: error
    }
};

export const carrierGetOne = (params:ODataParams) => {
    return {
        type: CARRIER_GET_ONE,
        payload: params
    };
};

export const carrierGetOneSuccess = (odataResp : any) => {
    return {
        type: CARRIER_GET_ONE_SUCCESS,
        payload: odataResp
    }
};

export const carrierGetOneFailure = (error) => {
    return {
        type: CARRIER_GET_ONE_FAILURE,
        payload: error
    }
};



export const carrierImport = (debug : boolean) => {
    return {
        type: CARRIER_IMPORT,
        payload : debug
    };
};

export const carrierImportSuccess = (odataResp:any) => {
    return {
        type: CARRIER_IMPORT_SUCCESS,
        payload: odataResp
    }
};

export const carrierImportFailure = (error) => {
    return {
        type: CARRIER_IMPORT_FAILURE,
        payload: error
    }
};


export const carrierAdd = (carrier:IShipVia) => {
    return {
        type: CARRIER_ADD,
        payload: carrier
    };
};

export const carrierAddSuccess = (carrier:IShipVia) => {
    return {
        type: CARRIER_ADD_SUCCESS,
        payload: carrier
    }
};

export const carrierAddFailure = (error) => {
    return {
        type: CARRIER_ADD_FAILURE,
        payload: error
    }
};

export const carrierUpdate = (carrier:IShipVia) => {
    return {
        type: CARRIER_UPDATE,
        payload: carrier
    };
};

export const carrierUpdateSuccess = (carrier:IShipVia) => {
    return {
        type: CARRIER_UPDATE_SUCCESS,
        payload: carrier
    }
};

export const carrierUpdateFailure = (error) => {
    return {
        type: CARRIER_UPDATE_FAILURE,
        payload: error
    }
};

export const carrierDelete = (carrier:IShipVia) => {
    return {
        type: CARRIER_DELETE,
        payload: carrier
    };
};

export const carrierDeleteSuccess = (carrier:IShipVia) => {
    return {
        type: CARRIER_DELETE_SUCCESS,
        payload: carrier
    }
};

export const carrierDeleteFailure = (error) => {
    return {
        type: CARRIER_DELETE_FAILURE,
        payload: error
    }
};

export const carrierGetImportStatus = (pid : string, importStart : string) => {
    return {
        type: CARRIER_IMPORT_GET_STATUS,
        payload : { pid, importStart }
    };
};

export const carrierGetImportStatusSuccess = (apiResp:any) => {
    return {
        type: CARRIER_IMPORT_GET_STATUS_SUCCESS,
        payload: apiResp
    }
};

export const carrierGetImportStatusFailure = (error) => {
    return {
        type: CARRIER_IMPORT_GET_STATUS_FAILURE,
        payload: error
    }
};
