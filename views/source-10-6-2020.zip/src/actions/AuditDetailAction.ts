
import { 
    AUDITDETAIL_GET_ALL, 
    AUDITDETAIL_GET_ALL_SUCCESS, 
    AUDITDETAIL_GET_ALL_FAILURE, 
    AUDITDETAIL_GET_ONE,
    AUDITDETAIL_GET_ONE_FAILURE,
    AUDITDETAIL_GET_ONE_SUCCESS,
} from '../constants/ActionTypes';
import ODataParams from '../constants/params/oDataParams';

// **************************************************************
// ******** AUDIT DETAIL ****************************************
// **************************************************************

export const auditDetailGetAll = (params:ODataParams) => {
    return {
        type: AUDITDETAIL_GET_ALL,
        payload: params
    };
};

export const auditDetailGetAllSuccess = (odataResp : any) => {
    return {
        type: AUDITDETAIL_GET_ALL_SUCCESS,
        payload: odataResp
    }
};

export const auditDetailGetAllFailure = (error) => {
    return {
        type: AUDITDETAIL_GET_ALL_FAILURE,
        payload: error
    }
};


export const AauditDetailGetOne = (params:ODataParams) => {
    return {
        type: AUDITDETAIL_GET_ONE,
        payload: params
    };
};

export const auditDetailGetOneSuccess = (odataResp : any) => {
    return {
        type: AUDITDETAIL_GET_ONE_SUCCESS,
        payload: odataResp
    }
};

export const auditDetailGetOneFailure = (error) => {
    return {
        type: AUDITDETAIL_GET_ONE_FAILURE,
        payload: error
    }
};

