import { 
    C303V850R_GET_LOOKUPS, 
    C303V850R_GET_LOOKUPS_SUCCESS, 
    C303V850R_GET_LOOKUPS_FAILURE, 
    C303V850R_GET_ALL, 
    C303V850R_GET_ALL_SUCCESS, 
    C303V850R_GET_ALL_FAILURE, 
    C303V850R_GET_ONE, 
    C303V850R_GET_ONE_SUCCESS, 
    C303V850R_GET_ONE_FAILURE, 
    C303V850R_ADD, 
    C303V850R_ADD_SUCCESS, 
    C303V850R_ADD_FAILURE, 
    C303V850R_UPDATE, 
    C303V850R_UPDATE_SUCCESS, 
    C303V850R_UPDATE_FAILURE,
    C303V850R_DELETE, 
    C303V850R_DELETE_SUCCESS, 
    C303V850R_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IC303v850r } from '../constants/edidb';

export const c303v850rGetLookups = (params: ODataParams) => {
    return {
        type: C303V850R_GET_LOOKUPS,
        payload: params
    };
};

export const c303v850rGetLookupsSuccess = ( /* tableNameList: any, ... */ ) => {
    return {
        type: C303V850R_GET_LOOKUPS_SUCCESS,
        payload: { /* tableNameList, ... */ }
    }
};

export const c303v850rGetLookupsFailure = (error) => {
    return {
        type: C303V850R_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const c303v850rGetAll = (params: ODataParams) => {
    return {
        type: C303V850R_GET_ALL,
        payload: params
    };
};

export const c303v850rGetAllSuccess = (c303v850rList: any) => {
    return {
        type: C303V850R_GET_ALL_SUCCESS,
        payload: c303v850rList
    }
};

export const c303v850rGetAllFailure = (error) => {
    return {
        type: C303V850R_GET_ALL_FAILURE,
        payload: error
    }
};

export const c303v850rGetOne = (params: ODataParams) => {
    return {
        type: C303V850R_GET_ONE,
        payload: params
    };
};

export const c303v850rGetOneSuccess = (c303v850rList: any) => {
    return {
        type: C303V850R_GET_ONE_SUCCESS,
        payload: c303v850rList
    }
};

export const c303v850rGetOneFailure = (error) => {
    return {
        type: C303V850R_GET_ONE_FAILURE,
        payload: error
    }
};

export const c303v850rAdd = (c303v850r: IC303v850r) => {
    return {
        type: C303V850R_ADD,
        payload: c303v850r
    };
};

export const c303v850rAddSuccess = (c303v850r: IC303v850r) => {
    return {
        type: C303V850R_ADD_SUCCESS,
        payload: c303v850r
    }
};

export const c303v850rAddFailure = (error) => {
    return {
        type: C303V850R_ADD_FAILURE,
        payload: error
    }
};

export const c303v850rUpdate = (c303v850r: IC303v850r) => {
    return {
        type: C303V850R_UPDATE,
        payload: c303v850r
    };
};

export const c303v850rUpdateSuccess = (c303v850r: IC303v850r) => {
    return {
        type: C303V850R_UPDATE_SUCCESS,
        payload: c303v850r
    }
};

export const c303v850rUpdateFailure = (error) => {
    return {
        type: C303V850R_UPDATE_FAILURE,
        payload: error
    }
};

export const c303v850rDelete = (c303v850r: IC303v850r) => {
    return {
        type: C303V850R_DELETE,
        payload: c303v850r
    };
};

export const c303v850rDeleteSuccess = (c303v850r: IC303v850r) => {
    return {
        type: C303V850R_DELETE_SUCCESS,
        payload: c303v850r
    }
};

export const c303v850rDeleteFailure = (error) => {
    return {
        type: C303V850R_DELETE_FAILURE,
        payload: error
    }
};
