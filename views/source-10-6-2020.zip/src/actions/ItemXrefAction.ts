import { 
    ITEM_GETXREF_ALL,
    ITEM_GETXREF_FAILURE,
    ITEM_GETXREF_SUCCESS,
    ITEM_DELETEXREF,
    ITEM_DELETEXREF_FAILURE,
    ITEM_DELETEXREF_SUCCESS,
    ITEM_UPDATEXREF,
    ITEM_UPDATEXREF_FAILURE,
    ITEM_UPDATEXREF_SUCCESS,
    ITEM_ADDXREF,
    ITEM_ADDXREF_FAILURE,
    ITEM_ADDXREF_SUCCESS
} from '../constants/ActionTypes';
import { IAPIitemXRef } from "../constants/edidb";
import ODataParams from '../constants/params/oDataParams';

export const itemGetXrefAll = (params:ODataParams) => {
    return {
        type: ITEM_GETXREF_ALL,
        payload: params
    };
};

export const itemGetXrefAllSuccess = (xrefList:IAPIitemXRef[]) => {
    return {
        type: ITEM_GETXREF_SUCCESS,
        payload: xrefList
    }
};

export const itemGetXrefAllFailure = (error) => {
    return {
        type: ITEM_GETXREF_FAILURE,
        payload: error
    }
};

export const itemUpdateXref = (xrefOrig:IAPIitemXRef, xrefNew:IAPIitemXRef) => {
    const pld : IAPIitemXRef[] = [];
    pld.push(xrefOrig);
    pld.push(xrefNew);
    return {
        type: ITEM_UPDATEXREF,
        payload:pld
    };
};

export const itemUpdateXrefSuccess = (xref:IAPIitemXRef) => {
    return {
        type: ITEM_UPDATEXREF_SUCCESS,
        payload: xref
    }
};

export const itemUpdateXrefFailure = (error) => {
    return {
        type: ITEM_UPDATEXREF_FAILURE,
        payload: error
    }
};

export const itemDeleteXref = (xref:IAPIitemXRef) => {
    return {
        type: ITEM_DELETEXREF,
        payload: xref
    };
};

export const itemDeleteXrefSuccess = (xref:IAPIitemXRef) => {
    return {
        type: ITEM_DELETEXREF_SUCCESS,
        payload: xref
    }
};

export const itemDeleteXrefFailure = (error) => {
    return {
        type: ITEM_DELETEXREF_FAILURE,
        payload: error
    }
};

export const itemAddXref = (xref:IAPIitemXRef) => {
    return {
        type: ITEM_ADDXREF,
        payload: xref
    };
};

export const itemAddXrefSuccess = (xref:IAPIitemXRef) => {
    return {
        type: ITEM_ADDXREF_SUCCESS,
        payload: xref
    }
};

export const itemAddXrefFailure = (error) => {
    return {
        type: ITEM_ADDXREF_FAILURE,
        payload: error
    }
};