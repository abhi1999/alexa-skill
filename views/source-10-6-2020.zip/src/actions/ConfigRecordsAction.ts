import ODataParams from '../constants/params/oDataParams';
import {
CONFIGRECORDS_GETALL,CONFIGRECORDS_GETALL_SUCCESS,CONFIGRECORDS_GETALL_FAILURE,
CONFIGRECORDS_GETCONFIG,CONFIGRECORDS_GETCONFIG_SUCCESS,CONFIGRECORDS_GETCONFIG_FAILURE,
CONFIGRECORDS_GETDASHBOARD, CONFIGRECORDS_GETDASHBOARD_SUCCESS, CONFIGRECORDS_GETDASHBOARD_FAILURE
} from '../constants/ActionTypes';

export const configRecordsGetDashboard = (params : ODataParams) => {
    return {
        type: CONFIGRECORDS_GETDASHBOARD,
        payload: params
   };
};
export const configRecordsGetDashboardSuccess = (data) => {
    return {
        type: CONFIGRECORDS_GETDASHBOARD_SUCCESS,
        payload: data
   };
};
export const configRecordsGetDashboardFailure = (error : Error) => {
    return {
        type: CONFIGRECORDS_GETDASHBOARD_FAILURE,
        payload: {error}
   };
};
export const configRecordsGetall = (params : ODataParams) => {
    return {
        type: CONFIGRECORDS_GETALL,
        payload: params
   };
};

export const configRecordsGetallSuccess = (apiResp : any) => {
    return {
        type: CONFIGRECORDS_GETALL_SUCCESS,
        payload: apiResp
   };
};

export const configRecordsGetallFailure = (error : Error) => {
    return {
        type: CONFIGRECORDS_GETALL_FAILURE,
        payload: error
   };
};

export const configRecordsGetconfig = (params : ODataParams) => {
    return {
        type: CONFIGRECORDS_GETCONFIG,
        payload: params
   };
};

export const configRecordsGetconfigSuccess = (apiResp : any) => {
    return {
        type: CONFIGRECORDS_GETCONFIG_SUCCESS,
        payload: apiResp
   };
};

export const configRecordsGetconfigFailure = (error : Error) => {
    return {
        type: CONFIGRECORDS_GETCONFIG_FAILURE,
        payload: error
   };
};