
import { 
    CACHE_GET_ALL, 
    CACHE_GET_ALL_SUCCESS, 
    CACHE_GET_ALL_FAILURE, 
    CACHE_BACKUP,
    CACHE_BACKUP_SUCCESS, 
    CACHE_BACKUP_FAILURE, 
    CACHE_RESTORE, 
    CACHE_RESTORE_SUCCESS, 
    CACHE_RESTORE_FAILURE,
    CACHE_DELETE, 
    CACHE_DELETE_SUCCESS, 
    CACHE_DELETE_FAILURE,
    CACHE_GET_REPORT,
    CACHE_GET_REPORT_SUCCESS,
    CACHE_GET_REPORT_FAILURE,
} from '../constants/ActionTypes';
import ODataParams from '../constants/params/oDataParams';


export const cacheGetAll = (params:ODataParams) => {
    return {
        type: CACHE_GET_ALL,
        payload: params
    };
};

export const cacheGetAllSuccess = (odataResp : any) => {
    return {
        type: CACHE_GET_ALL_SUCCESS,
        payload: odataResp
    }
};

export const cacheGetAllFailure = (error) => {
    return {
        type: CACHE_GET_ALL_FAILURE,
        payload: error
    }
};


export const cacheBackup = (cache : any) => {
    return {
        type: CACHE_BACKUP,
        payload : cache
    };
};

export const cacheBackupSuccess = (cache:any) => {
    return {
        type: CACHE_BACKUP_SUCCESS,
        payload: cache
    }
};

export const cacheBackupFailure = (error) => {
    return {
        type: CACHE_BACKUP_FAILURE,
        payload: error
    }
};


export const cacheRestore = (cache:any) => {
    return {
        type: CACHE_RESTORE,
        payload: cache
    };
};

export const cacheRestoreSuccess = (cache:any) => {
    return {
        type: CACHE_RESTORE_SUCCESS,
        payload: cache
    }
};

export const cacheRestoreFailure = (error) => {
    return {
        type: CACHE_RESTORE_FAILURE,
        payload: error
    }
};

export const cacheDelete = (cache:any) => {
    return {
        type: CACHE_DELETE,
        payload: cache
    };
};

export const cacheDeleteSuccess = (cache:any) => {
    return {
        type: CACHE_DELETE_SUCCESS,
        payload: cache
    }
};

export const cacheDeleteFailure = (error) => {
    return {
        type: CACHE_DELETE_FAILURE,
        payload: error
    }
};

export const cacheGetReport = (cache:any) => {
    return {
        type: CACHE_GET_REPORT,
        payload: cache
    };
};

export const cacheGetReportSuccess = (cache:any) => {
    return {
        type: CACHE_GET_REPORT_SUCCESS,
        payload: cache
    }
};

export const cacheGetReportFailure = (error) => {
    return {
        type: CACHE_GET_REPORT_FAILURE,
        payload: error
    }
};