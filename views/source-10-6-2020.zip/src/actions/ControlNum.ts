import { 
    CONTROLNUM_GET_ALL, 
    CONTROLNUM_GET_ALL_SUCCESS, 
    CONTROLNUM_GET_ALL_FAILURE, 
    CONTROLNUM_GET_ONE, 
    CONTROLNUM_GET_ONE_SUCCESS, 
    CONTROLNUM_GET_ONE_FAILURE, 
    CONTROLNUM_ADD, 
    CONTROLNUM_ADD_SUCCESS, 
    CONTROLNUM_ADD_FAILURE, 
    CONTROLNUM_UPDATE, 
    CONTROLNUM_UPDATE_SUCCESS, 
    CONTROLNUM_UPDATE_FAILURE,
    CONTROLNUM_DELETE, 
    CONTROLNUM_DELETE_SUCCESS, 
    CONTROLNUM_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IControlNum } from '../constants/edidb';

export const controlNumGetAll = (params: ODataParams) => {
    return {
        type: CONTROLNUM_GET_ALL,
        payload: params
    };
};

export const controlNumGetAllSuccess = (controlNumList: any) => {
    return {
        type: CONTROLNUM_GET_ALL_SUCCESS,
        payload: controlNumList
    }
};

export const controlNumGetAllFailure = (error) => {
    return {
        type: CONTROLNUM_GET_ALL_FAILURE,
        payload: error
    }
};

export const controlNumGetOne = (params: ODataParams) => {
    return {
        type: CONTROLNUM_GET_ONE,
        payload: params
    };
};

export const controlNumGetOneSuccess = (controlNumList: any) => {
    return {
        type: CONTROLNUM_GET_ONE_SUCCESS,
        payload: controlNumList
    }
};

export const controlNumGetOneFailure = (error) => {
    return {
        type: CONTROLNUM_GET_ONE_FAILURE,
        payload: error
    }
};

export const controlNumAdd = (controlNum: IControlNum) => {
    return {
        type: CONTROLNUM_ADD,
        payload: controlNum
    };
};

export const controlNumAddSuccess = (controlNum: IControlNum) => {
    return {
        type: CONTROLNUM_ADD_SUCCESS,
        payload: controlNum
    }
};

export const controlNumAddFailure = (error) => {
    return {
        type: CONTROLNUM_ADD_FAILURE,
        payload: error
    }
};

export const controlNumUpdate = (controlNum: IControlNum) => {
    return {
        type: CONTROLNUM_UPDATE,
        payload: controlNum
    };
};

export const controlNumUpdateSuccess = (controlNum: IControlNum) => {
    return {
        type: CONTROLNUM_UPDATE_SUCCESS,
        payload: controlNum
    }
};

export const controlNumUpdateFailure = (error) => {
    return {
        type: CONTROLNUM_UPDATE_FAILURE,
        payload: error
    }
};

export const controlNumDelete = (controlNum: IControlNum) => {
    return {
        type: CONTROLNUM_DELETE,
        payload: controlNum
    };
};

export const controlNumDeleteSuccess = (controlNum: IControlNum) => {
    return {
        type: CONTROLNUM_DELETE_SUCCESS,
        payload: controlNum
    }
};

export const controlNumDeleteFailure = (error) => {
    return {
        type: CONTROLNUM_DELETE_FAILURE,
        payload: error
    }
};
