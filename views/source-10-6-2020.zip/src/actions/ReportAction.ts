import { 
    REPORT_GET_DOCUMENT,
    REPORT_GET_DOCUMENT_MULTI_QUERIES,
    REPORT_GET_DOCUMENT_SUCCESS,
    REPORT_GET_DOCUMENT_FAILURE,
    REPORT_GET_FORMATTED_EDI,
    REPORT_GET_FORMATTED_EDI_SUCCESS,
    REPORT_GET_FORMATTED_EDI_FAILURE,
    REPORT_GET_HTML,
    REPORT_GET_HTML_SUCCESS,
    REPORT_GET_HTML_FAILURE,
    REPORT_GET_CUSTOMER_PO,
    REPORT_GET_CUSTOMER_PO_SUCCESS,
    REPORT_GET_CUSTOMER_PO_FAILURE,
    REPORT_GET_SHIPMENT,
    REPORT_GET_SHIPMENT_SUCCESS,
    REPORT_GET_SHIPMENT_FAILURE,
    REPORT_GET_POSTING_LOG,
    REPORT_GET_POSTING_LOG_SUCCESS,
    REPORT_GET_POSTING_LOG_FAILURE,
    REPORT_CANCEL

} from './../constants/ActionTypes';

export const reportGetDocument = (params:any) => {
    return {
        type: REPORT_GET_DOCUMENT,
        payload: params
    };
};

export const reportGetDocumentMultiQueries = (params:any) => {
    return {
        type: REPORT_GET_DOCUMENT_MULTI_QUERIES,
        payload: params
    };
};

export const reportGetDocumentSuccess = (report:any) => {
    return {
        type: REPORT_GET_DOCUMENT_SUCCESS,
        payload:report
    }
};

export const reportGetDocumentFailure = (error) => {
    return {
        type: REPORT_GET_DOCUMENT_FAILURE,
        payload: error
    }
};

export const reportGetFormattedEdi = (params:any) => {
    return {
        type: REPORT_GET_FORMATTED_EDI,
        payload: params
    };
};

export const reportGetFormattedEdiSuccess = (reportResult:any) => {
    return {
        type: REPORT_GET_FORMATTED_EDI_SUCCESS,
        payload:reportResult
    }
};

export const reportGetFormattedEdiFailure = (error) => {
    return {
        type: REPORT_GET_FORMATTED_EDI_FAILURE,
        payload: error
    }
};

export const reportGetHtml = (params:any) => {
    return {
        type: REPORT_GET_HTML,
        payload: params
    };
};

export const reportGetHtmlSuccess = (reportResult:any) => {
    return {
        type: REPORT_GET_HTML_SUCCESS,
        payload:reportResult
    }
};

export const reportGetHtmlFailure = (error) => {
    return {
        type: REPORT_GET_HTML_FAILURE,
        payload: error
    }
};

export const reportGetCustomerPO = (params:any) => {
    return {
        type: REPORT_GET_CUSTOMER_PO,
        payload: params
    };
};

export const reportGetCustomerPOSuccess = (reportResult:any) => {
    return {
        type: REPORT_GET_CUSTOMER_PO_SUCCESS,
        payload:reportResult
    }
};

export const reportGetCustomerPOFailure = (error) => {
    return {
        type: REPORT_GET_CUSTOMER_PO_FAILURE,
        payload: error
    }
};

export const reportGetShipment = (params:any) => {
    return {
        type: REPORT_GET_SHIPMENT,
        payload: params
    };
};

export const reportGetShipmentSuccess = (reportResult:any) => {
    return {
        type: REPORT_GET_SHIPMENT_SUCCESS,
        payload:reportResult
    }
};

export const reportGetShipmentFailure = (error) => {
    return {
        type: REPORT_GET_SHIPMENT_FAILURE,
        payload: error
    }
};



export const reportGetPostingLog = (params:any) => {
    return {
        type: REPORT_GET_POSTING_LOG,
        payload: params
    };
};

export const reportGetPostingLogSuccess = (reportResult:any) => {
    return {
        type: REPORT_GET_POSTING_LOG_SUCCESS,
        payload:reportResult
    }
};

export const reportGetPostingLogFailure = (error) => {
    return {
        type: REPORT_GET_POSTING_LOG_FAILURE,
        payload: error
    }
};

export const reportCancel = () => {
    return {
        type: REPORT_CANCEL,
    };
};