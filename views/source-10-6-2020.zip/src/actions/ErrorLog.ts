import { 
    ERRORLOG_GET_ALL, 
    ERRORLOG_GET_ALL_SUCCESS, 
    ERRORLOG_GET_ALL_FAILURE, 
    ERRORLOG_GET_ONE, 
    ERRORLOG_GET_ONE_SUCCESS, 
    ERRORLOG_GET_ONE_FAILURE, 
    ERRORLOG_ADD, 
    ERRORLOG_ADD_SUCCESS, 
    ERRORLOG_ADD_FAILURE, 
    ERRORLOG_UPDATE, 
    ERRORLOG_UPDATE_SUCCESS, 
    ERRORLOG_UPDATE_FAILURE,
    ERRORLOG_DELETE, 
    ERRORLOG_DELETE_SUCCESS, 
    ERRORLOG_DELETE_FAILURE 
} from './../constants/ActionTypes';

export const errorLogGetAll = (params) => {
    return {
        type: ERRORLOG_GET_ALL,
        payload: params
    };
};

export const errorLogGetAllSuccess = (errorLogList: any) => {
    return {
        type: ERRORLOG_GET_ALL_SUCCESS,
        payload: errorLogList
    }
};

export const errorLogGetAllFailure = (error) => {
    return {
        type: ERRORLOG_GET_ALL_FAILURE,
        payload: error
    }
};

export const errorLogGetOne = (params) => {
    return {
        type: ERRORLOG_GET_ONE,
        payload: params
    };
};

export const errorLogGetOneSuccess = (errorLogList: any) => {
    return {
        type: ERRORLOG_GET_ONE_SUCCESS,
        payload: errorLogList
    }
};

export const errorLogGetOneFailure = (error) => {
    return {
        type: ERRORLOG_GET_ONE_FAILURE,
        payload: error
    }
};

export const errorLogAdd = (errorLog) => {
    return {
        type: ERRORLOG_ADD,
        payload: errorLog
    };
};

export const errorLogAddSuccess = (errorLog) => {
    return {
        type: ERRORLOG_ADD_SUCCESS,
        payload: errorLog
    }
};

export const errorLogAddFailure = (error) => {
    return {
        type: ERRORLOG_ADD_FAILURE,
        payload: error
    }
};

export const errorLogUpdate = (errorLog, _read) => {
    return {
        type: ERRORLOG_UPDATE,
        payload: errorLog,
        read: _read,
    };
};

export const errorLogUpdateSuccess = (errorLog) => {
    return {
        type: ERRORLOG_UPDATE_SUCCESS,
        payload: errorLog
    }
};

export const errorLogUpdateFailure = (error) => {
    return {
        type: ERRORLOG_UPDATE_FAILURE,
        payload: error
    }
};

export const errorLogDelete = (errorLog) => {
    return {
        type: ERRORLOG_DELETE,
        payload: errorLog
    };
};

export const errorLogDeleteSuccess = (errorLog) => {
    return {
        type: ERRORLOG_DELETE_SUCCESS,
        payload: errorLog
    }
};

export const errorLogDeleteFailure = (error) => {
    return {
        type: ERRORLOG_DELETE_FAILURE,
        payload: error
    }
};
