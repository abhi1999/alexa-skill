import { 
    CUSTOMIZE_TERMS_GET_ALL, 
    CUSTOMIZE_TERMS_GET_ALL_SUCCESS, 
    CUSTOMIZE_TERMS_GET_ALL_FAILURE, 
    CUSTOMIZE_TERMS_GET_ONE, 
    CUSTOMIZE_TERMS_GET_ONE_SUCCESS, 
    CUSTOMIZE_TERMS_GET_ONE_FAILURE, 
    CUSTOMIZE_TERMS_ADD, 
    CUSTOMIZE_TERMS_ADD_SUCCESS, 
    CUSTOMIZE_TERMS_ADD_FAILURE, 
    CUSTOMIZE_TERMS_UPDATE, 
    CUSTOMIZE_TERMS_UPDATE_SUCCESS, 
    CUSTOMIZE_TERMS_UPDATE_FAILURE,
    CUSTOMIZE_TERMS_DELETE, 
    CUSTOMIZE_TERMS_DELETE_SUCCESS, 
    CUSTOMIZE_TERMS_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import * as xCustomizeTerms from '../constants/edidb/CReactLanguageTerms'

export const customizeTermsGetAll = (params:ODataParams) => {
    return {
        type: CUSTOMIZE_TERMS_GET_ALL,
        payload: params
    };
};

export const customizeTermsGetAllSuccess = (odataResp : any) => {
    return {
        type: CUSTOMIZE_TERMS_GET_ALL_SUCCESS,
        payload: odataResp
    }
};

export const customizeTermsGetAllFailure = (error) => {
    return {
        type: CUSTOMIZE_TERMS_GET_ALL_FAILURE,
        payload: error
    }
};

export const customizeTermsGetOne = (term:any) => {
    return {
        type: CUSTOMIZE_TERMS_GET_ONE,
        payload: term
    };
};

export const customizeTermsGetOneSuccess = (odataResp : any) => {
    return {
        type: CUSTOMIZE_TERMS_GET_ONE_SUCCESS,
        payload: odataResp
    }
};

export const customizeTermsGetOneFailure = (error) => {
    return {
        type: CUSTOMIZE_TERMS_GET_ONE_FAILURE,
        payload: error
    }
};

export const customizeTermsAdd = (customizeTerm:xCustomizeTerms.CReactLanguageTerms) => {
    return {
        type: CUSTOMIZE_TERMS_ADD,
        payload: customizeTerm
    };
};

export const customizeTermsAddSuccess = (customizeTerm:xCustomizeTerms.CReactLanguageTerms) => {
    return {
        type: CUSTOMIZE_TERMS_ADD_SUCCESS,
        payload: customizeTerm
    }
};

export const customizeTermsAddFailure = (error) => {
    return {
        type: CUSTOMIZE_TERMS_ADD_FAILURE,
        payload: error
    }
};

export const customizeTermsUpdate = (customizeTerm:xCustomizeTerms.CReactLanguageTerms) => {
    return {
        type: CUSTOMIZE_TERMS_UPDATE,
        payload: customizeTerm
    };
};

export const customizeTermsUpdateSuccess = (customizeTerm:xCustomizeTerms.CReactLanguageTerms) => {
    return {
        type: CUSTOMIZE_TERMS_UPDATE_SUCCESS,
        payload: customizeTerm
    }
};

export const customizeTermsUpdateFailure = (error) => {
    return {
        type: CUSTOMIZE_TERMS_UPDATE_FAILURE,
        payload: error
    }
};

export const customizeTermsDelete = (customizeTerm:xCustomizeTerms.CReactLanguageTerms) => {
    return {
        type: CUSTOMIZE_TERMS_DELETE,
        payload: customizeTerm
    };
};

export const customizeTermsDeleteSuccess = (customizeTerm:xCustomizeTerms.CReactLanguageTerms) => {
    return {
        type: CUSTOMIZE_TERMS_DELETE_SUCCESS,
        payload: customizeTerm
    }
};

export const customizeTermsDeleteFailure = (error) => {
    return {
        type: CUSTOMIZE_TERMS_DELETE_FAILURE,
        payload: error
    }
};


