import ODataParams from '../constants/params/oDataParams';
import {
PLANNINGSCHEDULE_GETALL,PLANNINGSCHEDULE_GETALL_SUCCESS,PLANNINGSCHEDULE_GETALL_FAILURE,
} from '../constants/ActionTypes';

export const planningScheduleGetall = (params : ODataParams) => {
    return {
        type: PLANNINGSCHEDULE_GETALL,
        payload: params
   };
};

export const planningScheduleGetallSuccess = (apiResp : any) => {
    return {
        type: PLANNINGSCHEDULE_GETALL_SUCCESS,
        payload: apiResp
   };
};

export const planningScheduleGetallFailure = (error : Error) => {
    return {
        type: PLANNINGSCHEDULE_GETALL_FAILURE,
        payload: error
   };
};