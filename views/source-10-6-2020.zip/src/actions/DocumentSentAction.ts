import { 
    DOC_SENT_GET_ALL, 
    DOC_SENT_GET_ALL_SUCCESS, 
    DOC_SENT_GET_ALL_FAILURE, 
    DOC_SENT_UPDATE, 
    DOC_SENT_UPDATE_SUCCESS, 
    DOC_SENT_UPDATE_FAILURE,
    DOC_SENT_DELETE, 
    DOC_SENT_DELETE_SUCCESS, 
    DOC_SENT_DELETE_FAILURE,
    DOC_SENT_GET_DOCUMENT,
    DOC_SENT_GET_DOCUMENT_SUCCESS,
    DOC_SENT_GET_DOCUMENT_FAILURE,
    DOC_SENT_GET_ORIGINAL_DOCUMENT_ID,
    DOC_SENT_GET_ORIGINAL_DOCUMENT_ID_SUCCESS,
    DOC_SENT_GET_ORIGINAL_DOCUMENT_ID_FAILURE,
    DOC_SENT_CLEAR_ORIGINAL_DOCUMENT_ID,
    DOC_SENT_GET_LOOKUPTABLES,
    DOC_SENT_GET_LOOKUPTABLES_SUCCESS,
    DOC_SENT_GET_LOOKUPTABLES_FAILURE,
} from './../constants/ActionTypes';

export const docSentGetAll = (params) => {
    return {
        type: DOC_SENT_GET_ALL,
        payload: params
    };
};

export const docSentGetAllSuccess = (docSentList: any) => {
    return {
        type: DOC_SENT_GET_ALL_SUCCESS,
        payload: docSentList
    }
};

export const docSentGetAllFailure = (error) => {
    return {
        type: DOC_SENT_GET_ALL_FAILURE,
        payload: error
    }
};

export const docSentUpdate = (docSentList, _read) => {
    return {
        type: DOC_SENT_UPDATE,
        payload: docSentList,
        read: _read,
    };
};

export const docSentUpdateSuccess = (docSent) => {
    return {
        type: DOC_SENT_UPDATE_SUCCESS,
        payload: docSent
    }
};

export const docSentUpdateFailure = (error) => {
    return {
        type: DOC_SENT_UPDATE_FAILURE,
        payload: error
    }
};

export const docSentDelete = (docSentList) => {
    return {
        type: DOC_SENT_DELETE,
        payload: docSentList
    };
};

export const docSentDeleteSuccess = (docSent) => {
    return {
        type: DOC_SENT_DELETE_SUCCESS,
        payload: docSent
    }
};

export const docSentDeleteFailure = (error) => {
    return {
        type: DOC_SENT_DELETE_FAILURE,
        payload: error
    }
};

export const docSentGetDocument= (sentID) => {
    return {
        type: DOC_SENT_GET_DOCUMENT,
        payload: sentID
    };
};

export const docSentGetDocumentSuccess = (document) => {
    return {
        type: DOC_SENT_GET_DOCUMENT_SUCCESS,
        payload: document
    }
};

export const docSentGetDocumentFailure = (error) => {
    return {
        type: DOC_SENT_GET_DOCUMENT_FAILURE,
        payload: error
    }
};

export const docSentGetOriginalDocumentID= (docSent) => {
    return {
        type: DOC_SENT_GET_ORIGINAL_DOCUMENT_ID,
        payload: docSent
    };
};

export const docSentGetOriginalDocumentIDSuccess = (docSent) => {
    return {
        type: DOC_SENT_GET_ORIGINAL_DOCUMENT_ID_SUCCESS,
        payload: docSent
    }
};

export const docSentGetOriginalDocumentIDFailure = (error) => {
    return {
        type: DOC_SENT_GET_ORIGINAL_DOCUMENT_ID_FAILURE,
        payload: error
    }
};


export const docSentClearOriginalDocumentID = () => {
    return {
        type: DOC_SENT_CLEAR_ORIGINAL_DOCUMENT_ID
    }
};


export const docSentGetLookupTables= () => {
    return {
        type: DOC_SENT_GET_LOOKUPTABLES,
    };
};

export const docSentGetLookupTablesSuccess = () => {
    return {
        type: DOC_SENT_GET_LOOKUPTABLES_SUCCESS,
    }
};

export const docSentGetLookupTablesFailure = (error) => {
    return {
        type: DOC_SENT_GET_LOOKUPTABLES_FAILURE,
        payload: error
    }
};

