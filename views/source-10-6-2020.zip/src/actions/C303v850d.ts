import { 
    C303V850D_GET_LOOKUPS, 
    C303V850D_GET_LOOKUPS_SUCCESS, 
    C303V850D_GET_LOOKUPS_FAILURE, 
    C303V850D_GET_ALL, 
    C303V850D_GET_ALL_SUCCESS, 
    C303V850D_GET_ALL_FAILURE, 
    C303V850D_GET_ONE, 
    C303V850D_GET_ONE_SUCCESS, 
    C303V850D_GET_ONE_FAILURE, 
    C303V850D_ADD, 
    C303V850D_ADD_SUCCESS, 
    C303V850D_ADD_FAILURE, 
    C303V850D_UPDATE, 
    C303V850D_UPDATE_SUCCESS, 
    C303V850D_UPDATE_FAILURE,
    C303V850D_UPDATE_WITH_KEY,
    C303V850D_DELETE, 
    C303V850D_DELETE_SUCCESS, 
    C303V850D_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IC303v850d } from '../constants/edidb';

export const c303v850dGetLookups = (params: ODataParams) => {
    return {
        type: C303V850D_GET_LOOKUPS,
        payload: params
    };
};

export const c303v850dGetLookupsSuccess = ( /* tableNameList: any, ... */ ) => {
    return {
        type: C303V850D_GET_LOOKUPS_SUCCESS,
        payload: { /* tableNameList, ... */ }
    }
};

export const c303v850dGetLookupsFailure = (error) => {
    return {
        type: C303V850D_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const c303v850dGetAll = (params: ODataParams) => {
    return {
        type: C303V850D_GET_ALL,
        payload: params
    };
};

export const c303v850dGetAllSuccess = (c303v850dList: any) => {
    return {
        type: C303V850D_GET_ALL_SUCCESS,
        payload: c303v850dList
    }
};

export const c303v850dGetAllFailure = (error) => {
    return {
        type: C303V850D_GET_ALL_FAILURE,
        payload: error
    }
};

export const c303v850dGetOne = (params: ODataParams) => {
    return {
        type: C303V850D_GET_ONE,
        payload: params
    };
};

export const c303v850dGetOneSuccess = (c303v850dList: any) => {
    return {
        type: C303V850D_GET_ONE_SUCCESS,
        payload: c303v850dList
    }
};

export const c303v850dGetOneFailure = (error) => {
    return {
        type: C303V850D_GET_ONE_FAILURE,
        payload: error
    }
};

export const c303v850dAdd = (c303v850d: IC303v850d) => {
    return {
        type: C303V850D_ADD,
        payload: c303v850d
    };
};

export const c303v850dAddSuccess = (c303v850d: IC303v850d) => {
    return {
        type: C303V850D_ADD_SUCCESS,
        payload: c303v850d
    }
};

export const c303v850dAddFailure = (error) => {
    return {
        type: C303V850D_ADD_FAILURE,
        payload: error
    }
};

export const c303v850dUpdate = (c303v850d: IC303v850d) => {
    return {
        type: C303V850D_UPDATE,
        payload: c303v850d
    };
};

export const c303v850dUpdateSuccess = (c303v850d: IC303v850d) => {
    return {
        type: C303V850D_UPDATE_SUCCESS,
        payload: c303v850d
    }
};

export const c303v850dUpdateWithKey = (old_c303v850d: IC303v850d,  new_c303v850d: IC303v850d) => {
    return {
        type: C303V850D_UPDATE_WITH_KEY,
        payload: { old_c303v850d, new_c303v850d }
    };
};

export const c303v850dUpdateFailure = (error) => {
    return {
        type: C303V850D_UPDATE_FAILURE,
        payload: error
    }
};

export const c303v850dDelete = (c303v850d: IC303v850d) => {
    return {
        type: C303V850D_DELETE,
        payload: c303v850d
    };
};

export const c303v850dDeleteSuccess = (c303v850d: IC303v850d) => {
    return {
        type: C303V850D_DELETE_SUCCESS,
        payload: c303v850d
    }
};

export const c303v850dDeleteFailure = (error) => {
    return {
        type: C303V850D_DELETE_FAILURE,
        payload: error
    }
};
