import { 
    CUMULATIVE_QTY_GET_ALL, 
    CUMULATIVE_QTY_GET_ALL_SUCCESS, 
    CUMULATIVE_QTY_GET_ALL_FAILURE,
    CUMULATIVE_QTY_GET_DETAIL,
    CUMULATIVE_QTY_GET_DETAIL_SUCCESS,
    CUMULATIVE_QTY_GET_DETAIL_FAILURE,
    CUMULATIVE_QTY_GET_LOOKUPS,
    CUMULATIVE_QTY_GET_LOOKUPS_SUCCESS,
    CUMULATIVE_QTY_GET_LOOKUPS_FAILURE,
    CUMULATIVE_QTY_GET_ONE,
    CUMULATIVE_QTY_GET_ONE_SUCCESS,
    CUMULATIVE_QTY_GET_ONE_FAILURE,
    CUMULATIVE_QTY_ADD,
    CUMULATIVE_QTY_ADD_SUCCESS,
    CUMULATIVE_QTY_ADD_FAILURE,
    CUMULATIVE_QTY_UPDATE,
    CUMULATIVE_QTY_UPDATE_SUCCESS,
    CUMULATIVE_QTY_UPDATE_FAILURE

} from './../constants/ActionTypes';

import { IApiCumulativeQuantity} from '../constants/edidb'
import ODataParams from '../constants/params/oDataParams';

export const cumulativeQtyGetAll = (params:ODataParams) => {
    return {
        type: CUMULATIVE_QTY_GET_ALL,
        payload: params
    };
};

export const cumulativeQtyGetAllSuccess = (apiCumulativeQtyList:any) => {
    return {
        type: CUMULATIVE_QTY_GET_ALL_SUCCESS,
        payload:apiCumulativeQtyList
    }
};

export const cumulativeQtyGetAllFailure = (error) => {
    return {
        type: CUMULATIVE_QTY_GET_ALL_FAILURE,
        payload: error
    }
};

export const cumulativeQtyGetDetail = (params:ODataParams) => {
    return {
        type: CUMULATIVE_QTY_GET_DETAIL,
        payload: params
    };
};

export const cumulativeQtyGetDetailSuccess = (apiCumulativeDetailList:any) => {
    return {
        type: CUMULATIVE_QTY_GET_DETAIL_SUCCESS,
        payload:apiCumulativeDetailList
    }
};

export const cumulativeQtyGetDetailFailure = (error) => {
    return {
        type: CUMULATIVE_QTY_GET_DETAIL_FAILURE,
        payload: error
    }
};

export const cumulativeQtyGetLookups = (params: any) => {
    return {
        type: CUMULATIVE_QTY_GET_LOOKUPS,
        payload: params
    };
};

export const cumulativeQtyGetLookupsSuccess = ( tradeList: any, shipToList: any, itemList:any ) => {
    return {
        type: CUMULATIVE_QTY_GET_LOOKUPS_SUCCESS,
        payload: { tradeList, shipToList, itemList }
    }
};

export const cumulativeQtyGetLookupsFailure = (error) => {
    return {
        type: CUMULATIVE_QTY_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const cumulativeQtyGetOne = (params: any) => {
    return {
        type: CUMULATIVE_QTY_GET_ONE,
        payload: params
    };
};

export const cumulativeQtyGetOneSuccess = ( cummulativeQtyAdj:any ) => {
    return {
        type: CUMULATIVE_QTY_GET_ONE_SUCCESS,
        payload: cummulativeQtyAdj
    }
};

export const cumulativeQtyGetOneFailure = (error) => {
    return {
        type: CUMULATIVE_QTY_GET_ONE_FAILURE,
        payload: error
    }
};

//
export const cumulativeQtyAdd = (params: any) => {
    return {
        type: CUMULATIVE_QTY_ADD,
        payload: params
    };
};

export const cumulativeQtyAddSuccess = ( params:any ) => {
    return {
        type: CUMULATIVE_QTY_ADD_SUCCESS,
        payload: params
    }
};

export const cumulativeQtyAddFailure = (error) => {
    return {
        type: CUMULATIVE_QTY_ADD_FAILURE,
        payload: error
    }
};

export const cumulativeQtyUpdate = (params: any) => {
    return {
        type: CUMULATIVE_QTY_UPDATE,
        payload: params
    };
};

export const cumulativeQtyUpdateSuccess = ( params:any ) => {
    return {
        type: CUMULATIVE_QTY_UPDATE_SUCCESS,
        payload: params
    }
};

export const cumulativeQtyUpdateFailure = (error) => {
    return {
        type: CUMULATIVE_QTY_UPDATE_FAILURE,
        payload: error
    }
};