import {
    MENUCONFIG_GET_ALL,
    MENUCONFIG_GET_ALL_SUCCESS,
    MENUCONFIG_GET_ALL_FAILURE,
    MENUCONFIG_GET_MENUS,
    MENUCONFIG_GET_MENUS_SUCCESS,
    MENUCONFIG_GET_MENUS_FAILURE,
    MENUCONFIG_GET_GROUPS,
    MENUCONFIG_GET_GROUPS_SUCCESS,
    MENUCONFIG_GET_GROUPS_FAILURE,
    MENUCONFIG_GET_TASKS,
    MENUCONFIG_GET_TASKS_SUCCESS,
    MENUCONFIG_GET_TASKS_FAILURE,
    MENUCONFIG_GET_USER_MENUS,
    MENUCONFIG_GET_USER_MENUS_SUCCESS,
    MENUCONFIG_GET_USER_MENUS_FAILURE,
    MENUCONFIG_GET_USER_MENU_GROUPS,
    MENUCONFIG_GET_USER_MENU_GROUPS_SUCCESS,
    MENUCONFIG_GET_USER_MENU_GROUPS_FAILURE,
    MENUCONFIG_GET_USER_MENU_GROUP_TASKS,
    MENUCONFIG_GET_USER_MENU_GROUP_TASKS_SUCCESS,
    MENUCONFIG_GET_USER_MENU_GROUP_TASKS_FAILURE,
    MENUCONFIG_UPDATE,
    MENUCONFIG_UPDATE_SUCCESS,
    MENUCONFIG_UPDATE_FAILURE,

} from './../constants/ActionTypes';

export const menuConfigGetAll = (params) => {
    return {
        type: MENUCONFIG_GET_ALL,
        payload: params
    };
};

export const menuConfigGetAllSuccess = (params) => {
    return {
        type: MENUCONFIG_GET_ALL_SUCCESS,
        payload: params
    }
};

export const menuConfigGetAllFailure = (error) => {
    return {
        type: MENUCONFIG_GET_ALL_FAILURE,
        payload: error
    }
};

export const menuConfigGetMenus = (params) => {
    return {
        type: MENUCONFIG_GET_MENUS,
        payload: params
    };
};

export const menuConfigGetMenusSuccess = (params) => {
    return {
        type: MENUCONFIG_GET_MENUS_SUCCESS,
        payload: params
    }
};

export const menuConfigGetMenusFailure = (error) => {
    return {
        type: MENUCONFIG_GET_MENUS_FAILURE,
        payload: error
    }
};

export const menuConfigGetGroups = (params) => {
    return {
        type: MENUCONFIG_GET_GROUPS,
        payload: params
    };
};

export const menuConfigGetGroupsSuccess = (params) => {
    return {
        type: MENUCONFIG_GET_GROUPS_SUCCESS,
        payload: params
    }
};

export const menuConfigGetGroupsFailure = (error) => {
    return {
        type: MENUCONFIG_GET_GROUPS_FAILURE,
        payload: error
    }
};

export const menuConfigGetTasks = (params) => {
    return {
        type: MENUCONFIG_GET_TASKS,
        payload: params
    };
};

export const menuConfigGetTasksSuccess = (params) => {
    return {
        type: MENUCONFIG_GET_TASKS_SUCCESS,
        payload: params
    }
};

export const menuConfigGetTasksFailure = (error) => {
    return {
        type: MENUCONFIG_GET_TASKS_FAILURE,
        payload: error
    }
};

export const menuConfigGetUserMenus = (params) => {
    return {
        type: MENUCONFIG_GET_USER_MENUS,
        payload: params
    };
};

export const menuConfigGetUserMenusSuccess = (params) => {
    return {
        type: MENUCONFIG_GET_USER_MENUS_SUCCESS,
        payload: params
    }
};

export const menuConfigGetUserMenusFailure = (error) => {
    return {
        type: MENUCONFIG_GET_USER_MENUS_FAILURE,
        payload: error
    }
};

export const menuConfigGetUserMenuGroups = (params) => {
    return {
        type: MENUCONFIG_GET_USER_MENU_GROUPS,
        payload: params
    };
};

export const menuConfigGetUserMenuGroupsSuccess = (params) => {
    return {
        type: MENUCONFIG_GET_USER_MENU_GROUPS_SUCCESS,
        payload: params
    }
};

export const menuConfigGetUserMenuGroupsFailure = (error) => {
    return {
        type: MENUCONFIG_GET_USER_MENU_GROUPS_FAILURE,
        payload: error
    }
};

export const menuConfigGetUserMenuGroupTasks = (params) => {
    return {
        type: MENUCONFIG_GET_USER_MENU_GROUP_TASKS,
        payload: params
    };
};

export const menuConfigGetUserMenuGroupTasksSuccess = (params) => {
    return {
        type: MENUCONFIG_GET_USER_MENU_GROUP_TASKS_SUCCESS,
        payload: params
    }
};

export const menuConfigGetUserMenuGroupTasksFailure = (error) => {
    return {
        type: MENUCONFIG_GET_USER_MENU_GROUP_TASKS_FAILURE,
        payload: error
    }
};

export const menuConfigUpdate = (params) => {
    return {
        type: MENUCONFIG_UPDATE,
        payload: params
    };
};

export const menuConfigUpdateSuccess = (params) => {
    return {
        type: MENUCONFIG_UPDATE_SUCCESS,
        payload: params
    }
};

export const menuConfigUpdateFailure = (error) => {
    return {
        type: MENUCONFIG_UPDATE_FAILURE,
        payload: error
    }
};