import { 
    FREIGHT_CODE_GET_ALL, 
    FREIGHT_CODE_GET_ALL_SUCCESS, 
    FREIGHT_CODE_GET_ALL_FAILURE, 
    FREIGHT_CODE_GET_ONE,
    FREIGHT_CODE_GET_ONE_SUCCESS,
    FREIGHT_CODE_GET_ONE_FAILURE,
    FREIGHT_CODE_ADD, 
    FREIGHT_CODE_ADD_SUCCESS, 
    FREIGHT_CODE_ADD_FAILURE, 
    FREIGHT_CODE_UPDATE, 
    FREIGHT_CODE_UPDATE_SUCCESS, 
    FREIGHT_CODE_UPDATE_FAILURE,
    FREIGHT_CODE_DELETE, 
    FREIGHT_CODE_DELETE_SUCCESS, 
    FREIGHT_CODE_DELETE_FAILURE,
    FREIGHT_CODE_CLEAR_ERROR
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import * as xFreightCode from '../constants/edidb/CFreightCode'

export const freightCodeGetAll = (params:ODataParams) => {
    return {
        type: FREIGHT_CODE_GET_ALL,
        payload: params
    };
};

export const freightCodeGetAllSuccess = (odataResp : any) => {
    return {
        type: FREIGHT_CODE_GET_ALL_SUCCESS,
        payload: odataResp
    }
};

export const freightCodeGetAllFailure = (error) => {
    return {
        type: FREIGHT_CODE_GET_ALL_FAILURE,
        payload: error
    }
};

export const freightCodeGetOne = (code:any) => {
    return {
        type: FREIGHT_CODE_GET_ONE,
        payload: code
    };
};

export const freightCodeGetOneSuccess = (odataResp : any) => {
    return {
        type: FREIGHT_CODE_GET_ONE_SUCCESS,
        payload: odataResp
    }
};

export const freightCodeGetOneFailure = (error) => {
    return {
        type: FREIGHT_CODE_GET_ONE_FAILURE,
        payload: error
    }
};

export const freightCodeAdd = (freightCode:xFreightCode.CFreightCode) => {
    return {
        type: FREIGHT_CODE_ADD,
        payload: freightCode
    };
};

export const freightCodeAddSuccess = (freightCode:xFreightCode.CFreightCode) => {
    return {
        type: FREIGHT_CODE_ADD_SUCCESS,
        payload: freightCode
    }
};

export const freightCodeAddFailure = (error) => {
    return {
        type: FREIGHT_CODE_ADD_FAILURE,
        payload: error
    }
};

export const freightCodeUpdate = (freightCode:xFreightCode.CFreightCode) => {
    return {
        type: FREIGHT_CODE_UPDATE,
        payload: freightCode
    };
};

export const freightCodeUpdateSuccess = (freightCode:xFreightCode.CFreightCode) => {
    return {
        type: FREIGHT_CODE_UPDATE_SUCCESS,
        payload: freightCode
    }
};

export const freightCodeUpdateFailure = (error) => {
    return {
        type: FREIGHT_CODE_UPDATE_FAILURE,
        payload: error
    }
};

export const freightCodeDelete = (freightCode:xFreightCode.CFreightCode) => {
    return {
        type: FREIGHT_CODE_DELETE,
        payload: freightCode
    };
};

export const freightCodeDeleteSuccess = (freightCode:xFreightCode.CFreightCode) => {
    return {
        type: FREIGHT_CODE_DELETE_SUCCESS,
        payload: freightCode
    }
};

export const freightCodeDeleteFailure = (error) => {
    return {
        type: FREIGHT_CODE_DELETE_FAILURE,
        payload: error
    }
};

export const freightCodeClearError = () => {
    return {
        type: FREIGHT_CODE_CLEAR_ERROR
    }
}
