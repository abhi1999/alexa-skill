import { 
    API_TRANS_OBJECT_GET_ALL, 
    API_TRANS_OBJECT_GET_ALL_SUCCESS, 
    API_TRANS_OBJECT_GET_ALL_FAILURE,
    API_TRANS_OBJECT_ADD,
    API_TRANS_OBJECT_ADD_SUCCESS,
    API_TRANS_OBJECT_ADD_FAILURE,
    API_TRANS_OBJECT_UPDATE,
    API_TRANS_OBJECT_UPDATE_SUCCESS,
    API_TRANS_OBJECT_UPDATE_FAILURE,
    API_TRANS_OBJECT_DELETE,
    API_TRANS_OBJECT_DELETE_SUCCESS,
    API_TRANS_OBJECT_DELETE_FAILURE,
} from './../constants/ActionTypes';

import { IApiTransObject } from '../constants/edidb'
import ODataParams from '../constants/params/oDataParams';

export const apiTransObjectGetAll = (params:ODataParams) => {
    return {
        type: API_TRANS_OBJECT_GET_ALL,
        payload: params
    };
};

export const apiTransObjectGetAllSuccess = (apiTransObjectList:IApiTransObject[]) => {
    return {
        type: API_TRANS_OBJECT_GET_ALL_SUCCESS,
        payload:apiTransObjectList
    }
};

export const apiTransObjectGetAllFailure = (error) => {
    return {
        type: API_TRANS_OBJECT_GET_ALL_FAILURE,
        payload: error
    }
};

export const apiTransObjectAdd = (apiTransObject:IApiTransObject) => {
    return {
        type: API_TRANS_OBJECT_ADD,
        payload: apiTransObject
    };
};

export const apiTransObjectAddSuccess = (apiTransObject:IApiTransObject) => {
    return {
        type: API_TRANS_OBJECT_ADD_SUCCESS,
        payload: apiTransObject
    }
};

export const apiTransObjectAddFailure = (error) => {
    return {
        type: API_TRANS_OBJECT_ADD_FAILURE,
        payload: error
    }
};

export const apiTransObjectUpdate = (apiTransObject:IApiTransObject) => {
    return {
        type: API_TRANS_OBJECT_UPDATE,
        payload: apiTransObject
    };
};

export const apiTransObjectUpdateSuccess = (apiTransObject:IApiTransObject) => {
    return {
        type: API_TRANS_OBJECT_UPDATE_SUCCESS,
        payload: apiTransObject
    }
};

export const apiTransObjectUpdateFailure = (error) => {
    return {
        type: API_TRANS_OBJECT_UPDATE_FAILURE,
        payload: error
    }
};

export const apiTransObjectDelete = (apiTransObject:IApiTransObject) => {
    return {
        type: API_TRANS_OBJECT_DELETE,
        payload: apiTransObject
    };
};

export const apiTransObjectDeleteSuccess = (apiTransObject:IApiTransObject) => {
    return {
        type: API_TRANS_OBJECT_DELETE_SUCCESS,
        payload: apiTransObject
    }
};

export const apiTransObjectDeleteFailure = (error) => {
    return {
        type: API_TRANS_OBJECT_DELETE_FAILURE,
        payload: error
    }
};
