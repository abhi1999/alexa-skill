import { 
    LOCATION_GET_ALL, 
    LOCATION_GET_ALL_SUCCESS, 
    LOCATION_GET_ALL_FAILURE, 
    LOCATION_GET_ONE, 
    LOCATION_GET_ONE_SUCCESS, 
    LOCATION_GET_ONE_FAILURE, 
    LOCATION_ADD, 
    LOCATION_ADD_SUCCESS, 
    LOCATION_ADD_FAILURE, 
    LOCATION_UPDATE, 
    LOCATION_UPDATE_SUCCESS, 
    LOCATION_UPDATE_FAILURE,
    LOCATION_DELETE, 
    LOCATION_DELETE_SUCCESS, 
    LOCATION_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { ILocation } from '../constants/edidb';

export const locationGetAll = (params: ODataParams) => {
    return {
        type: LOCATION_GET_ALL,
        payload: params
    };
};

export const locationGetAllSuccess = (locationList: any) => {
    return {
        type: LOCATION_GET_ALL_SUCCESS,
        payload: locationList
    }
};

export const locationGetAllFailure = (error) => {
    return {
        type: LOCATION_GET_ALL_FAILURE,
        payload: error
    }
};

export const locationGetOne = (params: ODataParams) => {
    return {
        type: LOCATION_GET_ONE,
        payload: params
    };
};

export const locationGetOneSuccess = (locationList: any) => {
    return {
        type: LOCATION_GET_ONE_SUCCESS,
        payload: locationList
    }
};

export const locationGetOneFailure = (error) => {
    return {
        type: LOCATION_GET_ONE_FAILURE,
        payload: error
    }
};

export const locationAdd = (location: ILocation) => {
    return {
        type: LOCATION_ADD,
        payload: location
    };
};

export const locationAddSuccess = (location: ILocation) => {
    return {
        type: LOCATION_ADD_SUCCESS,
        payload: location
    }
};

export const locationAddFailure = (error) => {
    return {
        type: LOCATION_ADD_FAILURE,
        payload: error
    }
};

export const locationUpdate = (location: ILocation) => {
    return {
        type: LOCATION_UPDATE,
        payload: location
    };
};

export const locationUpdateSuccess = (location: ILocation) => {
    return {
        type: LOCATION_UPDATE_SUCCESS,
        payload: location
    }
};

export const locationUpdateFailure = (error) => {
    return {
        type: LOCATION_UPDATE_FAILURE,
        payload: error
    }
};

export const locationDelete = (location: ILocation) => {
    return {
        type: LOCATION_DELETE,
        payload: location
    };
};

export const locationDeleteSuccess = (location: ILocation) => {
    return {
        type: LOCATION_DELETE_SUCCESS,
        payload: location
    }
};

export const locationDeleteFailure = (error) => {
    return {
        type: LOCATION_DELETE_FAILURE,
        payload: error
    }
};
