import { 
    C303V850C_GET_LOOKUPS, 
    C303V850C_GET_LOOKUPS_SUCCESS, 
    C303V850C_GET_LOOKUPS_FAILURE, 
    C303V850C_GET_ALL, 
    C303V850C_GET_ALL_SUCCESS, 
    C303V850C_GET_ALL_FAILURE, 
    C303V850C_GET_ONE, 
    C303V850C_GET_ONE_SUCCESS, 
    C303V850C_GET_ONE_FAILURE, 
    C303V850C_ADD, 
    C303V850C_ADD_SUCCESS, 
    C303V850C_ADD_FAILURE, 
    C303V850C_UPDATE, 
    C303V850C_UPDATE_SUCCESS, 
    C303V850C_UPDATE_FAILURE,
    C303V850C_DELETE, 
    C303V850C_DELETE_SUCCESS, 
    C303V850C_DELETE_FAILURE,
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { IC303v850c } from '../constants/edidb';

export const c303v850cGetLookups = (params: ODataParams) => {
    return {
        type: C303V850C_GET_LOOKUPS,
        payload: params
    };
};

export const c303v850cGetLookupsSuccess = ( /* tableNameList: any, ... */ ) => {
    return {
        type: C303V850C_GET_LOOKUPS_SUCCESS,
        payload: { /* tableNameList, ... */ }
    }
};

export const c303v850cGetLookupsFailure = (error) => {
    return {
        type: C303V850C_GET_LOOKUPS_FAILURE,
        payload: error
    }
};

export const c303v850cGetAll = (params: ODataParams) => {
    return {
        type: C303V850C_GET_ALL,
        payload: params
    };
};

export const c303v850cGetAllSuccess = (c303v850cList: any) => {
    return {
        type: C303V850C_GET_ALL_SUCCESS,
        payload: c303v850cList
    }
};

export const c303v850cGetAllFailure = (error) => {
    return {
        type: C303V850C_GET_ALL_FAILURE,
        payload: error
    }
};

export const c303v850cGetOne = (params: ODataParams) => {
    return {
        type: C303V850C_GET_ONE,
        payload: params
    };
};

export const c303v850cGetOneSuccess = (c303v850cList: any) => {
    return {
        type: C303V850C_GET_ONE_SUCCESS,
        payload: c303v850cList
    }
};

export const c303v850cGetOneFailure = (error) => {
    return {
        type: C303V850C_GET_ONE_FAILURE,
        payload: error
    }
};

export const c303v850cAdd = (c303v850c: IC303v850c) => {
    return {
        type: C303V850C_ADD,
        payload: c303v850c
    };
};

export const c303v850cAddSuccess = (c303v850c: IC303v850c) => {
    return {
        type: C303V850C_ADD_SUCCESS,
        payload: c303v850c
    }
};

export const c303v850cAddFailure = (error) => {
    return {
        type: C303V850C_ADD_FAILURE,
        payload: error
    }
};

export const c303v850cUpdate = (c303v850c: IC303v850c) => {
    return {
        type: C303V850C_UPDATE,
        payload: c303v850c
    };
};

export const c303v850cUpdateSuccess = (c303v850c: IC303v850c) => {
    return {
        type: C303V850C_UPDATE_SUCCESS,
        payload: c303v850c
    }
};

export const c303v850cUpdateFailure = (error) => {
    return {
        type: C303V850C_UPDATE_FAILURE,
        payload: error
    }
};

export const c303v850cDelete = (c303v850c: IC303v850c) => {
    return {
        type: C303V850C_DELETE,
        payload: c303v850c
    };
};

export const c303v850cDeleteSuccess = (c303v850c: IC303v850c) => {
    return {
        type: C303V850C_DELETE_SUCCESS,
        payload: c303v850c
    }
};

export const c303v850cDeleteFailure = (error) => {
    return {
        type: C303V850C_DELETE_FAILURE,
        payload: error
    }
};
