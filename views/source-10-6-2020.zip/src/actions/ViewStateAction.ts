
import { 
    SET_PAGE_FILTER_STATE,
    SET_PAGE_SORT_STATE,
    SET_PAGE_STATE,
    SET_EXTERNAL_LINK_FILTER_STATE
} from '../constants/ActionTypes';


export const setPageFilterState = (payload) => {
    return {
        type: SET_PAGE_FILTER_STATE,
        payload
    }
};

export const setPageSortState = (payload) => {
    return {
        type: SET_PAGE_SORT_STATE,
        payload
    }
};

export const setPageState = (payload) => {
    return {
        type: SET_PAGE_STATE,
        payload
    }
};

export const setExternalLinkFilterState = (payload) => {
    return {
        type: SET_EXTERNAL_LINK_FILTER_STATE,
        payload
    }
}