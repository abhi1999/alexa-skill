import { 
    TRANSOBJECT_GET_ALL, 
    TRANSOBJECT_GET_ALL_SUCCESS, 
    TRANSOBJECT_GET_ALL_FAILURE, 
    TRANSOBJECT_GET_ONE,
    TRANSOBJECT_GET_ONE_SUCCESS,
    TRANSOBJECT_GET_ONE_FAILURE,
    TRANSOBJECT_UPDATE, 
    TRANSOBJECT_UPDATE_SUCCESS, 
    TRANSOBJECT_UPDATE_FAILURE,
    TRANSOBJECT_GET_DISTINCT,
    TRANSOBJECT_GET_DISTINCT_SUCCESS,
    TRANSOBJECT_GET_DISTINCT_FAILURE
} from './../constants/ActionTypes';

import ODataParams from '../constants/params/oDataParams';
import { ITransObject } from '../constants/edidb';

export const transObjectGetAll = (params:ODataParams) => {
    return {
        type: TRANSOBJECT_GET_ALL,
        payload: params
    };
};

export const transObjectGetAllSuccess = (odataResp : any) => {
    return {
        type: TRANSOBJECT_GET_ALL_SUCCESS,
        payload: odataResp
    }
};

export const transObjectGetAllFailure = (error) => {
    return {
        type: TRANSOBJECT_GET_ALL_FAILURE,
        payload: error
    }
};

export const transObjectGetOne = (params:any) => {
    return {
        type: TRANSOBJECT_GET_ONE,
        payload: params
    };
};

export const transObjectGetOneSuccess = (odataResp : any) => {
    return {
        type: TRANSOBJECT_GET_ONE_SUCCESS,
        payload: odataResp
    }
};

export const transObjectGetOneFailure = (error) => {
    return {
        type: TRANSOBJECT_GET_ONE_FAILURE,
        payload: error
    }
};

export const transObjectUpdate = (transObject:ITransObject) => {
    return {
        type: TRANSOBJECT_UPDATE,
        payload: transObject
    };
};

export const transObjectUpdateSuccess = (transObject:ITransObject) => {
    return {
        type: TRANSOBJECT_UPDATE_SUCCESS,
        payload: transObject
    }
};

export const transObjectUpdateFailure = (error) => {
    return {
        type: TRANSOBJECT_UPDATE_FAILURE,
        payload: error
    }
};


export const transObjectGetDistinct = (params:ODataParams) => {
    return {
        type: TRANSOBJECT_GET_DISTINCT,
        payload: params
    };
};

export const transObjectGetDistinctSuccess = (odataResp : any) => {
    return {
        type: TRANSOBJECT_GET_DISTINCT_SUCCESS,
        payload: odataResp
    }
};

export const transObjectGetDistinctFailure = (error) => {
    return {
        type: TRANSOBJECT_GET_DISTINCT_FAILURE,
        payload: error
    }
};