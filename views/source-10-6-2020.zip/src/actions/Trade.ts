import { 
    TRADE_GET_ALL, 
    TRADE_GET_ALL_SUCCESS, 
    TRADE_GET_ALL_FAILURE, 
    TRADE_GET_ONE,
    TRADE_GET_ONE_SUCCESS,
    TRADE_GET_ONE_FAILURE,
    TRADE_ADD, 
    TRADE_ADD_SUCCESS, 
    TRADE_ADD_FAILURE,
    TRADE_UPDATE, 
    TRADE_UPDATE_SUCCESS, 
    TRADE_UPDATE_FAILURE,
    TRADE_DELETE, 
    TRADE_DELETE_SUCCESS, 
    TRADE_DELETE_FAILURE,
    TRADE_UPDATE_MAPS,
    TRADE_UPDATE_MAPS_SUCCESS,
    TRADE_UPDATE_MAPS_FAILURE,
    TRADE_GET_USER_FIELDS,
    TRADE_GET_USER_FIELDS_SUCCESS,
    TRADE_GET_USER_FIELDS_FAILURE,
    TRADE_BACKUP,
    TRADE_BACKUP_SUCCESS,
    TRADE_BACKUP_FAILURE,
    TRADE_RESTORE,
    TRADE_RESTORE_SUCCESS,
    TRADE_RESTORE_FAILURE,
    TRADE_IMPORT,
    TRADE_IMPORT_SUCCESS,
    TRADE_IMPORT_FAILURE,
    TRADE_IMPORT_CONFIG,
    TRADE_IMPORT_CONFIG_SUCCESS,
    TRADE_IMPORT_CONFIG_FAILURE,
    TRADE_GET_TRADELIST,
    TRADE_GET_TRADELIST_FAILURE,
    TRADE_GET_TRADELIST_SUCCESS,
    TRADE_GET_LOOKUPTABLES,
    TRADE_GET_LOOKUPTABLES_SUCCESS,
    TRADE_GET_LOOKUPTABLES_FAILURE
} from './../constants/ActionTypes';

import { ITrade } from '../constants/edidb'
import { MapSetting } from '../constants/MapSetting'
import { IUserDefinedFields } from '../constants/ApiStructs'
import { IImportConfigParameters } from '../constants/ApiStructs'

import ODataParams from '../constants/params/oDataParams';

export const tradeGetAll = (params:ODataParams) => {
    return {
        type: TRADE_GET_ALL,
        payload: params
    };
};

export const tradeGetAllSuccess = (odataResp : any) => {
    return {
        type: TRADE_GET_ALL_SUCCESS,
        payload: odataResp
    }
};

export const tradeGetAllFailure = (error) => {
    return {
        type: TRADE_GET_ALL_FAILURE,
        payload: error
    }
};

export const tradeGetOne = (params:any) => {
    return {
        type: TRADE_GET_ONE,
        payload: params
    };
};

export const tradeGetOneSuccess = (odataResp : any) => {
    return {
        type: TRADE_GET_ONE_SUCCESS,
        payload: odataResp
    }
};

export const tradeGetOneFailure = (error) => {
    return {
        type: TRADE_GET_ONE_FAILURE,
        payload: error
    }
};

export const tradeGetTradeList = (params:ODataParams) =>
{
    return {
        type: TRADE_GET_TRADELIST,
        payload: params
    };
}

export const tradeGetTradeListSuccess = (odataResp : any) =>
{
    return {
        type: TRADE_GET_TRADELIST_SUCCESS,
        payload: odataResp
    };
}

export const tradeGetTradeListFailure = (error) =>
{
    return {
        type: TRADE_GET_TRADELIST_FAILURE,
        payload: error
    };
}

export const tradeAdd = (params:any) => {
    return {
        type: TRADE_ADD,
        payload: params
    };
};

export const tradeAddSuccess = (trade:ITrade) => {
    return {
        type: TRADE_ADD_SUCCESS,
        payload: trade
    }
};

export const tradeAddFailure = (error) => {
    return {
        type: TRADE_ADD_FAILURE,
        payload: error
    }
};
export const tradeUpdate = (trade:ITrade) => {
    return {
        type: TRADE_UPDATE,
        payload: trade
    };
};

export const tradeUpdateSuccess = (trade:ITrade) => {
    return {
        type: TRADE_UPDATE_SUCCESS,
        payload: trade
    }
};

export const tradeUpdateFailure = (error) => {
    return {
        type: TRADE_UPDATE_FAILURE,
        payload: error
    }
};

export const tradeDelete = (trade:ITrade) => {
    return {
        type: TRADE_DELETE,
        payload: trade
    };
};

export const tradeDeleteSuccess = (trade:ITrade) => {
    return {
        type: TRADE_DELETE_SUCCESS,
        payload: trade
    }
};

export const tradeDeleteFailure = (error) => {
    return {
        type: TRADE_DELETE_FAILURE,
        payload: error
    }
};

export const tradeUpdateMaps = (mapSettingsList:MapSetting[]) => {
    return {
        type: TRADE_UPDATE_MAPS,
        payload: mapSettingsList
    }
};

export const tradeUpdateMapsSuccess = (mapStatus:any) => {
    return {
        type: TRADE_UPDATE_MAPS_SUCCESS,
        payload: mapStatus
    }
};

export const tradeUpdateMapsFailure = (error) => {
    return {
        type: TRADE_UPDATE_MAPS_FAILURE,
        payload: error
    }
};

export const tradeGetUserFields = (tpPartID:string) => {
    return {
        type: TRADE_GET_USER_FIELDS,
        payload: tpPartID
    }
};

export const tradeGetUserFieldsSuccess = (userFieldList:IUserDefinedFields[]) => {
    return {
        type: TRADE_GET_USER_FIELDS_SUCCESS,
        payload: userFieldList
    }
};

export const tradeGetUserFieldsFailure = (error) => {
    return {
        type: TRADE_GET_USER_FIELDS_FAILURE,
        payload: error
    }
};

export const tradeBackup = (installCode:string) => {
    return {
        type: TRADE_BACKUP,
        payload: installCode
    }
};

export const tradeBackupSuccess = (result:any) => {
    return {
        type: TRADE_BACKUP_SUCCESS,
        payload: result
    }
};

export const tradeBackupFailure = (error) => {
    return {
        type: TRADE_BACKUP_FAILURE,
        payload: error
    }
};

export const tradeRestore = (installCode:string) => {
    return {
        type: TRADE_RESTORE,
        payload: installCode
    }
};

export const tradeRestoreSuccess = (result:any) => {
    return {
        type: TRADE_RESTORE_SUCCESS,
        payload: result
    }
};

export const tradeRestoreFailure = (error) => {
    return {
        type: TRADE_RESTORE_FAILURE,
        payload: error
    }
};

export const tradeImport = (installCode:string) => {
    return {
        type: TRADE_IMPORT,
        payload: installCode
    }
};

export const tradeImportSuccess = (result:any) => {
    return {
        type: TRADE_IMPORT_SUCCESS,
        payload: result
    }
};

export const tradeImportFailure = (error) => {
    return {
        type: TRADE_IMPORT_FAILURE,
        payload: error
    }
};

export const tradeImportConfig = (importConfig:IImportConfigParameters) => {
    return {
        type: TRADE_IMPORT_CONFIG,
        payload: importConfig
    }
};

export const tradeImportConfigSuccess = (result:any) => {
    return {
        type: TRADE_IMPORT_CONFIG_SUCCESS,
        payload: result
    }
};

export const tradeImportConfigFailure = (error) => {
    return {
        type: TRADE_IMPORT_CONFIG_FAILURE,
        payload: error
    }
};

export const tradeGetLookupTables= () => {
    return {
        type: TRADE_GET_LOOKUPTABLES,
    };
};

export const tradeGetLookupTablesSuccess = () => {
    return {
        type: TRADE_GET_LOOKUPTABLES_SUCCESS,
    }
};

export const tradeGetLookupTablesFailure = (error) => {
    return {
        type: TRADE_GET_LOOKUPTABLES_FAILURE,
        payload: error
    }
};