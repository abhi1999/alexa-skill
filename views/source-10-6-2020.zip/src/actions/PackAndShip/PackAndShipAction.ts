import {
    // Actions for Main Pack And Ship Form

    PACK_AND_SHIP_ORDER_LINE_ITEMS_GET_ALL,
    PACK_AND_SHIP_ORDER_LINE_ITEMS_GET_ALL_SUCCESS,
    PACK_AND_SHIP_ORDER_LINE_ITEMS_GET_ALL_FAILURE,
    PACK_AND_SHIP_ORDER_LINE_ITEMS_PACKED_GET_ALL,
    PACK_AND_SHIP_ORDER_LINE_ITEMS_PACKED_GET_ALL_SUCCESS,
    PACK_AND_SHIP_ORDER_LINE_ITEMS_PACKED_GET_ALL_FAILURE,
    // Table Hamburger actions
    PACK_AND_SHIP_QUICK_PACK_LINE_ITEM,
    PACK_AND_SHIP_QUICK_PACK_LINE_ITEM_SUCCESS,
    PACK_AND_SHIP_QUICK_PACK_LINE_ITEM_FAILURE,
    PACK_AND_SHIP_PACK_LINE_ITEM,
    PACK_AND_SHIP_PACK_LINE_ITEM_SUCCESS,
    PACK_AND_SHIP_PACK_LINE_ITEM_FAILURE,
    PACK_AND_SHIP_UN_PACK_LINE_ITEM,
    PACK_AND_SHIP_UN_PACK_LINE_ITEM_SUCCESS,
    PACK_AND_SHIP_UN_PACK_LINE_ITEM_FAILURE,
    PACK_AND_SHIP_REDUCE_PACKED_QTY,
    PACK_AND_SHIP_REDUCE_PACKED_QTY_SUCCESS,
    PACK_AND_SHIP_REDUCE_PACKED_QTY_FAILURE,
    PACK_AND_SHIP_INCREASE_PACKED_QTY,
    PACK_AND_SHIP_INCREASE_PACKED_QTY_SUCCESS,
    PACK_AND_SHIP_INCREASE_PACKED_QTY_FAILURE,    
    // Actions Menu action
    PACK_AND_SHIP_QUICK_PACK_LINE_ITEM_ALL,
    PACK_AND_SHIP_QUICK_PACK_LINE_ITEM_ALL_SUCCESS,
    PACK_AND_SHIP_QUICK_PACK_LINE_ITEM_ALL_FAILURE,
    PACK_AND_SHIP_PACK_LINE_ITEM_ALL_IN_ONE,
    PACK_AND_SHIP_PACK_LINE_ITEM_ALL_IN_ONE_SUCCESS,
    PACK_AND_SHIP_PACK_LINE_ITEM_ALL_IN_ONE_FAILURE,
    PACK_AND_SHIP_UN_PACK_LINE_ITEM_ALL,
    PACK_AND_SHIP_UN_PACK_LINE_ITEM_ALL_SUCCESS,
    PACK_AND_SHIP_UN_PACK_LINE_ITEM_ALL_FAILURE,
    PACK_AND_SHIP_RESET_ALL,
    PACK_AND_SHIP_RESET_ALL_SUCCESS,
    PACK_AND_SHIP_RESET_ALL_FAILURE,
    PACK_AND_SHIP_CLONE_BOX,
    PACK_AND_SHIP_CLONE_BOX_SUCCESS,
    PACK_AND_SHIP_CLONE_BOX_FAILURE,
    PACK_AND_SHIP_RESEQUENCE,
    PACK_AND_SHIP_RESEQUENCE_SUCCESS,
    PACK_AND_SHIP_RESEQUENCE_FAILURE,
    PACK_AND_SHIP_ORDER_COMPLETE,
    PACK_AND_SHIP_ORDER_COMPLETE_SUCCESS,
    PACK_AND_SHIP_ORDER_COMPLETE_FAILURE,
    PACK_AND_SHIP_ORDER_COMPLETE_AND_SHIP,
    PACK_AND_SHIP_ORDER_COMPLETE_AND_SHIP_SUCCESS,
    PACK_AND_SHIP_ORDER_COMPLETE_AND_SHIP_FAILURE,
    PACK_AND_SHIP_GEN_PACKING_DETAIL,
    PACK_AND_SHIP_GEN_PACKING_DETAIL_SUCCESS,
    PACK_AND_SHIP_GEN_PACKING_DETAIL_FAILURE,
    // Misc Actions
    PACK_AND_SHIP_VALIDATE_ORDER_UPC_CODE,
    PACK_AND_SHIP_VALIDATE_ORDER_UPC_CODE_SUCCESS,
    PACK_AND_SHIP_VALIDATE_ORDER_UPC_CODE_FAILURE,
    PACK_AND_SHIP_CONFIG_SETTINGS_GET_ALL,
    PACK_AND_SHIP_CONFIG_SETTINGS_GET_ALL_SUCCESS,
    PACK_AND_SHIP_CONFIG_SETTINGS_GET_ALL_FAILURE,

} from '../../constants/ActionTypes';
import ODataParams from '../../constants/params/oDataParams';
import { IPackOrder } from '../../constants/PackAndShip/packAndShipOrder';
import { IPackAndShipConfigSettings } from '../../constants/PackAndShip/packAndShipConfigSettings';

export const packAndShipOrderLineItemsGetAll = (params: ODataParams) => {
    return {
        type: PACK_AND_SHIP_ORDER_LINE_ITEMS_GET_ALL,
        payload: params
    };
};

export const packAndShipOrderLineItemsGetAllSuccess = (odataResp: any) => {
    return {
        type: PACK_AND_SHIP_ORDER_LINE_ITEMS_GET_ALL_SUCCESS,
        payload: odataResp
    };
};

export const packAndShipOrderLineItemsGetAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_ORDER_LINE_ITEMS_GET_ALL_FAILURE,
        payload: error
    };
};

export const packAndShipOrderLineItemsPackedGetAll = (params: ODataParams) => {
    return {
        type: PACK_AND_SHIP_ORDER_LINE_ITEMS_PACKED_GET_ALL,
        payload: params
    };
};

export const packAndShipOrderLineItemsPackedGetAllSuccess = (odataResp: any) => {
    return {
        type: PACK_AND_SHIP_ORDER_LINE_ITEMS_PACKED_GET_ALL_SUCCESS,
        payload: odataResp
    };
};

export const packAndShipOrderLineItemsPackedGetAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_ORDER_LINE_ITEMS_PACKED_GET_ALL_FAILURE,
        payload: error
    };
};

// -----------------------------------------------------------------------------------------------------------------------------------
// Update Calls to the Api
// -----------------------------------------------------------------------------------------------------------------------------------

// Action methods for the Main Pack And Ship Form

export const packAndShipQuickPackLineItem = ( params: { packOrder: IPackOrder, distinct: boolean, quantity: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_LINE_ITEM,
        payload: params
    };
};

export const packAndShipQuickPackLineItemSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_LINE_ITEM_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipQuickPackLineItemFailure = (error) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_LINE_ITEM_FAILURE,
        payload: error
    };
};

export const packAndShipPackLineItem = (params: { packOrder: IPackOrder, distinct: boolean, quantity: number, debug: boolean }) => {
    return {
        type: PACK_AND_SHIP_PACK_LINE_ITEM,
        payload: params
    };
};

export const packAndShipPackLineItemSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_PACK_LINE_ITEM_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipPackLineItemFailure = (error) => {
    return {
        type: PACK_AND_SHIP_PACK_LINE_ITEM_FAILURE,
        payload: error
    };
};

export const packAndShipUnpackLineItem = ( params: { packOrder: IPackOrder, distinct: boolean, quantity: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_UN_PACK_LINE_ITEM,
        payload: params
    };
};

export const packAndShipUnpackLineItemSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_UN_PACK_LINE_ITEM_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipUnpackLineItemFailure = (error) => {
    return {
        type: PACK_AND_SHIP_UN_PACK_LINE_ITEM_FAILURE,
        payload: error
    };
};

export const packAndShipReducePackedQty = ( params: { packOrder: IPackOrder, distinct: boolean, quantity: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_REDUCE_PACKED_QTY,
        payload: params
    };
};

export const packAndShipReducePackedQtySuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_REDUCE_PACKED_QTY_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipReducePackedQtyFailure = (error) => {
    return {
        type: PACK_AND_SHIP_REDUCE_PACKED_QTY_FAILURE,
        payload: error
    };
};

export const packAndShipIncreasePackedQty = ( params: { packOrder: IPackOrder, distinct: boolean, quantity: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_INCREASE_PACKED_QTY,
        payload: params
    };
};

export const packAndShipIncreasePackedQtySuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_INCREASE_PACKED_QTY_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipIncreasePackedQtyFailure = (error) => {
    return {
        type: PACK_AND_SHIP_INCREASE_PACKED_QTY_FAILURE,
        payload: error
    };
};

export const packAndShipQuickPackLineItemAll = ( params: { packOrders: IPackOrder[], distinct: boolean, quantity: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_LINE_ITEM_ALL,
        payload: params
    };
};

export const packAndShipQuickPackLineItemAllSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_LINE_ITEM_ALL_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipQuickPackLineItemAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_LINE_ITEM_ALL_FAILURE,
        payload: error
    };
};

export const packAndShipPackLineItemAllInOne = ( params: { packOrders: IPackOrder[], distinct: boolean, quantity: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_PACK_LINE_ITEM_ALL_IN_ONE,
        payload: params
    };
};

export const packAndShipPackLineItemAllInOneSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_PACK_LINE_ITEM_ALL_IN_ONE_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipPackLineItemAllInOneFailure = (error) => {
    return {
        type: PACK_AND_SHIP_PACK_LINE_ITEM_ALL_IN_ONE_FAILURE,
        payload: error
    };
};

export const packAndShipUnpackLineItemAll = ( params: { packOrders: IPackOrder[] } ) => {
    return {
        type: PACK_AND_SHIP_UN_PACK_LINE_ITEM_ALL,
        payload: params
    };
};

export const packAndShipUnpackLineItemAllSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_UN_PACK_LINE_ITEM_ALL_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipUnpackLineItemAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_UN_PACK_LINE_ITEM_ALL_FAILURE,
        payload: error
    };
};

// export const packAndShipResetAll = ( params: { orders: number[], distinct: boolean, quantity: number, debug: boolean } ) => {
export const packAndShipResetAll = ( params: { orders: number[] } ) => {
        return {
        type: PACK_AND_SHIP_RESET_ALL,
        payload: params
    };
};

export const packAndShipResetAllSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_RESET_ALL_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipResetAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_RESET_ALL_FAILURE,
        payload: error
    };
};

export const packAndShipCloneBox = ( params: { orderId: number, boxId: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_CLONE_BOX,
        payload: params
    };
};

export const packAndShipCloneBoxSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_CLONE_BOX_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipCloneBoxFailure = (error) => {
    return {
        type: PACK_AND_SHIP_CLONE_BOX_FAILURE,
        payload: error
    };
};

export const packAndShipResequence = ( params: { orderId: number, boxId: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_RESEQUENCE,
        payload: params
    };
};

export const packAndShipResequenceSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_RESEQUENCE_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipResequenceFailure = (error) => {
    return {
        type: PACK_AND_SHIP_RESEQUENCE_FAILURE,
        payload: error
    };
};

export const packAndShipOrderComplete = ( params: { orderId: number, ship: boolean, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_ORDER_COMPLETE,
        payload: params
    };
};

export const packAndShipOrderCompleteSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_ORDER_COMPLETE_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipOrderCompleteFailure = (error) => {
    return {
        type: PACK_AND_SHIP_ORDER_COMPLETE_FAILURE,
        payload: error
    };
};

export const packAndShipOrderCompleteAndShip = ( params: { orderId: number, ship: boolean, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_ORDER_COMPLETE_AND_SHIP,
        payload: params
    };
};

export const packAndShipOrderCompleteAndShipSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_ORDER_COMPLETE_AND_SHIP_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipOrderCompleteAndShipFailure = (error) => {
    return {
        type: PACK_AND_SHIP_ORDER_COMPLETE_AND_SHIP_FAILURE,
        payload: error
    };
};

export const packAndShipValidateOrderUpcCode = ( params: { orderId: number, UPCCode: string, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_VALIDATE_ORDER_UPC_CODE,
        payload: params
    };
};

export const packAndShipValidateOrderUpcCodeSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_VALIDATE_ORDER_UPC_CODE_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipValidateOrderUpcCodeFailure = (error) => {
    return {
        type: PACK_AND_SHIP_VALIDATE_ORDER_UPC_CODE_FAILURE,
        payload: error
    };
};

export const packAndShipConfigSettingsGetAll = () => {
    return {
        type: PACK_AND_SHIP_CONFIG_SETTINGS_GET_ALL,
        payload: null
    };
};

export const packAndShipConfigSettingsGetAllSuccess = (data: IPackAndShipConfigSettings[]) => {
    return {
        type: PACK_AND_SHIP_CONFIG_SETTINGS_GET_ALL_SUCCESS,
        payload: data
    };
};

export const packAndShipConfigSettingsGetAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_CONFIG_SETTINGS_GET_ALL_FAILURE,
        payload: error
    };
};

export const packAndShipGenPackingDetail = (params: { orderNo: number }) => {
    return {
        type: PACK_AND_SHIP_GEN_PACKING_DETAIL,
        payload: params
    };
};

export const packAndShipGenPackingDetailSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_GEN_PACKING_DETAIL_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipGenPackingDetailFailure = (error) => {
    return {
        type: PACK_AND_SHIP_GEN_PACKING_DETAIL_FAILURE,
        payload: error
    };
};

