import {
    // Actions for Pack And Ship Shipment List Form

    PACK_AND_SHIP_SHIPMENT_LIST_GET_ALL,
    PACK_AND_SHIP_SHIPMENT_LIST_GET_ALL_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_LIST_GET_ALL_FAILURE,
    PACK_AND_SHIP_SHIPMENT_LIST_CREATE_SHIPMENT,
    PACK_AND_SHIP_SHIPMENT_LIST_CREATE_SHIPMENT_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_LIST_CREATE_SHIPMENT_FAILURE,
    PACK_AND_SHIP_SHIPMENT_LIST_CLONE_SHIPMENT,
    PACK_AND_SHIP_SHIPMENT_LIST_CLONE_SHIPMENT_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_LIST_CLONE_SHIPMENT_FAILURE,
    PACK_AND_SHIP_SHIPMENT_LIST_CLONE_SHIPMENT_FOR_ORDER,
    PACK_AND_SHIP_SHIPMENT_LIST_CLONE_SHIPMENT_FOR_ORDER_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_LIST_CLONE_SHIPMENT_FOR_ORDER_FAILURE,
    PACK_AND_SHIP_SHIPMENT_LIST_CONSOLIDATE_SHIPMENT,
    PACK_AND_SHIP_SHIPMENT_LIST_CONSOLIDATE_SHIPMENT_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_LIST_CONSOLIDATE_SHIPMENT_FAILURE,
    PACK_AND_SHIP_SHIPMENT_LIST_ADD_UPDATE_USER_NOTE,
    PACK_AND_SHIP_SHIPMENT_LIST_ADD_UPDATE_USER_NOTE_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_LIST_ADD_UPDATE_USER_NOTE_FAILURE

} from '../../constants/ActionTypes';
import ODataParams from '../../constants/params/oDataParams';
import { IAsn, INote } from '../../constants/edidb';

export const packAndShipShipmentListGetAll = (params: ODataParams) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_GET_ALL,
        payload: params
    };
};

export const packAndShipShipmentListGetAllSuccess = (odataResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_GET_ALL_SUCCESS,
        payload: odataResp
    };
};

export const packAndShipShipmentListGetAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_GET_ALL_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentListCreateShipment = (params: {  }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_CREATE_SHIPMENT,
        payload: params
    };
};

export const packAndShipShipmentListCreateShipmentSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_CREATE_SHIPMENT_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentListCreateShipmentFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_CREATE_SHIPMENT_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentListCloneShipment = (params: { orderId: number, acctOrderNo: string }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_CLONE_SHIPMENT,
        payload: params
    };
};

export const packAndShipShipmentListCloneShipmentSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_CLONE_SHIPMENT_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentListCloneShipmentFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_CLONE_SHIPMENT_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentListCloneShipmentForOrder = (params: { orderId: number, acctOrderNo: string }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_CLONE_SHIPMENT_FOR_ORDER,
        payload: params
    };
};

export const packAndShipShipmentListCloneShipmentForOrderSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_CLONE_SHIPMENT_FOR_ORDER_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentListCloneShipmentForOrderFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_CLONE_SHIPMENT_FOR_ORDER_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentListConsolidateShipment = (params: { asnId: number, bolNo: string }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_CONSOLIDATE_SHIPMENT,
        payload: params
    };
};

export const packAndShipShipmentListConsolidateShipmentSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_CONSOLIDATE_SHIPMENT_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentListConsolidateShipmentFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_CONSOLIDATE_SHIPMENT_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentListAddUpdateUserNote = (params: { note: INote }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_ADD_UPDATE_USER_NOTE,
        payload: params
    };
};

export const packAndShipShipmentListAddUpdateUserNoteSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_ADD_UPDATE_USER_NOTE_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentListAddUpdateUserNoteFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_LIST_ADD_UPDATE_USER_NOTE_FAILURE,
        payload: error
    };
};

