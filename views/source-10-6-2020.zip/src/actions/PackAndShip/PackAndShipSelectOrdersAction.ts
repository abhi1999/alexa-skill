import {
    // Actions for Select Orders Form
    PACK_AND_SHIP_SELECT_ORDERS_GET_ALL,
    PACK_AND_SHIP_SELECT_ORDERS_GET_ALL_SUCCESS,
    PACK_AND_SHIP_SELECT_ORDERS_GET_ALL_FAILURE,
    PACK_AND_SHIP_QUICK_PACK_PO_ONE,
    PACK_AND_SHIP_QUICK_PACK_PO_ONE_SUCCESS,
    PACK_AND_SHIP_QUICK_PACK_PO_ONE_FAILURE,
    PACK_AND_SHIP_QUICK_PACK_SELECTED,
    PACK_AND_SHIP_QUICK_PACK_SELECTED_SUCCESS,
    PACK_AND_SHIP_QUICK_PACK_SELECTED_FAILURE,
    PACK_AND_SHIP_QUICK_PACK_AND_SHIP_SELECTED,
    PACK_AND_SHIP_QUICK_PACK_AND_SHIP_SELECTED_SUCCESS,
    PACK_AND_SHIP_QUICK_PACK_AND_SHIP_SELECTED_FAILURE,
    PACK_AND_SHIP_UN_PACK_ORDER_ONE,
    PACK_AND_SHIP_UN_PACK_ORDER_ONE_SUCCESS,
    PACK_AND_SHIP_UN_PACK_ORDER_ONE_FAILURE,
    PACK_AND_SHIP_UN_PACK_ORDER_SELECTED,
    PACK_AND_SHIP_UN_PACK_ORDER_SELECTED_SUCCESS,
    PACK_AND_SHIP_UN_PACK_ORDER_SELECTED_FAILURE,
    PACK_AND_SHIP_QUICK_PACK_BY_ITEM_SELECTED,
    PACK_AND_SHIP_QUICK_PACK_BY_ITEM_SELECTED_SUCCESS,
    PACK_AND_SHIP_QUICK_PACK_BY_ITEM_SELECTED_FAILURE,
    PACK_AND_SHIP_QUICK_PACK_BY_ALT_ITEM_SELECTED,
    PACK_AND_SHIP_QUICK_PACK_BY_ALT_ITEM_SELECTED_SUCCESS,
    PACK_AND_SHIP_QUICK_PACK_BY_ALT_ITEM_SELECTED_FAILURE,
    PACK_AND_SHIP_PACK_ALL_IN_ONE_SELECTED,
    PACK_AND_SHIP_PACK_ALL_IN_ONE_SELECTED_SUCCESS,
    PACK_AND_SHIP_PACK_ALL_IN_ONE_SELECTED_FAILURE,
    PACK_AND_SHIP_PURGE,
    PACK_AND_SHIP_PURGE_SUCCESS,
    PACK_AND_SHIP_PURGE_FAILURE,
    PACK_AND_SHIP_ORDERL_GET_ONE,
    PACK_AND_SHIP_ORDERL_GET_ONE_SUCCESS,
    PACK_AND_SHIP_ORDERL_GET_ONE_FAILURE,
    PACK_AND_SHIP_ORDERL_UPDATE_ONE,
    PACK_AND_SHIP_ORDERL_UPDATE_ONE_SUCCESS,
    PACK_AND_SHIP_ORDERL_UPDATE_ONE_FAILURE,

} from '../../constants/ActionTypes';
import ODataParams from '../../constants/params/oDataParams';
// import * as xPackAndShip from '../../constants/edidb/CPackAndShipSelectOrder';
import { COrderL } from '../../constants/edidb/COrderL';

export const packAndShipSelectOrdersGetAll = (params: ODataParams) => {
    return {
        type: PACK_AND_SHIP_SELECT_ORDERS_GET_ALL,
        payload: params
    };
};

export const packAndShipSelectOrdersGetAllSuccess = (odataResp: any) => {
    return {
        type: PACK_AND_SHIP_SELECT_ORDERS_GET_ALL_SUCCESS,
        payload: odataResp
    };
};

export const packAndShipSelectOrdersGetAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SELECT_ORDERS_GET_ALL_FAILURE,
        payload: error
    };
};

// -----------------------------------------------------------------------------------------------------------------------------------
// Update Calls to the Api
// -----------------------------------------------------------------------------------------------------------------------------------


// Action methods for the Select Orders Form
export const packAndShipQuickPackPO = ( params: { purchaseOrderNo: string, distinct: boolean, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_PO_ONE,
        payload: params
    };
};

export const packAndShipQuickPackPOSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_PO_ONE_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipQuickPackPOFailure = (error) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_PO_ONE_FAILURE,
        payload: error
    };
};


export const packAndShipQuickPackSelected = ( params: { orders: number[], distinct: boolean, quantity: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_SELECTED,
        payload: params
    };
};

export const packAndShipQuickPackSelectedSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_SELECTED_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipQuickPackSelectedFailure = (error) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_SELECTED_FAILURE,
        payload: error
    };
};

export const packAndShipQuickPackAndShipSelected = ( params: { orders: number[], distinct: boolean, quantity: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_AND_SHIP_SELECTED,
        payload: params
    };
};

export const packAndShipQuickPackAndShipSelectedSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_AND_SHIP_SELECTED_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipQuickPackAndShipSelectedFailure = (error) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_AND_SHIP_SELECTED_FAILURE,
        payload: error
    };
};

export const packAndShipUnpackOrderOne = ( params: { orderNo: number, distinct: boolean, quantity: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_UN_PACK_ORDER_ONE,
        payload: params
    };
};

export const packAndShipUnpackOrderOneSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_UN_PACK_ORDER_ONE_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipUnpackOrderOneFailure = (error) => {
    return {
        type: PACK_AND_SHIP_UN_PACK_ORDER_ONE_FAILURE,
        payload: error
    };
};

export const packAndShipUnpackOrderSelected = ( params: { orders: number[], distinct: boolean, quantity: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_UN_PACK_ORDER_SELECTED,
        payload: params
    };
};

export const packAndShipUnpackOrderSelectedSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_UN_PACK_ORDER_SELECTED_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipUnpackOrderSelectedFailure = (error) => {
    return {
        type: PACK_AND_SHIP_UN_PACK_ORDER_SELECTED_FAILURE,
        payload: error
    };
};

export const packAndShipQuickPackByItemSelected = ( params: { orders: number[], distinct: boolean, quantity: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_BY_ITEM_SELECTED,
        payload: params
    };
};

export const packAndShipQuickPackByItemSelectedSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_BY_ITEM_SELECTED_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipQuickPackByItemSelectedFailure = (error) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_BY_ITEM_SELECTED_FAILURE,
        payload: error
    };
};

export const packAndShipQuickPackByAltItemSelected = ( params: { orders: number[], distinct: boolean, quantity: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_BY_ALT_ITEM_SELECTED,
        payload: params
    };
};

export const packAndShipQuickPackByAltItemSelectedSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_BY_ALT_ITEM_SELECTED_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipQuickPackByAltItemSelectedFailure = (error) => {
    return {
        type: PACK_AND_SHIP_QUICK_PACK_BY_ALT_ITEM_SELECTED_FAILURE,
        payload: error
    };
};

export const packAndShipPackAllInOneSelected = ( params: { orders: number[], distinct: boolean, quantity: number, debug: boolean } ) => {
    return {
        type: PACK_AND_SHIP_PACK_ALL_IN_ONE_SELECTED,
        payload: params
    };
};

export const packAndShipPackAllInOneSelectedSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_PACK_ALL_IN_ONE_SELECTED_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipPackAllInOneSelectedFailure = (error) => {
    return {
        type: PACK_AND_SHIP_PACK_ALL_IN_ONE_SELECTED_FAILURE,
        payload: error
    };
};

export const packAndShipPurgeRecords = ( params: { orders: number[] } ) => {
    return {
        type: PACK_AND_SHIP_PURGE,
        payload: params
    };
};

export const packAndShipPurgeRecordsSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_PURGE_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipPurgeRecordsFailure = (error) => {
    return {
        type: PACK_AND_SHIP_PURGE_FAILURE,
        payload: error
    };
};

export const packAndShipOrderLGetOne = ( params: { orderId: number } ) => {
    return {
        type: PACK_AND_SHIP_ORDERL_GET_ONE,
        payload: params
    };
};

export const packAndShipOrderLGetOneSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_ORDERL_GET_ONE_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipOrderLGetOneFailure = (error) => {
    return {
        type: PACK_AND_SHIP_ORDERL_GET_ONE_FAILURE,
        payload: error
    };
};

export const packAndShipOrderLUpdateOne = ( params: { order: COrderL } ) => {
    return {
        type: PACK_AND_SHIP_ORDERL_UPDATE_ONE,
        payload: params
    };
};

export const packAndShipOrderLUpdateOneSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_ORDERL_UPDATE_ONE_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipOrderLUpdateOneFailure = (error) => {
    return {
        type: PACK_AND_SHIP_ORDERL_UPDATE_ONE_FAILURE,
        payload: error
    };
};
