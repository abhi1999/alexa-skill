import {
    PACK_AND_SHIP_SHIPMENT_ASN_GET_ONE,
    PACK_AND_SHIP_SHIPMENT_ASN_GET_ONE_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_ASN_GET_ONE_FAILURE,
    PACK_AND_SHIP_SHIPMENT_PACKAGE_LEVELS_GET_DISTINCT,
    PACK_AND_SHIP_SHIPMENT_PACKAGE_LEVELS_GET_DISTINCT_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_PACKAGE_LEVELS_GET_DISTINCT_FAILURE,

    PACK_AND_SHIP_SHIPMENT_ORDER_READY_SUMMARY_GET_ALL,
    PACK_AND_SHIP_SHIPMENT_ORDER_READY_SUMMARY_GET_ALL_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_ORDER_READY_SUMMARY_GET_ALL_FAILURE,
    PACK_AND_SHIP_SHIPMENT_ORDER_READY_DETAIL_GET_ALL,
    PACK_AND_SHIP_SHIPMENT_ORDER_READY_DETAIL_GET_ALL_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_ORDER_READY_DETAIL_GET_ALL_FAILURE,

    PACK_AND_SHIP_SHIPMENT_ORDER_IN_SHIPMENT_SUMMARY_GET_ALL,
    PACK_AND_SHIP_SHIPMENT_ORDER_IN_SHIPMENT_SUMMARY_GET_ALL_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_ORDER_IN_SHIPMENT_SUMMARY_GET_ALL_FAILURE,
    PACK_AND_SHIP_SHIPMENT_ORDER_IN_SHIPMENT_DETAIL_GET_ALL,
    PACK_AND_SHIP_SHIPMENT_ORDER_IN_SHIPMENT_DETAIL_GET_ALL_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_ORDER_IN_SHIPMENT_DETAIL_GET_ALL_FAILURE,
    
    PACK_AND_SHIP_SHIPMENT_MOVE_ORDERS_TO_SHIPPED,
    PACK_AND_SHIP_SHIPMENT_MOVE_ORDERS_TO_SHIPPED_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_MOVE_ORDERS_TO_SHIPPED_FAILURE,
    PACK_AND_SHIP_SHIPMENT_MOVE_ORDERS_TO_READY,
    PACK_AND_SHIP_SHIPMENT_MOVE_ORDERS_TO_READY_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_MOVE_ORDERS_TO_READY_FAILURE,

    PACK_AND_SHIP_SHIPMENT_UPDATE_SHIPMENT,
    PACK_AND_SHIP_SHIPMENT_UPDATE_SHIPMENT_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_UPDATE_SHIPMENT_FAILURE,
    PACK_AND_SHIP_SHIPMENT_DELETE_SHIPMENT,
    PACK_AND_SHIP_SHIPMENT_DELETE_SHIPMENT_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_DELETE_SHIPMENT_FAILURE,
    PACK_AND_SHIP_SHIPMENT_COMPLETE_SHIPMENT,
    PACK_AND_SHIP_SHIPMENT_COMPLETE_SHIPMENT_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_COMPLETE_SHIPMENT_FAILURE,

    PACK_AND_SHIP_SHIPMENT_GEN_PACKING_LIST,
    PACK_AND_SHIP_SHIPMENT_GEN_PACKING_LIST_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_GEN_PACKING_LIST_FAILURE,
    PACK_AND_SHIP_SHIPMENT_EXPORT_TO_FEDEX,
    PACK_AND_SHIP_SHIPMENT_EXPORT_TO_FEDEX_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_EXPORT_TO_FEDEX_FAILURE,
    PACK_AND_SHIP_SHIPMENT_CALCULATE_VOLUME,
    PACK_AND_SHIP_SHIPMENT_CALCULATE_VOLUME_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_CALCULATE_VOLUME_FAILURE,
    PACK_AND_SHIP_SHIPMENT_GET_BOL_NUMBER,
    PACK_AND_SHIP_SHIPMENT_GET_BOL_NUMBER_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_GET_BOL_NUMBER_FAILURE,

    PACK_AND_SHIP_SHIPMENT_PRINT_CONTENT_LABELS_ALL,
    PACK_AND_SHIP_SHIPMENT_PRINT_CONTENT_LABELS_ALL_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_PRINT_CONTENT_LABELS_ALL_FAILURE,
    PACK_AND_SHIP_SHIPMENT_PRINT_PACKING_LABELS_ALL,
    PACK_AND_SHIP_SHIPMENT_PRINT_PACKING_LABELS_ALL_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_PRINT_PACKING_LABELS_ALL_FAILURE,
    PACK_AND_SHIP_SHIPMENT_PRINT_PACKING_LABELS_FOR_SELECTED_PKGS,
    PACK_AND_SHIP_SHIPMENT_PRINT_PACKING_LABELS_FOR_SELECTED_PKGS_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_PRINT_PACKING_LABELS_FOR_SELECTED_PKGS_FAILURE,

    PACK_AND_SHIP_SHIPMENT_UPDATE_ORDER_BOX_TRACKING_NUMBER,
    PACK_AND_SHIP_SHIPMENT_UPDATE_ORDER_BOX_TRACKING_NUMBER_SUCCESS,
    PACK_AND_SHIP_SHIPMENT_UPDATE_ORDER_BOX_TRACKING_NUMBER_FAILURE


} from '../../constants/ActionTypes';

// import ODataParams from '../../constants/params/oDataParams';
// import { IMultiPackOrder } from 'src/constants/PackAndShip/packAndShipOrder';
import { IAsn } from '../../constants/edidb';
import { IShipOrderInSelected } from 'src/constants/PackAndShip/packAndShipShipment';
import ODataParams from 'src/constants/params/oDataParams';

export const packAndShipShipmentAsnGetOne = (asnId: number) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_ASN_GET_ONE,
        payload: asnId
    };    
}

export const packAndShipShipmentAsnGetOneSuccess = (asn: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_ASN_GET_ONE_SUCCESS,
        payload: asn.data
    };    
}

export const packAndShipShipmentAsnGetOneFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_ASN_GET_ONE_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentPackageLevelsGetDistinct = () => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_PACKAGE_LEVELS_GET_DISTINCT,
    };    
}

export const packAndShipShipmentPackageLevelsGetDistinctSuccess = (resp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_PACKAGE_LEVELS_GET_DISTINCT_SUCCESS,
        payload: resp
    };    
}

export const packAndShipShipmentPackageLevelsGetDistinctFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_PACKAGE_LEVELS_GET_DISTINCT_FAILURE,
        payload: error
    };
};

// export const packAndShipShipmentOrderReadySummaryGetAll = (params: { filterByPartner: boolean, TP_PartID: string }) => { 
export const packAndShipShipmentOrderReadySummaryGetAll = (params: { filterByPartner: boolean, TP_PartID: string, oDataParams: ODataParams }) => { 
    return {
        type: PACK_AND_SHIP_SHIPMENT_ORDER_READY_SUMMARY_GET_ALL,
        payload: params
    };
};

export const packAndShipShipmentOrderReadySummaryGetAllSuccess = (resp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_ORDER_READY_SUMMARY_GET_ALL_SUCCESS,
        payload: resp
    };
};

export const packAndShipShipmentOrderReadySummaryGetAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_ORDER_READY_SUMMARY_GET_ALL_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentOrderReadyDetailGetAll = (params: { filterByPartner: boolean, TP_PartID: string, oDataParams: ODataParams }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_ORDER_READY_DETAIL_GET_ALL,
        payload: params
    };
};

export const packAndShipShipmentOrderReadyDetailGetAllSuccess = (resp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_ORDER_READY_DETAIL_GET_ALL_SUCCESS,
        payload: resp
    };
};

export const packAndShipShipmentOrderReadyDetailGetAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_ORDER_READY_DETAIL_GET_ALL_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentOrderInShipmentSummaryGetAll = (params: { asnId: string, oDataParams: ODataParams }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_ORDER_IN_SHIPMENT_SUMMARY_GET_ALL,
        payload: params
    };
};

export const packAndShipShipmentOrderInShipmentSummaryGetAllSuccess = (resp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_ORDER_IN_SHIPMENT_SUMMARY_GET_ALL_SUCCESS,
        payload: resp
    };
};

export const packAndShipShipmentOrderInShipmentSummaryGetAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_ORDER_IN_SHIPMENT_SUMMARY_GET_ALL_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentOrderInShipmentDetailGetAll = (params: { asnId: string, oDataParams: ODataParams }) => { 
    return {
        type: PACK_AND_SHIP_SHIPMENT_ORDER_IN_SHIPMENT_DETAIL_GET_ALL,
        payload: params
    };
};

export const packAndShipShipmentOrderInShipmentDetailGetAllSuccess = (resp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_ORDER_IN_SHIPMENT_DETAIL_GET_ALL_SUCCESS,
        payload: resp
    };
};

export const packAndShipShipmentOrderInShipmentDetailGetAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_ORDER_IN_SHIPMENT_DETAIL_GET_ALL_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentMoveOrdersToShipped = (params: { asnId: number, orderIdList: number[] }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_MOVE_ORDERS_TO_SHIPPED,
        payload: params
    };
};

export const packAndShipShipmentMoveOrdersToShippedSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_MOVE_ORDERS_TO_SHIPPED_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentMoveOrdersToShippedFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_MOVE_ORDERS_TO_SHIPPED_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentMoveOrdersToReady = (params: { asnId: number, orderIdList: number[] }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_MOVE_ORDERS_TO_READY,
        payload: params
    };
};

export const packAndShipShipmentMoveOrdersToReadySuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_MOVE_ORDERS_TO_READY_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentMoveOrdersToReadyFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_MOVE_ORDERS_TO_READY_FAILURE,
        payload: error
    };
};



export const packAndShipShipmentUpdateShipment = (params: { asn: IAsn }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_UPDATE_SHIPMENT,
        payload: params
    };
};

export const packAndShipShipmentUpdateShipmentSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_UPDATE_SHIPMENT_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentUpdateShipmentFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_UPDATE_SHIPMENT_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentDeleteShipment = (params: { asnId: number }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_DELETE_SHIPMENT,
        payload: params
    };
};

export const packAndShipShipmentDeleteShipmentSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_DELETE_SHIPMENT_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentDeleteShipmentFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_DELETE_SHIPMENT_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentCompleteShipment = (params: { asn: IAsn }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_COMPLETE_SHIPMENT,
        payload: params
    };
};

export const packAndShipShipmentCompleteShipmentSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_COMPLETE_SHIPMENT_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentCompleteShipmentFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_COMPLETE_SHIPMENT_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentGenPackingList = (params: { asnId: number }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_GEN_PACKING_LIST,
        payload: params
    };
};

export const packAndShipShipmentGenPackingListSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_GEN_PACKING_LIST_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentGenPackingListFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_GEN_PACKING_LIST_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentExportToFedex = (params: { DorI: string, startingAsnId: number, endingAsnId: number }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_EXPORT_TO_FEDEX,
        payload: params
    };
};

export const packAndShipShipmentExportToFedexSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_EXPORT_TO_FEDEX_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentExportToFedexFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_EXPORT_TO_FEDEX_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentCalculateVolume = (params: { asnId: number }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_CALCULATE_VOLUME,
        payload: params
    };
};

export const packAndShipShipmentCalculateVolumeSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_CALCULATE_VOLUME_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentCalculateVolumeFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_CALCULATE_VOLUME_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentGetBolNo = (params: { }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_GET_BOL_NUMBER,
        payload: params
    };
};

export const packAndShipShipmentGetBolNoSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_GET_BOL_NUMBER_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentGetBolNoFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_GET_BOL_NUMBER_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentPrintContentLabelsAll = (params: { asnId: number }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_PRINT_CONTENT_LABELS_ALL,
        payload: params
    };
};

export const packAndShipShipmentPrintContentLabelsAllSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_PRINT_CONTENT_LABELS_ALL_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentPrintContentLabelsAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_PRINT_CONTENT_LABELS_ALL_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentPrintPackingLabelsAll = (params: { asnId: number, printLevel: number }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_PRINT_PACKING_LABELS_ALL,
        payload: params
    };
};

export const packAndShipShipmentPrintPackingLabelsAllSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_PRINT_PACKING_LABELS_ALL_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentPrintPackingLabelsAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_PRINT_PACKING_LABELS_ALL_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentPrintPackingLabelsForSelectedPackages = (params: { asnId: number, ordersInSelectedList: IShipOrderInSelected[] }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_PRINT_PACKING_LABELS_FOR_SELECTED_PKGS,
        payload: params
    };
};

export const packAndShipShipmentPrintPackingLabelsForSelectedPackagesSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_PRINT_PACKING_LABELS_FOR_SELECTED_PKGS_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentPrintPackingLabelsForSelectedPackagesFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_PRINT_PACKING_LABELS_FOR_SELECTED_PKGS_FAILURE,
        payload: error
    };
};

export const packAndShipShipmentUpdateOrderBoxTrackingNumber = (params: { boxId: number, trackingNumber: string }) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_UPDATE_ORDER_BOX_TRACKING_NUMBER,
        payload: params
    };
};

export const packAndShipShipmentUpdateOrderBoxTrackingNumberSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_UPDATE_ORDER_BOX_TRACKING_NUMBER_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipShipmentUpdateOrderBoxTrackingNumberFailure = (error) => {
    return {
        type: PACK_AND_SHIP_SHIPMENT_UPDATE_ORDER_BOX_TRACKING_NUMBER_FAILURE,
        payload: error
    };
};
