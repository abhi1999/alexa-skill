import {
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_ALL,
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_ALL_SUCCESS,
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_ALL_FAILURE,    
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_ALL_LEVELS,
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_ALL_LEVELS_FAILURE,
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_0,
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_0_SUCCESS,
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_0_FAILURE,
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_1,
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_1_SUCCESS,
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_1_FAILURE,
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_2,
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_2_SUCCESS,
    PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_2_FAILURE,
    PACK_AND_SHIP_MULTI_LEVEL_RESET_ALL,
    PACK_AND_SHIP_MULTI_LEVEL_RESET_ALL_SUCCESS,
    PACK_AND_SHIP_MULTI_LEVEL_RESET_ALL_FAILURE,

    PACK_AND_SHIP_MULTI_LEVEL_QUICK_PACK_PKG_TYPE,
    PACK_AND_SHIP_MULTI_LEVEL_QUICK_PACK_PKG_TYPE_SUCCESS,
    PACK_AND_SHIP_MULTI_LEVEL_QUICK_PACK_PKG_TYPE_FAILURE,
    PACK_AND_SHIP_MULTI_LEVEL_PACK_ALL_PKG_TYPE_IN_ONE,
    PACK_AND_SHIP_MULTI_LEVEL_PACK_ALL_PKG_TYPE_IN_ONE_SUCCESS,
    PACK_AND_SHIP_MULTI_LEVEL_PACK_ALL_PKG_TYPE_IN_ONE_FAILURE,
    PACK_AND_SHIP_MULTI_LEVEL_PACK_SELECTED_PKG_IDS_IN_ONE,
    PACK_AND_SHIP_MULTI_LEVEL_PACK_SELECTED_PKG_IDS_IN_ONE_SUCCESS,
    PACK_AND_SHIP_MULTI_LEVEL_PACK_SELECTED_PKG_IDS_IN_ONE_FAILURE,
    PACK_AND_SHIP_MULTI_LEVEL_PACK_SELECTED_PKG_IDS_IN_SPEC_CONTAINER,
    PACK_AND_SHIP_MULTI_LEVEL_PACK_SELECTED_PKG_IDS_IN_SPEC_CONTAINER_SUCCESS,
    PACK_AND_SHIP_MULTI_LEVEL_PACK_SELECTED_PKG_IDS_IN_SPEC_CONTAINER_FAILURE,
    PACK_AND_SHIP_MULTI_LEVEL_UN_PACK_SELECTED_PKG_IDS,
    PACK_AND_SHIP_MULTI_LEVEL_UN_PACK_SELECTED_PKG_IDS_SUCCESS,
    PACK_AND_SHIP_MULTI_LEVEL_UN_PACK_SELECTED_PKG_IDS_FAILURE,


} from '../../constants/ActionTypes';

import ODataParams from '../../constants/params/oDataParams';
import { IMultiPackOrder } from 'src/constants/PackAndShip/packAndShipOrder';

export const packAndShipMultiLevelOrderLineItemsPackedGetAll = (params: {orderId: number, showAll: boolean}) => { 
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_ALL,
        payload: params
    };
};

export const packAndShipMultiLevelOrderLineItemsPackedGetAllSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_ALL_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipMultiLevelOrderLineItemsPackedGetAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_ALL_FAILURE,
        payload: error
    };
};

export const packAndShipMultiLevelOrderLineItemsPackedGetAllLevels = (params: {orderId: number, showAll: boolean, isLevel0Loaded}) => { 
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_ALL_LEVELS,
        payload: params
    };
};

export const packAndShipMultiLevelOrderLineItemsPackedGetAllLevelsFailure = (error) => { 
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_ALL_LEVELS_FAILURE,
        payload: error
    };
};

export const packAndShipMultiLevelOrderLineItemsPackedGetLevel0 = (params: {orderId: number, showAll: boolean}) => { 
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_0,
        payload: params
    };
};

export const packAndShipMultiLevelOrderLineItemsPackedGetLevel0Success = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_0_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipMultiLevelOrderLineItemsPackedGetLevel0Failure = (error) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_0_FAILURE,
        payload: error
    };
};

export const packAndShipMultiLevelOrderLineItemsPackedGetLevel1 = (params: {orderId: number, showAll: boolean}) => { 
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_1,
        payload: params
    };
};

export const packAndShipMultiLevelOrderLineItemsPackedGetLevel1Success = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_1_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipMultiLevelOrderLineItemsPackedGetLevel1Failure = (error) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_1_FAILURE,
        payload: error
    };
};

export const packAndShipMultiLevelOrderLineItemsPackedGetLevel2 = (params: { orderId: number, showAll: boolean }) => { 
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_2,
        payload: params
    };
};

export const packAndShipMultiLevelOrderLineItemsPackedGetLevel2Success = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_2_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipMultiLevelOrderLineItemsPackedGetLevel2Failure = (error) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_ORDER_LINE_ITEMS_PACKED_GET_LEVEL_2_FAILURE,
        payload: error
    };
};

export const packAndShipMultiLevelResetAll = (params: { orderId: number }) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_RESET_ALL,
        payload: params
    };
};

export const packAndShipMultiLevelResetAllSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_RESET_ALL_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipMultiLevelResetAllFailure = (error) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_RESET_ALL_FAILURE,
        payload: error
    };
};

export const packAndShipMultiLevelQuickPackPkgType = (params: { packOrder: IMultiPackOrder,  orderId: number, level: number, allInOne: boolean }) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_QUICK_PACK_PKG_TYPE,
        payload: params
    };
};

export const packAndShipMultiLevelQuickPackPkgTypeSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_QUICK_PACK_PKG_TYPE_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipMultiLevelQuickPackPkgTypeFailure = (error) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_QUICK_PACK_PKG_TYPE_FAILURE,
        payload: error
    };
};

export const packAndShipMultiLevelPackAllPkgTypeInOne = (params: { packOrder: IMultiPackOrder,  orderId: number, level: number, allInOne: boolean }) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_PACK_ALL_PKG_TYPE_IN_ONE,
        payload: params
    };
};

export const packAndShipMultiLevelPackAllPkgTypeInOneSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_PACK_ALL_PKG_TYPE_IN_ONE_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipMultiLevelPackAllPkgTypeInOneFailure = (error) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_PACK_ALL_PKG_TYPE_IN_ONE_FAILURE,
        payload: error
    };
};

export const packAndShipMultiLevelPackSelectedPkgIdsInOne = (params: { packOrders: IMultiPackOrder[],  orderId: number, level: number, boxId: number }) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_PACK_SELECTED_PKG_IDS_IN_ONE,
        payload: params
    };
};

export const packAndShipMultiLevelPackSelectedPkgIdsInOneSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_PACK_SELECTED_PKG_IDS_IN_ONE_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipMultiLevelPackSelectedPkgIdsInOneFailure = (error) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_PACK_SELECTED_PKG_IDS_IN_ONE_FAILURE,
        payload: error
    };
};

export const packAndShipMultiLevelPackSelectedPkgIdsInSpecContainer = (params: { packOrders: IMultiPackOrder[],  orderId: number, level: number, boxId: number }) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_PACK_SELECTED_PKG_IDS_IN_SPEC_CONTAINER,
        payload: params
    };
};

export const packAndShipMultiLevelPackSelectedPkgIdsInSpecContainerSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_PACK_SELECTED_PKG_IDS_IN_SPEC_CONTAINER_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipMultiLevelPackSelectedPkgIdsInSpecContainerFailure = (error) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_PACK_SELECTED_PKG_IDS_IN_SPEC_CONTAINER_FAILURE,
        payload: error
    };
};

export const packAndShipMultiLevelUnPackSelectedPkgIds = (params: { boxIdList: number[], orderId: number, level: number }) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_UN_PACK_SELECTED_PKG_IDS,
        payload: params
    };
};

export const packAndShipMultiLevelUnPackSelectedPkgIdsSuccess = (apiResp: any) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_UN_PACK_SELECTED_PKG_IDS_SUCCESS,
        payload: apiResp
    };
};

export const packAndShipMultiLevelUnPackSelectedPkgIdsFailure = (error) => {
    return {
        type: PACK_AND_SHIP_MULTI_LEVEL_UN_PACK_SELECTED_PKG_IDS_FAILURE,
        payload: error
    };
};

