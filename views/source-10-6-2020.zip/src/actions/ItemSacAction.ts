import { 
    ITEM_GETSAC_ALL,
    ITEM_GETSAC_FAILURE,
    ITEM_GETSAC_SUCCESS,
    ITEM_DELETESAC,
    ITEM_DELETESAC_FAILURE,
    ITEM_DELETESAC_SUCCESS,
    ITEM_UPDATESAC,
    ITEM_UPDATESAC_FAILURE,
    ITEM_UPDATESAC_SUCCESS,
    ITEM_ADDSAC,
    ITEM_ADDSAC_FAILURE,
    ITEM_ADDSAC_SUCCESS
} from '../constants/ActionTypes';
import { IAPIsacXRef } from "../constants/edidb";
import ODataParams from '../constants/params/oDataParams';

export const itemGetSacAll = (params:ODataParams) => {
    return {
        type: ITEM_GETSAC_ALL,
        payload: params
    };
};

export const itemGetSacAllSuccess = (odataResp:any) => {
    return {
        type: ITEM_GETSAC_SUCCESS,
        payload: odataResp
    }
};

export const itemGetSacAllFailure = (error) => {
    return {
        type: ITEM_GETSAC_FAILURE,
        payload: error
    }
};

export const itemUpdateSac = (xrefOrig:IAPIsacXRef, xrefNew:IAPIsacXRef) => {
    const pld : IAPIsacXRef[] = [];
    pld.push(xrefOrig);
    pld.push(xrefNew);
    return {
        type: ITEM_UPDATESAC,
        payload:pld
    };
};

export const itemUpdateSacSuccess = (xref:IAPIsacXRef) => {
    return {
        type: ITEM_UPDATESAC_SUCCESS,
        payload: xref
    }
};

export const itemUpdateSacFailure = (error) => {
    return {
        type: ITEM_UPDATESAC_FAILURE,
        payload: error
    }
};

export const itemDeleteSac = (xref:IAPIsacXRef) => {
    return {
        type: ITEM_DELETESAC,
        payload: xref
    };
};

export const itemDeleteSacSuccess = (xref:IAPIsacXRef) => {
    return {
        type: ITEM_DELETESAC_SUCCESS,
        payload: xref
    }
};

export const itemDeleteSacFailure = (error) => {
    return {
        type: ITEM_DELETESAC_FAILURE,
        payload: error
    }
};

export const itemAddSac = (xref:IAPIsacXRef) => {
    return {
        type: ITEM_ADDSAC,
        payload: xref
    };
};

export const itemAddSacSuccess = (xref:IAPIsacXRef) => {
    return {
        type: ITEM_ADDSAC_SUCCESS,
        payload: xref
    }
};

export const itemAddSacFailure = (error) => {
    return {
        type: ITEM_ADDSAC_FAILURE,
        payload: error
    }
};