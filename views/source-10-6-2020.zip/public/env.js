window.env = {
  VP4API_URL : 'https://2k12develop1.datamasons.com:5001',
  WSAPI_URL : 'https://2k12develop1.datamasons.com',
  TLEAPI_URL : 'https://2k12develop1.datamasons.com:5002',
  TLEUI_URL : 'https://2k12develop1.datamasons.com:5003',
  API_TIMEOUT_MINUTES: 5,
  VERSION: '4239.2019.5.20',
  LOCALE: 'en',
  UIDEBUG: true,
  MFA_ENABLED: false,
  LOGOUT_TIMEOUT_MINUTES: 20,
  UI_LOGGER_ENABLED:false,
  UI_LOGER_APP_ID:"j91rut/vp5-dev"
}
