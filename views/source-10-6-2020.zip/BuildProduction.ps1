cls
Write-Host -ForegroundColor Green  'Delete existing Build'
if (Test-Path -Path .\build\assets) { Remove-Item -Recurse -Force -Path .\build\assets }
if (Test-Path -Path .\build\static) { Remove-Item -Recurse -Force -Path .\build\static }
if (Test-Path -Path .\build) { Remove-Item -Force .\build\* }
Write-Host -ForegroundColor Gray 'Cleanup complete' 

Write-Host -ForegroundColor Gray 'Updating translations'
Start-Process C:\work\Critical\C#\VP4C_WPF\InnoTranslate\bin\Release\InnoTranslate.exe -argumentList "/log=.\translatelog.txt /react=.\src\languages\entries\en-US.ts" -Wait 
Get-Content -path .\translatelog.txt

# Update the version string to today's date
$content = [System.IO.File]::ReadAllLines('.\public\env.js')
for ($i=0; $i -lt $content.Length; $i++) {
    if ($content[$i].Contains("VERSION")) {
        # $content[$i] = "    VERSION : '" + (Get-Date -UFormat "%Y.%m.%d.%H") + "',"
		$content[$i] = "    VERSION : 4239.2019.5.18,"
    }
}
[System.IO.File]::WriteAllLines('.\public\env.js', $content)

#
# Get the version string from env.js and set it on the <link> statement to force
# the browser to get a fresh copy when the parameter changes
#
$version = 'unk'
$contentENV = [System.IO.File]::ReadAllLines('.\public\env.js')
for ($i=0; $i -lt $content.Length; $i++) {
    if ($contentENV[$i].Contains("VERSION")) {
        $firsta = $contentENV[$i].IndexOf("'")
        $lasta = $contentENV[$i].LastIndexOf("'");
        $version = $contentENV[$i].Substring($firsta + 1, $lasta - $firsta - 1)
    }
}

$contentInx = [System.IO.File]::ReadAllLines('.\public\index.html')
for ($i=0; $i -lt $contentInx.Length; $i++) {
    if ($contentInx[$i].Contains("env.js")) {
        $contentInx[$i] = '<script src="%PUBLIC_URL%/env.js?v=' + $version + '"></script>'
    }
}
[System.IO.File]::WriteAllLines('.\public\index.html', $contentInx)

Write-Host -ForegroundColor Green 'Building...'
Start-Process npm -ArgumentList "run build" -Wait -RedirectStandardError .\production.err -RedirectStandardOutput .\production.txt -NoNewWindow
Get-Content -path .\production.err
Get-Content -path .\production.txt
Read-Host 'Build Complete, press Enter to continue�' | Out-Null

Write-Host -ForegroundColor Green 'Compressing build to production.zip...'

Remove-Item production.zip
Compress-Archive -Path .\build\static -DestinationPath production.zip
Compress-Archive -Path .\build\assets -DestinationPath production.zip -Update

Compress-Archive -Path .\build\favicon.ico -DestinationPath production.zip -Update
Compress-Archive -Path .\build\index.html -DestinationPath production.zip -Update
Compress-Archive -Path .\build\manifest.json -DestinationPath production.zip -Update
Compress-Archive -Path .\build\web.config -DestinationPath production.zip -Update
Read-Host 'Created production.zip, press Enter to continue...' | Out-Null